/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "standalone",
  // TODO: 設定解除
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
    dirs: ["app", "components", "features", "hooks", "types"],
  },
  // https://nextjs.org/docs/app/api-reference/next-config-js/devIndicators#appisrstatus-static-indicator
  devIndicators: {
    appIsrStatus: false,
  },
  serverExternalPackages: ["@azure/storage-blob", "undici"],
};

module.exports = nextConfig;
