npm install --force
npm run build

# https://zenn.dev/team_zenn/articles/nextjs-standalone-mode-cloudrun#%E5%BF%85%E8%A6%81%E3%81%AA%E3%83%95%E3%82%A1%E3%82%A4%E3%83%AB%E3%82%92%E6%98%8E%E7%A4%BA%E7%9A%84%E3%81%AB%E3%82%B3%E3%83%94%E3%83%BC%E3%81%99%E3%82%8B
# https://nextjs.org/docs/pages/api-reference/next-config-js/output#automatically-copying-traced-files
cp -r public .next/standalone/ && cp -r .next/static .next/standalone/.next/
