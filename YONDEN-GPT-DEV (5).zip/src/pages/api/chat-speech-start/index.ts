import {
  AudioConfig,
  AudioInputStream,
  AutoDetectSourceLanguageConfig,
  SpeechConfig,
  SpeechRecognizer,
} from "microsoft-cognitiveservices-speech-sdk";
import { NextApiRequest } from "next";
import { Server } from "socket.io";
import * as v from "valibot";
import { GetSpeechToken } from "@/features/chat-view/chat-input/speech/speech-service";
import { NextApiResponseWithSocket } from "@/types/socket";

// Socket.IO公式のカスタムサーバを使った方法はstandaloneビルドとの相性が悪そう
// (カスタムサーバをstandaloneビルドの server.js とどう組み合わせればよいか不明)
// なので以下の別の方法を使用:
// https://www.zenryoku-kun.com/new-post/nextjs-socketio

/** Next.jsサーバに合わせて音声認識のWebSocketサーバを起動するAPI */
export default function SocketHandler(
  req: NextApiRequest,
  res: NextApiResponseWithSocket,
) {
  const socket = res.socket;
  if (!socket?.server) {
    console.error("Socket is not available");
    res.status(500).end(`{"error":"error"}`);
  }
  if (socket.server.io) {
    res.status(200).end(`{}`);
  } else {
    console.log("🎤 WebSocketサーバ起動");
    const io = new Server(res.socket.server, { addTrailingSlash: false });
    res.socket.server.io = io;

    io.on("connection", (socket) => {
      console.log("🎤 WebSocket接続");
      let recognizer: SpeechRecognizer | null = null;

      socket.on("startRecognition", async () => {
        let speechConfig: SpeechConfig;
        const privateEndpointHost =
          process.env.AZURE_SPEECH_PRIVATE_ENDPOINT_HOST;
        const privateEndpointKey =
          process.env.AZURE_SPEECH_PRIVATE_ENDPOINT_KEY;
        if (privateEndpointHost && privateEndpointKey) {
          speechConfig = SpeechConfig.fromEndpoint(
            new URL(
              `wss://${privateEndpointHost}/stt/speech/recognition/conversation/cognitiveservices/v1`,
            ),
            privateEndpointKey,
          );
        } else {
          const token = await GetSpeechToken();
          speechConfig = SpeechConfig.fromAuthorizationToken(
            token.token,
            token.region,
          );
        }

        // 言語設定
        const autoDetectSourceLanguageConfig =
          AutoDetectSourceLanguageConfig.fromLanguages(["ja-JP", "en-US"]);

        // WebSocket 経由で音声を受け取るための設定
        const pushStream = AudioInputStream.createPushStream();
        const audioConfig = AudioConfig.fromStreamInput(pushStream);

        recognizer = SpeechRecognizer.FromConfig(
          speechConfig,
          autoDetectSourceLanguageConfig,
          audioConfig,
        );

        recognizer.recognizing = (s, e) => {
          // console.log("recognizing", e.result);
          socket.emit("recognizing", {
            offset: e.result.offset,
            text: e.result.text,
          });
        };

        recognizer.recognized = (s, e) => {
          // console.log("recognized", e.result);
          socket.emit("recognized", {
            offset: e.result.offset,
            text: e.result.text,
          });
        };

        recognizer.canceled = (s, e) => {
          console.error("🎤 canceled", e);
          socket.emit("canceled");
        };

        recognizer.startContinuousRecognitionAsync();

        socket.on("audioData", (unsafeObj) => {
          try {
            const obj = v.parse(AudioDataMessageSchema, unsafeObj);
            const uint8Array = new Uint8Array(obj.data);
            const buffer = uint8Array.buffer;

            pushStream.write(buffer);
          } catch (error) {
            console.error("audioData error", error);
          }
        });

        socket.emit("startRecognitionOk");
      });

      socket.on("stopRecognition", () => {
        if (recognizer) {
          recognizer.stopContinuousRecognitionAsync();
          recognizer = null;
        }
      });

      socket.on("disconnect", () => {
        if (recognizer) {
          recognizer.stopContinuousRecognitionAsync();
          recognizer = null;
        }
      });
    });
  }
  res.status(200).end(`{}`);
}

const AudioDataMessageSchema = v.object({
  data: v.instance(Buffer),
});
