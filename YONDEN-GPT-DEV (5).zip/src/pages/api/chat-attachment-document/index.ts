import { NextApiRequest, NextApiResponse } from "next";
import { chatAttachmentDocumentAPIGETHandler } from "@/features/chat-view/chat-services/attachment/attachment-document-api";
import {
  getDefaultAPIRouteForbiddenErrorResponse,
  isDocumentDownloadAllowed,
} from "@/features/common/api-helpers";

// https://github.com/vercel/next.js/issues/47793
// https://github.com/vercel/next.js/pull/56797/files
// middleware ではリクエストヘッダーが取得でき、 x-forwarded-for を使ったIPアドレス取得が可能と思いきや
// 以上プルリクエスト内の実装にある通り、 x-forwarded-for への IPアドレス自動セットは、クライアントに既に x-forwarded-for がセットされていない場合に発動する
// 結論 → API Routes 使う

// 注意: Route Handler だとストリーミング処理に様々な最適化がかかっている一方、
// API Routes ではシンプルに Node.js の `pipe()` に渡すだけとなっているため、
// 基本的に大容量のストリーミングには Route Handler の使用が推奨されている
// (デフォルトの responseLimit が4MBな理由の1つかも)

// 上記により、IPアドレス制限が必要かつ常にクリックしない限りDLされない
// ドキュメント限定のAPIを用意

export const config = {
  api: {
    responseLimit: false,
  },
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse,
) {
  // GET メソッド以外は許可しない
  if (req.method !== "GET") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  // IPアドレス制限
  if (!isDocumentDownloadAllowed(req)) {
    return getDefaultAPIRouteForbiddenErrorResponse(
      res,
      "この環境からはアクセスできません。",
    );
  }

  return await chatAttachmentDocumentAPIGETHandler(req, res);
}
