import { NextApiRequest, NextApiResponse } from "next";
import { chatbotDocumentAPIGETHandler } from "@/features/chatbot-page/chatbot-document/chatbot-document-file-api";
import {
  getDefaultAPIRouteForbiddenErrorResponse,
  isDocumentDownloadAllowed,
} from "@/features/common/api-helpers";

// 注意: Route Handler だとストリーミング処理に様々な最適化がかかっている一方、
// API Routes ではシンプルに Node.js の `pipe()` に渡すだけとなっているため、
// 基本的に大容量のストリーミングには Route Handler の使用が推奨されている
// (デフォルトの responseLimit が4MBな理由の1つかも)
export const config = {
  api: {
    responseLimit: false,
  },
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse,
) {
  // GET メソッド以外は許可しない
  if (req.method !== "GET") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  // IPアドレス制限
  if (!isDocumentDownloadAllowed(req)) {
    return getDefaultAPIRouteForbiddenErrorResponse(
      res,
      "この環境からはアクセスできません。",
    );
  }

  return await chatbotDocumentAPIGETHandler(req, res);
}
