import { snapshot } from "valtio";

type AnyFunction = (...args: unknown[]) => unknown;
type AnyArray = readonly unknown[];
type MutableArrays<T> = T extends AnyFunction ? T :
  T extends AnyArray
    ? { -readonly [K in keyof T]: MutableArrays<T[K]> }
    : { [K in keyof T]: MutableArrays<T[K]> }; // prettier-ignore
type Snapshot<T extends object> = ReturnType<typeof snapshot<T>>;

// valtio の useSnapshot の返り値がデフォルトでは readonly なのを mutable にしている
// https://github.com/pmndrs/valtio/issues/327

// 現状これを外してもエラーになる箇所はないが、一先ずこのままにしておく
declare module "valtio" {
  function useSnapshot<T extends object>(p: T): MutableArrays<Snapshot<T>>;
}
