/* eslint-disable @typescript-eslint/no-empty-object-type */

// https://next-auth.js.org/getting-started/typescript#module-augmentation

declare module "next-auth" {
  interface Session {
    user: UserData;
  }

  // TODO: session.user と token の使い分け
  interface Token extends UserData {}

  interface User extends UserData {}
}

export type UserData = {
  /** ユーザID (従業員番号) */
  id: string;
  /** 名前 */
  name?: string;
  /** メールアドレス */
  email?: string;
  /** 所属組織名 */
  departmentName: string;
  /** このセッションで注意事項に承認済みかどうか */
  isApproved: boolean;
};

export type UserModel = Required<UserData>;
