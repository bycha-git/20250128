/* eslint-disable @typescript-eslint/unbound-method */
import { getIconCollections, iconsPlugin } from "@egoist/tailwindcss-icons";
import tailwindcssTypography from "@tailwindcss/typography";
import plugin from "tailwindcss/plugin";
import tailwindcssAnimate from "tailwindcss-animate";

/** @type {import('tailwindcss').Config["darkMode"]} */
export const darkMode = ["class"];
/** @type {import('tailwindcss').Config["content"]} */
export const content = [
  "./features/**/*.{ts,tsx}",
  "./figma/**/*.{ts,tsx}",
  "./components/**/*.{ts,tsx}",
  "./app/**/*.{ts,tsx}",
  "./src/**/*.{ts,tsx}",
];
/** @type {import('tailwindcss').Config["theme"]} */
export const theme = {
  container: {
    center: true,
    screens: {},
  },
  extend: {
    colors: {
      border: "hsl(var(--border))",
      input: "hsl(var(--input))",
      ring: "hsl(var(--ring))",
      background: "hsl(var(--background))",
      foreground: "hsl(var(--foreground))",
      primary: {
        DEFAULT: "hsl(var(--primary))",
        foreground: "hsl(var(--primary-foreground))",
      },
      secondary: {
        DEFAULT: "hsl(var(--secondary))",
        foreground: "hsl(var(--secondary-foreground))",
      },
      destructive: {
        DEFAULT: "hsl(var(--destructive))",
        foreground: "hsl(var(--destructive-foreground))",
      },
      muted: {
        DEFAULT: "hsl(var(--muted))",
        foreground: "hsl(var(--muted-foreground))",
      },
      accent: {
        DEFAULT: "hsl(var(--accent))",
        foreground: "hsl(var(--accent-foreground))",
      },
      popover: {
        DEFAULT: "hsl(var(--popover))",
        foreground: "hsl(var(--popover-foreground))",
      },
      card: {
        DEFAULT: "hsl(var(--card))",
        foreground: "hsl(var(--card-foreground))",
      },
      // from Figma/Anima
      "black-01": "var(--black-01)",
      "blue-01": "var(--blue-01)",
      "blue-transparency": "var(--blue-transparency)",
      "chatbot-role-organization": "var(--chatbot-role-organization)",
      "chatbot-role-user": "var(--chatbot-role-user)",
      "chatbot-strictness-default": "var(--chatbot-strictness-default)",
      "chatbot-strictness-high": "var(--chatbot-strictness-high)",
      "chatbot-strictness-low": "var(--chatbot-strictness-low)",
      "gray-01": "var(--gray-01)",
      "gray-02": "var(--gray-02)",
      "gray-03": "var(--gray-03)",
      "gray-hover": "var(--gray-hover)",
      "green-01": "var(--green-01)",
      "green-transparency": "var(--green-transparency)",
      "home-style-balance": "var(--home-style-balance)",
      "home-style-creative": "var(--home-style-creative)",
      "home-style-strict": "var(--home-style-strict)",
      "orange-01": "var(--orange-01)",
      "orange-02": "var(--orange-02)",
      "orange-03": "var(--orange-03)",
      "orange-hover": "var(--orange-hover)",
      "red-01": "var(--red-01)",
      "red-transparency": "var(--red-transparency)",
      "template-style-organization": "var(--template-style-organization)",
      "template-style-user": "var(--template-style-user)",
      "white-01": "var(--white-01)",
      "yellow-01": "var(--yellow-01)",
    },
    borderRadius: {
      lg: "var(--radius)",
      md: "calc(var(--radius) - 2px)",
      sm: "calc(var(--radius) - 4px)",
    },
    keyframes: {
      "accordion-down": {
        from: { height: 0 },
        to: { height: "var(--radix-accordion-content-height)" },
      },
      "accordion-up": {
        from: { height: "var(--radix-accordion-content-height)" },
        to: { height: 0 },
      },
    },
    animation: {
      "accordion-down": "accordion-down 0.2s ease-out",
      "accordion-up": "accordion-up 0.2s ease-out",
    },
    height: {
      screen: "100dvh",
    },
  },
};
/** @type {import('tailwindcss').Config["plugins"]} */
export const plugins = [
  tailwindcssAnimate,
  tailwindcssTypography,
  iconsPlugin({
    collections: getIconCollections([
      "bx",
      "heroicons-solid",
      "lucide",
      "majesticons",
      "material-symbols",
      "mdi",
      "ooui",
      "tabler",
      "tdesign",
    ]),
  }),
  plugin(({ addUtilities }) => {
    addUtilities({
      // https://coliss.com/articles/build-websites/operation/css/css-stretch-keyword.html
      // https://github.com/tailwindlabs/tailwindcss-intellisense/issues/227#issuecomment-1269592872
      ".w-stretch": {
        "@apply w-[-webkit-fill-available] w-[-moz-available] w-[stretch]": {},
      },

      // theme のほうが優先されるようなので
      // ".h-screen": {
      //   "@apply h-[100vh] h-[100dvh]": {},
      // },
    });
  }),
];
