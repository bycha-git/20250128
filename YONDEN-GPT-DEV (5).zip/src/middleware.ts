import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import { checkPathHrefMatch } from "./features/common/redirect-helpers";

const requireAuth: string[] = [
  "/unauthorized",
  "/api",
  "/chat",
  "/chatbot",
  "/prompttemplate",
  "/historysearch",
  "/approval-window",
];

export async function middleware(request: NextRequest) {
  const res = NextResponse.next();
  const pathname = request.nextUrl.pathname;

  if (requireAuth.some((href) => checkPathHrefMatch(pathname, href))) {
    const token = await getToken({
      req: request,
    });

    //check not logged in
    if (!token) {
      const url = new URL(`/`, request.url);
      return NextResponse.redirect(url);
    }
  }

  return res;
}

// - 認証に必要なため、 api/auth には適用しない
// - middleware を経由するとリクエストボディ全体がメモリに格納されるため、
//   リクエストボディのストリーミングが必要な場合は対象から外し、API側でセッションを検証する
//   https://github.com/vercel/next.js/issues/65563
export const config = {
  matcher: [
    "/unauthorized/:path*",
    "/api/chat-attachment:path*",
    "/api/chatbot-document-file:path*",
    "/chat:path*",
    "/chatbot:path*",
    "/prompttemplate:path*",
    "/historysearch:path*",
  ],
};
