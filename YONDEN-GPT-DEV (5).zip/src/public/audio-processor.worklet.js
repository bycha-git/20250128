/* eslint-disable unused-imports/no-unused-vars */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */

// バッファサイズ (Int16Array なので、バイト数を 2 で割る)
const BUFFER_SIZE = 8096 / 2; // 8KB

/**
 * 音声入力の処理スクリプト
 * @extends AudioWorkletProcessor
 */
class AudioProcessor extends AudioWorkletProcessor {
  /** @type {Int16Array} */
  buffer;
  /** @type {number} */
  bufferedSize = 0;

  constructor() {
    super();
    this.buffer = new Int16Array(BUFFER_SIZE);
  }

  /**
   * 音声処理
   * @param {Float32Array[][]} inputs Input audio buffers
   * @param {Float32Array[][]} outputs Output audio buffers
   * @param {Record<string, Float32Array>} parameters Audio parameters
   * @returns {boolean} Whether to continue processing
   */
  process(inputs, outputs, parameters) {
    const input = inputs[0][0];
    if (!input) return true;

    // 16kHz にダウンサンプリング
    const sampleRateRatio = sampleRate / 16000;
    const newLength = Math.round(input.length / sampleRateRatio);
    const downsampledBuffer = new Float32Array(newLength);

    for (let i = 0; i < newLength; i++) {
      const offset = Math.round(i * sampleRateRatio);
      downsampledBuffer[i] = input[offset];
    }

    // 16-bit PCM に変換
    const int16Buffer = new Int16Array(newLength);
    for (let i = 0; i < newLength; i++) {
      const s = Math.max(-1, Math.min(1, downsampledBuffer[i]));
      int16Buffer[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }

    // バッファが溜まったらメインスレッドに送信
    // (何もしないと 86 bytes ごとに送られたので……)
    if (this.bufferedSize + int16Buffer.length > BUFFER_SIZE) {
      const bufferToSend = this.buffer.slice(0, this.bufferedSize);
      this.port.postMessage(bufferToSend.buffer, [bufferToSend.buffer]);

      // バッファをリセット
      this.buffer = new Int16Array(Math.max(BUFFER_SIZE, int16Buffer.length));
      this.bufferedSize = 0;
    } else {
      this.buffer.set(int16Buffer, this.bufferedSize);
      this.bufferedSize += int16Buffer.length;
    }

    return true;
  }
}

registerProcessor("audio-processor", AudioProcessor);
