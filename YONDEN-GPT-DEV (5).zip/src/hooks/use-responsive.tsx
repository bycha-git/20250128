import { useMemo, useSyncExternalStore } from "react";
import { useMediaQuery } from "react-responsive";

/**
 * PC/モバイル間でJS側の処理を切り替える場合に用いるHooks
 *
 * - 現状だとこのHookを直接使った場合、画面上に一瞬 (0.7秒程度) デスクトップ版が表示されてしまう
 *   - `md:` でなく useResponsive で制御していて見た目に影響がありそうな箇所では、
 *     `dynamic()` で対策している ForDesktop, ForMobile を使うか
 *     コンポーネント側で `dynamic()` を使う必要がありそう
 */
export const useResponsive = () => {
  const isDesktopRaw = useMediaQuery({ minWidth: 768 });

  // Hydration Error 対策
  // https://github.com/yocontra/react-responsive/issues/162
  // この方法だと上記の「画面上に一瞬デスクトップ版が表示されてしまう」問題がある
  const isServer = useSyncExternalStore(
    emptySubscribe,
    () => false,
    () => true,
  );

  const isIOSSafari = useMemo(
    () => !isServer && checkIsIOSSafari(),
    [isServer],
  );

  const isDesktop = isServer ? true : isDesktopRaw;

  const value = useMemo(
    () => ({
      isDesktop,
      isMobile: !isDesktop,
      isIOSSafari,
    }),
    [isDesktop, isIOSSafari],
  );
  return value;
};

const emptySubscribe = () => () => {};

/** iOS Safari (またはその他の iOS WebView ブラウザ) であるかを判定 */
const checkIsIOSSafari = (): boolean => {
  return (
    [
      "iPad Simulator",
      "iPhone Simulator",
      "iPod Simulator",
      "iPad",
      "iPhone",
      "iPod",
    ].includes(navigator.platform) ||
    // iPad OS 13以降のデスクトップモード対応
    (navigator.userAgent.includes("Mac") && "ontouchend" in document)
  );
};
