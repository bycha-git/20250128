/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
// ↑ js で型指定するの大変なので

import { promises as fs, readFileSync } from "fs";
import { CosmosClient } from "@azure/cosmos";
import { v7 as uuidv7 } from "uuid";

// Azure Cosmos DB の設定 (なければ .env.local から読み込む)
const customEndpoint = "";
const customKey = "";
const customDatabaseId = "";

// デフォルトSQL
const DEFAULT_SELECT_SQL = "SELECT TOP 100 * FROM c ORDER BY c._ts DESC";

// 同時挿入件数 (max 100)。これ以上の件数は分割する
const BULK_UPSERT_COUNT = 20;

const dirname = new URL(".", import.meta.url).pathname;
const envLocalPath = dirname + "/../.env.local";
const envLocal = readFileSync(envLocalPath, "utf8");

const endpoint =
  customEndpoint ||
  process.env.AZURE_COSMOSDB_URI ||
  envLocal.match(/(?:^|\n)AZURE_COSMOSDB_URI=(.*)/)?.[1] ||
  "";
const key =
  customKey ||
  process.env.AZURE_COSMOSDB_KEY ||
  envLocal.match(/(?:^|\n)AZURE_COSMOSDB_KEY=(.*)/)?.[1] ||
  "";
const databaseId =
  customDatabaseId ||
  process.env.AZURE_COSMOSDB_DB_NAME ||
  envLocal.match(/(?:^|\n)AZURE_COSMOSDB_DB_NAME=(.*)/)?.[1] ||
  "";
const cosmosClient = new CosmosClient({ endpoint, key });

const dbCommandPrefix = process.env.DB_COMMAND_PREFIX || "node db.mjs";

const dateFormatterUtc = new Intl.DateTimeFormat("ja-JP", {
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  // devcontainer に locale 情報が入っていないからか、常に UTC になるので明示的に指定
  timeZone: "UTC",
});

/** ヘルプ表示 */
function showHelp() {
  console.log(
    `
使い方:
  # ヘルプを表示
  node db.mjs --help

  # コンテナリストを表示
  node db.mjs

  # コンテナ内のレコードをテーブルで表示
  # (デフォルトSQL: "${DEFAULT_SELECT_SQL}")
  # (table は省略可)
  node db.mjs <コンテナ名> select table
  node db.mjs <コンテナ名> select "<SELECT文またはWHERE文>" table

  # JSON で表示
  node db.mjs <コンテナ名> select json
  node db.mjs <コンテナ名> select "<SELECT文またはWHERE文>" json
  node db.mjs <コンテナ名> select "<SELECT文またはWHERE文>" json index=0,1,2

  # JSON をファイルに保存
  node db.mjs <コンテナ名> select json > <保存ファイルパス>
  node db.mjs <コンテナ名> select "<SELECT文またはWHERE文>" json > <保存ファイルパス>
  node db.mjs <コンテナ名> select "<SELECT文またはWHERE文>" json index=0,1,2 > <保存ファイルパス>

  # TSV (タブ区切り) をファイルに保存 (Excel貼り付け用, 改行は "\\n" で出力)
  node db.mjs <コンテナ名> select tsv > <保存ファイルパス>
  node db.mjs <コンテナ名> select "<SELECT文またはWHERE文>" tsv > <保存ファイルパス>
  node db.mjs <コンテナ名> select "<SELECT文またはWHERE文>" tsv index=0,1,2 > <保存ファイルパス>

  # テーブルに表示する列を追加
  # (列名リスト省略の場合、idとパーティションキーを表示)
  node db.mjs <コンテナ名> select "<SELECT文>" table [カンマ区切りの列名リスト]

  # コンテナ内でSELECT文を実行した結果から削除
  node db.mjs <コンテナ名> select "<SELECT文>" delete all
  node db.mjs <コンテナ名> select "<SELECT文>" delete index=0,1,2

  # コンテナ内のレコードを挿入/更新 (ファイル内容は配列または単体レコード)
  node db.mjs <コンテナ名> upsert <JSONファイルパス>
  # ※ 挿入時変換
  # 「<<ID>>」→ 自動生成IDに変換
  # 「<<ID1>>」「<<ID2>>」... → 自動生成IDに変換。同じ「ID1」は同じIDになる。
  # 「<<NOW>>」→ 現在日時に変換
  # 「<<NOW-1>>」「<<NOW+1>>」→ 指定した秒数ずらす

例:
  # config コンテナのレコードを表示
  node db.mjs config select

  # 条件絞り込み
  node db.mjs config select "select * from c where c.type = 'MODEL'"
  # または
  node db.mjs config select "where c.type = 'MODEL'"

  # テーブルの表示項目を増やす
  node db.mjs config select "where c.type = 'MODEL'" table name,sortNo,enabled

  # 表示した中の 0 番目の全項目を json で表示
  node db.mjs config select "where c.type = 'MODEL'" json index=0

  # 指定したレコードを削除
  node db.mjs config select "where c.type = 'MODEL'" delete index=0

  # 表示した中の 0 番目の全項目を json で編集
  node db.mjs config select "where c.type = 'MODEL'" json index=0 > data.json
  code data.json

  # 編集内容を反映
  node db.mjs config upsert data.json

  # TSV で保存
  node db.mjs config select "where c.type = 'MODEL'" tsv index=0 > data.tsv
  code data.tsv
`.replace(/node db.mjs/g, dbCommandPrefix),
  );
}

/** コンテナリスト表示 */
async function showContainerList() {
  console.warn(`${dbCommandPrefix} --help でヘルプを表示\n`);

  const database = cosmosClient.database(databaseId);
  const containers = await database.containers.readAll().fetchAll();

  for (const containerDef of containers.resources) {
    console.warn("container name:", [containerDef.id]);
    console.warn("パーティションキー:", containerDef.partitionKey.paths);

    // get container items
    const container = database.container(containerDef.id);
    const { resources: itemsCount } = await container.items
      .query("SELECT VALUE COUNT(1) FROM c")
      .fetchAll();
    console.warn("item count:", itemsCount);
    console.warn("");
  }
}

/** テーブル表示 */
async function showTable(containerName, results, columns) {
  // コンテナ情報を取得してパーティションキーを特定
  const database = cosmosClient.database(databaseId);
  const container = database.container(containerName);
  const containerInfo = await container.read();
  const partitionKeyName = containerInfo.resource.partitionKey.paths[0].replace(
    "/",
    "",
  );

  // 表示するデータを整形
  const tableData = results.map((item) => {
    let row = {};
    if (item?._ts) {
      row["__レコード更新日"] = dateFormatterUtc.format(
        new Date((item._ts + 60 * 60 * 9) * 1000),
      );
    }
    if (item?.id !== undefined) {
      // 通常のデータ構成
      row.id = item.id;
      row[partitionKeyName] = item[partitionKeyName];

      // 指定された追加の列があれば追加
      if (columns) {
        columns.forEach((col) => {
          if (col !== "id" && col !== partitionKeyName) {
            row[col] = item[col];
          }
        });
      }
    } else {
      // SELECT VALUE などの場合、そのまま表示
      row = item;
    }

    return row;
  });

  console.table(tableData);
}

/** SELECT実行 */
async function executeQuery(containerName, sql) {
  const database = cosmosClient.database(databaseId);
  const container = database.container(containerName);

  if (sql.toLowerCase().startsWith("where ")) {
    sql = `SELECT * FROM c ${sql}`;
  }
  console.warn(sql);

  const { resources } = await container.items.query(sql).fetchAll();
  return resources;
}

/** 削除実行 */
async function deleteItems(containerName, items) {
  if (items.length === 0) {
    console.error("対象0件");
    return;
  }

  console.warn(
    `${items.length} 件削除します。 キャンセルしたい場合、3秒以内に Ctrl+C を押してください`,
  );
  await wait(3000);

  console.warn("削除中");
  const database = cosmosClient.database(databaseId);
  const container = database.container(containerName);

  const containerInfo = await container.read();
  const partitionKeyName = containerInfo.resource.partitionKey.paths[0].replace(
    "/",
    "",
  );

  let deletedCount = 0;
  let totalRUs = 0;

  // bulk delete
  /** @type {import("@azure/cosmos").OperationInput[]} */
  const operations = items.map((item) => ({
    operationType: "Delete",
    id: item.id,
    partitionKey: item[partitionKeyName],
  }));

  for (let i = 0; i < operations.length; i += 100) {
    const chunk = operations.slice(i, i + 100);
    const results = await container.items.bulk(chunk);
    for (const result of results) {
      if (result.statusCode === 204) {
        deletedCount++;
        totalRUs += result.requestCharge;
      } else {
        console.error(`削除エラー (${result.statusCode})`);
      }
    }
  }

  console.warn(`\n削除完了:`);
  console.warn(`- 削除数: ${deletedCount}`);
  console.warn(`- RU: ${totalRUs.toFixed(2)}`);
}

/** Upsert実行 */
async function upsertItems(containerName, filePath) {
  console.warn("読込中");
  const fileContent = await fs.readFile(filePath, "utf8");

  // 挿入時変換
  /** @type {Map<number, string>} */
  const idMap = new Map();
  const nowDate = new Date();
  const nowMsec = nowDate.getTime();
  const jsonText = fileContent
    .replace(/<<ID>>/g, () => uuidv7Time(nowMsec))
    .replace(/<<ID(\d+)>>/g, (_, numStr) => {
      const num = Number(numStr);
      if (!idMap.has(num)) idMap.set(num, uuidv7Time(nowMsec));
      return idMap.get(num);
    })
    .replace(/<<NOW>>/g, () => nowDate.toISOString())
    .replace(/<<NOW([+-]\d+)>>/g, (_, offset) => {
      const date = new Date(nowDate);
      date.setSeconds(date.getSeconds() + Number(offset));
      return date.toISOString();
    });

  let items;
  try {
    items = JSON.parse(jsonText);
    if (!Array.isArray(items)) {
      items = [items]; // 単体レコードの場合は配列に変換
    }
  } catch (error) {
    console.error("JSONファイル解釈失敗:", error.message);
    return;
  }

  console.warn(
    `${items.length} 件 Upsert します。 キャンセルしたい場合、3秒以内に Ctrl+C を押してください`,
  );
  await wait(3000);

  console.warn(`${items.length} 件の Upsert 開始`);

  const database = cosmosClient.database(databaseId);
  const container = database.container(containerName);

  let upsertedCount = 0;
  let totalRUs = 0;

  // バルクアップサート用の操作リストを作成
  const bulkOperations = items.map((item) => ({
    operationType: "Upsert",
    resourceBody: item,
  }));

  // BULK_UPSERT_COUNT 件ずつに分割してバルク処理
  for (let i = 0; i < bulkOperations.length; i += BULK_UPSERT_COUNT) {
    const chunk = bulkOperations.slice(i, i + BULK_UPSERT_COUNT);
    try {
      if (i > 0) {
        // CosmosDBのレート制限を考慮して少し待機
        await wait(1000);
      }

      const results = await container.items.bulk(chunk);

      for (const result of results) {
        if (result.statusCode === 200 || result.statusCode === 201) {
          upsertedCount++;
          totalRUs += result.requestCharge;
        } else {
          console.error(
            `index ${i + results.indexOf(result)} の Upsert に失敗:`,
            result.statusCode,
          );
        }
      }

      console.warn(
        `${Math.min(i + BULK_UPSERT_COUNT, items.length)}/${items.length} items...`,
      );
    } catch (error) {
      console.error(
        `Failed to process chunk starting at index ${i}:`,
        error.message,
      );
    }
  }

  console.warn(`\nUpsert 完了:`);
  console.warn(`- Upsert 数: ${upsertedCount}`);
  console.warn(`- RU: ${totalRUs.toFixed(2)}`);
}

/** メイン処理 */
async function run() {
  const args = process.argv.slice(2);

  if (!args[0]) {
    await showContainerList();
    return;
  }
  if (args[0] === "--help") {
    showHelp();
    return;
  }

  const [containerName, operation, ...params] = args;

  try {
    switch (operation) {
      case "select": {
        const sqlDefined =
          params[0]?.toLowerCase().startsWith("select ") ||
          params[0]?.toLowerCase().startsWith("where ");
        if (!sqlDefined) {
          // params[0] を空文字で挿入
          params.unshift("");
        }
        const sql = params[0] || DEFAULT_SELECT_SQL;
        const selectMode = params[1] || "table";
        /** 取得結果 */
        let results = await executeQuery(containerName, sql);

        const indexDefined = params[2]?.startsWith("index=");
        if (indexDefined) {
          const indexes = params[2].slice(6).split(",").map(Number);
          const indexesSet = new Set(indexes);
          results = results.filter((_, i) => indexesSet.has(i));
          console.warn(`index=${indexes.join(",")}`);
        }

        if (selectMode === "delete") {
          if (params[2] !== "all" && !indexDefined) {
            throw new Error(
              "「delete all」または「delete index=数値」を指定してください",
            );
          }
          await showTable(containerName, results, null);
          await deleteItems(containerName, results);
        } else if (selectMode === "table") {
          if (indexDefined) {
            throw new Error("table では、 index=数値 は使用できません");
          }
          const columns = params[2] ? params[2].split(",") : null;
          await showTable(containerName, results, columns);
        } else if (selectMode === "json") {
          console.log(
            JSON.stringify(
              results,
              // `_` から始まるキーを除外
              (key, val) =>
                key.startsWith("_") && !key.startsWith("__") ? undefined : val,
              2,
            ),
          );
        } else if (selectMode === "tsv") {
          // ヘッダー行を作成
          if (results.length > 0) {
            const headersSet = new Set();
            for (const item of results) {
              for (const key of Object.keys(item)) {
                if (!key.startsWith("_") || key.startsWith("__")) {
                  headersSet.add(key);
                }
              }
            }
            const headers = [...headersSet];
            console.log(headers.join("\t"));

            // データ行を出力
            results.forEach((item) => {
              const row = headers.map((header) => {
                const value = item[header];
                // null、undefined、オブジェクト型の場合は空文字列に変換
                if (value === null || value === undefined) return "";
                if (typeof value === "object") return JSON.stringify(value);
                return String(value).replace(/\t/g, " ").replace(/\n/g, "\n");
              });
              console.log(row.join("\t"));
            });
          }
        } else {
          throw new Error(`不明なモード: ${selectMode}`);
        }
        break;
      }

      case "upsert": {
        if (!params[0]) {
          throw new Error("JSONファイルパスを指定してください");
        }
        await upsertItems(containerName, params[0]);
        break;
      }

      default:
        throw new Error(`不明な操作: ${operation}`);
    }
  } catch (error) {
    throw error;
  }
}

run()
  .catch((e) => {
    console.error("Error: " + e.message);
  })
  .finally(() => {
    cosmosClient.dispose();
    process.exit();
  });

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const uuidv7Time = (nowMsec) => {
  return uuidv7({
    msecs: nowMsec,
  });
};
