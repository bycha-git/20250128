import { Noto_Sans_JP } from "next/font/google";
import { AI_NAME } from "@/features/theme/theme-config";
import { ConfirmProvider } from "@/features/ui/confirm";
import { LoadingOverlay } from "@/features/ui/loading-overlay";
import { Toaster } from "@/features/ui/toaster";
import { cn } from "@/ui/lib";

import "./globals.css";

const notoSansJp = Noto_Sans_JP({ subsets: ["latin"] });

export const metadata = {
  title: AI_NAME,
  description: AI_NAME,
};

export const dynamic = "force-dynamic";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ja" className="h-full w-full overflow-hidden">
      <body
        className={cn(notoSansJp.className, "flex h-full w-full bg-background")}
      >
        <ConfirmProvider>{children}</ConfirmProvider>
        <LoadingOverlay />
        <Toaster />
      </body>
    </html>
  );
}
