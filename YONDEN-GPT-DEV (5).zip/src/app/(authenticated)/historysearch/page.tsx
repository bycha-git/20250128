import { HistorySearch } from "@/features/history-search-page/HistorySearch";

export default async function Home() {
  return (
    <>
      <HistorySearch />
    </>
  );
}
