import { findAllChatMessagesWithAttachmentsInThreadForCurrentUser } from "@/features/chat-view/chat-services/chat-message-service";
import { findAllModelAndParams } from "@/features/chat-view/chat-services/chat-model-service";
import { findThreadForCurrentUser } from "@/features/chat-view/chat-services/chat-thread-service";
import { ModelWithParams } from "@/features/chat-view/chat-services/modelOrganizer";
import { ChatView } from "@/features/chat-view/chat-view";
import { MODEL_THREAD_ATTRIBUTE } from "@/features/common/model/history/thread-model";
import { DisplayError } from "@/features/ui/error/display-error";

interface ChatParams {
  params: Promise<{
    id: string;
  }>;
}

export default async function Chat(props: ChatParams) {
  const { id: threadId } = await props.params;
  const [chatResponse, chatThreadResponse, modelsResponse] = await Promise.all([
    findAllChatMessagesWithAttachmentsInThreadForCurrentUser(threadId),
    findThreadForCurrentUser(threadId),
    findAllModelAndParams(),
  ]);

  if (chatResponse.status !== "OK") {
    return <DisplayError errors={[{ message: "ECOMMON0001" }]} />;
  }

  if (chatThreadResponse.status !== "OK") {
    return <DisplayError errors={[{ message: "ECOMMON0001" }]} />;
  }

  if (modelsResponse.status !== "OK") {
    return <DisplayError errors={[{ message: "ECOMMON0001" }]} />;
  }

  // TODO: 最初から単独のモデルを取得
  // TODO: チャットボットについても同様に取得
  const thread = chatThreadResponse.response;
  const models = modelsResponse.response;
  let currentModel: ModelWithParams | undefined = undefined;
  if (thread.type === MODEL_THREAD_ATTRIBUTE) {
    currentModel = models.find((m) => m.id === thread.modelId);
  }

  return (
    <ChatView
      messages={chatResponse.response}
      thread={chatThreadResponse.response}
      models={modelsResponse.response}
      currentModel={currentModel}
    />
  );
}
