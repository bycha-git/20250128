import { PropsWithChildren } from "react";
import { ChatLayout } from "@/features/chat-menu/chat-layout";
import { HomeEnvProvider } from "@/features/chat-menu/home-env-context";
import { findAllModelAndParams } from "@/features/chat-view/chat-services/chat-model-service";
import { findAllThreadForCurrentUser } from "@/features/chat-view/chat-services/chat-thread-service";
import { AI_NAME } from "@/features/theme/theme-config";
import { DisplayError } from "@/features/ui/error/display-error";

export const dynamic = "force-dynamic";

export const metadata = {
  title: AI_NAME,
  description: AI_NAME,
};

export default async function RootLayout({ children }: PropsWithChildren) {
  const [chatHistoryResponse, modelsResponse] = await Promise.all([
    findAllThreadForCurrentUser(),
    findAllModelAndParams(),
  ]);

  if (chatHistoryResponse.status !== "OK") {
    return <DisplayError errors={[{ message: "ECOMMON0001" }]} />;
  }

  if (modelsResponse.status !== "OK") {
    return <DisplayError errors={[{ message: "ECOMMON0001" }]} />;
  }

  const supportedFileExt = process.env.SUPPORTED_FILE_EXT ?? "";
  const supportedImageExt = process.env.SUPPORTED_IMAGE_EXT ?? "";

  return (
    <HomeEnvProvider
      supportedFileExt={supportedFileExt}
      supportedImageExt={supportedImageExt}
    >
      <ChatLayout
        listItems={chatHistoryResponse.response}
        models={modelsResponse.response}
      >
        {children}
      </ChatLayout>
    </HomeEnvProvider>
  );
}
