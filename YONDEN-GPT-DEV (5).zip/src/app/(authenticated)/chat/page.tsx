import { HomePage } from "@/features/home-page/home-page";

export default async function Home() {
  return <HomePage />;
}
