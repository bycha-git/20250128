"use client";

import { DisplayError } from "@/features/ui/error/display-error";

export default function Error() {
  return <DisplayError errors={[{ message: "ECOMMON0001" }]} />;
}
