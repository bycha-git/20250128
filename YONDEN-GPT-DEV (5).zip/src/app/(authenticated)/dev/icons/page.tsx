import { IconsPage } from "@/features/dev-page/icons-page";

export default async function TkmTest() {
  // a
  return (
    <>
      <IconsPage />
    </>
  );
}
