import { PromptTemplate } from "@/features/prompt-template-page/PromptTemplate";

export default async function Home() {
  return (
    <>
      <PromptTemplate />
    </>
  );
}
