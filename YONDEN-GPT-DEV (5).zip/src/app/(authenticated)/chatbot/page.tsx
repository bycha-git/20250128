import { findAllModelAndParams } from "@/features/chat-view/chat-services/chat-model-service";
import { Chatbot } from "@/features/chatbot-page/Chatbot";
import { ChatbotEnvProvider } from "@/features/chatbot-page/chatbot-env-context";
import { DisplayError } from "@/features/ui/error/display-error";

export default async function Home() {
  const supportedFileExt = process.env.SUPPORTED_FILE_EXT ?? "";
  const maxTotalDocumentUpSize =
    process.env.MAX_TOTAL_DOCUMENT_UPLOAD_SIZE ?? "1073741824";

  const modelsResponse = await findAllModelAndParams();

  if (modelsResponse.status !== "OK") {
    return <DisplayError errors={[{ message: "ECOMMON0001" }]} />;
  }
  return (
    <ChatbotEnvProvider
      supportedFileExt={supportedFileExt}
      models={modelsResponse.response}
      maxTotalDocumentUpSize={maxTotalDocumentUpSize}
    >
      <Chatbot />
    </ChatbotEnvProvider>
  );
}
