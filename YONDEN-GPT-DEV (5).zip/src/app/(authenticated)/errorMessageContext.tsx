"use client";
import React, { createContext, useContext } from "react";

const defaultErrorMessage: ErrorMessages = {};

const ErrorMessageContext = createContext<ErrorMessages>(defaultErrorMessage);

export const useErrorMessage = () => {
  const context = useContext(ErrorMessageContext);

  return context;
};

export const ErrorMessageProvider = ({
  children,
  errMessage,
}: {
  children: React.ReactNode;
  errMessage: { [key: string]: string };
}) => {
  return (
    <ErrorMessageContext.Provider value={errMessage as ErrorMessages}>
      {children}
    </ErrorMessageContext.Provider>
  );
};

type ErrorID =
  | "EHOME0001"
  | "EHOME0002"
  | "EHOME0003"
  | "EHOME0004"
  | "ECHATBOT0001"
  | "ECHATBOT0002"
  | "ECHATBOT0003"
  | "ECHATBOT0004"
  | "ECHATBOT0005"
  | "ECHATBOT0006"
  | "ECHATBOT0007"
  | "ECHATBOT0008"
  | "ECHATBOT0009"
  | "ECHATBOT0010"
  | "ECHATBOT0011"
  | "ECHATBOT0012"
  | "ECHATBOT0013"
  | "ECHATBOT0014"
  | "ECHATBOT0015"
  | "ECHATBOT0016"
  | "ECHATBOT0017"
  | "ETEMPLATE0001"
  | "ETEMPLATE0002"
  | "ETEMPLATE0003"
  | "ETEMPLATE0004"
  | "ETEMPLATE0005"
  | "ETEMPLATE0006"
  | "ETEMPLATE0007"
  | "ETEMPLATE0008"
  | "ETEMPLATE0009"
  | "ECOMMON0001";

// `(string & {})` について: https://github.com/formkit/tempo/pull/54
// 全文字列をキーに使用可能としつつ、補完候補も出す
type ErrorMessagesKey = ErrorID | (string & {});
export type ErrorMessages = { [key in ErrorMessagesKey]?: string | undefined };
