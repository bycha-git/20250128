import { handlers } from "@/features/auth-page/auth-api";

export { handlers as GET, handlers as POST };
