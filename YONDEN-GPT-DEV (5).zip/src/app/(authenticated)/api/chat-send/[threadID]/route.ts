import { NextRequest } from "next/server";
import { chatAPIEntry } from "@/features/chat-view/chat-services/chat-api/chat-api";

// App Router では恐らく使われない
// export const config = {
//   api: {
//     bodyParser: false,
//   },
// };

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ threadID: string }> },
) {
  return await chatAPIEntry(req, await params);
}
