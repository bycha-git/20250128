import { NextRequest } from "next/server";
import { chatAttachmentAPIEntry } from "@/features/chat-view/chat-services/attachment/attachment-api";

export async function GET(req: NextRequest) {
  return await chatAttachmentAPIEntry(req);
}
