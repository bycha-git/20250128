import { NextRequest } from "next/server";
import { chatbotIndexUpdateAPIEntry } from "@/features/chatbot-page/chatbot-services/index-update-api/index-update-api";

/** チャットボット インデックス更新 */
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ chatbotId: string }> },
) {
  return await chatbotIndexUpdateAPIEntry(req, await params);
}
