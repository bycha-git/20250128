import { ErrorMessageProvider } from "./errorMessageContext";
import { Approval } from "@/features/approval-window/Approval";
import { FindAllErrorMessages } from "@/features/common/services/errMessage-service";
import { AuthenticatedProviders } from "@/features/globals/providers";
import { MainMenu } from "@/features/main-menu/main-menu";
import { AI_NAME } from "@/features/theme/theme-config";
import { cn } from "@/ui/lib";

export const dynamic = "force-dynamic";

export const metadata = {
  title: AI_NAME,
  description: AI_NAME,
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  let errMessage: { [key: string]: string } = {};

  try {
    const errMessageResponse = await FindAllErrorMessages();
    errMessage =
      errMessageResponse.status === "OK" ? errMessageResponse.response : {};
  } catch (error) {
    //return <DisplayError errors={} />;
  }

  return (
    <AuthenticatedProviders>
      <ErrorMessageProvider errMessage={errMessage}>
        <div className={cn("flex flex-1 items-stretch overflow-x-auto")}>
          <MainMenu />
          <div className="flex h-full flex-1 overflow-y-auto">{children}</div>
        </div>
        <Approval />
      </ErrorMessageProvider>
    </AuthenticatedProviders>
  );
}
