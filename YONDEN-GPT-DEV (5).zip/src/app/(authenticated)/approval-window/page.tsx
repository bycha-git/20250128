import { CheckApprovalNeeded } from "@/features/approval-window/Approval-service";
import { ApprovalWindow } from "@/features/approval-window/ApprovalWindow";

export default async function Home() {
  // 承認要否チェック
  const checkResult = (await CheckApprovalNeeded()) ?? true;
  const message = process.env.AZURE_APPROVAL_MESSAGE!;

  return <ApprovalWindow dispFlg={checkResult} message={message} />;
}
