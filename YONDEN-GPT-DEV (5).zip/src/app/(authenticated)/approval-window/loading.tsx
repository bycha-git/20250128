import { PageLoader } from "@/features/ui/page-loader";

export default function Loading() {
  return <PageLoader />;
}
