import { TestPage } from "@/features/db-test-page/db-test-page";

// interface Props {
//   params: {};
//   searchParams: {
//     pageNumber?: string;
//   };
// }

export default async function Home() {
  return <TestPage />;
}
