"use client";

import { FormEvent } from "react";
import * as v from "valibot";
import { proxy, ref, useSnapshot } from "valtio";
import { ServerAPIErrorMessageIDResponseSchema } from "../common/api-models";
import {
  MESSAGE_ATTRIBUTE,
  MessageModel,
} from "../common/model/history/message-model";
import {
  CHATBOT_THREAD_ATTRIBUTE,
  MODEL_THREAD_ATTRIBUTE,
  ThreadModel,
} from "../common/model/history/thread-model";
import { revalidateCache } from "../common/navigation-helpers";
import { fetchChat } from "./chat-services/chat-api/chat-api-client";
import { ChatAPIContent } from "./chat-services/chat-api/models";
import { getTopChatMessagesForCurrentUser } from "./chat-services/chat-message-actions";
import { updateThreadTitle } from "./chat-services/chat-thread-service";
import { ModelWithParams } from "./chat-services/modelOrganizer";
import {
  LocalAttachment,
  MessageWithServerAttachments,
  ServerAttachment,
} from "./models";
import { ErrorMessages } from "@/app/(authenticated)/errorMessageContext";
import { showError } from "@/features/globals/global-message-store";
let abortController: AbortController = new AbortController();

type ChatStatus = "idle" | "loading" | "file upload";

class ChatState {
  public messages: Array<MessageWithServerAttachments> = [];
  public loading: ChatStatus = "idle";
  public input: string = "";
  public lastMessage: string = "";
  public autoScroll: boolean = false;
  public userName: string = "";
  public chatThreadId: string = "";
  public chatThreadModelName: string | undefined = undefined;
  public chatThreadChatbotName: string | undefined = undefined;
  /** 一番下にスクロールされているか */
  public isBottom: boolean = false;
  /** ファイル名をキーとした添付ファイルのマップ */
  // valtio で追跡しない (Proxy でラップしない)
  private attachmentsMap: Map<string, LocalAttachment> = ref(new Map());
  /** ファイルのリスト (読取用) */
  public attachmentsList: LocalAttachment[] = [];

  private chatThread: ThreadModel | undefined;
  private chatThreadModel: ModelWithParams | undefined = undefined;

  /** 状態を更新 */
  public updateLoading(value: ChatStatus) {
    this.loading = value;
  }

  /** 表示用添付ファイルリストを更新 */
  private updateAttachmentList() {
    // そのまま追加順で表示

    // attachmentsList へのセットの際は deep-copy を行う
    // (valtio@2 では proxy の返り値が deep-clone されなくなったため、
    //  attachmentsList にセットして表示する過程で
    //  attachmentsMap のオブジェクトも Proxy でラップされてしまい、
    //  File が Proxy(File) になってしまう)
    this.attachmentsList = [...this.attachmentsMap.values()].map((o) => ({
      ...o,
    }));
  }

  /** 添付ファイル追加 */
  public addAttachment(fileProp: File, type: "file" | "image") {
    // ファイル名のUnicode正規化をNFCで統一
    const name = fileProp.name.normalize("NFC");
    const file = new File([fileProp], name, {
      type: fileProp.type,
    });

    const attachment: LocalAttachment = {
      file,
      name,
      type,
    };

    // 既にあれば上書き
    // 常に最後に追加ファイルをリスト上の最後に設置するため、一旦削除 (仕様にないが)
    this.attachmentsMap.delete(name);
    this.attachmentsMap.set(name, attachment);
    this.updateAttachmentList();
  }

  /** 指定した添付ファイルを削除 */
  public removeAttachment(name: string) {
    this.attachmentsMap.delete(name);
    this.updateAttachmentList();
  }

  /** サーバーから取得したスレッドのデータをこのクラスに反映 */
  public initChatSession({
    userName,
    messages,
    chatThread,
    chatThreadModel,
  }: {
    chatThread: ThreadModel;
    chatThreadModel?: ModelWithParams | undefined;
    userName: string;
    messages: Array<MessageWithServerAttachments>;
  }) {
    this.chatThread = chatThread;
    this.chatThreadId = chatThread.id;
    this.chatThreadModel = chatThreadModel;
    this.chatThreadModelName =
      chatThread.type === MODEL_THREAD_ATTRIBUTE
        ? chatThread.modelName
        : undefined;
    this.chatThreadChatbotName =
      chatThread.type === CHATBOT_THREAD_ATTRIBUTE
        ? chatThread.chatbotName
        : undefined;
    this.messages = messages;
    this.userName = userName;
  }

  /** 入力欄を更新 */
  public updateInput(value: string) {
    this.input = value;
  }

  /** リクエストをキャンセル */
  public stopGeneratingMessages() {
    abortController.abort();
  }

  public updateAutoScroll(value: boolean) {
    this.autoScroll = value;
  }

  public updateIsBottom(value: boolean) {
    this.isBottom = value;
  }

  private reset() {
    this.input = "";
    this.attachmentsMap.clear();
    this.updateAttachmentList();
  }

  // TODO: formData を使っていないなら削除
  private async chat(formData: FormData, errorMessage: ErrorMessages) {
    this.updateAutoScroll(true);
    this.loading = "loading";

    const thread = this.chatThread;
    if (thread === undefined) {
      showError(errorMessage["ECOMMON0001"]);
      return;
    }

    let modelId: string | undefined = undefined;
    let chatbotId: string | undefined = undefined;

    if (thread.type === MODEL_THREAD_ATTRIBUTE) {
      modelId = thread.modelId;
    }
    if (thread.type === CHATBOT_THREAD_ATTRIBUTE) {
      chatbotId = thread.chatbotId;
    }

    const newUserMessage: MessageModel = {
      id: "",
      role: "user",
      content: this.input,
      createdAt: new Date().toISOString(),
      isDeleted: false,
      threadId: this.chatThreadId,
      type: MESSAGE_ATTRIBUTE,
      userId: "",
      isError: false,
      isAttachment: false,
      modelId: modelId,
      chatbotId: chatbotId,
    };

    const controller = new AbortController();
    abortController = controller;

    // valtioによりProxyでラップされた`Proxy(File)`はFormDataにファイル扱いされなかったので
    // ProxyでラップしていないattachmentsMapを使用
    const fileList = [...this.attachmentsMap.values()];

    const content: ChatAPIContent = {
      message: newUserMessage,
      attachmentsInfo: fileList.map((attachment) => ({
        name: attachment.name,
        type: attachment.type,
      })),
    };

    const files = fileList.map((attachment) => attachment.file);

    // disabled にしたい

    // 表示用のメッセージデータを作成
    const tmpServerAttachments: ServerAttachment[] = fileList.map(
      (attachment) => ({
        name: attachment.name,
        type: attachment.type,
        src: URL.createObjectURL(attachment.file),
      }),
    );
    const messageAndAttachments: MessageWithServerAttachments = {
      messageData: newUserMessage,
      attachments: tmpServerAttachments,
    };
    this.messages.push(messageAndAttachments);
    const messagesCount = this.messages.length;

    try {
      if (this.chatThreadId === "" || this.chatThreadId === undefined) {
        showError(errorMessage["ECOMMON0001"]);
        return;
      }

      const response = await fetchChat(content, files, controller);

      if (response.status !== 200) {
        // 配列に追加したメッセージを元に戻す
        this.messages = [...this.messages].slice(0, -1);

        let error: string | undefined = undefined;
        const json = v.safeParse(
          ServerAPIErrorMessageIDResponseSchema,
          response.data,
        );
        if (json.success) {
          error = json.output.errorMessageId;
        }
        if (!error) {
          error = "メッセージ送信失敗: " + response.statusText;
        }
        throw new Error(error);
      }

      this.reset();
      await this.updateTitle(messagesCount);
    } catch (error) {
      console.warn(error);
      const errorText =
        error instanceof Error
          ? errorMessage[error.message] || errorMessage["ECOMMON0001"]
          : errorMessage["ECOMMON0001"];
      showError(errorText);
    } finally {
      this.loading = "idle";
    }
  }

  private async updateTitle(count: number) {
    if (this.chatThread && !this.chatThread.edited && count == 1) {
      // メッセージが一件目かつスレッド名編集済みフラグがfalseの場合
      // メッセージの先頭10文字でスレッド名を更新
      await updateThreadTitle(
        this.chatThreadId,
        this.messages[0].messageData.content.slice(0, 10),
      );
    }
    revalidateCache({
      page: "chat",
      type: "layout",
    });
  }

  /** メッセージの最新2件を比較。一致していれば true を返す */
  public async diffCheck() {
    const messagesResponse = await getTopChatMessagesForCurrentUser(
      this.chatThreadId,
      2,
    );
    if (messagesResponse.status === "OK") {
      const checkResult = messagesResponse.response.every((message, i) => {
        const localMessage = this.messages.at(-(i + 1))?.messageData;
        if (!localMessage) return false;
        return (
          localMessage.content === message.content &&
          localMessage.createdAt === message.createdAt
        );
      });
      return checkResult;
    }
  }

  public async submitChat(
    e: FormEvent<HTMLFormElement>,
    errorMessage: ErrorMessages,
  ) {
    e.preventDefault();
    if (
      (this.input === "" && this.attachmentsList.length == 0) ||
      this.loading !== "idle"
    ) {
      return;
    }

    // get form data from e
    const formData = new FormData(e.currentTarget);

    const body = JSON.stringify({
      id: this.chatThreadId,
      message: this.input,
    });
    formData.append("content", body);

    this.chat(formData, errorMessage);
  }
}

// 仕組み:
// このファイルを初めてインポートした際からオブジェクトとして存在する、グローバル変数のようなもの
// Proxy API (getter, setter を作れる機構) で ChatState のインスタンスをラップして、値の変更を検知
export const chatStore = proxy(new ChatState());

export const useChat = () => {
  // 仕組み: Proxy API で値の変更を検知した度に再レンダーを実行し、最新の値を反映
  return useSnapshot(chatStore, { sync: true });
};
