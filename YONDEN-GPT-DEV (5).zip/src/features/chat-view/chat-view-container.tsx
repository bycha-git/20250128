import { PropsWithChildren } from "react";

export const ChatViewContainer = ({ children }: PropsWithChildren) => (
  <div className="grid h-screen w-full grid-cols-[3rem_minmax(0,1fr)] grid-rows-[auto_1fr_auto] md:grid-cols-[1fr]">
    {children}
  </div>
);
