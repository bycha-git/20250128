import { FC, useEffect, useState } from "react";
import {
  MODEL_THREAD_ATTRIBUTE,
  ThreadModel,
} from "../../common/model/history/thread-model";
import { PromptSlider } from "../chat-input/prompt/prompt-slider";
import { useSpeechToText } from "../chat-input/speech/use-speech-to-text";
import { ModelWithParams } from "../chat-services/modelOrganizer";
import { useChat } from "../chat-store";
import { ThreadDataWindow } from "./thread-data-window";
import { ChatbotModal } from "@/features/chatbot-page/CahtBotModal";
import { ChatBotModel } from "@/features/chatbot-page/Chatbot-model";
import {
  FindChatbotByID,
  referenceOpen,
} from "@/features/chatbot-page/Chatbot-service";
import { ChatbotContextProvider } from "@/features/chatbot-page/ChatbotContext";
import { Button } from "@/features/ui/button";
import { useResponsive } from "@/features/ui/responsive";

interface ChatHeaderProps {
  thread: ThreadModel;
  models: ModelWithParams[];
  focusChatInputAndMoveCursorToTop: () => void;
}
interface Info {
  chatbotData: ChatBotModel;
  mode: string;
  visible: boolean;
}
export const ChatHeader: FC<ChatHeaderProps> = (props) => {
  const { isMobile } = useResponsive();
  const { isMicrophoneReady } = useSpeechToText();
  const { loading } = useChat();
  const disabledInput = isMicrophoneReady || loading === "loading";
  const [windowOpen, setWindowOpen] = useState(false);
  const [chatbotWindowInfo, setChatbotWindowInfo] = useState<Info>({
    chatbotData: {
      id: "",
      type: "CHATBOT",
      userId: "",
      createdAt: "",
      lastUpdateAt: "",
      lastUpdateUser: "",
      status: "",
      errorMessage: "",
      chatbotName: "",
      description: "",
      modelId: "",
      modelName: "",
      chunkSizeId: "",
      token: "",
      overlap: "",
    },
    mode: "参照",
    visible: false,
  });
  useEffect(() => {
    const setChatbotDetail = async () => {
      const thread = props.thread;
      if (thread.type == MODEL_THREAD_ATTRIBUTE) return;
      // 表示チェック
      const checkResult = await referenceOpen(thread.chatbotId);
      if (checkResult?.check) {
        // 対象チャットボット・取得
        const chatbotResponse = await FindChatbotByID(thread.chatbotId);

        if (chatbotResponse.response) {
          // 表示内容・セット
          setChatbotWindowInfo({
            chatbotData: {
              id: chatbotResponse.response.id,
              type: chatbotResponse.response.type,
              userId: chatbotResponse.response.userId,
              createdAt: chatbotResponse.response.createdAt,
              lastUpdateAt: chatbotResponse.response.lastUpdateAt,
              lastUpdateUser: chatbotResponse.response.lastUpdateUser,
              status: chatbotResponse.response.status,
              errorMessage: chatbotResponse.response.errorMessage,
              chatbotName: chatbotResponse.response.chatbotName,
              description: chatbotResponse.response.description,
              modelId: chatbotResponse.response.modelId,
              modelName: chatbotResponse.response.modelName,
              chunkSizeId: chatbotResponse.response.chunkSizeId,
              token: chatbotResponse.response.token,
              overlap: chatbotResponse.response.overlap,
            },
            mode: "参照",
            visible: false,
          });
        }
      }
    };
    setChatbotDetail();
  }, [props.thread]);
  return (
    <div className="flex w-full justify-between border-b border-gray-03 p-2 md:p-4">
      <h2 className="truncate text-lg font-medium md:text-xl">
        {props.thread.name || " "}
      </h2>

      <div className="flex">
        {isMobile && (
          <PromptSlider
            disabled={disabledInput}
            focusChatInputAndMoveCursorToTop={
              props.focusChatInputAndMoveCursorToTop
            }
          ></PromptSlider>
        )}
        <Button
          type="button"
          variant="ghost"
          size="auto"
          title="スレッド情報を参照"
          onClick={() => setWindowOpen(true)}
          className="aspect-square h-max w-max"
        >
          <span className="i-material-symbols-info-outline-rounded size-6" />
        </Button>
        <ThreadDataWindow
          open={windowOpen}
          onOpenChange={setWindowOpen}
          thread={props.thread}
          models={props.models}
          openChatbotWindow={() => {
            setWindowOpen(false);
            setChatbotWindowInfo({ ...chatbotWindowInfo, visible: true });
          }}
        />

        {chatbotWindowInfo.visible && (
          <ChatbotContextProvider
            initialChatbotData={chatbotWindowInfo.chatbotData}
          >
            <ChatbotModal
              visible={chatbotWindowInfo.visible}
              openModal={doNothing}
              initialize={doNothing}
              closeModal={() => {
                setChatbotWindowInfo({ ...chatbotWindowInfo, visible: false });
              }}
              chatbotData={chatbotWindowInfo.chatbotData}
              mode={chatbotWindowInfo.mode}
              talkStartVisible={false}
            />
          </ChatbotContextProvider>
        )}
      </div>
    </div>
  );
};

const doNothing = () => {};
