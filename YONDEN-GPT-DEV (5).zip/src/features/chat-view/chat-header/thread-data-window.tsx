"use client";

import { useEffect, useState } from "react";
import { FindModelByID } from "../chat-services/chat-thread-service";
import { ModelWithParams } from "../chat-services/modelOrganizer";
import {
  ModelParameterArea,
  ModelSelector,
} from "@/features/chat-menu/chat-menu-header/chat-menu-new-window";
import { FindChatbotByID } from "@/features/chatbot-page/Chatbot-service";
import { ChatbotThreadParameterArea } from "@/features/chatbot-page/chatbot-thread-new-window";
import {
  CHATBOT_THREAD_ATTRIBUTE,
  ChatbotThreadModel,
  MODEL_THREAD_ATTRIBUTE,
  ModelThreadModel,
  ThreadModel,
} from "@/features/common/model/history/thread-model";
import { useResponsive } from "@/features/ui/responsive";
import { Window } from "@/features/ui/window";
interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  thread: ThreadModel;
  models: ModelWithParams[];
  openChatbotWindow: () => void;
}

export const ThreadDataWindow = ({
  open,
  onOpenChange,
  thread,
  models,
  openChatbotWindow,
}: Props) => {
  const { isMobile } = useResponsive();
  const [loading, setLoading] = useState(false);
  const [prevOpen, setPrevOpen] = useState(open);
  const [modelData, setModelData] = useState(
    thread.type == MODEL_THREAD_ATTRIBUTE
      ? { name: thread.modelName, isExist: false }
      : { name: "", isExist: false },
  );
  const [chatbotData, setChatbotData] = useState(
    thread.type == CHATBOT_THREAD_ATTRIBUTE
      ? { name: thread.chatbotName, isExist: false }
      : { name: "", isExist: false },
  );
  if (prevOpen !== open) {
    if (open) setLoading(false);
    setPrevOpen(open);
  }
  useEffect(() => {
    const getThreadData = async () => {
      const result = { name: "", isExist: false };
      if (thread.type == MODEL_THREAD_ATTRIBUTE) {
        const model = await FindModelByID(thread.modelId);
        if (model.status == "OK") {
          result.isExist = true;
          result.name = model.response?.name || thread.modelName;
          setModelData(result);
        }
      } else {
        const chatbot = await FindChatbotByID(thread.chatbotId);
        if (chatbot.status == "OK") {
          result.isExist = true;
          result.name = chatbot.response?.chatbotName || thread.chatbotName;
          setChatbotData(result);
        }
      }
    };
    getThreadData();
  }, [thread]);

  return (
    <>
      <Window
        open={open}
        onOpenChange={onOpenChange}
        title={"スレッド情報"}
        showClose={true}
        secondaryButtonText={isMobile ? "" : "閉じる"}
        onClickSecondary={() => {
          onOpenChange(false);
        }}
        className={`${isMobile ? "h-full w-full rounded-none" : "w-fit"} `}
        mobileFlg={isMobile}
      >
        {thread.type == "MODEL_THREAD" ? (
          <ModelThreadDetail
            thread={thread}
            models={models}
            modelData={modelData}
          />
        ) : (
          <ChatbotThreadDetail
            thread={thread}
            chatbotData={chatbotData}
            openChatbot={() => {
              openChatbotWindow();
            }}
            model={models.find((model) => model.id === "#chatbot#")}
          />
        )}
      </Window>
    </>
  );
};

const ModelThreadDetail = ({
  thread,
  models,
  modelData,
}: {
  thread: ModelThreadModel;
  models: ModelWithParams[];
  modelData: { name: string; isExist: boolean };
}) => {
  const { isMobile } = useResponsive();
  return (
    <div
      className={`grid h-[90%] items-center gap-2 ${isMobile ? "grid-cols-1 grid-rows-[auto_auto_minmax(auto,1fr)_auto]" : "grid-cols-[150px_1fr]"}`}
    >
      <p>モデル</p>
      <ModelSelector
        models={models}
        selectedItemName={modelData.isExist ? modelData.name : thread.modelName}
        disabled
      />
      <ModelParameterArea
        model={models.find((model) => model.id == thread.modelId)}
        threadParams={thread}
        disabled
      />
    </div>
  );
};
const ChatbotThreadDetail = ({
  thread,
  chatbotData,
  openChatbot,
  model,
}: {
  thread: ChatbotThreadModel;
  chatbotData: { name: string; isExist: boolean };
  openChatbot: () => void;
  model?: ModelWithParams;
}) => {
  const { isMobile } = useResponsive();
  return (
    <div
      className={`grid items-center gap-2 ${isMobile ? "w-fit grid-cols-1" : "grid-cols-[auto_1fr]"}`}
    >
      <ChatbotThreadParameterArea
        threadParameter={thread}
        chatbotData={chatbotData}
        openChatbot={openChatbot}
        disabled
        model={model}
      />
    </div>
  );
};
