import React, { memo } from "react";
import { MessageWithServerAttachments } from "../models";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { showError } from "@/features/globals/global-message-store";
import { ChatMessageAttachment } from "@/features/ui/chat/chat-message-attachment";
import { ChatMessageImage } from "@/features/ui/chat/chat-message-image";
import { MarkdownSimple } from "@/features/ui/markdown/markdown-simple";

interface MessageContentProps {
  message: MessageWithServerAttachments;
}

const MessageContent: React.FC<MessageContentProps> = ({ message }) => {
  const { attachments, messageData } = message;
  const errorMessages = useErrorMessage();

  const dlImage = async (src: string) => {
    try {
      const res = await fetch(src);
      if (res.ok) {
        const srcFilename = new URL(src).pathname.replace(/.*\//, "");
        const blob = await res.blob();
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = blobUrl;
        a.download = srcFilename;
        a.click();
      } else {
        throw new Error(`${res.status} ${res.statusText}`);
      }
    } catch (e) {
      console.warn(e);
      showError(errorMessages["ECOMMON0001"]);
    }
  };

  const renderMarkdown =
    messageData.role === "assistant" || messageData.isAttachment;
  if (messageData.role === "assistant" || messageData.role === "user") {
    return (
      <div
        onClick={(e) => {
          const target = e.target;
          if (target instanceof HTMLImageElement && target.src) {
            dlImage(target.src);
          }
        }}
      >
        <div className="flex flex-wrap">
          {attachments.map((attachment, index) => {
            if (attachment.type === "image") {
              return (
                <ChatMessageImage
                  key={index}
                  src={attachment.src}
                  alt={attachment.name}
                  className="max-h-screen w-full object-contain"
                />
              );
            }
          })}
        </div>
        {renderMarkdown && (
          <MarkdownSimple content={messageData.content}></MarkdownSimple>
        )}
        {!renderMarkdown && (
          <div className="whitespace-pre-wrap">{messageData.content}</div>
        )}
        <div className="flex flex-wrap">
          {attachments.map((attachment, index) => {
            if (attachment.type === "file") {
              return (
                <ChatMessageAttachment
                  key={index}
                  name={attachment.name}
                  type={attachment.type}
                  src={attachment.src}
                />
              );
            }
          })}
        </div>
      </div>
    );
  }

  return null;
};

const MessageContentMemo = memo(MessageContent);

export { MessageContentMemo as MessageContent };
