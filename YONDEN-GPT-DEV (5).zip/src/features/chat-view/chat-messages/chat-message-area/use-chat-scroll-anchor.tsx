import { throttle } from "es-toolkit";
import { RefObject, useEffect } from "react";
import { chatStore } from "../../chat-store";

export const useChatScrollAnchor = (props: {
  ref: RefObject<HTMLDivElement | null>;
}) => {
  const { ref } = props;

  // スクロール/リサイズイベントを処理
  useEffect(() => {
    const div = ref.current;
    if (!div) return;

    // throttle: 最初はすぐ実行、その後200ms以内に呼び出されたら200ms待機
    const handleRecalculate = throttle(() => {
      recalculateIsBottom(div);
    }, 200);

    // スクロールされた
    div.addEventListener("scroll", handleRecalculate);

    // リサイズされた (ウィンドウリサイズ、ズーム等)
    const resizeObserver = new ResizeObserver((entries) => {
      const [entry] = entries;
      if (entry) {
        handleRecalculate();
      }
    });
    resizeObserver.observe(div);

    return () => {
      div.removeEventListener("scroll", handleRecalculate);
      resizeObserver.disconnect();
      handleRecalculate.cancel();
    };
  }, [ref]);
};

/** 一番下までスクロールされているかチェック */
const recalculateIsBottom = (element: HTMLDivElement) => {
  /** 一番下までスクロールされていた場合のscrollTop値 */
  const scrollTopIfScrolledToBottom =
    element.scrollHeight - element.clientHeight;
  /** 実際のscrollTopとの差 */
  const diffWithRealScrollTop = Math.abs(
    scrollTopIfScrolledToBottom - element.scrollTop,
  );
  // ズーム倍率やDPI設定などによる細かい誤差を考慮し、3px未満の差であれば無視
  const isScrollBottom = diffWithRealScrollTop < 3;
  chatStore.updateIsBottom(isScrollBottom);
};

export { recalculateIsBottom as chatRecalculateIsBottom };
