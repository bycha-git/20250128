import React, { forwardRef } from "react";

interface ChatMessageContentAreaProps {
  children?: React.ReactNode;
}

export const ChatMessageContentArea = forwardRef<
  HTMLDivElement,
  ChatMessageContentAreaProps
>((props, ref) => {
  return (
    <div
      ref={ref}
      // className="container relative flex min-h-full max-w-3xl flex-col gap-16 pb-[240px] pt-16"
      className="container relative flex min-h-full w-full flex-col"
    >
      {props.children}
    </div>
  );
});
ChatMessageContentArea.displayName = "ChatMessageContentArea";
