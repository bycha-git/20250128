"use client";
import { useEffect, useState } from "react";
import { Button } from "@/features/ui/button";
import { RoleIconAssistant } from "@/features/ui/chat/role-icon/role-icon-assistant";
import { RoleIconUser } from "@/features/ui/chat/role-icon/role-icon-user";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/features/ui/dropdown-menu";
import { useResponsive } from "@/hooks/use-responsive";
import { cn } from "@/ui/lib";

export const ChatMessageArea = (props: {
  children?: React.ReactNode;
  profileName?: string;
  role: "function" | "user" | "assistant" | "system" | "tool";
  className?: string;
  id: string;
  onCopy: () => void;
  onDelete?: () => void;
  createdAt: string;
}) => {
  const [isIconChecked, setIsIconChecked] = useState(false);
  const { isMobile } = useResponsive();

  const handleButtonClick = () => {
    props.onCopy();
    setIsIconChecked(true);
  };

  useEffect(() => {
    const timeout = setTimeout(() => {
      setIsIconChecked(false);
    }, 2000);

    return () => clearTimeout(timeout);
  }, [isIconChecked]);

  // 日付データをフォーマット
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const hours = String(date.getHours());
    const minutes = String(date.getMinutes()).padStart(2, "0");

    return `送信日：${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()} ${hours}:${minutes}`;
  };

  return (
    <div
      className={cn("flex flex-col gap-4 px-6 py-6 md:px-24", props.className)}
    >
      <div className="flex h-7 items-center justify-between text-lg font-bold">
        <div className="flex h-7 items-center gap-3">
          {props.role === "assistant" && <RoleIconAssistant />}
          {props.role === "user" && <RoleIconUser />}
          {props.profileName}
          <div className="text-xs font-normal md:text-base">
            {props.onDelete && formatDate(props.createdAt)}
          </div>
        </div>
        <div className="flex h-7 items-center justify-between">
          <div>
            {!isMobile && props.onDelete && (
              <Button
                variant={"ghost"}
                size={"sm"}
                title="削除する"
                className="justify-right flex p-0 text-gray-500 hover:text-gray-700"
                onClick={props.onDelete}
              >
                <span className="i-material-symbols-delete-outline-rounded h-6 w-6" />
              </Button>
            )}
            {isMobile && props.onDelete && (
              <DropdownMenu>
                <DropdownMenuTrigger>
                  <span className="justify-right i-mdi-dots-horizontal flex h-6 w-6 p-0 text-gray-500 hover:text-gray-700" />
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={props.onCopy}>
                    <div className="flex gap-2">
                      <div className="flex justify-center">
                        <span className="i-material-symbols-content-copy-outline-rounded size-5" />
                      </div>
                      <div className="text-xs/5">コピー</div>
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="mx-0" />
                  <DropdownMenuItem onClick={props.onDelete}>
                    <div className="flex gap-2">
                      <div className="flex justify-center">
                        <span className="i-material-symbols-delete-outline-rounded size-5" />
                      </div>
                      <div className="text-xs/5">削除</div>
                    </div>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </div>
      <div className="flex flex-1 flex-col gap-4">
        <div className="prose prose-slate max-w-none break-words dark:prose-invert prose-p:leading-relaxed prose-pre:p-0">
          {props.children}
        </div>
        {!isMobile && props.onDelete && (
          <Button
            variant={"ghost"}
            size={"sm"}
            title="コピーする"
            className="h-fit w-fit p-0 text-gray-500 hover:text-gray-700"
            onClick={props.onCopy}
          >
            <span className="i-material-symbols-content-copy-outline-rounded h-6 w-6" />
          </Button>
        )}
      </div>
    </div>
  );
};
