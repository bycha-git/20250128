import React, { forwardRef } from "react";
import { ScrollArea } from "@/features/ui/scroll-area";

interface ChatMessageContainerProps {
  children?: React.ReactNode;
}

export const ChatMessageContainer = forwardRef<
  HTMLDivElement,
  ChatMessageContainerProps
>((props, ref) => {
  return (
    <ScrollArea ref={ref} className="h-full flex-1" type="always">
      {props.children}
    </ScrollArea>
  );
});
ChatMessageContainer.displayName = "ChatMessageContainer";
