import React, { FC, useEffect, useRef } from "react";
import { softDeleteChatMessageForCurrentUser } from "../chat-services/chat-message-actions";
import { useChat } from "../chat-store";
import { MessageWithServerAttachments } from "../models";
import { ChatLoading } from "./chat-message-area/chat-loading";
import { ChatMessageArea } from "./chat-message-area/chat-message-area";
import { ChatMessageContentArea } from "./chat-message-area/chat-message-content";
import {
  chatRecalculateIsBottom,
  useChatScrollAnchor,
} from "./chat-message-area/use-chat-scroll-anchor";
import { MessageContent } from "./message-content";
import { showError } from "@/features/globals/global-message-store";
import { Button } from "@/features/ui/button";
import { useConfirm } from "@/features/ui/confirm";
import { ScrollArea } from "@/features/ui/scroll-area";

export const ChatMessages: FC = () => {
  const {
    messages,
    loading,
    chatThreadModelName,
    chatThreadChatbotName,
    isBottom,
  } = useChat();

  const { confirmWait } = useConfirm();
  const confirmDeleteMessage = async (
    message: MessageWithServerAttachments,
  ) => {
    const confirmWindow = await confirmWait({
      title: "メッセージを削除します。よろしいですか？",
      okButtonText: "削除する",
      cancelButtonText: "キャンセルする",
      className: "max-w-lg",
    });
    if (confirmWindow.ok) {
      await handleDeleteMessage(message);
    }
    confirmWindow.close();
  };
  const handleDeleteMessage = async (message: MessageWithServerAttachments) => {
    try {
      const response = await softDeleteChatMessageForCurrentUser(
        message.messageData.id,
      );
    } catch (error) {
      showError("ECOMMON0001");
    }
  };

  const ref = useRef<HTMLDivElement>(null);
  useChatScrollAnchor({ ref });
  const scrollToBottom = () => {
    const element = ref.current;
    if (element) {
      element.scrollTop = element.scrollHeight;
    }
  };

  useEffect(() => {
    scrollToBottom();
    if (ref.current) chatRecalculateIsBottom(ref.current);
  }, [ref, messages]);
  return (
    <ScrollArea className="col-span-full" ref={ref}>
      <div className="flex h-full flex-col">
        {/* <ChatMessageContainer ref={current}> */}
        <ChatMessageContentArea>
          {messages.map((message, i) => {
            const { messageData } = message;
            return (
              <ChatMessageArea
                key={messageData.id || messageData.createdAt}
                profileName={
                  messageData.role === "user"
                    ? "あなた"
                    : chatThreadModelName || chatThreadChatbotName || ""
                }
                role={messageData.role}
                onCopy={() => {
                  navigator.clipboard.writeText(messageData.content);
                }}
                onDelete={
                  messageData.isDeleted
                    ? undefined
                    : () => {
                        confirmDeleteMessage(message);
                      }
                }
                className={i % 2 == 0 ? "bg-white" : "bg-orange-01"}
                id={messageData.id}
                createdAt={messageData.createdAt}
              >
                {messageData.isDeleted ? (
                  <div>(メッセージを削除しました)</div>
                ) : (
                  <MessageContent message={message} />
                )}
              </ChatMessageArea>
            );
          })}
          {loading === "loading" && <ChatLoading />}
        </ChatMessageContentArea>
        {/* </ChatMessageContainer> */}
      </div>
      {!isBottom && (
        <Button
          onClick={scrollToBottom}
          icon="i-material-symbols-arrow-downward-alt-rounded size-10"
          className="absolute bottom-0 left-0 right-0 m-auto w-fit bg-black p-0"
          title="最新のメッセージに移動"
        ></Button>
      )}
    </ScrollArea>
  );
};
