"use client";

import { useSession } from "next-auth/react";
import { FC, useCallback, useEffect, useRef } from "react";
import {
  MODEL_THREAD_ATTRIBUTE,
  ThreadModel,
} from "../common/model/history/thread-model";
import { revalidateCache } from "../common/navigation-helpers";
import { ChatHeader } from "./chat-header/chat-header";
import { ChatInput } from "./chat-input/chat-input";
import { speechToTextStore } from "./chat-input/speech/use-speech-to-text";
import { ChatMessages } from "./chat-messages/chat-messages";
import { ModelWithParams } from "./chat-services/modelOrganizer";
import { chatStore } from "./chat-store";
import { MessageWithServerAttachments } from "./models";

/** スレッドのメッセージ自動更新間隔 */
const THREAD_MESSAGE_AUTO_UPDATE_SEC = 5;

interface ChatViewProps {
  messages: MessageWithServerAttachments[];
  thread: ThreadModel;
  models: ModelWithParams[];
  currentModel?: ModelWithParams | undefined;
}

export const ChatView: FC<ChatViewProps> = (props) => {
  const { data: session } = useSession();
  const userName = session?.user?.name || "あなた";

  const textInputRef = useRef<HTMLTextAreaElement>(null);
  /** プロンプトテンプレート画面を閉じた */
  const focusChatInputAndMoveCursorToTop = useCallback(() => {
    const input = textInputRef.current;
    if (input) {
      input.focus();
      input.setSelectionRange(0, 0);
      input.scrollTo(0, 0);
    }
  }, [textInputRef]);
  const corsorPosition = textInputRef.current?.selectionEnd;

  const { thread, models, currentModel } = props;
  const imageEnabled =
    thread.type == MODEL_THREAD_ATTRIBUTE
      ? currentModel?.imageEnabled || false
      : false;

  useEffect(() => {
    speechToTextStore.disconnect();
  }, []);

  useEffect(() => {
    chatStore.initChatSession({
      chatThread: thread,
      chatThreadModel: currentModel,
      messages: props.messages,
      userName,
    });
  }, [props.messages, userName, thread, currentModel]);

  useEffect(() => {
    // THREAD_MESSAGE_AUTO_UPDATE_SEC 秒ごとにメッセージの最新2件を比較し、
    // 差分があればメッセージ一覧を更新する
    const interval = setInterval(async () => {
      const diffCheckResult = await chatStore.diffCheck();
      if (!diffCheckResult) {
        console.log("差分あり");
        revalidateCache({
          page: "chat",
          params: thread.id,
          type: "page",
        });
      }
    }, 1000 * THREAD_MESSAGE_AUTO_UPDATE_SEC);
    return () => clearInterval(interval);
  }, [thread.id]);

  return (
    <>
      <ChatHeader
        thread={thread}
        models={models}
        focusChatInputAndMoveCursorToTop={focusChatInputAndMoveCursorToTop}
      />
      <ChatMessages />
      <ChatInput
        ref={textInputRef}
        imageEnabled={imageEnabled}
        cursorPosition={corsorPosition}
        focusChatInputAndMoveCursorToTop={focusChatInputAndMoveCursorToTop}
        currentModel={currentModel}
      />
    </>
  );
};
