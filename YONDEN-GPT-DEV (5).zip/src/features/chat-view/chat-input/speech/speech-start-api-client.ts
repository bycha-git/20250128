import axios from "axios";
import * as v from "valibot";
import { SpeechStartResponse, SpeechStartResponseSchema } from "./models";

export const fetchSpeechStart = async (): Promise<SpeechStartResponse> => {
  // fetch で問題ないが、他の api-client で axios を使っているので統一
  try {
    const res = await axios.post("/api/chat-speech-start", {
      responseType: "json",
    });
    const body = v.parse(SpeechStartResponseSchema, res.data);
    return body;
  } catch (e) {
    throw e;
  }
};
