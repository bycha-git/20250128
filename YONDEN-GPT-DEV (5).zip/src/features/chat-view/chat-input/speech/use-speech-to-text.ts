import { io } from "socket.io-client";
import * as v from "valibot";
import { proxy, ref, useSnapshot } from "valtio";
import { chatStore } from "../../chat-store";
import { SpeechRecognizedSchema } from "./models";
import { fetchSpeechStart } from "./speech-start-api-client";
import { ErrorMessages } from "@/app/(authenticated)/errorMessageContext";
import { loadingOverlayStore } from "@/features/common/store/loading-overlay-store";
import { showError } from "@/features/globals/global-message-store";

const socket = io({ autoConnect: false });

type Offset = number;

/** 音声認識 */
class SpeechToText {
  public isMicrophoneUsed: boolean = false;
  public isMicrophoneReady: boolean = false;
  private oldInput: string = "";
  private oldInputCaretPosition: number = 0;
  /** オフセット (認識開始時刻) と文字列の組み合わせ */
  private recognizingTextMap: Map<Offset, string> = ref(new Map());
  private lastRecognizingOffset: number = 0;
  // 音声送信用
  private mediaStream: MediaStream | null = null;
  private audioContext: AudioContext | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private workletNode: AudioWorkletNode | null = null;

  /** 認識中のテキストを文字列として取得 */
  private getRecognizedText() {
    const sortedMap = new Map(
      [...this.recognizingTextMap.entries()].sort((a, b) => a[0] - b[0]),
    );
    return Array.from(sortedMap.values()).join("");
  }

  /** 認識イベントをテキストに反映 */
  private applyRecognizeEvent(
    offset: number,
    text: string,
    recognizing: boolean,
  ) {
    if (recognizing) {
      if (offset < this.lastRecognizingOffset) {
        // 認識途中でタイミングが手前にずれた場合、一番最後の認識結果を削除
        this.recognizingTextMap.delete(this.lastRecognizingOffset);
      }
      this.lastRecognizingOffset = offset;
    }
    this.recognizingTextMap.set(offset, text);

    const recognizedText = this.getRecognizedText();

    const oldInputStart = this.oldInput.slice(0, this.oldInputCaretPosition);
    const oldInputEnd = this.oldInput.slice(this.oldInputCaretPosition);
    const newInput = `${oldInputStart}${recognizedText}${oldInputEnd}`;
    chatStore.updateInput(newInput);
  }

  /** 音声認識開始 */
  public async startRecognition({
    input = "",
    inputCaretPosition,
    errorMessage,
  }: {
    input?: string;
    inputCaretPosition?: number | null;
    errorMessage: ErrorMessages;
  }) {
    loadingOverlayStore.startLoading();
    const startResult = await fetchSpeechStart();

    if (startResult.error) {
      console.error("Failed to fetchSpeechStart", startResult.error);
      showError(errorMessage["ECOMMON0001"]);
      return;
    }

    this.oldInput = input;
    this.oldInputCaretPosition = inputCaretPosition ?? input.length;

    if (!socket.connected) {
      socket.connect();
    }

    socket.emit("startRecognition");

    const started = async () => {
      console.log("started");

      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          audio: true,
        });
        this.mediaStream = ref(mediaStream);

        const audioContext = new AudioContext();
        this.audioContext = ref(audioContext);

        // AudioWorklet の読込
        await audioContext.audioWorklet.addModule(
          "/audio-processor.worklet.js",
        );

        const source = audioContext.createMediaStreamSource(this.mediaStream);
        this.source = ref(source);

        const workletNode = new AudioWorkletNode(
          audioContext,
          "audio-processor",
        );
        this.workletNode = ref(workletNode);

        // Worklet で処理した音声をサーバに送信
        workletNode.port.onmessage = (e) => {
          // e.data は ArrayBuffer
          socket.emit("audioData", { data: e.data });
        };

        // マイク音声をWorkletに接続
        source.connect(workletNode);
        workletNode.connect(audioContext.destination);

        this.isMicrophoneReady = true;
        this.isMicrophoneUsed = true;
        this.recognizingTextMap.clear();

        socket.on("recognizing", (unsafeData: unknown) => {
          try {
            const data = v.parse(SpeechRecognizedSchema, unsafeData);
            this.applyRecognizeEvent(data.offset, data.text, true);
          } catch {}
        });

        socket.on("recognized", (unsafeData: unknown) => {
          try {
            const data = v.parse(SpeechRecognizedSchema, unsafeData);
            this.applyRecognizeEvent(data.offset, data.text, false);
          } catch {}
        });

        socket.on("canceled", () => {
          showError(errorMessage["ECOMMON0001"]);
          this.disconnect();
        });
      } catch (error) {
        console.error("Error starting audio processing:", error);
        showError(errorMessage["ECOMMON0001"]);
        this.disconnect();
      } finally {
        loadingOverlayStore.stopLoading();
      }
    };

    socket.once("startRecognitionOk", () => {
      console.log("startRecognitionOk");
      started();
    });
  }

  /** 音声認識を停止 */
  public stopRecognition() {
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }

    try {
      if (this.workletNode) {
        this.workletNode.disconnect();
        this.workletNode = null;
      }
    } catch (e) {
      console.error(e);
    }

    try {
      if (this.source) {
        this.source.disconnect();
        this.source = null;
      }
    } catch (e) {
      console.error(e);
    }

    try {
      if (this.audioContext) {
        this.audioContext.close();
        this.audioContext = null;
      }
    } catch (e) {
      console.error(e);
    }

    if (socket.connected) {
      socket.emit("stopRecognition");
      this.isMicrophoneReady = false;
      socket.disconnect();
    }
  }

  public userDidUseMicrophone() {
    return this.isMicrophoneUsed;
  }

  public resetMicrophoneUsed() {
    this.isMicrophoneUsed = false;
  }

  public disconnect() {
    this.stopRecognition();
    socket.disconnect();
  }
}

export const speechToTextStore = proxy(new SpeechToText());

export const useSpeechToText = () => {
  return useSnapshot(speechToTextStore);
};
