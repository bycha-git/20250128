import * as v from "valibot";

export const SpeechStartResponseSchema = v.partial(
  v.object({
    error: v.string(),
  }),
);
export type SpeechStartResponse = v.InferInput<
  typeof SpeechStartResponseSchema
>;

export const SpeechRecognizedSchema = v.object({
  offset: v.number(),
  text: v.string(),
});

export type SpeechRecognized = v.InferInput<typeof SpeechRecognizedSchema>;
