"use client";

import React, { forwardRef, useMemo, useRef } from "react";
import { ModelWithParams } from "../chat-services/modelOrganizer";
import { chatStore, useChat } from "../chat-store";
import { AttachCamera } from "./chat-input-area/attach-camera";
import { AttachFile } from "./chat-input-area/attach-file";
import { AttachImage } from "./chat-input-area/attach-image";
import {
  ChatInputActionArea,
  ChatInputForm,
  ChatInputPrimaryActionArea,
  ChatInputSecondaryActionArea,
} from "./chat-input-area/chat-input-area";
import { ChatInputAttachments } from "./chat-input-area/chat-input-attachments";
import { ChatInputBox, ChatTextInput } from "./chat-input-area/chat-input-box";
import { Microphone } from "./chat-input-area/microphone";
import { SubmitChat } from "./chat-input-area/submit-chat";
import { PromptSlider } from "./prompt/prompt-slider";
import {
  speechToTextStore,
  useSpeechToText,
} from "./speech/use-speech-to-text";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { useResponsive } from "@/features/ui/responsive";

interface ChatInputProps {
  imageEnabled: boolean;
  cursorPosition: number | undefined;
  focusChatInputAndMoveCursorToTop: () => void;
  currentModel?: ModelWithParams;
}
export const ChatInput = forwardRef<HTMLTextAreaElement, ChatInputProps>(
  (
    {
      imageEnabled,
      cursorPosition,
      focusChatInputAndMoveCursorToTop,
      currentModel,
    }: ChatInputProps,
    ref,
  ) => {
    const { isMobile, isDesktop } = useResponsive();
    const { loading, input, attachmentsList } = useChat();
    const { isMicrophoneReady } = useSpeechToText();

    const submitButton = useRef<HTMLButtonElement>(null);
    const formRef = useRef<HTMLFormElement>(null);

    const disabledInput = isMicrophoneReady || loading === "loading";
    const inputCharCount = useMemo(() => [...input].length, [input]);
    const inputByteCount = useMemo(
      () => textEncoder.encode(input).byteLength,
      [input],
    );

    const submit = () => {
      if (formRef.current) {
        formRef.current.requestSubmit();
      }
    };
    const errMessage = useErrorMessage();

    return (
      <ChatInputForm
        ref={formRef}
        onSubmit={(e) => {
          e.preventDefault();
          chatStore.submitChat(e, errMessage);
        }}
        // TODO: 不要なら削除
        status={""}
      >
        {isDesktop && (
          <>
            <ChatInputBox>
              <fieldset disabled={disabledInput}>
                <ChatTextInput
                  disabled={disabledInput}
                  ref={ref}
                  onKeyDown={(e) => {
                    onKeyDown(e, submit);
                  }}
                  value={input}
                  onChange={(e) => {
                    chatStore.updateInput(e.currentTarget.value);
                  }}
                />
                <ChatInputAttachments />
              </fieldset>
            </ChatInputBox>
            <ChatInputActionArea>
              <ChatInputSecondaryActionArea>
                <Microphone
                  startRecognition={() =>
                    speechToTextStore.startRecognition({
                      input: input,
                      inputCaretPosition: cursorPosition,
                      errorMessage: errMessage,
                    })
                  }
                  stopRecognition={() => speechToTextStore.stopRecognition()}
                  isPlaying={false}
                  stopPlaying={() => {}}
                  isMicrophoneReady={isMicrophoneReady}
                />
                <div className="ml-1 content-center">
                  {inputCharCount + "文字 / " + inputByteCount + "バイト"}
                </div>
              </ChatInputSecondaryActionArea>
              <ChatInputPrimaryActionArea>
                <PromptSlider
                  disabled={disabledInput}
                  focusChatInputAndMoveCursorToTop={
                    focusChatInputAndMoveCursorToTop
                  }
                />
                <AttachImage
                  disabled={disabledInput || !imageEnabled}
                  accept={currentModel?.supportedImageExt}
                />
                <AttachFile
                  disabled={disabledInput}
                  accept={currentModel?.supportedFileExt}
                />
                <SubmitChat
                  ref={submitButton}
                  disabled={
                    disabledInput ||
                    (input.length < 1 && attachmentsList.length < 1)
                  }
                />
              </ChatInputPrimaryActionArea>
            </ChatInputActionArea>
          </>
        )}

        {isMobile && (
          <ChatInputActionArea>
            <ChatInputPrimaryActionArea>
              <AttachImage
                disabled={disabledInput || !imageEnabled}
                accept={currentModel?.supportedImageExt}
              />
              <AttachFile
                disabled={disabledInput}
                accept={currentModel?.supportedFileExt}
              />
              <AttachCamera disabled={disabledInput || !imageEnabled} />
            </ChatInputPrimaryActionArea>
            <ChatInputBox>
              <div className="flex-row items-end">
                <fieldset
                  disabled={disabledInput}
                  className="flex-grow flex-row"
                >
                  <ChatInputAttachments />
                </fieldset>
                <div className="flex items-end">
                  <ChatTextInput
                    disabled={disabledInput}
                    ref={ref}
                    onKeyDown={(e) => {
                      onKeyDown(e, submit);
                    }}
                    value={input}
                    onChange={(e) => {
                      chatStore.updateInput(e.currentTarget.value);
                    }}
                  />
                  <Microphone
                    startRecognition={() =>
                      speechToTextStore.startRecognition({
                        input: input,
                        inputCaretPosition: cursorPosition,
                        errorMessage: errMessage,
                      })
                    }
                    stopRecognition={() => speechToTextStore.stopRecognition()}
                    isPlaying={false}
                    stopPlaying={() => {}}
                    isMicrophoneReady={isMicrophoneReady}
                  />
                </div>
              </div>
            </ChatInputBox>
            <ChatInputSecondaryActionArea>
              {!(
                disabledInput ||
                (input.length < 1 && attachmentsList.length < 1)
              ) && (
                <SubmitChat
                  ref={submitButton}
                  disabled={
                    disabledInput ||
                    (input.length < 1 && attachmentsList.length < 1)
                  }
                />
              )}
            </ChatInputSecondaryActionArea>
          </ChatInputActionArea>
        )}
      </ChatInputForm>
    );
  },
);

ChatInput.displayName = "ChatInput";

export const onKeyDown = (
  event: React.KeyboardEvent<HTMLTextAreaElement>,
  submit: () => void,
) => {
  // キーボードで送信のトリガー: Ctrl + Enter
  if (
    !event.nativeEvent.isComposing &&
    event.key === "Enter" &&
    event.ctrlKey
  ) {
    submit();
    event.preventDefault();
  }
};

const textEncoder = new TextEncoder();
