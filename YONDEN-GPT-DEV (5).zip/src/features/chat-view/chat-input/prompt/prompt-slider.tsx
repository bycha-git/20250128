"use client";

import { FC } from "react";
import { inputPromptStore, useInputPromptState } from "./input-prompt-store";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/features/ui/card";
import { Input } from "@/features/ui/input";
import { LoadingIndicator } from "@/features/ui/loading";
import { ScrollArea } from "@/features/ui/scroll-area";
import { Button } from "@/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/ui/sheet";

type Props = {
  disabled?: boolean;
  focusChatInputAndMoveCursorToTop: () => void;
};

export const PromptSlider: FC<Props> = (props) => {
  const { templates, isLoading, isOpened, searchInput, viewMore } =
    useInputPromptState();
  const errMessage = useErrorMessage();

  return (
    <Sheet
      open={isOpened}
      onOpenChange={(value) => {
        inputPromptStore.updateOpened(value);
      }}
    >
      <SheetTrigger asChild>
        <Button
          disabled={props.disabled}
          type="button"
          variant="ghost"
          size="auto"
          onClick={() => inputPromptStore.openPrompt(errMessage)}
          aria-label="プロンプトテンプレート"
          className="aspect-square h-max w-max"
          title="テンプレートから入力"
        >
          <span className="i-material-symbols-book-2-outline-rounded size-6 md:size-8" />
        </Button>
      </SheetTrigger>

      <SheetContent
        className="flex w-[30rem] max-w-[80vw] flex-col p-3 md:p-6"
        onCloseAutoFocus={(event) => {
          event.preventDefault();
          props.focusChatInputAndMoveCursorToTop();
        }}
      >
        <SheetHeader className="text-left">
          <SheetTitle className="text-base md:text-lg">
            プロンプトテンプレート
          </SheetTitle>
        </SheetHeader>
        <Input
          className="w-full"
          icon="i-material-symbols-search-rounded"
          text={searchInput}
          onInputText={(value) => inputPromptStore.updateSearchInput(value)}
        />
        <ScrollArea className="-mx-3 flex flex-1 md:-mx-6">
          <div className="whitespace-pre-wrap px-6 pb-6">
            <SheetDescription>
              {/* {!isLoading && prompts.length === 0 ? "There are no prompts" : ""} */}
              {""}
            </SheetDescription>
            <LoadingIndicator isLoading={isLoading} />
            {templates.map((prompt) => (
              <Card
                key={prompt.id}
                className="mt-2 flex cursor-pointer flex-col hover:bg-secondary/80"
                onClick={() =>
                  inputPromptStore.selectTemplate(prompt, errMessage)
                }
                title={prompt.templateName}
              >
                <CardHeader className="flex flex-row p-3 md:p-4">
                  <CardTitle className="flex-1 truncate text-base md:text-lg">
                    {prompt.templateName}
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex-1 p-3 pt-0 text-xs text-muted-foreground md:p-4 md:pt-0 md:text-base">
                  <div className="line-clamp-[10]">{prompt.template}</div>
                </CardContent>
              </Card>
            ))}
          </div>
          {viewMore.visible && (
            <Button
              className="mx-auto w-[90%]"
              variant="more"
              onClick={() => inputPromptStore.handleViewMore(errMessage)}
            >
              もっと見る
            </Button>
          )}
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
};
