import { debounce } from "es-toolkit";
import { proxy, ref, useSnapshot } from "valtio";
import { ensureUseTemplate } from "../../chat-services/chat-template-actions";
import { chatStore } from "../../chat-store";
import { ErrorMessages } from "@/app/(authenticated)/errorMessageContext";
import { type TemplateModel } from "@/features/common/model/history/template-model";
import { loadingOverlayStore } from "@/features/common/store/loading-overlay-store";
import { showError } from "@/features/globals/global-message-store";
import {
  fetchPrompts,
  ViewMore,
} from "@/features/prompt-template-page/Prompt-service";

/** 初回表示件数 */
const FIRST_VIEW_COUNT = 20;

const defaultViewMore: ViewMore = {
  viewCount: FIRST_VIEW_COUNT,
  visible: false,
};

class InputPromptState {
  public templates: Array<TemplateModel> = [];
  public isOpened: boolean = false;
  public isLoading: boolean = false;
  public searchInput: string = "";
  public viewMore: ViewMore = defaultViewMore;
  private debouncedFind: ReturnType<typeof debounce> | undefined = undefined;
  /** 最後の検索以外を無視するための値 */
  // TODO: 検索キャンセルを実装 (api)
  private lastFindTime: number = 0;

  /** 取得実行 */
  public async find(errMessage: ErrorMessages) {
    this.isLoading = true;
    const findTime = Date.now();
    this.lastFindTime = findTime;
    const response = await fetchPrompts(
      {
        text: this.searchInput,
        // 全権限
        tab: -1,
        sort: "更新日順",
      },
      this.viewMore,
    );
    if (this.lastFindTime !== findTime) return;

    this.isLoading = false;

    const templatesResponse = response?.promptsResponse;
    const templates = templatesResponse?.response;
    const viewMore = response?.viewMore;
    if (!templates || !viewMore) {
      showError(errMessage["ECOMMON0001"]);
      return;
    }

    this.templates = templates;
    this.viewMore = viewMore;
  }

  /** プロンプトテンプレート選択画面を開く */
  public async openPrompt(errMessage: ErrorMessages) {
    this.isOpened = true;
    this.searchInput = "";
    this.viewMore = defaultViewMore;
    this.templates = [];
    this.debouncedFind?.cancel();
    this.debouncedFind = ref(
      debounce(() => {
        this.viewMore = defaultViewMore;
        this.find(errMessage);
      }, 100),
    );

    this.find(errMessage);
  }

  /** 開閉状態を変更 (主に閉じるのに利用) */
  public updateOpened(value: boolean) {
    if (this.isOpened !== value) {
      this.isOpened = value;
      this.debouncedFind?.cancel();
    }
  }

  /** プロンプトテンプレート選択 */
  public async selectTemplate(
    template: TemplateModel,
    errMessage: ErrorMessages,
  ) {
    loadingOverlayStore.startLoading();
    try {
      // プロンプトテンプレートを使用
      const newTemplateResponse = await ensureUseTemplate({
        templateId: template.id,
      });
      if (newTemplateResponse.status !== "OK") {
        if (newTemplateResponse.errors[0].message === "ETEMPLATE0001") {
          showError(errMessage["EHOME0004"]);
        } else if (newTemplateResponse.errors[0].message === "ETEMPLATE0002") {
          showError(errMessage["EHOME0003"]);
        } else {
          showError(errMessage["ECOMMON0001"]);
        }
        return;
      }
      const newTemplate = newTemplateResponse.response.template;

      chatStore.updateInput(
        newTemplate.template.replace(/\n$/, "") + "\n" + chatStore.input,
      );
    } finally {
      this.isOpened = false;
      loadingOverlayStore.stopLoading();
    }
  }

  /** 検索文字列を更新。検索の実行を予約 */
  public updateSearchInput(value: string) {
    if (this.searchInput !== value) {
      this.searchInput = value;
      this.debouncedFind?.();
    }
  }

  /** [もっと見る]ボタン押下時処理 */
  public async handleViewMore(errMessage: ErrorMessages) {
    this.viewMore = {
      ...this.viewMore,
      viewCount: this.viewMore.viewCount + FIRST_VIEW_COUNT,
    };
    this.debouncedFind?.cancel();
    await this.find(errMessage);
  }
}

export const inputPromptStore = proxy(new InputPromptState());

export const useInputPromptState = () => {
  return useSnapshot(inputPromptStore, {
    sync: true,
  });
};
