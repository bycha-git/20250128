"use client";

import { FC } from "react";
import { Attach } from "./attach";

type Props = {
  disabled?: boolean;
};

export const AttachCamera: FC<Props> = (props) => {
  return (
    <Attach
      disabled={props.disabled}
      type="image"
      label="画像を追加"
      capture
      // Android Chrome では、accept=".jpg" 形式だとカメラ画面にならない
      // accept="image/*" または "image/jpeg" であれば Android Chrome, iOS Safari 共にカメラになる
      accept={"image/jpeg"}
      className="i-material-symbols-photo-camera-outline-rounded size-6 md:size-8"
    />
  );
};
