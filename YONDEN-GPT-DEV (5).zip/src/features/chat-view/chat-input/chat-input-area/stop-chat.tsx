import { Button } from "@/features/ui/button";

export const StopChat = (props: { stop: () => void }) => {
  return (
    <Button
      type="submit"
      variant="ghost"
      size="auto"
      onClick={() => props.stop()}
      aria-label="Stop speech readout"
    >
      <span className="i-lucide-square size-6 md:size-8" />
    </Button>
  );
};
