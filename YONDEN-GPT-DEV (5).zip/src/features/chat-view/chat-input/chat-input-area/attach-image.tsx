"use client";

import { FC } from "react";
import { Attach } from "./attach";
import { useHomeEnvContext } from "@/features/chat-menu/home-env-context";

type Props = {
  disabled?: boolean;
  accept?: string;
};

export const AttachImage: FC<Props> = (props) => {
  const { supportedImageExt } = useHomeEnvContext();

  return (
    <Attach
      disabled={props.disabled}
      type="image"
      label="画像を追加"
      accept={props.accept ?? supportedImageExt}
      className="i-material-symbols-imagesmode-outline-rounded size-6 md:size-8"
      title="画像を添付する"
    />
  );
};
