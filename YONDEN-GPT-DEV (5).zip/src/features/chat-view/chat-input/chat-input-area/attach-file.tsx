"use client";

import { FC } from "react";
import { Attach } from "./attach";
import { useHomeEnvContext } from "@/features/chat-menu/home-env-context";

type Props = {
  disabled?: boolean;
  accept?: string;
};

export const AttachFile: FC<Props> = (props) => {
  const { supportedFileExt } = useHomeEnvContext();

  return (
    <Attach
      disabled={props.disabled}
      type="file"
      label="添付ファイルを追加"
      accept={props.accept ?? supportedFileExt}
      className="i-material-symbols-attach-file-rounded size-6 md:size-8"
      title="ファイルを添付する"
    />
  );
};
