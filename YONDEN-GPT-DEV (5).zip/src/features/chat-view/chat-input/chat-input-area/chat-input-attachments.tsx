import { useCallback } from "react";
import { chatStore, useChat } from "../../chat-store";
import { LocalAttachment } from "../../models";
import { Button } from "@/features/ui/button";
import { ChatMessageAttachment } from "@/features/ui/chat/chat-message-attachment";

export const ChatInputAttachments = () => {
  const { attachmentsList } = useChat();

  return (
    <div className="flex max-h-40 flex-wrap overflow-auto">
      {attachmentsList.map((attachment, index) => (
        <Attachment attachment={attachment} key={index} />
      ))}
    </div>
  );
};

const Attachment = ({ attachment }: { attachment: LocalAttachment }) => {
  const { name, type } = attachment;
  const handleRemove = useCallback(() => {
    chatStore.removeAttachment(name);
  }, [name]);

  return (
    <ChatMessageAttachment name={name} type={type}>
      <Button variant="ghost" size="auto" onClick={handleRemove}>
        <div className="i-material-symbols-close-small-rounded relative h-6 w-6 rounded-md" />
      </Button>
    </ChatMessageAttachment>
  );
};
