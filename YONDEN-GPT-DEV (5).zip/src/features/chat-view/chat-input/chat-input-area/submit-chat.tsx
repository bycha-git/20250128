import React, { forwardRef } from "react";
import { Button } from "@/features/ui/button";

export const SubmitChat = forwardRef<
  HTMLButtonElement,
  React.ButtonHTMLAttributes<HTMLButtonElement> // Add ChatInputAreaProps to the type definition
>(({ ...props }, ref) => (
  <Button
    type="submit"
    variant="ghost"
    size="auto"
    {...props}
    ref={ref}
    aria-label="Submit chat input"
    className="aspect-square h-max w-max"
    title="メッセージを送信"
  >
    <span className="i-tabler-send size-6 md:size-8" />
  </Button>
));
SubmitChat.displayName = "SubmitChat";
