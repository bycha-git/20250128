"use client";

import { FC, useRef } from "react";
import { chatStore } from "../../chat-store";
import { Button } from "@/features/ui/button";
import { cn } from "@/features/ui/lib";

type Props = {
  disabled?: boolean | undefined;
  className?: string | undefined;
  /** 添付ファイルか画像か (アイコン等の分岐に使用) */
  type: "file" | "image";
  /** スクリーンリーダ用ラベル */
  label: string;
  /** 取込可能なファイル形式 (accept属性に使用) */
  accept?: string | undefined;
  /** trueなら、押下時すぐにカメラを起動 (capture属性に使用) */
  capture?: boolean | undefined;
  /** ツールチップ表示用 */
  title?: string;
};

export const Attach: FC<Props> = (props) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleClick = () => {
    const fileInput = fileInputRef.current;
    fileInput?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      for (const file of files) {
        let newFile = file;

        if (props.capture) {
          // 連続写真アップロード時のファイル名被りによる上書きを防止するため
          // ファイル名を日時に変更
          // (Safari では "image.jpg" という固定値なため)
          const extension = file.name.split(".").pop();
          const fileName = `img_${generateDateTimeForFileName()}.${extension}`;
          newFile = new File([file], fileName, { type: file.type });
        }

        chatStore.addAttachment(newFile, props.type);
      }
      // TODO: これ AzureChat にあったけど効かないのでは
      event.target.value = "";
    }
  };

  return (
    <>
      <Button
        disabled={props.disabled}
        size="auto"
        variant={"ghost"}
        onClick={handleClick}
        type="button"
        aria-label={props.label}
        className="aspect-square size-max"
        title={props.title}
      >
        <span className={cn(props.className)} />
      </Button>
      <input
        type="file"
        accept={props.accept}
        // iOS 18.1.1 Safari, Android Chrome 131 で動作確認済
        capture={props.capture}
        ref={fileInputRef}
        className="hidden"
        onChange={handleFileChange}
        multiple
      />
    </>
  );
};

/** ファイル名用の日時文字列を生成 */
const generateDateTimeForFileName = () => {
  const date = new Date();
  const YYYY = date.getFullYear();
  const MM = String(date.getMonth() + 1).padStart(2, "0");
  const DD = String(date.getDate()).padStart(2, "0");
  const HH = String(date.getHours()).padStart(2, "0");
  const mm = String(date.getMinutes()).padStart(2, "0");
  const ss = String(date.getSeconds()).padStart(2, "0");
  return `${YYYY}${MM}${DD}_${HH}${mm}${ss}`;
};
