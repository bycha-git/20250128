"use client";

import React, { forwardRef } from "react";
import TextareaAutosize, {
  TextareaAutosizeProps,
} from "react-textarea-autosize";

export const ChatTextInput = forwardRef<
  HTMLTextAreaElement,
  TextareaAutosizeProps
>(({ ...props }, ref) => {
  return (
    <TextareaAutosize
      minRows={1}
      maxRows={6}
      ref={ref}
      className="w-full resize-none bg-transparent px-2 py-1 focus:outline-none md:p-4"
      placeholder="メッセージを入力"
      {...props}
    />
  );
});
ChatTextInput.displayName = "ChatTextInput";

export const ChatInputBox = (props: { children?: React.ReactNode }) => {
  return (
    <div className="mx-1 flex-grow overflow-hidden rounded-md border bg-background/70 backdrop-blur-xl focus-within:border-primary md:mx-0">
      {props.children}
    </div>
  );
};
