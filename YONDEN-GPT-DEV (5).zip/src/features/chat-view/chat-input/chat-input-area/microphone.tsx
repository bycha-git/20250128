import { Button } from "@/features/ui/button";

export const Microphone = (props: {
  isPlaying: boolean;
  isMicrophoneReady: boolean;
  stopPlaying: () => void;
  startRecognition: () => void;
  stopRecognition: () => void;
}) => {
  const startRecognition = () => {
    props.startRecognition();
  };

  const stopRecognition = () => {
    props.stopRecognition();
  };

  return (
    <>
      {props.isPlaying ? (
        <Button
          type="button"
          variant="ghost"
          size="auto"
          onClick={props.stopPlaying}
        >
          <span className="i-lucide-square size-6 md:size-8" />
        </Button>
      ) : (
        <Button
          type="button"
          variant="ghost"
          size="auto"
          onClick={props.isMicrophoneReady ? stopRecognition : startRecognition}
          aria-label="Microphone for speech input"
          className="aspect-square h-max w-max"
          title={props.isMicrophoneReady ? "音声入力を終了" : "音声で入力"}
        >
          {props.isMicrophoneReady && (
            <span className="i-material-symbols-mic-off size-6 md:size-8" />
          )}
          {!props.isMicrophoneReady && (
            <span className="i-material-symbols-mic size-6 md:size-8" />
          )}
        </Button>
      )}
    </>
  );
};
