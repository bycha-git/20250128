import axios, { AxiosProgressEvent } from "axios";
import { ChatAPIContent } from "./models";
import { loadingOverlayStore } from "@/features/common/store/loading-overlay-store";

export const fetchChat = async (
  content: ChatAPIContent,
  files: File[],
  abortController: AbortController,
) => {
  const formData = new FormData();

  // 必ず content を先に追加しておく
  formData.append("content", JSON.stringify(content));
  for (const file of files) {
    formData.append("file", file);
  }

  if (files.length) {
    loadingOverlayStore.startLoading("アップロード中");
  }

  // fetch だとアップロード進捗を取れないため XMLHTTPRequest (axios) を使用
  try {
    const res = await axios.post(
      "/api/chat-send/" + content.message.threadId,
      formData,
      {
        signal: abortController.signal,
        // デフォルトでは、 4xx でも reject される
        // 今回は 400 でエラーコードを返しているので reject しない
        validateStatus: (status) => status < 500,
        onUploadProgress(progressEvent) {
          console.log(
            "uploading:",
            progressEvent.loaded,
            "/",
            progressEvent.total,
            "bytes",
          );
          if (files.length) {
            if (progressEvent.loaded === progressEvent.total) {
              loadingOverlayStore.stopLoading();
            }
            loadingOverlayStore.updateLoadingMessage(
              getProgressMessage(progressEvent),
            );
          }
        },
        responseType: "json",
      },
    );
    return res;
  } catch (e) {
    throw e;
  } finally {
    loadingOverlayStore.stopLoading();
  }
};

const getProgressMessage = (progress: AxiosProgressEvent) => {
  if (!progress.total || progress.loaded === progress.total) {
    return "";
  }
  return `アップロード中 (${toMB(progress.loaded)} / ${toMB(progress.total)})`;
};

const toMB = (bytes: number) => {
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
};
