import "server-only";

import { ReadableStream as NodeReadableStream } from "node:stream/web";
import { Readable } from "stream";
import { Busboy } from "@fastify/busboy";
import { NextRequest, NextResponse } from "next/server";
import { uploadChatAttachmentFileStreamToStore } from "../attachment/attachment-file";
import { getAttachmentModel } from "../attachment/chat-attachment-service";
import { createChatMessageModel } from "../chat-message-service";
import {
  findIsModelEnabledById,
  findModelWithFuncInfoByID,
} from "../chat-model-service";
import { ensureThreadOperation } from "../chat-thread-service";
import { ChatAPIContent, ChatAPIContentSchema } from "./models";
import { userSession } from "@/features/auth-page/helpers";
import {
  FindChatbotByID,
  modelCheckForChatbot,
} from "@/features/chatbot-page/Chatbot-service";
import {
  getDefaultAPIBadRequestErrorResponse,
  getDefaultAPIErrorMessageIdResponse,
  getDefaultAPIServerErrorResponse,
  getDefaultAPIUnauthorizedErrorResponse,
} from "@/features/common/api-helpers";
import { bulkUpsertHistory } from "@/features/common/bulk/history-bulk-operation";
import {
  CHATBOT_THREAD_ATTRIBUTE,
  MODEL_THREAD_ATTRIBUTE,
  ThreadModel,
} from "@/features/common/model/history/thread-model";
import { FindSelectAuthorityCompanyByID } from "@/features/common/services/authority-company-service";
import { FindSelectAuthorityEmployeeByID } from "@/features/common/services/authority-employee-service";
import { runAzureFuncChat } from "@/features/common/services/azure-functions";
import { FindEmployeeByID } from "@/features/common/services/employee-service";
import { uniqueId } from "@/features/common/util";
import { UserData } from "@/types/next-auth";

export const chatAPIEntry = async (
  req: NextRequest,
  params: { threadID: string },
) => {
  console.log("/api/chat-send");
  console.log("request content-length:", req.headers.get("content-length"));

  const user = await userSession();
  if (!user) {
    // middleware を使わないので手動認証
    return getDefaultAPIUnauthorizedErrorResponse();
  }

  const threadId = params.threadID ?? "";

  try {
    return await chatAPI(user, threadId, req, req.signal);
  } catch (e) {
    const error = e instanceof Error ? e : new Error(String(e));
    console.error("🔴 Error on chatAPI:", error);
    return getDefaultAPIServerErrorResponse();
  }
};

const chatAPI = async (
  user: Required<UserData>,
  threadId: string,
  req: NextRequest,
  signal: AbortSignal,
) => {
  const userId = user.id;

  const currentChatThreadResponse = await ensureThreadOperation(threadId);
  if (currentChatThreadResponse.status !== "OK") {
    // TODO: エラーコード
    return getDefaultAPIUnauthorizedErrorResponse();
  }
  const currentChatThread = currentChatThreadResponse.response;

  // スレッドのモデル使用可否チェック
  if (currentChatThread.type === MODEL_THREAD_ATTRIBUTE) {
    const modelId = currentChatThread.modelId;

    // スレッドのモデル使用不可フラグ有無取得
    const isModelEnabledResponse = await findIsModelEnabledById(modelId);
    if (isModelEnabledResponse.status !== "OK") {
      console.error(
        "🔴 モデル使用可否取得エラー:",
        isModelEnabledResponse.errors,
      );
      return getDefaultAPIServerErrorResponse();
    }
    const isModelEnabled = isModelEnabledResponse.response;
    if (!isModelEnabled) {
      // 使用不可
      return getDefaultAPIErrorMessageIdResponse("EHOME0001");
    }
  }

  // チャットボットの存在/権限チェック
  if (currentChatThread.type === CHATBOT_THREAD_ATTRIBUTE) {
    const chatbotId = currentChatThread.chatbotId;

    // チャットボットの存在チェック
    const chatbotResponse = await FindChatbotByID(chatbotId);
    if (
      !chatbotResponse ||
      chatbotResponse.status !== "OK" ||
      !chatbotResponse.response
    ) {
      // 該当データ無し
      return getDefaultAPIErrorMessageIdResponse("EHOME0002");
    }
    const chatbot = chatbotResponse.response;

    // チャットボットの権限チェック

    // ユーザ情報取得
    const employeeResponse = await FindEmployeeByID(userId);
    if (
      !employeeResponse ||
      employeeResponse.status !== "OK" ||
      !employeeResponse.response
    ) {
      console.error("🔴 ユーザ情報取得エラー:", employeeResponse.errors);
      return getDefaultAPIServerErrorResponse();
    }
    const employee = employeeResponse.response;

    // ユーザ/組織のチャットボット閲覧権限確認
    const [employeeAuthority, companyAuthority] = await Promise.all([
      FindSelectAuthorityEmployeeByID(chatbotId, userId),
      FindSelectAuthorityCompanyByID(
        employee.department_code_8 ?? "",
        chatbotId,
      ),
    ]);
    if (
      employeeAuthority.status === "ERROR" ||
      companyAuthority.status === "ERROR"
    ) {
      console.error("🔴 チャットボット権限取得エラー");
      return getDefaultAPIServerErrorResponse();
    }
    if (
      employeeAuthority.status === "NOT_FOUND" &&
      companyAuthority.status === "NOT_FOUND"
    ) {
      // 組織/ユーザーともに権限なし
      return getDefaultAPIErrorMessageIdResponse("EHOME0003");
    }

    // チャットボットで指定しているモデルの使用可否チェック
    const modelCheckResult = await modelCheckForChatbot(chatbot.modelId);
    if (!modelCheckResult.check) {
      // 使用不可
      return getDefaultAPIErrorMessageIdResponse("EHOME0001");
    }
  }

  // メッセージと添付ファイルの読込開始
  return await new Promise((resolve, reject) => {
    try {
      chatAPIReadFormData({
        req,
        threadId,
        userId,
        currentChatThread,
        resolve,
        signal,
      });
    } catch (e) {
      reject(e instanceof Error ? e : new Error(String(e)));
    }
  });
};

const chatAPIReadFormData = ({
  req,
  threadId,
  userId,
  currentChatThread,
  resolve,
  signal,
}: {
  req: NextRequest;
  threadId: string;
  userId: string;
  currentChatThread: ThreadModel;
  resolve: (value: NextResponse) => void;
  signal: AbortSignal;
}): void => {
  const body = req.body;
  if (!(body instanceof NodeReadableStream)) {
    throw new Error("req.body is not a ReadableStream from node:stream/web");
  }
  const inputStream: NodeReadableStream = body;
  const readable = Readable.fromWeb(inputStream);

  const messageId = uniqueId();
  let content: ChatAPIContent | undefined = undefined;
  type Attachment = {
    id: string;
    fileName: string;
    type: "file" | "image";
    uploading: boolean;
    uploaded: boolean;
  };
  let attachments: Attachment[] = [];
  const attachmentsMapByFileName = new Map<string, Attachment>();

  // multipart/form-data のパースをストリーミングで行う
  const busboy = new Busboy({
    headers: {
      "content-type": req.headers.get("content-type") ?? "",
    },
  });

  signal.addEventListener("abort", (): void => {
    console.log("🔴 chatAPIReadFormData: abort");
    busboy.removeAllListeners();
    resolve(getDefaultAPIBadRequestErrorResponse());
  });

  busboy.on("field", (fieldname, value): void => {
    console.log("📄 field:", fieldname);
    if (fieldname === "content") {
      // ここでは、同期処理のみ行うこと
      // (非同期処理を行うと、 file に先を越される可能性がある)
      const unsafeContentJson = value;
      if (!unsafeContentJson || typeof unsafeContentJson !== "string") {
        console.error("🔴 content が文字列でない");
        busboy.removeAllListeners();
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }

      try {
        const unsafeContent: unknown = JSON.parse(unsafeContentJson);
        content = ChatAPIContentSchema.parse(unsafeContent);
      } catch (e) {
        console.error("🔴 content のパース失敗:", e);
        busboy.removeAllListeners();
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }

      attachments = content.attachmentsInfo.map((attachmentInfo) => {
        const { name, type } = attachmentInfo;
        const attachment = {
          id: uniqueId(),
          fileName: name,
          type,
          uploading: false,
          uploaded: false,
        };
        attachmentsMapByFileName.set(name, attachment);
        return attachment;
      });
    }
  });

  busboy.on(
    "file",
    (fieldname, readable, filename, encoding, mimetype): void => {
      console.log("📁 file:", fieldname, filename, mimetype);
      if (fieldname !== "file") {
        console.error("🔴 content, file 以外のパラメータを検出");
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }
      if (!content) {
        console.error("🔴 content より先に file を検出");
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }
      const attachment = attachmentsMapByFileName.get(filename);
      if (!attachment) {
        console.error("🔴 content に存在しない file を検出");
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }
      if (attachment.uploading || attachment.uploaded) {
        console.error("🔴 重複した file を検出");
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }
      attachment.uploading = true;
      uploadChatAttachmentFileStreamToStore(
        {
          threadId,
          messageId,
          fileName: filename,
        },
        readable,
        mimetype,
      )
        .then(() => {
          console.log("📤 file uploaded:", filename);
          attachment.uploading = false;
          attachment.uploaded = true;

          const allUploaded = attachments.every((a) => a.uploaded);
          if (allUploaded) {
            console.log("🏁 ファイルアップロード完了");
            finalize();
          }
        })
        .catch((e) => {
          console.error("🔴 Error on uploading file:", e);
          resolve(getDefaultAPIServerErrorResponse());
        });
    },
  );

  busboy.on("finish", (): void => {
    console.log("🏁 finish");
    if (!content) {
      console.error("🔴 content が存在しない");
      resolve(getDefaultAPIBadRequestErrorResponse());
      return;
    }
    const allUploadedOrUploading = attachments.every(
      (a) => a.uploaded || a.uploading,
    );
    if (!allUploadedOrUploading) {
      console.error("🔴 ファイル不足");
      resolve(getDefaultAPIBadRequestErrorResponse());
      return;
    }
    // attachments が存在しない場合そのまま終了
    if (attachments.length === 0) {
      finalize();
    }
  });

  /** メッセージを作成 */
  const finalize = async (): Promise<void> => {
    if (!content) {
      console.error("🔴 content より先に終了を検出");
      resolve(getDefaultAPIBadRequestErrorResponse());
      return;
    }

    const { message } = content;
    const attachmentsOnlyUploaded = attachments.filter(
      (attachment) => attachment.uploaded,
    );

    if (attachmentsOnlyUploaded.length !== content.attachmentsInfo.length) {
      console.error(
        "🔴 attachmentsInfo と実際のファイル数の差を検出",
        attachmentsOnlyUploaded,
        content.attachmentsInfo,
      );
      resolve(getDefaultAPIBadRequestErrorResponse());
      return;
    }

    // 送信日時
    const createdAt = new Date().toISOString();

    // ユーザのメッセージを保存
    const messageModel = createChatMessageModel({
      userId,
      messageId,
      createdAt,
      content: message.content,
      role: "user",
      chatThreadId: threadId,
      chatbotId: message.chatbotId,
      modelId: message.modelId,
    });
    const attachmentModels = attachmentsOnlyUploaded.map(
      (attachment, index) => {
        const { id, fileName, type } = attachment;
        return getAttachmentModel({
          userId,
          id,
          createdAt,
          messageId,
          fileName,
          type,
          sortNo: index + 1,
        });
      },
    );
    const newThreadModel = {
      ...currentChatThread,
      lastMessageAt: createdAt,
    };

    await bulkUpsertHistory([
      messageModel,
      ...attachmentModels,
      newThreadModel,
    ]);

    let functionsUrl: string | undefined;
    let accessKey: string | undefined;
    if (currentChatThread.type === MODEL_THREAD_ATTRIBUTE) {
      // モデルの場合

      // モデルを取得
      const modelResponse = await findModelWithFuncInfoByID(
        currentChatThread.modelId,
      );
      if (modelResponse.status !== "OK") {
        console.error(modelResponse.errors[0].message);
        resolve(
          getDefaultAPIServerErrorResponse(modelResponse.errors[0].message),
        );
        return;
      }
      const modelWithFuncInfo = modelResponse.response;

      functionsUrl = modelWithFuncInfo.functionsUrl;
      accessKey = modelWithFuncInfo.accessKey;

      if (!functionsUrl || !accessKey) {
        console.error(
          `🔴 モデル ${currentChatThread.modelId} の functionsUrl, accessKey が指定されていません`,
        );
      }
    } else {
      // チャットボット

      functionsUrl = process.env.AZURE_FUNCTIONS_CHATBOT_URL;
      accessKey = process.env.AZURE_FUNCTIONS_CHATBOT_KEY;

      if (!functionsUrl || !accessKey) {
        console.error(
          "🔴 AZURE_FUNCTIONS_CHATBOT_URL, AZURE_FUNCTIONS_CHATBOT_KEY が指定されていません",
        );
      }
    }

    if (functionsUrl && accessKey) {
      // Azure Function にリクエスト
      const azureFuncRequest = {
        messageId,
        threadId: currentChatThread.id,
      };
      const azureFuncResponse = await runAzureFuncChat({
        request: azureFuncRequest,
        funcInfo: { functionsUrl, accessKey },
      });
      if (azureFuncResponse.status !== "OK") {
        resolve(
          getDefaultAPIServerErrorResponse(azureFuncResponse.errors[0].message),
        );
      }
    } else {
      // TODO: 有効化
      // resolve(getDefaultAPIServerErrorResponse());
      // return;
    }

    resolve(
      new NextResponse(`{"status":"OK"}`, {
        headers: {
          "Cache-Control": "no-store",
          "Content-Type": "application/json",
          // Connection: "keep-alive",
          // "Content-Type": "text/event-stream",
        },
      }),
    );
  };

  busboy.on("error", (err) => {
    console.error("🔴 busboyエラー:", err);
    resolve(getDefaultAPIServerErrorResponse(String(err)));
  });

  readable.pipe(busboy);
};
