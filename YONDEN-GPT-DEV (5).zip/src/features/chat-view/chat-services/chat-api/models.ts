import { z } from "zod";
import { MessageModelSchema } from "@/features/common/model/history/message-model";

/** チャットメッセージ送信時 添付ファイル情報 */
export const ChatAPIContentAttachmentInfoSchema = z.object({
  /** ファイル名 */
  name: z.string(),
  /** 添付ファイルタイプ */
  type: z.enum(["file", "image"]),
});

/** チャットメッセージ送信情報 */
export const ChatAPIContentSchema = z.object({
  /** メッセージ内容 */
  message: MessageModelSchema,
  /** 添付ファイル情報 */
  attachmentsInfo: z.array(ChatAPIContentAttachmentInfoSchema),
});

/** チャットメッセージ送信時 添付ファイル情報 */
export type ChatAPIContentAttachmentInfo = z.infer<
  typeof ChatAPIContentAttachmentInfoSchema
>;
/** チャットメッセージ送信情報 */
export type ChatAPIContent = z.infer<typeof ChatAPIContentSchema>;
