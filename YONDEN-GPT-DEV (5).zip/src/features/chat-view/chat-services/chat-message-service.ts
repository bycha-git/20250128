import "server-only";

import { SqlQuerySpec } from "@azure/cosmos";
import { HistoryContainer } from "../../common/services/cosmos";
import { MessageWithServerAttachments } from "../models";
import { findAttachmentsAndMergeByMessagesForCurrentUser } from "./attachment/chat-attachment-service";
import { userHashedId } from "@/features/auth-page/helpers";
import { IDSchema } from "@/features/common/model/common";
import {
  MESSAGE_ATTRIBUTE,
  MessageModel,
  MessageModelSchema,
  MessageRole,
} from "@/features/common/model/history/message-model";
import { getOnlyParsed } from "@/features/common/schema-validation";
import { ServerActionResponse } from "@/features/common/server-action-response";
import { uniqueId } from "@/features/common/util";

/** スレッドから最新 n 件のメッセージを取得 */
// TODO: 使ってないなら消す
export const findTopChatMessagesForCurrentUser = async (
  chatThreadID: string,
  top: number = 30,
): Promise<ServerActionResponse<Array<MessageModel>>> => {
  try {
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT TOP @top * FROM root r WHERE r.type=@type AND r.threadId = @threadId AND r.userId=@userId ORDER BY r.createdAt DESC",
      parameters: [
        {
          name: "@type",
          value: MESSAGE_ATTRIBUTE,
        },
        {
          name: "@threadId",
          value: chatThreadID,
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
        {
          name: "@top",
          value: top,
        },
      ],
    };

    const { resources } = await HistoryContainer()
      .items.query<MessageModel>(querySpec)
      .fetchAll();

    return {
      status: "OK",
      response: resources,
    };
  } catch (e) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `${e}`,
        },
      ],
    };
  }
};

/** 指定したスレッドの全メッセージと添付ファイルを取得 */
export const findAllChatMessagesWithAttachmentsInThreadForCurrentUser = async (
  chatThreadID: string,
): Promise<ServerActionResponse<Array<MessageWithServerAttachments>>> => {
  try {
    // メッセージ取得
    const messagesResponse =
      await findAllChatMessagesInThreadForCurrentUser(chatThreadID);
    if (messagesResponse.status !== "OK") {
      return messagesResponse;
    }
    const messages = messagesResponse.response;

    // 添付ファイル取得
    const withAttachmentsResponse =
      await findAttachmentsAndMergeByMessagesForCurrentUser(messages);
    if (withAttachmentsResponse.status !== "OK") {
      return withAttachmentsResponse;
    }
    const withAttachments = withAttachmentsResponse.response;

    return {
      status: "OK",
      response: withAttachments,
    };
  } catch (e) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `${e}`,
        },
      ],
    };
  }
};

/** 指定したスレッドの全メッセージを取得 */
export const findAllChatMessagesInThreadForCurrentUser = async (
  chatThreadID: string,
): Promise<ServerActionResponse<Array<MessageModel>>> => {
  try {
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT * FROM root r WHERE r.type=@type AND r.threadId=@threadId AND r.userId=@userId ORDER BY r.createdAt ASC",
      parameters: [
        {
          name: "@type",
          value: MESSAGE_ATTRIBUTE,
        },
        {
          name: "@threadId",
          value: chatThreadID,
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
      ],
    };

    const { resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();

    const safeResources = getOnlyParsed(resources, MessageModelSchema);

    return {
      status: "OK",
      response: safeResources,
    };
  } catch (e) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `${e}`,
        },
      ],
    };
  }
};
/** 現在のユーザの全メッセージを取得 */
export const findAllChatMessagesForCurrentUser = async (): Promise<
  ServerActionResponse<Array<MessageModel>>
> => {
  try {
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT * FROM root r WHERE r.type=@type AND r.userId=@userId ORDER BY r.createdAt ASC",
      parameters: [
        {
          name: "@type",
          value: MESSAGE_ATTRIBUTE,
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
      ],
    };

    const { resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();

    const safeResources = getOnlyParsed(resources, MessageModelSchema);

    return {
      status: "OK",
      response: safeResources,
    };
  } catch (e) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `${e}`,
        },
      ],
    };
  }
};

/** 現在のユーザの全メッセージIDを取得 */
export const findAllChatMessageIDsForCurrentUser = async (): Promise<
  ServerActionResponse<Array<string>>
> => {
  try {
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT VALUE r.id FROM root r WHERE r.type=@type AND r.userId=@userId",
      parameters: [
        {
          name: "@type",
          value: MESSAGE_ATTRIBUTE,
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
      ],
    };

    const { resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();

    const safeResources = getOnlyParsed(resources, IDSchema);

    return {
      status: "OK",
      response: safeResources,
    };
  } catch (e) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `${e}`,
        },
      ],
    };
  }
};

/** メッセージを取得 */
export const findChatMessageForCurrentUser = async (
  messageId: string,
): Promise<ServerActionResponse<MessageModel>> => {
  try {
    const querySpec: SqlQuerySpec = {
      query: `
SELECT * FROM root r
WHERE
  r.type=@type
  AND r.id=@id
  AND r.userId=@userId
`,
      parameters: [
        {
          name: "@type",
          value: MESSAGE_ATTRIBUTE,
        },
        {
          name: "@id",
          value: messageId,
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
      ],
    };

    const { resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();

    const safeResources = getOnlyParsed(resources, MessageModelSchema);

    const resource = safeResources[0];
    if (!resource) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: `メッセージが存在しません`,
          },
        ],
      };
    }

    return {
      status: "OK",
      response: resource,
    };
  } catch (e) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `${e}`,
        },
      ],
    };
  }
};

/** スレッド内の全メッセージIDを取得 */
export const findAllChatMessageIDsInThreadForCurrentUser = async (
  chatThreadID: string,
): Promise<ServerActionResponse<Array<string>>> => {
  try {
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT VALUE r.id FROM root r WHERE r.type=@type AND r.threadId=@threadId AND r.userId=@userId",
      parameters: [
        {
          name: "@type",
          value: MESSAGE_ATTRIBUTE,
        },
        {
          name: "@threadId",
          value: chatThreadID,
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
      ],
    };

    const { resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();

    const safeResources = getOnlyParsed(resources, IDSchema);

    return {
      status: "OK",
      response: safeResources,
    };
  } catch (e) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `${e}`,
        },
      ],
    };
  }
};

/** メッセージレコードを作成 */
export const createChatMessageModel = ({
  messageId,
  createdAt,
  content,
  role,
  chatThreadId,
  modelId,
  chatbotId,
  userId,
}: {
  messageId?: string;
  createdAt?: string;
  role: MessageRole;
  content: string;
  chatThreadId: string;
  modelId?: MessageModel["modelId"];
  chatbotId?: MessageModel["chatbotId"];
  userId: string;
}): MessageModel => {
  const modelToSave: MessageModel = {
    id: messageId || uniqueId(),
    createdAt: createdAt || new Date().toISOString(),
    type: MESSAGE_ATTRIBUTE,
    isDeleted: false,
    content: content,
    role: role,
    threadId: chatThreadId,
    userId: userId,
    isError: false,
    isAttachment: false,
    modelId,
    chatbotId,
  };
  return modelToSave;
};

/** メッセージを作成 */
export const createChatMessage = async ({
  messageId,
  content,
  role,
  chatThreadId,
  modelId,
  chatbotId,
}: {
  messageId?: string;
  role: MessageRole;
  content: string;
  chatThreadId: string;
  modelId?: MessageModel["modelId"];
  chatbotId?: MessageModel["chatbotId"];
}): Promise<ServerActionResponse<MessageModel>> => {
  const userId = await userHashedId();
  const modelToSave: MessageModel = {
    id: messageId || uniqueId(),
    createdAt: new Date().toISOString(),
    type: MESSAGE_ATTRIBUTE,
    isDeleted: false,
    content: content,
    role: role,
    threadId: chatThreadId,
    userId: userId,
    isError: false,
    isAttachment: false,
    modelId,
    chatbotId,
  };
  return await upsertChatMessage(modelToSave);
};

/** メッセージを作成/更新 */
export const upsertChatMessage = async (
  chatModel: MessageModel,
): Promise<ServerActionResponse<MessageModel>> => {
  try {
    const modelToSave: MessageModel = {
      ...chatModel,
      id: uniqueId(),
      createdAt: new Date().toISOString(),
      type: MESSAGE_ATTRIBUTE,
      isDeleted: false,
    };

    // TODO: できれば zod に任せたい (優先度低)
    if (!chatModel.modelId && !chatModel.chatbotId) {
      return {
        status: "ERROR",
        errors: [
          {
            message: `modelId, chatbotId どちらかは必須です`,
          },
        ],
      };
    }

    const safeModel = MessageModelSchema.parse(modelToSave);

    const { resource } =
      await HistoryContainer().items.upsert<MessageModel>(safeModel);

    if (resource) {
      return {
        status: "OK",
        response: resource,
      };
    }

    return {
      status: "ERROR",
      errors: [
        {
          message: `Chat message not found`,
        },
      ],
    };
  } catch (e) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `${e}`,
        },
      ],
    };
  }
};
