import "server-only";

import { SqlQuerySpec } from "@azure/cosmos";
import { ConfigContainer } from "../../common/services/cosmos";
import { ModelWithParams, organizeModelData } from "./modelOrganizer";
import { ObjectWithIDAndTypeSchema } from "@/features/common/model/common";
import {
  MODEL_ATTRIBUTE,
  MODEL_PARAMETER_ATTRIBUTE,
  MODEL_PARAMETER_OPTION_ATTRIBUTE,
  ModelModelSchema,
  ModelParameterModelSchema,
  ModelParameterOptionModelSchema,
  ModelWithFuncInfoModel,
  ModelWithFuncInfoModelSchema,
} from "@/features/common/model/config/model-model";
import { getOnlyParsed } from "@/features/common/schema-validation";
import { ServerActionResponse } from "@/features/common/server-action-response";

/** 全モデルと全パラメータをまとめて取得し、整形して返す */
export const findAllModelAndParams = async (): Promise<
  ServerActionResponse<ModelWithParams[]>
> => {
  try {
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT * FROM root r WHERE r.type=@type1 OR r.type=@type2 OR r.type=@type3",
      parameters: [
        {
          name: "@type1",
          value: MODEL_ATTRIBUTE,
        },
        {
          name: "@type2",
          value: MODEL_PARAMETER_ATTRIBUTE,
        },
        {
          name: "@type3",
          value: MODEL_PARAMETER_OPTION_ATTRIBUTE,
        },
      ],
    };

    const { resources } = await ConfigContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();
    const safeResources = getOnlyParsed(resources, ObjectWithIDAndTypeSchema);

    const unsafeModels = safeResources.filter(
      (r) => r.type === MODEL_ATTRIBUTE,
    );
    const models = getOnlyParsed(unsafeModels, ModelModelSchema);

    const unsafeParams = safeResources.filter(
      (r) => r.type === MODEL_PARAMETER_ATTRIBUTE,
    );
    const params = getOnlyParsed(unsafeParams, ModelParameterModelSchema);

    const unsafeOptions = safeResources.filter(
      (r) => r.type === MODEL_PARAMETER_OPTION_ATTRIBUTE,
    );
    const options = getOnlyParsed(
      unsafeOptions,
      ModelParameterOptionModelSchema,
    );

    const modelAndParams = organizeModelData(models, params, options);

    return {
      status: "OK",
      response: modelAndParams,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

/** モデルとAzure Function情報を取得 */
export const findModelWithFuncInfoByID = async (
  modelID: string,
): Promise<ServerActionResponse<ModelWithFuncInfoModel>> => {
  try {
    const querySpec: SqlQuerySpec = {
      query: "SELECT * FROM root r WHERE r.type=@type AND r.id=@id",
      parameters: [
        {
          name: "@type",
          value: MODEL_ATTRIBUTE,
        },
        {
          name: "@id",
          value: modelID,
        },
      ],
    };

    const { resources } = await ConfigContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();
    const safeResources = getOnlyParsed(
      resources,
      ModelWithFuncInfoModelSchema,
    );

    return {
      status: "OK",
      response: safeResources[0],
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

/** モデルの使用可否を取得 (チャットボットとしての使用可否は確認しない) */
export const findIsModelEnabledById = async (
  modelId: string,
): Promise<ServerActionResponse<boolean>> => {
  try {
    const querySpec: SqlQuerySpec = {
      query: `
SELECT VALUE r.id FROM root r
WHERE
  r.type=@type
  AND r.id=@id
  AND r.enabled
`,
      parameters: [
        {
          name: "@type",
          value: MODEL_ATTRIBUTE,
        },
        {
          name: "@id",
          value: modelId,
        },
      ],
    };

    const { resources } = await ConfigContainer()
      .items.query<string>(querySpec)
      .fetchAll();

    return {
      status: "OK",
      response: resources.length > 0,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};
