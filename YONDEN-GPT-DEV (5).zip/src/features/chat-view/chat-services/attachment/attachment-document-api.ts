import contentDisposition from "content-disposition";
import { NextApiRequest, NextApiResponse } from "next";
import {
  getChatAttachmentFileFromStore,
  parseChatAttachmentDocumentParam,
} from "./attachment-file";
import { findChatAttachmentFileAPIData } from "./chat-attachment-api-service";
import {
  GetChatAttachmentDocumentFileParam,
  GetChatAttachmentFileParam,
} from "./models";
import { userSession } from "@/features/auth-page/helpers";
import { FindChatbotByID } from "@/features/chatbot-page/Chatbot-service";
import {
  getDefaultAPIRouteBadRequestErrorResponse,
  getDefaultAPIRouteForbiddenErrorResponse,
  getDefaultAPIRouteNotFoundErrorResponse,
  getDefaultAPIRouteServerErrorResponse,
  getDefaultAPIRouteUnauthorizedErrorResponse,
} from "@/features/common/api-helpers";
import { checkAdmin } from "@/features/common/checkAdmin";
import { CHATBOT_THREAD_ATTRIBUTE } from "@/features/common/model/history/thread-model";
import { FindSelectAuthorityCompanyByID } from "@/features/common/services/authority-company-service";
import { FindSelectAuthorityEmployeeByID } from "@/features/common/services/authority-employee-service";
import { FindEmployeeByID } from "@/features/common/services/employee-service";

/** スレッド内添付ドキュメントファイル取得API */
export const chatAttachmentDocumentAPIGETHandler = async (
  req: NextApiRequest,
  res: NextApiResponse,
): Promise<void> => {
  // パラメータ取得
  const urlPath = req.url;
  if (!urlPath) {
    return getDefaultAPIRouteBadRequestErrorResponse(res);
  }
  // パース
  const parsedParams = parseChatAttachmentDocumentParam(urlPath);
  if (!parsedParams.success) {
    return getDefaultAPIRouteBadRequestErrorResponse(res);
  }
  const params = parsedParams.output;

  try {
    // 実行
    return await chatbotDocumentAPI(params, req, res);
  } catch (error) {
    console.error("chatbotDocumentAPI エラー:", error);
    return getDefaultAPIRouteServerErrorResponse(res);
  }
};

/** チャットボットのドキュメント (標準リンク) ファイル取得APIのロジック */
const chatbotDocumentAPI = async (
  params: GetChatAttachmentDocumentFileParam,
  req: NextApiRequest,
  res: NextApiResponse,
): Promise<void> => {
  // ユーザーID取得
  const user = await userSession(req, res);
  if (!user) {
    return getDefaultAPIRouteUnauthorizedErrorResponse(res);
  }
  const userId = user.id;
  // 社員情報取得
  const employeeResponse = await FindEmployeeByID(userId);
  if (employeeResponse.status !== "OK") {
    console.error(
      "社員情報取得エラー: ",
      employeeResponse.errors?.[0]?.message,
    );
    return getDefaultAPIRouteServerErrorResponse(res);
  }
  const employee = employeeResponse.response!;

  // 管理者かどうか取得
  const adminResponse = await checkAdmin(employee);
  if (adminResponse.status !== "OK") {
    console.error("管理者チェックエラー");
    return getDefaultAPIRouteServerErrorResponse(res);
  }
  const isAdmin = adminResponse.admin;

  const [
    apiDataResponse,
    chatbotResponse,
    employeeAuthority,
    companyAuthority,
  ] = await Promise.all([
    // 各種データ
    findChatAttachmentFileAPIData({
      threadId: params.threadId,
      messageId: params.messageId,
      attachmentId: params.attachmentId,
      userId,
    }),
    // チャットボット存在確認
    FindChatbotByID(params.chatbotId),
    // ユーザのチャットボット閲覧権限確認
    isAdmin
      ? Promise.resolve({
          status: "OK" as const,
        })
      : FindSelectAuthorityEmployeeByID(params.chatbotId, userId),
    // 組織のチャットボット閲覧権限確認
    isAdmin
      ? Promise.resolve({
          status: "OK" as const,
        })
      : FindSelectAuthorityCompanyByID(
          employee.department_code_8,
          params.chatbotId,
        ),
  ]);

  // OK でも NOT_FOUND でもない場合の確認は不要 (4つとも throw しているため)
  if (apiDataResponse.status === "NOT_FOUND") {
    return getDefaultAPIRouteNotFoundErrorResponse(res, "添付ファイル");
  }
  if (chatbotResponse.status === "NOT_FOUND" || !chatbotResponse.response) {
    return getDefaultAPIRouteNotFoundErrorResponse(res, "チャットボット");
  }

  if (
    employeeAuthority.status === "NOT_FOUND" &&
    companyAuthority.status === "NOT_FOUND"
  ) {
    // 組織/ユーザーともに権限なし
    return getDefaultAPIRouteForbiddenErrorResponse(res);
  }

  const apiData = apiDataResponse.response;
  const thread = apiData.thread;
  const message = apiData.message;
  const attachment = apiData.attachment;

  if (thread.id !== message.threadId || message.id !== attachment.messageId) {
    console.error(
      "🔴 添付ファイル取得エラー: " +
        "thread.id !== message.threadId || message.id !== attachment.messageId",
    );
    return getDefaultAPIRouteBadRequestErrorResponse(res);
  }
  if (thread.type !== CHATBOT_THREAD_ATTRIBUTE) {
    console.error(
      "🔴 添付ファイル取得エラー: 対象スレッドがチャットボットでない",
    );
    return getDefaultAPIRouteBadRequestErrorResponse(res);
  }

  if (thread.chatbotId !== params.chatbotId) {
    console.error(
      "🔴 添付ファイル取得エラー: thread.chatbotId !== params.chatbotId",
    );
    return getDefaultAPIRouteBadRequestErrorResponse(res);
  }

  const blobParam: GetChatAttachmentFileParam = {
    threadId: params.threadId,
    messageId: params.messageId,
    fileName: attachment.fileName,
  };
  const fileResponse = await getChatAttachmentFileFromStore(blobParam);

  if (fileResponse.status === "OK") {
    const fileResult = fileResponse.response;
    const stream: NodeJS.ReadableStream = fileResult.stream;

    // レスポンスヘッダーをセット
    // TODO: キャッシュ関係
    res.setHeader(
      "Content-Type",
      fileResult.contentType || "application/octet-stream",
    );
    if (fileResult.contentLength !== undefined) {
      res.setHeader("Content-Length", fileResult.contentLength.toString());
    }
    // ドキュメントは常にダウンロードされてほしいので type=attachment
    res.setHeader(
      "Content-Disposition",
      contentDisposition(attachment.fileName, {
        type: "attachment",
      }),
    );

    // ストリームをパイプしてレスポンスを返す
    stream.pipe(res);
  } else if (fileResponse.status === "NOT_FOUND") {
    return getDefaultAPIRouteNotFoundErrorResponse(res, "ファイル");
  } else {
    return getDefaultAPIRouteServerErrorResponse(res);
  }
};
