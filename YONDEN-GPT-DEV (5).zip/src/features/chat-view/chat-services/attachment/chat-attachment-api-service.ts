import { SqlQuerySpec } from "@azure/cosmos";
import { ChatAttachmentFileAPIData } from "./models";
import { AttachmentModelSchema } from "@/features/common/model/history/attachment-model";
import { MessageModelSchema } from "@/features/common/model/history/message-model";
import { ThreadModelSchema } from "@/features/common/model/history/thread-model";
import { getOnlyParsed } from "@/features/common/schema-validation";
import { ServerActionResponseOrThrow } from "@/features/common/server-action-response";
import { HistoryContainer } from "@/features/common/services/cosmos";

/** 自分のユーザに関する添付ファイルAPI用データ (1パーティションから取得できるもの) をまとめて取得 */
export const findChatAttachmentFileAPIData = async ({
  threadId,
  messageId,
  attachmentId,
  userId,
}: {
  /** スレッドID */
  threadId: string;
  /** メッセージID */
  messageId: string;
  /** 添付ファイルID */
  attachmentId: string;
  /** ユーザID */
  userId: string;
}): Promise<ServerActionResponseOrThrow<ChatAttachmentFileAPIData>> => {
  try {
    const querySpec: SqlQuerySpec = {
      query: `
SELECT * FROM root r
WHERE
  r.userId = @userId
  AND
  (
    r.id = @threadId
    OR r.id = @messageId
    OR r.id = @attachmentId
  )
`,
      parameters: [
        {
          name: "@userId",
          value: userId,
        },
        {
          name: "@threadId",
          value: threadId,
        },
        {
          name: "@messageId",
          value: messageId,
        },
        {
          name: "@attachmentId",
          value: attachmentId,
        },
      ],
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();

    const threadSafeResources = getOnlyParsed(resources, ThreadModelSchema);
    const messageSafeResources = getOnlyParsed(resources, MessageModelSchema);
    const attachmentSafeResources = getOnlyParsed(
      resources,
      AttachmentModelSchema,
    );

    // 結果0件
    if (
      threadSafeResources.length === 0 ||
      messageSafeResources.length === 0 ||
      attachmentSafeResources.length === 0
    ) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "",
          },
        ],
      };
    }

    const thread = threadSafeResources[0];
    const message = messageSafeResources[0];
    const attachment = attachmentSafeResources[0];

    // thread, message, attachment それぞれの ID が一致していない場合は存在しない扱い
    if (
      thread.id !== threadId ||
      message.id !== messageId ||
      attachment.id !== attachmentId
    ) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "",
          },
        ],
      };
    }

    return {
      status: "OK",
      response: {
        thread,
        message,
        attachment,
      },
    };
  } catch (error) {
    console.error("🔴 添付ファイル情報権限取得エラー", error);
    throw error;
  }
};
