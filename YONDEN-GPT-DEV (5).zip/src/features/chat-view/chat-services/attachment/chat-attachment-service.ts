import "server-only";

import { SqlQuerySpec } from "@azure/cosmos";
import { HistoryContainer } from "../../../common/services/cosmos";
import { MessageWithServerAttachments, ServerAttachment } from "../../models";
import {
  getChatAttachmentDocumentParamUrl,
  getChatAttachmentParamUrl,
} from "./attachment-file";
import { getCurrentUser, userHashedId } from "@/features/auth-page/helpers";
import { IDSchema } from "@/features/common/model/common";
import {
  ATTACHMENT_FILE_ATTRIBUTE,
  ATTACHMENT_IMAGE_ATTRIBUTE,
  AttachmentModel,
  AttachmentModelSchema,
} from "@/features/common/model/history/attachment-model";
import { MessageModel } from "@/features/common/model/history/message-model";
import { getOnlyParsed } from "@/features/common/schema-validation";
import { ServerActionResponse } from "@/features/common/server-action-response";
import { uniqueId } from "@/features/common/util";

/** 現在のユーザの全添付ファイルを取得 */
export const findAllAttachmentForCurrentUser = async (): Promise<
  ServerActionResponse<Array<AttachmentModel>>
> => {
  try {
    // TODO: これを使うかどうか
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT * FROM root r WHERE (r.type=@typeFile OR r.type=@typeImage) AND r.userId=@userId ORDER BY r.createdAt DESC",
      parameters: [
        {
          name: "@typeFile",
          value: ATTACHMENT_FILE_ATTRIBUTE,
        },
        {
          name: "@typeImage",
          value: ATTACHMENT_IMAGE_ATTRIBUTE,
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
        {
          name: "@isDeleted",
          value: false,
        },
      ],
    };

    const { resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();
    const safeResources = getOnlyParsed(resources, AttachmentModelSchema);

    return {
      status: "OK",
      response: safeResources,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

/** 現在のユーザの全添付ファイルのIDを取得 */
export const findAllAttachmentIDsForCurrentUser = async (): Promise<
  ServerActionResponse<Array<string>>
> => {
  try {
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT VALUE r.id FROM root r WHERE (r.type=@typeFile OR r.type=@typeImage) AND r.userId=@userId",
      parameters: [
        {
          name: "@typeFile",
          value: ATTACHMENT_FILE_ATTRIBUTE,
        },
        {
          name: "@typeImage",
          value: ATTACHMENT_IMAGE_ATTRIBUTE,
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
      ],
    };

    const { resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();
    const safeResources = getOnlyParsed(resources, IDSchema);

    return {
      status: "OK",
      response: safeResources,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

/** メッセージから添付ファイルを検索して、メッセージとマージ */
export const findAttachmentsAndMergeByMessagesForCurrentUser = async (
  messages: MessageModel[],
): Promise<ServerActionResponse<Array<MessageWithServerAttachments>>> => {
  const messageIDs = messages.map((message) => message.id);
  const attachmentsResponse =
    await findAttachmentByMessageIDsForCurrentUser(messageIDs);
  if (attachmentsResponse.status !== "OK") {
    return attachmentsResponse;
  }
  const attachments = attachmentsResponse.response;

  // マージ用Mapを作成
  const attachmentsMapByMessageId = new Map<string, AttachmentModel[]>();
  for (const attachment of attachments) {
    const { messageId } = attachment;
    const list = attachmentsMapByMessageId.get(messageId);
    if (list) {
      list.push(attachment);
    } else {
      attachmentsMapByMessageId.set(messageId, [attachment]);
    }
  }

  // マージ
  const messagesWithAttachments: MessageWithServerAttachments[] = messages.map(
    (message) => {
      // メッセージデータ
      const isAssistant = message.role === "assistant";
      const chatbotId = message.chatbotId;

      // 添付ファイル
      const attachments = attachmentsMapByMessageId.get(message.id) ?? [];
      // sortNo でソート
      attachments.sort((a, b) => a.sortNo - b.sortNo);

      // 型を整える
      const serverAttachments: ServerAttachment[] = attachments.map(
        (attachment) => {
          const type =
            attachment.type === ATTACHMENT_IMAGE_ATTRIBUTE ? "image" : "file";
          const isDocument = chatbotId && isAssistant && type === "file";
          return {
            name: attachment.fileName,
            type,
            src: isDocument
              ? getChatAttachmentDocumentParamUrl({
                  threadId: message.threadId,
                  messageId: message.id,
                  attachmentId: attachment.id,
                  chatbotId: chatbotId,
                })
              : getChatAttachmentParamUrl({
                  threadId: message.threadId,
                  messageId: message.id,
                  fileName: attachment.fileName,
                }),
          };
        },
      );
      return {
        messageData: message,
        attachments: serverAttachments,
      };
    },
  );

  return {
    status: "OK",
    response: messagesWithAttachments,
  };
};

/**
 * 現在のユーザかつ指定したメッセージIDの全添付ファイルを取得
 * (約13100件まで)
 */
export const findAttachmentByMessageIDsForCurrentUser = async (
  messageIDs: string[],
): Promise<ServerActionResponse<Array<AttachmentModel>>> => {
  if (messageIDs.length === 0) {
    // SQL構文エラー回避
    return {
      status: "OK",
      response: [],
    };
  }
  try {
    const querySpec: SqlQuerySpec = {
      query: `
        SELECT * FROM root r
        WHERE
          (r.type=@type1 OR r.type=@type2)
          AND r.userId=@userId
          AND r.messageId IN (${messageIDs.map((_, i) => `@m${i}`).join(",")})
        ORDER BY r.createdAt DESC
        `,
      parameters: [
        {
          name: "@type1",
          value: ATTACHMENT_FILE_ATTRIBUTE,
        },
        {
          name: "@type2",
          value: ATTACHMENT_IMAGE_ATTRIBUTE,
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
        ...messageIDs.map((messageID, i) => ({
          name: `@m${i}`,
          value: messageID,
        })),
      ],
    };

    const { resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();
    const safeResources = getOnlyParsed(resources, AttachmentModelSchema);

    return {
      status: "OK",
      response: safeResources,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

/** 現在のユーザの指定した添付ファイルを取得 */
export const findAttachmentForCurrentUser = async (
  /** 添付ファイルID */
  attachmentID: string,
): Promise<ServerActionResponse<AttachmentModel>> => {
  try {
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT TOP 1 * FROM root r WHERE (r.type=@type1 OR r.type=@type2) AND r.userId=@userId AND r.id=@id",
      parameters: [
        {
          name: "@type1",
          value: ATTACHMENT_FILE_ATTRIBUTE,
        },
        {
          name: "@type2",
          value: ATTACHMENT_IMAGE_ATTRIBUTE,
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
        {
          name: "@id",
          value: attachmentID,
        },
      ],
    };

    const { resources: resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();
    const safeResources = getOnlyParsed(resources, AttachmentModelSchema);

    if (safeResources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [{ message: `Chat attachment not found` }],
      };
    }

    return {
      status: "OK",
      response: safeResources[0],
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

/** 現在のユーザの指定した添付ファイルを削除 */
export const deleteAttachmentForCurrentUser = async (
  attachmentID: string,
): Promise<ServerActionResponse<boolean>> => {
  try {
    const attachmentResponse = await findAttachmentForCurrentUser(attachmentID);

    if (attachmentResponse.status === "OK") {
      const attachment = attachmentResponse.response;

      // Azure Blob Storage から添付ファイルを削除

      // DB から削除
      await HistoryContainer()
        .item(attachment.id, attachment.userId)
        .delete<AttachmentModel>();
    }

    return {
      status: "OK",
      response: true,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

export const ensureAttachmentOperation = async (
  chatAttachmentID: string,
): Promise<ServerActionResponse<AttachmentModel>> => {
  const response = await findAttachmentForCurrentUser(chatAttachmentID);
  const currentUser = await getCurrentUser();
  const hashedId = await userHashedId();

  if (response.status === "OK") {
    if (currentUser.isAdmin || response.response.userId === hashedId) {
      return response;
    }
  }

  return response;
};

export const getAttachmentModel = ({
  userId,
  id,
  createdAt,
  messageId,
  fileName,
  type,
  sortNo,
}: {
  userId: string;
  id?: string;
  createdAt?: string;
  messageId: string;
  fileName: string;
  type: "file" | "image";
  sortNo: number;
}): AttachmentModel => {
  const modelToSave: AttachmentModel = {
    userId,
    id: id || uniqueId(),
    createdAt: createdAt || new Date().toISOString(),
    type:
      type === "file" ? ATTACHMENT_FILE_ATTRIBUTE : ATTACHMENT_IMAGE_ATTRIBUTE,
    fileName,
    messageId,
    sortNo,
  };

  return modelToSave;
};
