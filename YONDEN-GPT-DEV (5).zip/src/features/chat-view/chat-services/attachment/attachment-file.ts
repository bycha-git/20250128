import { Readable } from "stream";
import * as v from "valibot";
import {
  deleteBlob,
  getBlob,
  uploadBlob,
  uploadBlobStream,
} from "../../../common/services/azure-storage";
import {
  GetChatAttachmentDocumentFileParam,
  GetChatAttachmentDocumentFileParamSchema,
  GetChatAttachmentFileParam,
  GetChatAttachmentFileParamSchema,
} from "./models";
import { ServerActionResponse } from "@/features/common/server-action-response";
import { GetBlobResult } from "@/features/common/services/azure-storage-models";

const IMAGE_CONTAINER_NAME =
  process.env.AZURE_STORAGE_ATTACHMENT_CONTAINER_NAME ?? "attachment";
const IMAGE_API_PATH = `${process.env.NEXTAUTH_URL}/api/chat-attachment`;
const IMAGE_DOCUMENT_API_PATH = `${process.env.NEXTAUTH_URL}/api/chat-attachment-document`;

export const getBlobStorePath = ({
  threadId,
  messageId,
  fileName,
}: GetChatAttachmentFileParam): string => {
  return `${threadId}/${messageId}/${fileName}`;
};

export const uploadChatAttachmentFileToStore = async (
  params: GetChatAttachmentFileParam,
  imageData: Blob,
) => {
  const blobPath = getBlobStorePath(params);
  return await uploadBlob(IMAGE_CONTAINER_NAME, blobPath, imageData);
};

export const uploadChatAttachmentFileStreamToStore = async (
  params: GetChatAttachmentFileParam,
  readable: Readable,
  mimeType: string,
) => {
  const blobPath = getBlobStorePath(params);
  return await uploadBlobStream(
    IMAGE_CONTAINER_NAME,
    blobPath,
    mimeType,
    readable,
  );
};

export const getChatAttachmentFileFromStore = async (
  params: GetChatAttachmentFileParam,
): Promise<ServerActionResponse<GetBlobResult>> => {
  const blobPath = getBlobStorePath(params);
  return await getBlob(IMAGE_CONTAINER_NAME, blobPath);
};

export const deleteChatAttachmentFileFromStore = async (
  params: GetChatAttachmentFileParam,
) => {
  const blobPath = getBlobStorePath(params);
  return await deleteBlob(IMAGE_CONTAINER_NAME, blobPath);
};

export const parseChatAttachmentParam = (urlStr: string) => {
  if (urlStr.startsWith("/")) {
    urlStr = `http://localhost${urlStr}`;
  }
  const url = new URL(urlStr);
  const threadId = url.searchParams.get("t");
  const messageId = url.searchParams.get("m");
  const fileName = url.searchParams.get("f");
  const unsafeParams = {
    threadId,
    messageId,
    fileName,
  };

  const parsedParams = GetChatAttachmentFileParamSchema.safeParse(unsafeParams);
  return parsedParams;
};

export const parseChatAttachmentDocumentParam = (urlStr: string) => {
  if (urlStr.startsWith("/")) {
    urlStr = `http://localhost${urlStr}`;
  }
  const url = new URL(urlStr);
  const threadId = url.searchParams.get("t");
  const messageId = url.searchParams.get("m");
  const attachmentId = url.searchParams.get("a");
  const chatbotId = url.searchParams.get("c");
  const unsafeParams = {
    threadId,
    messageId,
    attachmentId,
    chatbotId,
  };

  const parsedParams = v.safeParse(
    GetChatAttachmentDocumentFileParamSchema,
    unsafeParams,
  );
  return parsedParams;
};

// TODO: attachment-id を使う形に修正
export const getChatAttachmentParamUrl = (
  params: GetChatAttachmentFileParam,
) => {
  const paramsObj = {
    t: params.threadId,
    m: params.messageId,
    f: params.fileName,
  };
  const searchParams = new URLSearchParams(paramsObj);
  const paramsStr = searchParams.toString();

  return `${IMAGE_API_PATH}?${paramsStr}`;
};

export const getChatAttachmentDocumentParamUrl = (
  params: GetChatAttachmentDocumentFileParam,
) => {
  const paramsObj = {
    t: params.threadId,
    m: params.messageId,
    a: params.attachmentId,
    c: params.chatbotId,
  };
  const searchParams = new URLSearchParams(paramsObj);
  const paramsStr = searchParams.toString();

  return `${IMAGE_DOCUMENT_API_PATH}?${paramsStr}`;
};
