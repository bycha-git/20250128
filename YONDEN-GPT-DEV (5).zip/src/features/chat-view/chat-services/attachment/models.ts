import * as v from "valibot";
import { z } from "zod";
import { AttachmentModel } from "@/features/common/model/history/attachment-model";
import { MessageModel } from "@/features/common/model/history/message-model";
import { ThreadModel } from "@/features/common/model/history/thread-model";

// TODO: valibot に変更
export const GetChatAttachmentFileParamSchema = z.object({
  threadId: z.string(),
  messageId: z.string(),
  fileName: z.string(),
});

export const GetChatAttachmentDocumentFileParamSchema = v.object({
  threadId: v.string(),
  messageId: v.string(),
  attachmentId: v.string(),
  chatbotId: v.string(),
});

export type GetChatAttachmentFileParam = z.infer<
  typeof GetChatAttachmentFileParamSchema
>;

export type GetChatAttachmentDocumentFileParam = v.InferInput<
  typeof GetChatAttachmentDocumentFileParamSchema
>;

export interface ChatAttachmentFileAPIData {
  thread: ThreadModel;
  message: MessageModel;
  attachment: AttachmentModel;
}
