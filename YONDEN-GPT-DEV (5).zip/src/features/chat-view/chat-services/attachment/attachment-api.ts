import contentDisposition from "content-disposition";
import { NextRequest, NextResponse } from "next/server";
import {
  getChatAttachmentFileFromStore,
  parseChatAttachmentParam,
} from "./attachment-file";
import {
  getDefaultAPIBadRequestErrorResponse,
  getDefaultAPINotFoundErrorResponse,
  getDefaultAPIServerErrorResponse,
} from "@/features/common/api-helpers";

export const chatAttachmentAPIEntry = async (
  request: NextRequest,
): Promise<NextResponse> => {
  const urlPath = request.url;

  const parsedParams = parseChatAttachmentParam(urlPath);
  if (!parsedParams.success) {
    return getDefaultAPIBadRequestErrorResponse();
  }

  const params = parsedParams.data;

  const fileResponse = await getChatAttachmentFileFromStore(params);

  if (fileResponse.status === "OK") {
    const fileResult = fileResponse.response;
    const stream: NodeJS.ReadableStream = fileResult.stream;
    const headers: Record<string, string> = {};

    // レスポンスヘッダーをセット
    // TODO: キャッシュ関係
    headers["Content-Type"] =
      fileResult.contentType || "application/octet-stream";
    if (fileResult.contentLength !== undefined) {
      headers["Content-Length"] = fileResult.contentLength.toString();
    }
    // XSS対策のため、できるだけ type=attachment にしたいが
    // 画像を新しいタブで表示できてほしいという要望があるため、画像のみ inline とする
    const isImage = fileResult.contentType?.startsWith("image/") ?? false;
    headers["Content-Disposition"] = contentDisposition(params.fileName, {
      type: isImage ? "inline" : "attachment",
    });

    // https://github.com/vercel/next.js/discussions/50614#discussioncomment-8820193
    // 型としてはWebの ReadableStream が要求されるが、 NodeJS.ReadableStream でも動いていそう
    return new NextResponse(stream as unknown as ReadableStream, { headers });
  } else if (fileResponse.status === "NOT_FOUND") {
    return getDefaultAPINotFoundErrorResponse("ファイル");
  } else {
    return getDefaultAPIServerErrorResponse();
  }
};
