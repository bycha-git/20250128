"use server";

import { SqlQuerySpec } from "@azure/cosmos";
import {
  ConfigContainer,
  HistoryContainer,
} from "../../common/services/cosmos";
import {
  findAllChatMessagesForCurrentUser,
  findAllChatMessagesInThreadForCurrentUser,
} from "./chat-message-service";
import { findIsModelEnabledById } from "./chat-model-service";
import { userHashedId } from "@/features/auth-page/helpers";
import {
  FindChatbotByID,
  findModelParameterOptionById,
  modelCheckForChatbot,
  referenceOpen,
} from "@/features/chatbot-page/Chatbot-service";
import {
  bulkDeleteHistoryForCurrentUser,
  bulkUpsertHistory,
} from "@/features/common/bulk/history-bulk-operation";
import { IDSchema, JSONValue } from "@/features/common/model/common";
import {
  ModelModel,
  ModelModelSchema,
} from "@/features/common/model/config/model-model";
import {
  CHATBOT_THREAD_ATTRIBUTE,
  ChatbotThreadModel,
  MODEL_THREAD_ATTRIBUTE,
  ModelThreadModel,
  ThreadModel,
  ThreadModelSchema,
} from "@/features/common/model/history/thread-model";
import { revalidateCache } from "@/features/common/navigation-helpers";
import { redirectToChatThread } from "@/features/common/redirect-helpers";
import { getOnlyParsed } from "@/features/common/schema-validation";
import { ServerActionResponse } from "@/features/common/server-action-response";
import { FindErrorMessages } from "@/features/common/services/errMessage-service";
import { uniqueId } from "@/features/common/util";
import { NEW_CHAT_NAME } from "@/features/theme/theme-config";

/** 現在のユーザの全スレッドを取得 */
export const findAllThreadForCurrentUser = async (): Promise<
  ServerActionResponse<Array<ThreadModel>>
> => {
  try {
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT * FROM root r WHERE (r.type=@typeChatbot OR r.type=@typeModel) AND r.userId=@userId ORDER BY r.createdAt DESC",
      parameters: [
        {
          name: "@typeChatbot",
          value: CHATBOT_THREAD_ATTRIBUTE,
        },
        {
          name: "@typeModel",
          value: MODEL_THREAD_ATTRIBUTE,
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
        {
          name: "@isDeleted",
          value: false,
        },
      ],
    };

    const { resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();
    const safeResources = getOnlyParsed(resources, ThreadModelSchema);

    return {
      status: "OK",
      response: safeResources,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

/** 現在のユーザの全スレッドのIDを取得 */
export const findAllThreadIDsForCurrentUser = async (): Promise<
  ServerActionResponse<Array<string>>
> => {
  try {
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT VALUE r.id FROM root r WHERE (r.type=@typeChatbot OR r.type=@typeModel) AND r.userId=@userId",
      parameters: [
        {
          name: "@typeChatbot",
          value: CHATBOT_THREAD_ATTRIBUTE,
        },
        {
          name: "@typeModel",
          value: MODEL_THREAD_ATTRIBUTE,
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
      ],
    };

    const { resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();
    const safeResources = getOnlyParsed(resources, IDSchema);

    return {
      status: "OK",
      response: safeResources,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

/** 現在のユーザの指定したスレッドを取得 */
export const findThreadForCurrentUser = async (
  /** スレッドID */
  threadID: string,
): Promise<ServerActionResponse<ThreadModel>> => {
  try {
    // 何故か IN 句より OR 句のほうが RU コストがほんの若干低い場合があったので
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT TOP 1 * FROM root r WHERE (r.type=@typeChatbot OR r.type=@typeModel) AND r.userId=@userId AND r.id=@id",
      parameters: [
        {
          name: "@typeChatbot",
          value: CHATBOT_THREAD_ATTRIBUTE,
        },
        {
          name: "@typeModel",
          value: MODEL_THREAD_ATTRIBUTE,
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
        {
          name: "@id",
          value: threadID,
        },
      ],
    };

    const { resources: resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();
    const safeResources = getOnlyParsed(resources, ThreadModelSchema);

    if (safeResources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [{ message: `Chat thread not found` }],
      };
    }

    return {
      status: "OK",
      response: safeResources[0],
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

/** 現在のユーザの指定したスレッドを削除 */
export const deleteThreadForCurrentUser = async (
  threadID: string,
): Promise<ServerActionResponse<ThreadModel>> => {
  try {
    const threadResponse = await findThreadForCurrentUser(threadID);

    if (threadResponse.status === "OK") {
      const thread = threadResponse.response;
      // スレッドの全メッセージを取得
      const messagesResponse =
        await findAllChatMessagesInThreadForCurrentUser(threadID);

      if (messagesResponse.status !== "OK") {
        return messagesResponse;
      }
      const messages = messagesResponse.response;

      // TODO: 添付ファイルを削除 (messageID で検索するしかない)

      // 取得したメッセージを論理削除
      messages.forEach((message) => {
        message.isDeleted = true;
      });
      const deleteMessageResponse = await bulkUpsertHistory(messages);
      if (deleteMessageResponse.status !== "OK") {
        return deleteMessageResponse;
      }
      // スレッドを削除
      const deleteIDs = [threadID];
      const deleteResponse = await bulkDeleteHistoryForCurrentUser(deleteIDs);
      if (deleteResponse.status !== "OK") {
        return deleteResponse;
      }
    }

    return threadResponse;
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

/** 現在のユーザの全スレッドを削除 */
export const deleteAllThreadsForCurrentUser = async (): Promise<
  ServerActionResponse<boolean>
> => {
  try {
    const threadIDsResponse = await findAllThreadIDsForCurrentUser();
    if (threadIDsResponse.status !== "OK") {
      return threadIDsResponse;
    }
    const threadIDs = threadIDsResponse.response;

    // 現在のユーザーの全メッセージを取得
    const messagesResponse = await findAllChatMessagesForCurrentUser();
    if (messagesResponse.status !== "OK") {
      return messagesResponse;
    }
    const messages = messagesResponse.response;

    // TODO: 他色々なデータを削除
    // 添付ファイル
    //

    // const chatDocumentsResponse = await FindAllChatDocuments(chatThreadID);

    // if (chatDocumentsResponse.status !== "OK") {
    //   return chatDocumentsResponse;
    // }

    // const chatDocuments = chatDocumentsResponse.response;

    // if (chatDocuments.length !== 0) {
    //   await DeleteDocuments(chatThreadID);
    // }

    // chatDocuments.forEach(async (chatDocument: ChatDocumentModel) => {
    //   const itemToUpdate = {
    //     ...chatDocument,
    //   };
    //   itemToUpdate.isDeleted = true;
    //   await HistoryContainer().items.upsert(itemToUpdate);
    // });

    // メッセージを論理削除
    messages.forEach((message) => (message.isDeleted = true));
    const messageDeleteResponse = await bulkUpsertHistory(messages);
    if (messageDeleteResponse.status !== "OK") {
      return messageDeleteResponse;
    }

    // スレッドを削除
    const deleteIDs = [...threadIDs];
    const deleteResponse = await bulkDeleteHistoryForCurrentUser(deleteIDs);

    if (deleteResponse.status !== "OK") {
      return deleteResponse;
    }

    return {
      status: "OK",
      response: true,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

/** 指定したスレッドの読み書き権がある (自分のものである) かを返す */
export const ensureThreadOperation = async (
  chatThreadID: string,
): Promise<ServerActionResponse<ThreadModel>> => {
  const response = await findThreadForCurrentUser(chatThreadID);
  const hashedId = await userHashedId();

  if (response.status === "OK") {
    if (response.response.userId === hashedId) {
      return response;
    } else {
      return {
        status: "FORBIDDEN",
        errors: [{ message: "スレッドの所有者ではありません" }],
      };
    }
  }

  return response;
};

/** スレッドを作成/更新 */
export const upsertThread = async (
  chatThread: ThreadModel,
  updateLastMessageAt: boolean = true,
): Promise<ServerActionResponse<ThreadModel>> => {
  try {
    const safeChatThread = ThreadModelSchema.parse(chatThread);

    if (safeChatThread.id) {
      const response = await ensureThreadOperation(safeChatThread.id);
      if (response.status !== "OK") {
        return response;
      }
    }

    if (updateLastMessageAt)
      safeChatThread.lastMessageAt = new Date().toISOString();
    const { resource } =
      await HistoryContainer().items.upsert<ThreadModel>(safeChatThread);

    if (resource) {
      return {
        status: "OK",
        response: resource,
      };
    }

    return {
      status: "ERROR",
      errors: [{ message: `Chat thread not found` }],
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

export type ModelThreadParams = {
  modelId: string;
  modelName: string;
} & Record<string, JSONValue>;

export const createModelThread = async (
  params: ModelThreadParams,
): Promise<ServerActionResponse<ModelThreadModel>> => {
  try {
    const modelToSave: ModelThreadModel = {
      name: NEW_CHAT_NAME,
      userId: await userHashedId(),
      id: uniqueId(),
      createdAt: new Date().toISOString(),
      lastMessageAt: new Date().toISOString(),
      bookmarked: false,
      type: MODEL_THREAD_ATTRIBUTE,
      edited: false,
      ...params,
    };

    const { resource } =
      await HistoryContainer().items.create<ModelThreadModel>(modelToSave);
    if (resource) {
      return {
        status: "OK",
        response: resource,
      };
    }

    return {
      status: "ERROR",
      errors: [{ message: "ECOMMON0001" }],
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: "ECOMMON0001" }],
    };
  }
};
export type ChatbotThreadParams = {
  chatbotId: string;
  chatbotName: string;
  inScope: boolean;
  topNDocuments: number;
  optionId?: string;
} & Record<string, JSONValue>;
export const createChatbotThread = async (
  params: ChatbotThreadParams,
): Promise<ServerActionResponse<ChatbotThreadModel>> => {
  try {
    const modelToSave: ChatbotThreadModel = {
      id: uniqueId(),
      type: CHATBOT_THREAD_ATTRIBUTE,
      userId: await userHashedId(),
      createdAt: new Date().toISOString(),
      lastMessageAt: new Date().toISOString(),
      name: NEW_CHAT_NAME,
      bookmarked: false,
      edited: false,
      ...params,
    };

    const { resource } =
      await HistoryContainer().items.create<ChatbotThreadModel>(modelToSave);
    if (resource) {
      return {
        status: "OK",
        response: resource,
      };
    }

    return {
      status: "ERROR",
      errors: [{ message: `Chat thread not found` }],
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

export const updateThreadTitle = async (
  chatThreadId: string,
  title: string,
): Promise<ServerActionResponse<ThreadModel>> => {
  try {
    const response = await findThreadForCurrentUser(chatThreadId);
    if (response.status === "OK") {
      const chatThread = response.response;
      // 50字取り出す
      if (title) chatThread.name = title.slice(0, 50);

      chatThread.edited = true;
      const safeChatThread = ThreadModelSchema.parse(chatThread);
      return await upsertThread(safeChatThread, false);
    }
    return response;
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

// TODO 型やコードの質など調整
export const createChatAndRedirect = async (
  params: ModelThreadParams | ChatbotThreadParams,
) => {
  const chatbotThreadParams: ChatbotThreadParams = {
    chatbotId: "",
    chatbotName: "",
    inScope: false,
    topNDocuments: 5,
    strictness: "neutral",
    strictnessValue: 3,
    ocr: "ocr_yes",
  };
  if (!("chatbotId" in params)) {
    // モデルの使用可否チェック
    const isModelEnabledResponse = await findIsModelEnabledById(params.modelId);
    if (isModelEnabledResponse.status !== "OK") {
      return {
        status: "Error",
        errors: [{ message: "ECOMMON0001" }],
      };
    }
    const isModelEnabled = isModelEnabledResponse.response;
    if (!isModelEnabled) {
      return {
        status: "Error",
        errors: [{ message: "EHOME0001" }],
      };
    }
  } else if (!("modelId" in params)) {
    // チャットボットの存在権限チェック
    const checkResult = await referenceOpen(params.chatbotId, false);
    if (!checkResult.check) {
      return {
        status: "REDIRECT",
        errors: [{ message: checkResult.message }],
      };
    }

    // チャットボットを再取得
    const chatbot = await FindChatbotByID(params.chatbotId);
    // モデルの使用可否チェック
    const enabledCheckResult = await modelCheckForChatbot(
      chatbot.response?.modelId || "",
    );
    if (!enabledCheckResult.check) {
      return {
        status: "REDIRECT",
        errors: [{ message: enabledCheckResult.message }],
      };
    }
    // 必須チェック
    if (!params.topNDocuments) {
      const errMessage = await FindErrorMessages("ECHATBOT0004");
      return {
        status: "CHECK",
        errors: [
          {
            message:
              errMessage.status == "OK" ? errMessage.response[0].message : "",
          },
        ],
      };
    }
    // 単独チェック
    if (params.topNDocuments < 1 || params.topNDocuments > 99) {
      const errMessage = await FindErrorMessages("ECHATBOT0012");
      return {
        status: "CHECK",
        errors: [
          {
            message:
              errMessage.status == "OK" ? errMessage.response[0].message : "",
          },
        ],
      };
    }
    // optionIdから会話のスタイルの設定値を取得
    const optionResponse = await findModelParameterOptionById(
      params.optionId || "",
    );
    if (optionResponse.status !== "OK")
      return {
        status: "ERROR",
        errors: [
          {
            message:
              "パラメータの取得に失敗しました。" +
              optionResponse.errors?.[0].message,
          },
        ],
      };
    // スレッドパラメータ設定
    chatbotThreadParams.chatbotId = params.chatbotId;
    chatbotThreadParams.chatbotName = params.chatbotName;
    chatbotThreadParams.inScope = params.inScope;
    chatbotThreadParams.topNDocuments = Number(params.topNDocuments);
    chatbotThreadParams.strictness = params.strictness;
    chatbotThreadParams.strictnessValue = Number(
      optionResponse.response?.value,
    );
    chatbotThreadParams.ocr = params.ocr;
  }

  const response = !("chatbotId" in params)
    ? await createModelThread(params)
    : await createChatbotThread(chatbotThreadParams);
  // TODO: 元AzureChatにはなかったが、どこでやっていた？
  revalidateCache({
    page: "chat",
    type: "layout",
  });
  console.log("createChatAndRedirect response", response);
  if (response.status === "OK") {
    // redirect() を実行した場合は throw されるため、何も返せない
    redirectToChatThread(response.response.id);
  } else {
    return response;
  }
};

/**
 * モデル検索処理
 * @param id 検索対象モデルID
 * @returns 結果 OK or ERRPR
 */
export const FindModelByID = async (
  id: string,
): Promise<ServerActionResponse<ModelModel>> => {
  try {
    // パラメータ
    const querySpec: SqlQuerySpec = {
      query: "SELECT * FROM root r WHERE r.type=@type AND r.id=@id",
      parameters: [
        {
          name: "@type",
          value: "MODEL",
        },
        {
          name: "@id",
          value: id,
        },
      ],
    };

    // 検索
    const { resources } = await ConfigContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();
    const safeResources = getOnlyParsed(resources, ModelModelSchema);

    // 0件の場合
    if (safeResources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "Model not found",
          },
        ],
      };
    }

    return {
      status: "OK",
      response: safeResources[0],
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `Error finding model: ${error}`,
        },
      ],
    };
  }
};
