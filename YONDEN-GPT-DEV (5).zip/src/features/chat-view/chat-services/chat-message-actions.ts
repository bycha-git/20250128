"use server";

import {
  findChatMessageForCurrentUser,
  findTopChatMessagesForCurrentUser,
} from "./chat-message-service";
import { MessageModel } from "@/features/common/model/history/message-model";
import { revalidateCache } from "@/features/common/navigation-helpers";
import { ServerActionResponse } from "@/features/common/server-action-response";
import { HistoryContainer } from "@/features/common/services/cosmos";

/** メッセージを論理削除 */
export const softDeleteChatMessageForCurrentUser = async (
  messageId: string,
): Promise<ServerActionResponse<boolean>> => {
  try {
    const messageResponse = await findChatMessageForCurrentUser(messageId);
    if (messageResponse.status !== "OK") {
      return messageResponse;
    }
    const messageModel = messageResponse.response;

    // 論理削除
    const modelToSave: MessageModel = {
      ...messageModel,
      isDeleted: true,
    };

    await HistoryContainer().items.upsert<MessageModel>(modelToSave);

    revalidateCache({
      page: "chat",
      params: messageModel.threadId,
      type: "page",
    });

    return {
      status: "OK",
      response: true,
    };
  } catch (e) {
    throw e;
  }
};

/** 最新n件のメッセージを取得 */
export const getTopChatMessagesForCurrentUser = async (
  chatThreadID: string,
  top: number = 30,
): Promise<ServerActionResponse<Array<MessageModel>>> => {
  try {
    const messagesResponse = await findTopChatMessagesForCurrentUser(
      chatThreadID,
      top,
    );
    return messagesResponse;
  } catch (e) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `${e}`,
        },
      ],
    };
  }
};
