"use server";

import {
  TemplateModel,
  TemplateModelSchema,
} from "@/features/common/model/history/template-model";
import { ServerActionResponse } from "@/features/common/server-action-response";
import { HistoryContainer } from "@/features/common/services/cosmos";
import { PromptModel } from "@/features/prompt-template-page/Prompt-model";
import { referenceOpen } from "@/features/prompt-template-page/Prompt-service";

/** 指定したプロンプトテンプレートの選択回数を増加 */
const incrementTemplateUsage = async (
  templatedata: PromptModel,
): Promise<ServerActionResponse<TemplateModel>> => {
  try {
    // 回数増加
    const modelToSave: TemplateModel = {
      ...templatedata,
      numberOfChoices: (templatedata.numberOfChoices ?? 0) + 1,
    };

    // TODO: upsert じゃなく、純粋な update にしたい
    // (削除後にこれが実行されて余計なデータが残らないように)
    const { resource } =
      await HistoryContainer().items.upsert<TemplateModel>(modelToSave);

    const safeResource = TemplateModelSchema.parse(resource);

    return {
      status: "OK",
      response: safeResource,
    };
  } catch (e) {
    console.error("🔴 incrementTemplateUsage エラー:", e);
    return {
      status: "ERROR",
      errors: [
        {
          message: `${e}`,
        },
      ],
    };
  }
};

/** プロンプトテンプレートを使用 */
export const ensureUseTemplate = async ({
  templateId,
}: {
  templateId: string;
}): Promise<ServerActionResponse<EnsureUseTemplateResult>> => {
  try {
    // プロンプトの存在権限チェック
    const checkResult = await referenceOpen(templateId, false);
    if (!checkResult.check || !checkResult.promptData) {
      return {
        status: "ERROR",
        errors: [
          {
            message: checkResult.message ?? "",
          },
        ],
      };
    }

    const template = checkResult.promptData;

    // 回数増加 (非同期実行)
    void incrementTemplateUsage(template);

    return {
      status: "OK",
      response: {
        template: template,
      },
    };
  } catch (e) {
    console.error("🔴 incrementTemplateUsage エラー:", e);
    return {
      status: "ERROR",
      errors: [
        {
          message: "ECOMMON0001",
        },
      ],
    };
  }
};

type EnsureUseTemplateResult = {
  template: PromptModel;
};
