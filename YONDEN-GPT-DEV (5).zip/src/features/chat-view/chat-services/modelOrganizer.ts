import { JSONValue } from "@/features/common/model/common";
import {
  ModelModel,
  ModelParameterModel,
  ModelParameterOptionModel,
} from "@/features/common/model/config/model-model";

// 整理後のデータ構造
export type ModelParameterOption = {
  /** 選択肢ID */
  id: string;
  /** 選択肢の表示名 */
  label: string;
  /** 選択肢の値 */
  value: JSONValue;
  /** 選択内容保存/表示用の値 */
  valueForDisplay?: string;
  /** 表示順 */
  sortNo: number;
  /** 初期値フラグ */
  isInitial: boolean;
};
export type ModelParameter = {
  /** パラメータID */
  id: string;
  /** パラメータ名 */
  name: string;
  /** 表示名 */
  label: string;
  /** 要素の種類 */
  elementType: "select" | "button";
  /** 表示順 */
  sortNo: number;
  /** 説明文 */
  description: string;
  /** 選択肢のリスト */
  options: ModelParameterOption[];
};
export type ModelWithParams = {
  /** モデルID */
  id: string;
  /** モデル名 */
  name: string;
  /** 表示順 */
  sortNo: number;
  /** 使用可能フラグ */
  enabled: boolean;
  /** 画像ボタン利用可能フラグ */
  imageEnabled: boolean;
  /** チャットボットで指定可能フラグ */
  enabledAtChatbot: boolean;
  /** モデル用初期値フラグ */
  isInitialAtThread: boolean;
  /** チャットボット用初期値フラグ */
  isInitialAtChatbot: boolean;
  /** 対応ファイル形式 */
  supportedFileExt: string;
  /** 画像対応ファイル形式 */
  supportedImageExt?: string;
  /** パラメータのリスト */
  parameters: ModelParameter[];
};

/** モデルとパラメータのDBレコードから、扱いやすいオブジェクトを作成 */
export function organizeModelData(
  rawModels: ModelModel[],
  rawParameters: ModelParameterModel[],
  rawOptions: ModelParameterOptionModel[],
): ModelWithParams[] {
  // パラメータIDごとに選択肢をグループ化
  const optionsByParameterId = new Map<string, ModelParameterOptionModel[]>();

  for (const option of rawOptions) {
    const existingOptions =
      optionsByParameterId.get(option.modelParameterId) || [];
    existingOptions.push(option);
    optionsByParameterId.set(option.modelParameterId, existingOptions);
  }

  // モデルIDごとにパラメータをグループ化
  const parametersByModelId = new Map<string, ModelParameter[]>();

  for (const param of rawParameters) {
    // パラメータに対応する選択肢を取得してソート
    const options = (optionsByParameterId.get(param.id) ?? [])
      .map((opt) => ({
        id: opt.id,
        label: opt.label,
        value: opt.value,
        valueForDisplay: opt.valueForDisplay,
        sortNo: opt.sortNo,
        isInitial: opt.isInitial,
      }))
      .sort((a, b) => a.sortNo - b.sortNo);

    // パラメータを整理
    const organizedParam: ModelParameter = {
      id: param.id,
      name: param.name,
      label: param.label,
      elementType: param.elementType,
      sortNo: param.sortNo,
      description: param.description,
      options,
    };

    const existingParams = parametersByModelId.get(param.modelId) ?? [];
    existingParams.push(organizedParam);
    parametersByModelId.set(param.modelId, existingParams);
  }

  // パラメータのソート
  for (const params of parametersByModelId.values()) {
    params.sort((a, b) => a.sortNo - b.sortNo);
  }

  // モデルごとのデータを作成
  const organizedModels = rawModels.map((model) => ({
    id: model.id,
    name: model.name,
    sortNo: model.sortNo,
    enabled: model.enabled,
    imageEnabled: model.imageEnabled,
    enabledAtChatbot: model.enabledAtChatbot,
    isInitialAtThread: model.isInitialAtThread,
    isInitialAtChatbot: model.isInitialAtChatbot,
    supportedFileExt: model.supportedFileExt,
    supportedImageExt: model.supportedImageExt,
    parameters: parametersByModelId.get(model.id) ?? [],
  }));

  // モデルをソート
  organizedModels.sort((a, b) => a.sortNo - b.sortNo);
  // チャットボット用パラメータを追加
  const chatbotId = "#chatbot#";
  organizedModels.push({
    id: chatbotId,
    name: "チャットボット",
    sortNo: 0,
    enabled: false,
    imageEnabled: false,
    enabledAtChatbot: false,
    isInitialAtThread: false,
    isInitialAtChatbot: false,
    supportedFileExt: "false",
    supportedImageExt: "",
    parameters: parametersByModelId.get(chatbotId) ?? [],
  });

  return organizedModels;
}
