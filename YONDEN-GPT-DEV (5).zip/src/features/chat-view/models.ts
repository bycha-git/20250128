import { MessageModel } from "@/features/common/model/history/message-model";

/** 添付ファイルの定義 */
export interface LocalAttachment {
  file: File;
  name: string;
  type: "file" | "image";
}

/** アップロードされた添付ファイルの定義 */
export interface ServerAttachment {
  src: string;
  name: string;
  type: "file" | "image";
}

/** メッセージ (添付ファイルつき) */
export interface MessageWithServerAttachments {
  messageData: MessageModel;
  attachments: readonly ServerAttachment[];
}
