"use client";
import { signIn } from "next-auth/react";
import { FC } from "react";
import { Button } from "../ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../ui/card";
import { AI_NAME } from "@/features/theme/theme-config";

interface LoginProps {
  isDevMode: boolean;
  githubEnabled: boolean;
  entraIdEnabled: boolean;
}

export const LogIn: FC<LoginProps> = (props) => {
  return (
    <Card className="flex min-w-[300px] flex-col items-center gap-2">
      <CardHeader className="gap-2">
        <CardTitle className="flex gap-2 text-2xl">
          <span className="text-primary">{AI_NAME}</span>
        </CardTitle>
        <CardDescription>ログインしてください。</CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4">
        {props.githubEnabled && (
          <Button onClick={() => signIn("github")}>GitHub</Button>
        )}
        {props.entraIdEnabled && (
          <Button onClick={() => signIn("azure-ad")}>Microsoft 365</Button>
        )}
        {props.isDevMode && (
          <Button onClick={() => signIn("localdev")}>
            Basic Auth (DEV ONLY)
          </Button>
        )}
      </CardContent>
    </Card>
  );
};
