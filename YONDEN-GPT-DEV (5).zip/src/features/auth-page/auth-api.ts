/* eslint-disable import/no-named-as-default -- CredentialsProvider に必要 */
import NextAuth, { NextAuthOptions, type User } from "next-auth";
import AzureADProvider from "next-auth/providers/azure-ad";
import CredentialsProvider from "next-auth/providers/credentials";
import { Provider } from "next-auth/providers/index";
import * as v from "valibot";
import {
  FindEmployeeByID,
  findEmployeeByUserPrincipalName,
} from "../common/services/employee-service";
import { SessionUpdateModelSchema } from "./helpers";

const configureIdentityProvider = () => {
  const providers: Array<Provider> = [];

  if (
    process.env.AZURE_AD_CLIENT_ID &&
    process.env.AZURE_AD_CLIENT_SECRET &&
    process.env.AZURE_AD_TENANT_ID
  ) {
    providers.push(
      AzureADProvider({
        clientId: process.env.AZURE_AD_CLIENT_ID,
        clientSecret: process.env.AZURE_AD_CLIENT_SECRET,
        tenantId: process.env.AZURE_AD_TENANT_ID,
        async profile(unsafeProfile) {
          const profile = v.parse(AzureADProfileSchema, unsafeProfile);
          const userPrincipalName = String(
            profile.preferred_username || profile.email || "",
          );
          const employeeResponse =
            await findEmployeeByUserPrincipalName(userPrincipalName);
          if (employeeResponse.status !== "OK") {
            const unknownProfile: User = {
              id: "#unknown_user#",
              email: "",
              name: "",
              departmentName: "",
              isApproved: false,
            };
            return unknownProfile;
          }
          const employee = employeeResponse.response;
          const newProfile: User = {
            id: employee.id,
            email: employee.mailAddress ?? "",
            name: employee.employeeName ?? "",
            departmentName: employee.department_code_8_name ?? "",
            isApproved: false,
          };
          return newProfile;
        },
      }),
    );
  }

  // 開発用ログイン
  // Refer to: https://next-auth.js.org/configuration/providers/credentials
  if (process.env.NODE_ENV === "development") {
    providers.push(
      CredentialsProvider({
        name: "localdev",
        // 入力項目
        credentials: {
          username: {
            label: "userId (従業員番号)",
            type: "text",
            placeholder: "00000000",
          },
          password: { label: "Password (空欄可)", type: "password" },
        },
        async authorize(credentials): Promise<User> {
          // クレデンシャルを取得してユーザに変換するロジックを記載
          const username = credentials?.username || "00000000";
          const employeeResponse = await FindEmployeeByID(username);
          const employee =
            employeeResponse.status === "OK"
              ? employeeResponse.response
              : undefined;
          const user: User = {
            id: employee?.id ?? username,
            name: employee?.employeeName ?? username,
            email: employee?.mailAddress ?? "",
            departmentName:
              employee?.department_code_8_name ??
              `注: ${
                process.env.AZURE_COSMOSDB_EMPLOYEE_CONTAINER_NAME ?? "employee"
              }コンテナに存在しないIDでログインしています。一部機能が動作しません。`,
            isApproved: false,
          };
          console.log(
            "=== DEV USER LOGGED IN:\n",
            JSON.stringify(user, null, 2),
          );
          return user;
        },
      }),
    );
  }

  return providers;
};

export const options: NextAuthOptions = {
  secret: process.env.NEXTAUTH_SECRET,
  providers: [...configureIdentityProvider()],
  callbacks: {
    async signIn({ user }) {
      // console.log("=== SIGN IN CALLBACK", { user, account, profile, email });
      if (user?.id === "#unknown_user#") {
        return false;
      }
      return true;
    },
    async jwt({ token, user, trigger, session }) {
      // console.log("=== JWT CALLBACK", { token, user });
      if (trigger === "update") {
        const sessionUpdateSafeParsed = v.safeParse(
          SessionUpdateModelSchema,
          session,
        );
        if (sessionUpdateSafeParsed.success) {
          const sessionUpdate = sessionUpdateSafeParsed.output;
          console.log("=== JWT更新", { token, user, sessionUpdate });
          if (user) user.isApproved = sessionUpdate.isApproved;
          token.isApproved = sessionUpdate.isApproved;
        }
      }
      if (user?.id) token.id = user.id;
      if (user?.name) token.name = user.name;
      if (user?.email) token.email = user.email;
      if (user?.departmentName) token.departmentName = user.departmentName;
      if (user?.isApproved) token.isApproved = user.isApproved;

      return token;
    },
    async session({ session, token }) {
      // console.log("=== SESSION CALLBACK", { session, token, user });
      session.user.id = token.id as string;
      session.user.name = token.name as string;
      session.user.email = token.email as string;
      session.user.departmentName = token.departmentName as string;
      session.user.isApproved =
        (token.isApproved as boolean | undefined) ?? false;
      return session;
    },
  },
  session: {
    strategy: "jwt",
  },
};

// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment -- NextAuth の仕様
export const handlers = NextAuth(options);

/**
 * Azure AD から返ってくるログイン情報
 * @see https://learn.microsoft.com/ja-jp/entra/identity-platform/id-token-claims-reference#payload-claims
 */
const AzureADProfileSchema = v.partial(
  v.object({
    preferred_username: v.string(),
    email: v.string(),
  }),
);
