import { createHash } from "crypto";
import { NextApiRequest, NextApiResponse } from "next";
import { getServerSession } from "next-auth";
import * as v from "valibot";
import { redirectToPage } from "../common/redirect-helpers";
import { options } from "./auth-api";
import { UserModel } from "@/types/next-auth";

/**
 * サーバ側でセッション情報を取得
 * - 有効なセッションが存在しない場合は null を返す
 * - /pages/api/ から呼び出す場合は引数に req, res を指定すること
 */
export const userSession = async (
  ...params: [] | [req: NextApiRequest, res: NextApiResponse]
): Promise<UserModel | null> => {
  const session = await getServerSession(...params, options);
  if (session && session.user) {
    return {
      name: session.user.name ?? "",
      email: session.user.email ?? "",
      departmentName: session.user.departmentName ?? "",
      id: session.user.id ?? "",
      isApproved: session.user.isApproved ?? false,
    };
  }

  return null;
};

/**
 * サーバ側でユーザ情報を取得
 * - 有効なセッションが存在しない場合は throw する
 */
export const getCurrentUser = async (): Promise<UserModel> => {
  const user = await userSession();
  if (user) {
    return user;
  }
  throw new Error("User not found");
};

/**
 * サーバ側でユーザID (従業員番号) を取得
 * - 有効なセッションが存在しない場合は throw する
 */
export const userHashedId = async (): Promise<string> => {
  const user = await userSession();
  if (user) {
    return user.id || user.email || "";
  }

  throw new Error("User not found");
};

export const hashValue = (value: string): string => {
  const hash = createHash("sha256");
  hash.update(value);
  return hash.digest("hex");
};

export const redirectIfAuthenticated = async () => {
  const user = await userSession();
  if (user) {
    redirectToPage("chat");
  }
};

export const SessionUpdateModelSchema = v.object({
  /** このセッションで注意事項に承認済みかどうか */
  isApproved: v.boolean(),
});
export type SessionUpdateModel = v.InferInput<typeof SessionUpdateModelSchema>;
