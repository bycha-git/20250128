import React, {
  createContext,
  Dispatch,
  ReactNode,
  SetStateAction,
  useContext,
  useState,
} from "react";
import {
  AuthorityCompanyInfo,
  AuthorityEmployeeInfo,
  AuthorityKind,
  ChatBotModel,
  ChunkSizeModel,
  DocumentTabData,
  Model,
} from "./Chatbot-model";

interface ErrorTabContent {
  err: boolean;
  message?: string;
}

interface ChatbotContextProps {
  /** チャットボットデータ  */
  chatbot: ChatBotModel;
  setChatbot: Dispatch<SetStateAction<ChatBotModel>>;
  /** 基本情報タブ　設定するモデルの選択肢 */
  models: Model[];
  setModels: Dispatch<SetStateAction<Model[]>>;
  /** パラメータタブ　チャンクサイズの選択肢 */
  chunkSize: ChunkSizeModel[];
  setChunkSize: Dispatch<SetStateAction<ChunkSizeModel[]>>;
  /** 画面モード　新規・編集・参照 */
  openMode: string | undefined;
  setOpenMode: Dispatch<SetStateAction<string | undefined>>;
  /** 権限タブ 組織の画面表示データ */
  authorityCompanyInfo: AuthorityCompanyInfo[];
  setAuthorityCompanyInfo: Dispatch<SetStateAction<AuthorityCompanyInfo[]>>;
  /** 権限タブ ユーザーの画面表示データ */
  authorityEmployeeInfo: AuthorityEmployeeInfo[];
  setAuthorityEmployeeInfo: Dispatch<SetStateAction<AuthorityEmployeeInfo[]>>;
  /** 権限タブ 組織の初期データ（削除時に使用） */
  initialAuthorityCompanyInfo: AuthorityCompanyInfo[];
  setInitialAuthorityCompanyInfo: Dispatch<
    SetStateAction<AuthorityCompanyInfo[]>
  >;
  /** 権限タブ ユーザーの初期データ（削除時に使用） */
  initialAuthorityEmployeeInfo: AuthorityEmployeeInfo[];
  setInitialAuthorityEmployeeInfo: Dispatch<
    SetStateAction<AuthorityEmployeeInfo[]>
  >;
  /** 権限タブ 組織の検索結果 */
  companySearchResults: AuthorityCompanyInfo[];
  setCompanySearchResults: Dispatch<SetStateAction<AuthorityCompanyInfo[]>>;
  /** 権限タブ ユーザーの検索結果 */
  employeeSearchResults: AuthorityEmployeeInfo[];
  setEmployeeSearchResults: Dispatch<SetStateAction<AuthorityEmployeeInfo[]>>;
  /** 管理者ID保持用 */
  adminId: string | undefined;
  setAdminId: Dispatch<SetStateAction<string | undefined>>;
  /** 権限タブ　権限の選択肢*/
  authority: AuthorityKind[];
  setAuthority: Dispatch<SetStateAction<AuthorityKind[]>>;
  /** ドキュメントタブ　画面表示情報 */
  documentTableData: DocumentTabData[];
  setDocumentTableData: Dispatch<SetStateAction<DocumentTabData[]>>;
  /** パラメータタブ　チャンクサイズの選択状態 */
  selectedChunkLabel: string;
  setSelectedChunkLabel: Dispatch<SetStateAction<string>>;
  /** 画面自体の表示非表示 */
  isModalVisible: boolean;
  setIsModalVisible: Dispatch<SetStateAction<boolean>>;
  /** エラーアイコン制御用 */
  errTabsContents: {
    name: ErrorTabContent;
    description: ErrorTabContent;
    overlap: ErrorTabContent;
    token: ErrorTabContent;
    chunkSize: ErrorTabContent;
    model: ErrorTabContent;
  };
  setErrTabsContents: Dispatch<
    SetStateAction<{
      name: ErrorTabContent;
      description: ErrorTabContent;
      overlap: ErrorTabContent;
      token: ErrorTabContent;
      chunkSize: ErrorTabContent;
      model: ErrorTabContent;
    }>
  >;
}

export const ChatbotContext = createContext<ChatbotContextProps | undefined>(
  undefined,
);

export const ChatbotContextProvider = ({
  children,
  initialChatbotData,
}: {
  children: ReactNode;
  initialChatbotData: ChatBotModel;
}) => {
  const [chatbot, setChatbot] = useState<ChatBotModel>(initialChatbotData);
  const [models, setModels] = useState<Model[]>([]);
  const [chunkSize, setChunkSize] = useState<ChunkSizeModel[]>([]);
  const [openMode, setOpenMode] = useState<string | undefined>();
  const [authorityCompanyInfo, setAuthorityCompanyInfo] = useState<
    AuthorityCompanyInfo[]
  >([]);
  const [authorityEmployeeInfo, setAuthorityEmployeeInfo] = useState<
    AuthorityEmployeeInfo[]
  >([]);
  const [initialAuthorityCompanyInfo, setInitialAuthorityCompanyInfo] =
    useState<AuthorityCompanyInfo[]>([]);
  const [initialAuthorityEmployeeInfo, setInitialAuthorityEmployeeInfo] =
    useState<AuthorityEmployeeInfo[]>([]);
  const [companySearchResults, setCompanySearchResults] = useState<
    AuthorityCompanyInfo[]
  >([]);
  const [employeeSearchResults, setEmployeeSearchResults] = useState<
    AuthorityEmployeeInfo[]
  >([]);
  const [adminId, setAdminId] = useState<string | undefined>();
  const [authority, setAuthority] = useState<AuthorityKind[]>([]);
  const [documentTableData, setDocumentTableData] = useState<DocumentTabData[]>(
    [],
  );
  const [selectedChunkLabel, setSelectedChunkLabel] = useState<string>("");
  const [isModalVisible, setIsModalVisible] = useState<boolean>(true);
  const [errTabsContents, setErrTabsContents] = useState({
    name: { err: false },
    description: { err: false },
    overlap: { err: false },
    token: { err: false },
    chunkSize: { err: false },
    model: { err: false },
  });

  return (
    <ChatbotContext.Provider
      value={{
        chatbot,
        setChatbot,
        models,
        setModels,
        chunkSize,
        setChunkSize,
        openMode,
        setOpenMode,
        authorityCompanyInfo,
        setAuthorityCompanyInfo,
        authorityEmployeeInfo,
        setAuthorityEmployeeInfo,
        initialAuthorityCompanyInfo,
        setInitialAuthorityCompanyInfo,
        initialAuthorityEmployeeInfo,
        setInitialAuthorityEmployeeInfo,
        companySearchResults,
        setCompanySearchResults,
        employeeSearchResults,
        setEmployeeSearchResults,
        adminId,
        setAdminId,
        authority,
        setAuthority,
        documentTableData,
        setDocumentTableData,
        selectedChunkLabel,
        setSelectedChunkLabel,
        isModalVisible,
        setIsModalVisible,
        errTabsContents,
        setErrTabsContents,
      }}
    >
      {children}
    </ChatbotContext.Provider>
  );
};

export const useChatbotContext = () => {
  const context = useContext(ChatbotContext);
  if (!context) {
    throw new Error("contextでエラーが発生しました。");
  }
  return context;
};
