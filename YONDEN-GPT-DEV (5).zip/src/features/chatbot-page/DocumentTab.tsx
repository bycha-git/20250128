"use client";

import React, { useEffect, useRef, useState } from "react";
import { countWord } from "../common/countWord";
import { uniqueId } from "../common/util";
import { showError } from "../globals/global-message-store";
import Breadcrumbs from "../ui/breadcrumbs";
import { Checkbox } from "../ui/checkbox";
import { useConfirm } from "../ui/confirm";
import CustomDropdownMenu from "../ui/DropdownMenu";
import { useResponsive } from "../ui/responsive";
import { Separator } from "../ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { useChatbotEnvContext } from "./chatbot-env-context";
import { DocumentTabData } from "./Chatbot-model";
import { useChatbotContext } from "./ChatbotContext";
import { Link } from "./link";
import OverwriteDialog from "./OverwriteDialog";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { Button } from "@/features/ui/button";
import { Input } from "@/features/ui/input";

// 新規追加メニュー
const createNewMenu = [
  { iconClass: "i-mdi-folder-outline", label: "フォルダー" },
  { iconClass: "i-mdi-folder-add-outline", label: "フォルダーのアップロード" },
  { iconClass: "i-mdi-file-document-outline", label: "ファイルのアップロード" },
];

// 個別データメニュー
const selectDataMenu = [
  {
    iconClass: "i-tdesign-edit-2",
    label: "名前を変更",
  },
  { iconClass: "i-material-symbols-delete-outline-rounded", label: "削除" },
];

// 個別データメニュー（リンク編集有）
const selectDataLinkMenu = [
  {
    iconClass: "i-material-symbols-link-rounded",
    label: "リンクを編集",
  },
  {
    iconClass: "i-tdesign-edit-2",
    label: "名前を変更",
  },
  { iconClass: "i-material-symbols-delete-outline-rounded", label: "削除" },
];

// パンくずリスト初期値
const breadcrumbItems = [{ label: "ホーム", id: "home" }];
interface BreadcrumbItem {
  label: string;
  id: string;
}

const DocumentTab: React.FC = () => {
  const {
    documentTableData,
    setDocumentTableData,
    chatbot,
    openMode,
    setIsModalVisible,
  } = useChatbotContext();

  // 環境変数
  const { supportedFileExt, maxTotalDocumentUpSize } = useChatbotEnvContext();

  // 確認ダイアログ
  const { confirm } = useConfirm();

  // パンくずリスト管理
  const [breadcrumbs, setBreadcrumbs] =
    useState<BreadcrumbItem[]>(breadcrumbItems);
  // メニュー制御
  const [createMenuOpen, setCreateMenuOpen] = useState(false);
  const [allDelete, setAllDelete] = useState(false);
  const [selectDataMenuOpen, setSelectDataMenuOpen] = useState(false);
  // ファイル/フォルダ取得用
  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);
  // 名前変更用
  const inputRef = useRef<HTMLInputElement>(null);

  // 上書き確認ダイアログの表示制御
  const [isOverwriteDialogOpen, setIsOverwriteDialogOpen] = useState(false);
  // 重複しているファイルやフォルダーのリスト
  const [duplicateItems, setDuplicateItems] = useState<DocumentTabData[]>([]);
  // 追加予定のファイルやフォルダーのリスト
  const [pendingItems, setPendingItems] = useState<DocumentTabData[]>([]);

  // リンク編集画面制御
  const [isLinkWindowOpen, setIsLinkWindowOpen] = useState(false);

  // フォルダー名編集用
  const [editingFolderId, setEditingFolderId] = useState<string | null>(null);
  const [editingFolderName, setEditingFolderName] = useState<string>("");

  // どのメニューが開かれているか
  const [activeMenuId, setActiveMenuId] = useState<string>();
  // 選択されたデータの状態を追加
  const [selectedData, setSelectedData] = useState<DocumentTabData>();
  const [currentDuplicateIndex, setCurrentDuplicateIndex] = useState(0);

  // 変更前のドキュメント名
  const [originalFolderName, setOriginalFolderName] = useState<string>("");

  const { isMobile } = useResponsive();

  // エラーメッセージ
  const errMessage = useErrorMessage();

  // 活性非活性制御のためstateで管理
  const [deleteMenu, setDeleteMenu] = useState([
    {
      iconClass: "i-material-symbols-delete-outline-rounded",
      label: "削除",
      disabled: true,
    },
    {
      iconClass: "i-material-symbols-delete-outline-rounded",
      label: "全て削除",
      disabled: true,
    },
  ]);

  // 削除対象になっているドキュメントは画面に表示しない
  const currentFolderId = breadcrumbs[breadcrumbs.length - 1].id;
  // フィルタリングされたデータを取得
  const filteredData = documentTableData.filter(
    (item) =>
      item.document.parentFolderId === currentFolderId &&
      item.dispStatus !== "delete",
  );

  // 表示データをソート
  const sortedData = filteredData.sort((a, b) => {
    // フォルダを先に、ファイルを後にソート
    if (a.folderFlg && !b.folderFlg) return -1;
    if (!a.folderFlg && b.folderFlg) return 1;

    // 名前の昇順でソート
    return a.document.documentName.localeCompare(
      b.document.documentName,
      "ja",
      { numeric: true },
    );
  });

  // チェックされているデータがあるか確認
  const checkedItems = documentTableData.some((item) => item.selectFlg);
  // 表示されているデータがあるか確認
  const noDeleteItems = documentTableData.some(
    (item) => item.dispStatus !== "delete",
  );

  /** パンくずリストの更新 */
  const breadcrumbClick = (id: string) => {
    const index = breadcrumbs.findIndex((item) => item.id === id);
    setBreadcrumbs(breadcrumbs.slice(0, index + 1));
  };

  /** ドキュメントが更新されるたびメニューの活性非活性を制御 */
  useEffect(() => {
    setDeleteMenu([
      {
        iconClass: "i-material-symbols-delete-outline-rounded",
        label: "削除",
        disabled: !checkedItems,
      },
      {
        iconClass: "i-material-symbols-delete-outline-rounded",
        label: "全て削除",
        disabled: !noDeleteItems,
      },
    ]);
  }, [documentTableData, checkedItems, noDeleteItems]);

  // ドロップダウン内ボタン押下で編集モードに切り替わった際に、フォーカスを設定
  const onDropDownCloseAutoFocus = (event: Event) => {
    // 「新規追加→フォルダー」「名前を変更」が押されて
    // DropDownMenu の open 引数が false となったことで
    // onCloseAutoFocus が実行された場合、
    // onCloseAutoFocus をキャンセルして input にフォーカス

    // onCloseAutoFocus (onUnmountAutoFocus) はかなり遅めに発動される
    // (useEffect のクリーンアップ ＋ setTimeout(fn, 0))
    // ので、発動前に inputRef.current がセットされている
    // https://www.radix-ui.com/primitives/docs/components/dropdown-menu#content
    // https://github.com/radix-ui/primitives/blob/4584a37b/packages/react/focus-scope/src/FocusScope.tsx#L156
    if (editingFolderId) {
      event.preventDefault();
      // 一応 setTimeout しておく (radix-ui 側の setTimeout が無くなった時のため)
      setTimeout(() => {
        inputRef.current?.focus();
      }, 0);
    }
  };

  /** チェック状態更新 */
  const checkedChange = (checked: boolean, documentId: string) => {
    setDocumentTableData((prevData) =>
      prevData.map((data) =>
        data.document.id === documentId
          ? { ...data, selectFlg: checked }
          : data,
      ),
    );
  };

  /** フォルダクリック時の階層移動 */
  const folderClick = (item: DocumentTabData) => {
    if (item.folderFlg) {
      setBreadcrumbs([
        ...breadcrumbs,
        { label: item.document.documentName, id: item.document.id },
      ]);
    }
  };

  /** フォルダ新規追加処理 */
  const createNew = (label: string) => {
    if (label === "フォルダー") {
      // 新しいフォルダー名を作成（重複しないように）
      const newFolderName = (baseName: string) => {
        let folderName = baseName;
        let counter = 2;
        const filteredData = documentTableData.filter(
          (item) => item.document.parentFolderId === currentFolderId,
        );

        while (
          filteredData.some((item) => item.document.documentName === folderName)
        ) {
          folderName = `${baseName} (${counter})`;
          counter += 1;
        }

        return folderName;
      };

      const uniqueFolderName = newFolderName("新しいフォルダー");

      const newFolder: DocumentTabData = {
        document: {
          id: uniqueId(),
          type: "FOLDER_DOCUMENT",
          userId: "",
          createdAt: "",
          chatbotId: openMode === "新規" ? "" : chatbot.id,
          parentFolderId: currentFolderId,
          documentName: uniqueFolderName,
          lastUpdateAt: new Date().toISOString(),
          documentSize: undefined,
          isOriginalLink: undefined,
          standardLink: "",
          originalLink: "",
          isError: false,
          errorMessage: "",
        },
        folderFlg: true,
        dispStatus: "add",
        selectFlg: false,
      };

      // テーブルの状態を更新
      setDocumentTableData([...documentTableData, newFolder]);

      // フォルダー名編集モードに設定
      setEditingFolderId(newFolder.document.id);
      setOriginalFolderName(uniqueFolderName);
      setEditingFolderName(uniqueFolderName);
    } else if (label === "ファイルのアップロード" && fileInputRef.current) {
      fileInputRef.current.multiple = true;
      fileInputRef.current.click();
    } else if (label === "フォルダーのアップロード" && folderInputRef.current) {
      folderInputRef.current.webkitdirectory = true;
      folderInputRef.current.click();
    }
  };

  /** 「名前を変更」ボタン押下処理 */
  const editName = (documentId: string, currentName: string) => {
    setEditingFolderId(documentId);
    setOriginalFolderName(currentName);
    setEditingFolderName(currentName);
  };

  /** ドキュメント名を変更する */
  const nameSave = async (documentId: string) => {
    // 現在のフォルダ内の既存のアイテム名を取得（自分自身を除く）
    const existingNames = documentTableData
      .filter(
        (item) =>
          item.document.parentFolderId === currentFolderId &&
          item.document.id !== documentId &&
          item.dispStatus !== "delete",
      )
      .map((item) => item.document.documentName);

    if (!originalFolderName.trim() && !editingFolderName.trim()) {
      setEditingFolderId(null);
      return;
    }

    const selectDocument = documentTableData.filter(
      (item) => item.document.id === documentId,
    );

    // ドキュメント名が入力されていない場合元の名前に戻す
    if (!editingFolderName.trim()) {
      setDocumentTableData((prevData) =>
        prevData.map((data) =>
          data.document.id === documentId
            ? {
                ...data,
                document: {
                  ...data.document,
                  documentName: originalFolderName,
                },
              }
            : data,
        ),
      );
      setEditingFolderId(null);
      return;
    }

    // 重複がある場合、フォルダーの作成を中止し、エラーメッセージを表示
    if (existingNames.includes(editingFolderName.trim())) {
      const messeageId = selectDocument[0].folderFlg
        ? "ECHATBOT0010"
        : "ECHATBOT0011";

      showError(errMessage[messeageId]);
      return;
    }

    // ドキュメント名を更新
    setDocumentTableData((prevData) =>
      prevData.map((data) =>
        data.document.id === documentId
          ? {
              ...data,
              document: { ...data.document, documentName: editingFolderName },
              dispStatus: data.dispStatus !== "add" ? "name_change" : "add",
              blobFilePath: getFullBlobPathArray(
                data.document.parentFolderId,
                data.folderFlg ? documentId : editingFolderName,
              ).join("/"),
            }
          : data,
      ),
    );
    setEditingFolderId(null);
  };

  /** ファイル取得処理 */
  const fileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    const MAX_TOTAL_DOCUMENT_UPLOAD_SIZE = Number(maxTotalDocumentUpSize);

    if (files) {
      // 現在の合計サイズを計算(アップロードするものだけ)
      const currentTotalSize = documentTableData.reduce((sum, item) => {
        if (
          item.document.documentSize &&
          (item.dispStatus === "add" || item.dispStatus === "update")
        ) {
          return sum + item.document.documentSize;
        }
        return sum;
      }, 0);

      // アップロードされたファイルのサイズを合計
      const uploadedFilesTotalSize = Array.from(files).reduce((sum, file) => {
        return sum + file.size;
      }, 0);
      // 合計サイズを計算
      const newTotalSize = currentTotalSize + uploadedFilesTotalSize;

      // サイズ制限を超えている場合はエラーメッセージを表示して中断
      if (newTotalSize > MAX_TOTAL_DOCUMENT_UPLOAD_SIZE) {
        showError("合計サイズが1GBを超えています。");
        event.target.value = "";
        return;
      }

      const newFiles: DocumentTabData[] = Array.from(files).map((file) => ({
        document: {
          id: uniqueId(),
          type: "FILE_DOCUMENT",
          userId: "",
          createdAt: "",
          chatbotId: openMode === "新規" ? "" : chatbot.id,
          parentFolderId: currentFolderId,
          documentName: file.name,
          lastUpdateAt: new Date(file.lastModified).toISOString(),
          documentSize: file.size,
          isOriginalLink: false,
          standardLink: "",
          originalLink: "",
          isError: false,
          errorMessage: "",
        },
        folderFlg: false,
        dispStatus: "add",
        selectFlg: false,
        originalFile: file,
        // currentFolderId のフォルダが既に存在するためIDで検索。
        // ファイルはまだ存在しないため直接ファイル名を追加
        // TODO: 普通に documentPath を使えばよいのでは
        blobFilePath: getFullBlobPathArray(currentFolderId, file.name).join(
          "/",
        ),
      }));

      // 現在のフォルダ内の既存のアイテム名を取得
      const existingNames = filteredData.map(
        (item) => item.document.documentName,
      );

      // 重複しているファイルをチェック
      const duplicates = newFiles.filter((newFile) =>
        existingNames.includes(newFile.document.documentName),
      );

      if (duplicates.length > 0) {
        // 重複がある場合、ダイアログを表示
        setDuplicateItems(duplicates);
        // 重複していないアイテムを先に追加
        const nonDuplicates = newFiles.filter(
          (newFile) => !existingNames.includes(newFile.document.documentName),
        );
        setDocumentTableData([...documentTableData, ...nonDuplicates]);
        setPendingItems(newFiles);
        setCurrentDuplicateIndex(0);
        setIsOverwriteDialogOpen(true);
      } else {
        // 重複がない場合、そのまま追加
        setDocumentTableData([...documentTableData, ...newFiles]);
      }
    }
    event.target.value = "";
  };

  /** フォルダ取得処理 */
  const folderUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const MAX_TOTAL_DOCUMENT_UPLOAD_SIZE = Number(maxTotalDocumentUpSize);

    const files = event.target.files;
    if (files) {
      const fileList = Array.from(files);

      // 現在の合計サイズを計算
      const currentTotalSize = documentTableData.reduce((sum, item) => {
        if (
          item.document.documentSize &&
          (item.dispStatus === "add" || item.dispStatus === "update")
        ) {
          return sum + item.document.documentSize;
        }
        return sum;
      }, 0);

      // アップロードされたフォルダ内のファイルの総サイズを計算
      const uploadedFilesTotalSize = fileList.reduce((sum, file) => {
        return sum + file.size;
      }, 0);

      // 新しい合計サイズを計算
      const newTotalSize = currentTotalSize + uploadedFilesTotalSize;

      // サイズ制限を超えている場合はエラーメッセージを表示して中断
      if (newTotalSize > MAX_TOTAL_DOCUMENT_UPLOAD_SIZE) {
        showError("合計サイズが1GBを超えています。");
        event.target.value = "";
        return;
      }
      const newItems: DocumentTabData[] = [];

      // フォルダパスとID（既存のフォルダーを含む）
      const folderMap = new Map<string, string>();
      documentTableData
        .filter((item) => item.folderFlg && item.dispStatus !== "delete")
        .forEach((item) => {
          const fullPath = getFullPath(item.document.id);
          folderMap.set(fullPath, item.document.id);
        });

      // ファイルのパスとID（既存のファイルを含む）
      const fileMap = new Map<string, string>();
      documentTableData.forEach((item) => {
        if (!item.folderFlg && item.dispStatus !== "delete") {
          const fullPath = getFullPath(item.document.id);
          fileMap.set(fullPath, item.document.id);
        }
      });

      // 重複しているファイルを収集
      const duplicates: DocumentTabData[] = [];

      // 取得したデータからフォルダとファイルを取得
      // TODO: フォルダ内ファイルの拡張子制限がacceptに合わせてかかるか確認
      // TODO: 空フォルダを取り込めるようにしたい場合 webkitEntries 使う？
      // https://developer.mozilla.org/ja/docs/Web/API/HTMLInputElement/webkitdirectory
      fileList.forEach((file) => {
        // 1ファイルに対する処理 (現状空フォルダは無視される)

        // 「a」フォルダをアップロードしてその中に b/c/d.txt があった場合
        // pathParts は ["a", "b", "c"], fileName は "d.txt" となる
        const relativePath = file.webkitRelativePath;
        const pathParts = relativePath.split("/");
        const fileName = pathParts.pop()!;
        let parentId = currentFolderId;
        // 現在表示中のフォルダまでのパスとBlob Storageパス
        let currentPath = getFullPath(parentId);
        const blobPathParts = getFullBlobPathArray(parentId);

        // フォルダーの作成
        pathParts.forEach((part) => {
          currentPath = currentPath ? `${currentPath}/${part}` : part;
          const fullPath = currentPath;
          const folderIdInFolderMap = folderMap.get(fullPath);
          if (!folderIdInFolderMap) {
            const folderId = uniqueId();
            const newFolder: DocumentTabData = {
              document: {
                id: folderId,
                type: "FOLDER_DOCUMENT",
                userId: "",
                createdAt: "",
                chatbotId: openMode === "新規" ? "" : chatbot.id,
                parentFolderId: parentId,
                documentName: part,
                lastUpdateAt: new Date().toISOString(),
                documentSize: undefined,
                isOriginalLink: undefined,
                standardLink: "",
                originalLink: "",
                isError: false,
                errorMessage: "",
              },
              folderFlg: true,
              dispStatus: "add",
              selectFlg: false,
            };
            newItems.push(newFolder);
            folderMap.set(fullPath, folderId);
            parentId = folderId;
            blobPathParts.push(folderId);
          } else {
            parentId = folderIdInFolderMap;
            blobPathParts.push(folderIdInFolderMap);
          }
        });

        // blobFilePath を完成させる
        blobPathParts.push(fileName);
        const blobFilePath = blobPathParts.join("/");

        // ファイルの作成
        const fileId = uniqueId();
        const newFile: DocumentTabData = {
          document: {
            id: fileId,
            type: "FILE_DOCUMENT",
            userId: "",
            createdAt: "",
            chatbotId: openMode === "新規" ? "" : chatbot.id,
            parentFolderId: parentId,
            documentName: fileName,
            lastUpdateAt: new Date(file.lastModified).toISOString(),
            documentSize: file.size,
            isOriginalLink: false,
            standardLink: "",
            originalLink: "",
            isError: false,
            errorMessage: "",
          },
          folderFlg: false,
          dispStatus: "add",
          selectFlg: false,
          originalFile: file,
          blobFilePath,
        };

        const fullFilePath = `${currentPath}/${fileName}`;

        if (fileMap.has(fullFilePath)) {
          // 重複しているファイルを収集
          duplicates.push(newFile);
        } else {
          // 重複していないファイルを追加
          newItems.push(newFile);
          fileMap.set(fullFilePath, fileId);
        }
      });

      if (duplicates.length > 0) {
        // 重複がある場合、ダイアログを表示
        setDuplicateItems(duplicates);
        // 重複していないアイテムを先に追加
        setDocumentTableData([...documentTableData, ...newItems]);
        setPendingItems(duplicates);
        setCurrentDuplicateIndex(0);
        setIsOverwriteDialogOpen(true);
      } else {
        // 重複がない場合、そのまま追加
        setDocumentTableData([...documentTableData, ...newItems]);
      }
    }
    event.target.value = "";
  };

  /** フォルダーやファイルのパスを取得する */
  const getFullPath = (itemId: string): string => {
    if (itemId === "home") return "";
    const pathParts: string[] = [];
    let currentItem = documentTableData.find(
      (item) => item.document.id === itemId,
    );

    while (currentItem && currentItem.document.parentFolderId !== "home") {
      pathParts.unshift(currentItem.document.documentName);
      currentItem = documentTableData.find(
        (item) => item.document.id === currentItem?.document.parentFolderId,
      );
    }

    if (currentItem && currentItem.document.parentFolderId === "home") {
      pathParts.unshift(currentItem.document.documentName);
    }

    return pathParts.join("/");
  };

  /**
   * フォルダーやファイルの Blob Storage 上のパスを配列で取得する
   * (フォルダのドキュメントID/フォルダのドキュメントID/.../ファイル名)
   */
  const getFullBlobPathArray = (
    itemId: string,
    fileName?: string,
  ): string[] => {
    const getFolderIdOrFileName = (item: DocumentTabData): string => {
      return item.folderFlg ? item.document.id : item.document.documentName;
    };

    const pathParts: string[] = [];
    if (fileName !== undefined) {
      pathParts.unshift(fileName);
    }

    if (itemId === "home") return pathParts;

    let currentItem = documentTableData.find(
      (item) => item.document.id === itemId,
    );

    while (currentItem && currentItem.document.parentFolderId !== "home") {
      pathParts.unshift(getFolderIdOrFileName(currentItem));
      currentItem = documentTableData.find(
        (item) => item.document.id === currentItem?.document.parentFolderId,
      );
    }

    if (currentItem && currentItem.document.parentFolderId === "home") {
      pathParts.unshift(getFolderIdOrFileName(currentItem));
    }

    return pathParts;
  };

  console.log("ドキュメントデータ >>", documentTableData);

  /** 上書き処理　全てスキップ */
  const skipAll = () => {
    // 何もせずダイアログを閉じる
    setIsOverwriteDialogOpen(false);
  };

  /** 上書き処理　スキップ */
  const skip = () => {
    nextDucument();
  };

  /** 上書き処理　置換 */
  const replace = () => {
    const currentItem = duplicateItems[currentDuplicateIndex];
    const fullPath =
      getFullPath(currentItem.document.parentFolderId) +
      "/" +
      currentItem.document.documentName;

    setDocumentTableData((prevData) =>
      prevData.map((data) => {
        const dataFullPath =
          getFullPath(data.document.parentFolderId) +
          "/" +
          data.document.documentName;

        if (dataFullPath === fullPath && !data.folderFlg) {
          return {
            ...data,
            document: {
              ...data.document,
              ...currentItem.document,
              id: data.document.id,
              userId: data.document.userId,
            },
            dispStatus:
              data.dispStatus === "old" ? "update" : currentItem.dispStatus,
            originalFile: currentItem.originalFile,
            blobFilePath: getFullBlobPathArray(
              data.document.parentFolderId,
              data.document.documentName,
            ).join("/"),
          };
        }

        return data;
      }),
    );

    nextDucument();
  };

  /** 上書き処理　全て置換 */
  const replaceAll = () => {
    const duplicatePaths = duplicateItems.map(
      (item) =>
        getFullPath(item.document.parentFolderId) +
        "/" +
        item.document.documentName,
    );

    setDocumentTableData((prevData) =>
      prevData.map((data) => {
        const dataFullPath =
          getFullPath(data.document.parentFolderId) +
          "/" +
          data.document.documentName;

        if (duplicatePaths.includes(dataFullPath) && !data.folderFlg) {
          const newItem = duplicateItems.find(
            (item) => item.document.documentName === data.document.documentName,
          );
          return {
            ...data,
            document: {
              ...data.document,
              ...newItem!.document,
              id: data.document.id,
              userId: data.document.userId,
            },
            dispStatus:
              data.dispStatus === "old" ? "update" : newItem!.dispStatus,
            originalFile: newItem!.originalFile,
            blobFilePath: getFullBlobPathArray(
              data.document.parentFolderId,
              data.document.documentName,
            ).join("/"),
          };
        }

        return data;
      }),
    );
    // 上書きダイアログを閉じる
    setIsOverwriteDialogOpen(false);
  };

  /** 上書き処理　次の重複ドキュメントへ */
  const nextDucument = () => {
    if (currentDuplicateIndex + 1 < duplicateItems.length) {
      setCurrentDuplicateIndex(currentDuplicateIndex + 1);
    } else {
      setIsOverwriteDialogOpen(false);
    }
  };

  /** 重複しているドキュメントを取得する */
  const getExistingItem = (item: DocumentTabData) => {
    const fullPath =
      getFullPath(item.document.parentFolderId) +
      "/" +
      item.document.documentName;
    return documentTableData.find((data) => {
      const dataFullPath =
        getFullPath(data.document.parentFolderId) +
        "/" +
        data.document.documentName;
      return dataFullPath === fullPath && !data.folderFlg;
    });
  };

  /** チェックされたドキュメントを削除する */
  const deleteSelected = async () => {
    // モーダルを一時的に非表示にする
    setIsModalVisible(false);

    const result = await confirm({
      text: (
        <>
          <strong>選択したフォルダーまたはファイル</strong>
          を削除します。
        </>
      ),
      title: "ドキュメントを削除しますか？",
      okButtonText: "削除する",
      cancelButtonText: "キャンセルする",
    });

    setIsModalVisible(true);

    if (result) {
      setDocumentTableData((prevData) => {
        // 削除対象
        const deleteDocumennt = new Set<string>();

        // 選択されたアイテムを取得
        const selectedItems = prevData.filter((item) => item.selectFlg);

        // 削除対象のIDを収集
        selectedItems.forEach((item) => {
          getDeleteData(item, prevData, deleteDocumennt);
        });

        return prevData
          .map((item) => {
            if (deleteDocumennt.has(item.document.id)) {
              if (item.dispStatus === "add") {
                // 新規データは削除
                return null;
              } else {
                // 既存データは削除フラグを設定
                return { ...item, dispStatus: "delete", selectFlg: false };
              }
            }
            return item;
          })
          .filter((item): item is DocumentTabData => item !== null);
      });
    }
  };

  /** 全てのドキュメントを削除する */
  const deleteAll = async () => {
    // モーダルを一時的に非表示にする
    setIsModalVisible(false);

    const result = await confirm({
      text: (
        <>
          <strong>全てのフォルダーまたはファイル</strong>
          を削除します。
        </>
      ),
      title: "ドキュメントを削除しますか？",
      okButtonText: "削除する",
      cancelButtonText: "キャンセルする",
    });

    if (result) {
      // 新規作成したデータはデータから削除し、既存データはdeleteにする
      setDocumentTableData((prevData) =>
        prevData
          .filter((data) => data.dispStatus !== "add")
          .map((data) => {
            if (data.dispStatus === "old") {
              return { ...data, dispStatus: "delete", selectFlg: false };
            }

            if (data.folderFlg) {
              return {
                ...data,
                dispStatus: "delete",
                children: prevData
                  .filter(
                    (child) =>
                      child.document.parentFolderId === data.document.id,
                  )
                  .map((child) => {
                    if (child.dispStatus === "add") return null;
                    if (child.dispStatus === "old") {
                      return {
                        ...child,
                        dispStatus: "delete",
                        selectFlg: false,
                      };
                    }
                    return child;
                  })
                  .filter(Boolean),
              };
            }

            return data;
          }),
      );
    }
    setIsModalVisible(true);
  };

  /** 行ごとのドキュメントを削除する */
  const rowDataDelete = async (selectDoc: DocumentTabData) => {
    // モーダルを一時的に非表示にする
    setIsModalVisible(false);

    const result = await confirm({
      text: (
        <>
          <strong>{selectDoc.document.documentName}</strong>
          を削除します。
        </>
      ),
      title: "ドキュメントを削除しますか？",
      okButtonText: "削除する",
      cancelButtonText: "キャンセルする",
    });

    if (result) {
      setDocumentTableData((prevData) => {
        const deleteDocumennt = new Set<string>();

        // 選択されたドキュメントと配下のデータを取得
        getDeleteData(selectDoc, prevData, deleteDocumennt);
        return prevData
          .map((data) => {
            if (deleteDocumennt.has(data.document.id)) {
              if (data.dispStatus === "add") {
                // 新規データは削除
                return null;
              } else {
                // 既存データは削除フラグを設定
                return { ...data, dispStatus: "delete" };
              }
            }
            return data;
          })
          .filter((item): item is DocumentTabData => item !== null);
      });
    }
    setIsModalVisible(true);
  };

  /** 削除対象のデータを取得する */
  const getDeleteData = (
    item: DocumentTabData,
    allItems: DocumentTabData[],
    deleteDocumennt: Set<string>,
  ) => {
    deleteDocumennt.add(item.document.id);

    // フォルダの場合、再帰的に子要素を取得
    if (item.folderFlg) {
      const childItems = allItems.filter(
        (child) => child.document.parentFolderId === item.document.id,
      );
      childItems.forEach((child) =>
        getDeleteData(child, allItems, deleteDocumennt),
      );
    }
  };

  /** ファイルサイズ変換 */
  const formatSize = (size: number) => {
    if (size === undefined) {
      return "";
    } else if (size >= 1024 * 1024 * 1024) {
      return `${(size / (1024 * 1024 * 1024)).toFixed(2)} GB`;
    } else if (size >= 1024 * 1024) {
      return `${(size / (1024 * 1024)).toFixed(2)} MB`;
    } else if (size >= 1024) {
      return `${(size / 1024).toFixed(2)} KB`;
    } else {
      return `${size} バイト`;
    }
  };

  /** 拡張子以前の文字列を省略する */
  const renameExtension = (fileName: string, digit: number): string => {
    const lastIndex = fileName.lastIndexOf(".");
    if (lastIndex > 0) {
      const fimeName = fileName.slice(0, lastIndex);
      const extensionName = fileName.slice(lastIndex);
      const dispName = countWord(fimeName, digit);
      return dispName + extensionName;
    }
    return countWord(fileName, digit);
  };

  return (
    <div className="flex min-h-0 min-w-0 flex-1 flex-col">
      <div className="flex">
        {openMode !== "参照" && (
          <>
            <CustomDropdownMenu
              items={createNewMenu}
              open={createMenuOpen}
              onOpenChange={setCreateMenuOpen}
              onCloseAutoFocus={onDropDownCloseAutoFocus}
              onItemClick={(label) => createNew(label)}
              side="bottom"
              align="start"
              sideOffset={5}
              alignOffset={50}
              triggerElement={
                <Button
                  color="default"
                  text="新規追加"
                  onClick={() => setCreateMenuOpen((prev) => !prev)}
                  icon={"i-material-symbols-add"}
                  className="w-[22%] flex-shrink-0 rounded-md"
                />
              }
            />
          </>
        )}

        {/* パンくずリスト */}
        {isMobile ? (
          // スマホ時のパンくずリスト表示
          <div className="relative flex w-full flex-col items-center">
            <div className="flex w-full items-center">
              <Button
                variant="icon"
                icon="i-mdi-chevron-left h-8 w-8 "
                onClick={() => {
                  if (breadcrumbs.length > 1) {
                    const parentId = breadcrumbs[breadcrumbs.length - 2].id;
                    breadcrumbClick(parentId);
                  }
                }}
                disabled={breadcrumbs.length <= 1}
                className={`absolute left-0 p-0 ${
                  breadcrumbs.length <= 1 ? "opacity-50" : ""
                }`}
              />
              <span className="mx-auto text-sm font-bold">
                {breadcrumbs[breadcrumbs.length - 1].label}
              </span>
            </div>
            <Separator className="mt-2" />
          </div>
        ) : (
          // PC時のパンくずリスト表示
          <div className="ml-2 mt-2 min-w-0 overflow-x-auto">
            <div className="inline-block whitespace-nowrap">
              <Breadcrumbs
                items={breadcrumbs}
                onClick={(id) => breadcrumbClick(id)}
              />
            </div>
          </div>
        )}

        {/* ファイルアップロード用 */}
        <input
          type="file"
          ref={fileInputRef}
          multiple
          className="hidden"
          onChange={fileUpload}
          accept={supportedFileExt}
        />

        {/* フォルダーアップロード用 */}
        <input
          type="file"
          ref={folderInputRef}
          className="hidden"
          onChange={folderUpload}
        />
        {openMode !== "参照" && (
          <div className="ml-auto flex-none">
            <CustomDropdownMenu
              items={deleteMenu}
              open={allDelete}
              onOpenChange={setAllDelete}
              side="bottom"
              align="end"
              sideOffset={0}
              alignOffset={0}
              onItemClick={(label) => {
                if (label === "削除") deleteSelected();
                if (label === "全て削除") deleteAll();
              }}
              triggerElement={
                <Button
                  variant={"icon"}
                  icon="i-mdi-dots-horizontal h-7 w-7"
                  onClick={() => setAllDelete((prev) => !prev)}
                />
              }
            />
          </div>
        )}
      </div>

      <div className="min-h-0 flex-1 overflow-auto">
        <Table className="min-h-0">
          {/* テーブルヘッダー: スマホ時は非表示 */}
          {!isMobile && (
            <TableHeader>
              <TableRow>
                <TableHead className="w-[0%]"></TableHead>
                <TableHead className="w-[52%] px-0">名前</TableHead>
                <TableHead className="w-[25%] px-0">更新日時</TableHead>
                <TableHead className="w-[15%] px-0">サイズ</TableHead>
                <TableHead className="w-[0%]"></TableHead>
              </TableRow>
            </TableHeader>
          )}

          {/* テーブルボディ */}
          <TableBody>
            {sortedData.map((item) => {
              const date = new Date(item.document.lastUpdateAt);
              const formattedDate = `${date.getFullYear()}年${
                date.getMonth() + 1
              }月${date.getDate()}日`;
              const linkDispFlg =
                !item.folderFlg &&
                (item.document.originalLink.trim() !== "" ||
                  item.document.standardLink.trim() !== "") &&
                (item.document.isOriginalLink || !item.originalFile);

              return isMobile ? (
                // スマホ時の表示
                <TableRow
                  key={item.document.id}
                  className="flex flex-col gap-2 border-b border-gray-200"
                >
                  <TableCell className="px-0 py-1">
                    <div className="flex flex-shrink-0 items-center">
                      <span
                        className={`mr-2 flex h-5 w-5 ${
                          item.folderFlg
                            ? "i-mdi-folder-outline"
                            : "i-mdi-file-document-outline"
                        }`}
                      />

                      <div className="flex flex-col">
                        <span
                          className="cursor-pointer text-[12px]"
                          onClick={() => folderClick(item)}
                        >
                          {countWord(item.document.documentName ?? "", 20)}
                        </span>

                        <div className="text-[12px] text-gray-600">
                          更新日： {formattedDate} 、
                          {formatSize(item.document.documentSize)}
                        </div>
                      </div>
                      {item.document.isError && (
                        <Button
                          icon="i-material-symbols-warning-outline-rounded text-red-500 h-5 w-5"
                          variant="icon"
                          className="ml-auto mr-2 flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1"
                          onClick={() => showError(item.document.errorMessage)}
                        />
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                // PC時の表示
                <TableRow key={item.document.id}>
                  <TableCell className="px-0 py-0.5">
                    <Checkbox
                      className="ml-1 items-center border-transparent bg-white text-black hover:border-gray-500 data-[state=checked]:border-gray-500 data-[state=checked]:bg-white data-[state=checked]:text-black"
                      onCheckedChange={(value) =>
                        checkedChange(value, item.document.id)
                      }
                      checked={item.selectFlg}
                    />
                  </TableCell>
                  <TableCell className="px-0 py-0.5 text-[13px]">
                    <div className="flex items-center">
                      {/* アイコン */}
                      <span
                        className={`mr-2 h-5 w-5 ${
                          item.folderFlg
                            ? "i-mdi-folder-outline"
                            : "i-mdi-file-document-outline"
                        }`}
                      />

                      {/* 編集モードかどうか */}
                      {editingFolderId === item.document.id ? (
                        // 名前を編集する場合の入力フィールド
                        <form
                          onSubmit={(e) => {
                            e.preventDefault();
                            nameSave(item.document.id);
                          }}
                        >
                          <Input
                            value={editingFolderName}
                            onInputText={(text) => setEditingFolderName(text)}
                            onBlur={() => nameSave(item.document.id)}
                            onFocus={(e) => {
                              // メモ: 今後「拡張子部分以外を選択」となった場合
                              // e.target.value.length から拡張子分減らす
                              e.target.setSelectionRange(
                                0,
                                e.target.value.length,
                              );
                            }}
                            enterKeyHint="done"
                            ref={inputRef}
                          />
                        </form>
                      ) : (
                        <>
                          {/* ファイルリンク */}
                          {linkDispFlg ? (
                            <a
                              href={
                                item.document.isOriginalLink
                                  ? item.document.originalLink
                                  : item.standardLinkApiUrl
                              }
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-500 underline"
                            >
                              {renameExtension(
                                item.document.documentName ?? "",
                                20,
                              )}
                            </a>
                          ) : (
                            // フォルダクリック時の処理
                            <span
                              className="cursor-pointer"
                              onDoubleClick={() => folderClick(item)}
                            >
                              {!item.folderFlg
                                ? renameExtension(
                                    item.document.documentName ?? "",
                                    20,
                                  )
                                : countWord(
                                    item.document.documentName ?? "",
                                    20,
                                  )}
                            </span>
                          )}
                        </>
                      )}
                      {/* エラーアイコン */}
                      {item.document.isError && (
                        <Button
                          icon="i-material-symbols-warning-outline-rounded text-red-500 h-5 w-5"
                          variant="icon"
                          className="ml-auto mr-2 flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1"
                          onClick={() => showError(item.document.errorMessage)}
                        />
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="px-0 py-0.5 text-[13px]">
                    {formattedDate}
                  </TableCell>
                  <TableCell className="px-0 py-0.5">
                    {formatSize(item.document.documentSize)}
                  </TableCell>
                  <TableCell className="flex-col px-0 py-0.5">
                    <CustomDropdownMenu
                      items={
                        item.folderFlg ? selectDataMenu : selectDataLinkMenu
                      }
                      open={activeMenuId === item.document.id}
                      onOpenChange={(open) => {
                        if (open) {
                          setActiveMenuId(item.document.id ?? "");
                        } else {
                          setActiveMenuId(undefined);
                        }
                      }}
                      onCloseAutoFocus={onDropDownCloseAutoFocus}
                      onItemClick={(label) => {
                        if (label === "リンクを編集") {
                          setSelectedData(item);
                          setIsLinkWindowOpen(true);
                        }
                        if (label === "名前を変更")
                          editName(
                            item.document.id,
                            item.document.documentName,
                          );
                        if (label === "削除") {
                          rowDataDelete(item);
                        }
                      }}
                      side="bottom"
                      align="end"
                      sideOffset={0}
                      alignOffset={0}
                      triggerElement={
                        <Button
                          variant={"icon"}
                          icon="i-mdi-dots-horizontal h-7 w-7"
                          onClick={() => setSelectDataMenuOpen((prev) => !prev)}
                          className={openMode !== "参照" ? "" : "invisible"}
                        />
                      }
                    />
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>

        {/* リンク編集画面 */}
        {isLinkWindowOpen && (
          <Link
            open={isLinkWindowOpen}
            setOpen={setIsLinkWindowOpen}
            selectDocument={selectedData}
          />
        )}
        {/* 上書き確認画面 */}
        {isOverwriteDialogOpen && (
          <OverwriteDialog
            open={isOverwriteDialogOpen}
            onClose={() => setIsOverwriteDialogOpen(false)}
            currentItem={duplicateItems[currentDuplicateIndex]}
            existingItem={getExistingItem(
              duplicateItems[currentDuplicateIndex],
            )}
            remainingDuplicates={duplicateItems.slice(
              currentDuplicateIndex + 1,
            )}
            onSkip={skip}
            onSkipAll={skipAll}
            onReplace={replace}
            onReplaceAll={replaceAll}
            breadcrumbs={breadcrumbs}
          />
        )}
      </div>
    </div>
  );
};

export default DocumentTab;
