"use client";

import {
  createContext,
  FC,
  PropsWithChildren,
  useContext,
  useMemo,
} from "react";
import { ModelWithParams } from "../chat-view/chat-services/modelOrganizer";

interface ContextProps {
  /** 添付ファイル/ドキュメントとして取込可能なファイル形式のリスト (accept属性に使用) */
  supportedFileExt: string;
  /** インデックス更新1回あたりの最大バイト数 */
  maxTotalDocumentUpSize: string;

  /** モデルパラメーターリスト */
  models?: ModelWithParams[];
}

const Context = createContext<ContextProps | null>(null);

const defaultValue: ContextProps = {
  supportedFileExt: "",
  maxTotalDocumentUpSize: "",
};

interface ProviderProps extends PropsWithChildren, ContextProps {}

/** チャットボット画面用の環境引数等を提供 */
export const ChatbotEnvProvider: FC<ProviderProps> = (props: ProviderProps) => {
  const { supportedFileExt, maxTotalDocumentUpSize, models } = props;

  const value = useMemo(() => {
    return {
      supportedFileExt,
      maxTotalDocumentUpSize,
      models,
    };
  }, [supportedFileExt, maxTotalDocumentUpSize, models]);
  return <Context.Provider value={value}>{props.children}</Context.Provider>;
};

/** チャットボット画面用の環境引数等を取得 */
export const useChatbotEnvContext = () => {
  const context = useContext(Context);
  if (!context) {
    // throw new Error("Chatbot Context is null");

    // ホームからチャットボット情報を参照
    // ドキュメントのアップロードはしないので、空文字としての設定を許容
    return defaultValue;
  }

  return context;
};
