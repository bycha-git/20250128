"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ChatbotThreadParams,
  createChatAndRedirect,
} from "../chat-view/chat-services/chat-thread-service";
import {
  ModelParameter,
  ModelWithParams,
} from "../chat-view/chat-services/modelOrganizer";
import { JSONValue } from "../common/model/common";
import { ChatbotThreadModel } from "../common/model/history/thread-model";
import { showError } from "../globals/global-message-store";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { useResponsive } from "../ui/responsive";
import { Separator } from "../ui/separator";
import { Switch } from "../ui/switch";
import { Window } from "../ui/window";
import { useChatbotEnvContext } from "./chatbot-env-context";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { isRedirectError } from "@/features/common/util";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  chatbot: { chatbotId: string; chatbotName: string; modelId: string };
  clear: () => void;
}

export const ChatbotThreadNewWindow = ({
  open,
  onOpenChange,
  chatbot,
  clear,
}: Props) => {
  const { isDesktop, isMobile } = useResponsive();
  const [loading, setLoading] = useState(false);
  const [prevOpen, setPrevOpen] = useState(open);
  const { models } = useChatbotEnvContext();
  // エラーメッセージ
  const errMessage = useErrorMessage();

  if (prevOpen !== open) {
    if (open) setLoading(false);
    setPrevOpen(open);
  }
  // 初期スレッドパラメータ
  const initialParam: ChatbotThreadParams = useMemo(() => {
    const initParam: ChatbotThreadParams = {
      chatbotId: chatbot.chatbotId,
      chatbotName: chatbot.chatbotName,
      inScope: true,
      topNDocuments: 5,
    };
    models
      ?.find((model) => model.id === "#chatbot#")
      ?.parameters.forEach((param) => {
        const initialOption =
          param.options.find((option) => option.isInitial) ??
          param.options.at(0);
        if (param.name === "strictness") {
          initParam[param.name] = initialOption?.valueForDisplay;
          initParam.optionId = initialOption?.id;
        } else {
          initParam[param.name] = initialOption?.value;
        }
      });
    return initParam;
  }, [models, chatbot.chatbotId, chatbot.chatbotName]);
  const [threadParameter, setThreadParameter] =
    useState<ChatbotThreadParams>(initialParam);

  // パラメータ選択時の処理
  const handleThreadParameter = (
    paramName: string,
    value: JSONValue,
    optionId?: string,
  ) => {
    if (
      threadParameter[paramName] !== value ||
      threadParameter["optionId"] !== optionId
    ) {
      const newThreadParameter = { ...threadParameter, [paramName]: value };
      if (paramName == "strictness")
        newThreadParameter.optionId = optionId || "";
      setThreadParameter(newThreadParameter);
    }
  };
  // 会話開始ボタン押下時の処理
  const handleStartChat = useCallback(async () => {
    setLoading(true);
    const createChatbotThreadParams: ChatbotThreadParams = {
      ...threadParameter,
    };
    try {
      const response = await createChatAndRedirect(createChatbotThreadParams);
      if (response?.status == "REDIRECT") {
        // チャットボットの存在権限チェック、モデルの使用可否チェックを通らなかった場合
        // エラーメッセージを表示
        showError(errMessage[response.errors[0].message]);
        // モーダルを閉じチャットボット一覧画面の初期化処理を実行
        onOpenChange(false);
        clear();
        return;
      }
      if (response?.status == "CHECK") {
        // 必須、単独チェック
        // エラーメッセージを表示
        return showError(errMessage[response.errors[0].message]);
      }
      console.log("handleStartChat response", response);
      if (response) {
        showError(errMessage[response.errors[0]?.message]);
      }
    } catch (e) {
      // リダイレクトされた場合ここに入るのは正常
      if (!isRedirectError(e)) {
        const redirectError = e instanceof Error ? e.message : String(e);
        console.error("リダイレクトエラー", redirectError);
        showError(errMessage["ECOMMON0001"]);
      }
    }
    setLoading(false);
    onOpenChange(false);
  }, [clear, onOpenChange, threadParameter]);
  // モーダル開閉時にパラメータの選択を初期化
  useEffect(() => {
    setThreadParameter(initialParam);
  }, [initialParam, open]);

  return (
    <Window
      open={open}
      onOpenChange={onOpenChange}
      title={"会話を始めましょう"}
      showClose={true}
      mobileFlg={isMobile}
      primaryButtonText={isDesktop && "会話を開始する"}
      onClickPrimary={handleStartChat}
      className={`${isMobile ? "h-screen w-full rounded-none" : "w-fit"} `}
    >
      <div
        className={`grid h-full min-h-0 items-center gap-2 overflow-y-auto ${isMobile ? "grid-cols-1 grid-rows-[auto_auto_minmax(auto,1fr)_auto]" : "grid-cols-[150px_1fr]"}`}
      >
        <ChatbotThreadParameterArea
          threadParameter={threadParameter}
          handleThreadParameter={handleThreadParameter}
          buttonDisabled
          model={models?.find((model) => model.id === "#chatbot#")}
        />
        {isMobile && (
          <Button
            text="会話を開始する"
            className={`mx-auto`}
            onClick={handleStartChat}
          />
        )}
      </div>
    </Window>
  );
};

export const ChatbotThreadParameterArea = (props: {
  threadParameter: ChatbotThreadParams | ChatbotThreadModel;
  chatbotData?: { name: string; isExist: boolean };
  disabled?: boolean;
  buttonDisabled?: boolean;
  handleThreadParameter?: (
    paramName: string,
    value: JSONValue,
    optionId?: string,
  ) => void;
  openChatbot?: () => void;
  model?: ModelWithParams;
}) => {
  const {
    threadParameter,
    chatbotData,
    disabled = false,
    buttonDisabled = false,
    handleThreadParameter,
    openChatbot,
    model,
  } = props;

  const { isMobile } = useResponsive();
  return (
    <>
      <div className={`${isMobile ? "text-sm" : ""} `}>チャットボット</div>
      <div
        className={`${isMobile ? "flex flex-row-reverse" : "flex w-full"} gap-2`}
      >
        {!buttonDisabled && (
          <>
            <Button
              onClick={() => {
                // console.log("チャットボット詳細ウィンドウを開きます");
                openChatbot?.();
              }}
              icon="i-material-symbols-info-outline-rounded size-6 text-black"
              disabled={chatbotData ? !chatbotData.isExist : true}
              className="bg-white p-0"
            ></Button>
          </>
        )}
        <Input
          className="w-[310px] text-ellipsis rounded-sm bg-white"
          disabled
          value={chatbotData ? chatbotData.name : threadParameter.chatbotName}
        ></Input>
      </div>
      {!isMobile && <Separator className="col-span-full" />}

      <div className={`${isMobile ? "text-sm" : ""} `}>一般論の制限</div>

      <div className={`${isMobile ? "flex-col" : "flex justify-end"} `}>
        <Switch
          disabled={disabled}
          checked={threadParameter.inScope}
          onClick={() => {
            if (handleThreadParameter)
              handleThreadParameter("inScope", !threadParameter.inScope);
          }}
        ></Switch>
      </div>
      {!isMobile && <Separator className="col-span-full" />}

      <div className="flex">
        <div className={`${isMobile ? "text-sm" : ""} `}>
          上位検索結果件数（1～99）
        </div>
        <span
          className={`${isMobile ? "" : "i-material-symbols-asterisk-rounded text-red-500"} `}
        ></span>
      </div>
      <div
        className={`${isMobile ? "flex flex-row items-center gap-2" : "flex justify-end"} `}
      >
        <Button
          onClick={() => {
            const value = threadParameter.topNDocuments || 0;
            if (handleThreadParameter && value > 1)
              handleThreadParameter("topNDocuments", value - 1);
          }}
          icon="i-majesticons-minus w-10 h-8 text-black"
          className="bg-gray-01 p-0"
          disabled={disabled}
        />
        <div className="w-20">
          <Input
            disabled={disabled}
            numberOnly={true}
            min={1}
            max={99}
            value={threadParameter.topNDocuments}
            onInputText={(value) => {
              let numericValue = Number(value);
              if (
                !isNaN(numericValue) &&
                numericValue >= 0 &&
                numericValue <= 99
              ) {
                if (value == "00") {
                  numericValue = 0;
                }
                if (handleThreadParameter) {
                  handleThreadParameter("topNDocuments", numericValue);
                }
              }
            }}
            maxLength={2}
            className="w-20 text-center"
          />
        </div>
        <Button
          onClick={() => {
            const value = threadParameter.topNDocuments || 0;
            if (handleThreadParameter && value < 99)
              handleThreadParameter("topNDocuments", value + 1);
          }}
          icon="i-material-symbols-add w-10 h-8 text-black"
          className="bg-gray-01 p-0"
          disabled={disabled}
        />
      </div>
      {model?.parameters.map((param, i) => {
        return (
          <ParameterContent
            key={i}
            param={param}
            threadParams={threadParameter}
            handleThreadParameter={handleThreadParameter}
            disabled={disabled}
          ></ParameterContent>
        );
      })}
    </>
  );
};
const ParameterContent = ({
  param,
  threadParams,
  handleThreadParameter,
  disabled,
}: {
  param: ModelParameter;
  threadParams: ChatbotThreadParams | ChatbotThreadModel;
  handleThreadParameter?: (
    paramName: string,
    value: JSONValue,
    optionId?: string,
  ) => void;
  disabled?: boolean;
}) => {
  const { isMobile } = useResponsive();
  return (
    <>
      {!isMobile && <Separator className="col-span-full" />}
      <div className={`${isMobile ? "text-sm" : ""} `}>{param.label}</div>
      <div
        className={`size-fit items-center rounded-md ${disabled ? "bg-white-01" : "bg-gray-01"} p-2 ${isMobile ? "flex flex-row items-center gap-2" : "flex justify-end gap-4"} `}
      >
        {param.options.map((option, index) => {
          return (
            <Button
              key={index}
              className={`h-fit !flex-[0_0_auto] p-2 ${
                option.value === threadParams[param.name] ||
                option.valueForDisplay === threadParams[param.name]
                  ? disabled
                    ? "bg-gray-hover"
                    : "bg-white-01"
                  : disabled
                    ? "bg-white-01"
                    : "bg-gray-01"
              } !rounded-md text-sm/4 text-black md:text-base`}
              color="default"
              text={option.label}
              disabled={disabled}
              onClick={() => {
                if (handleThreadParameter)
                  handleThreadParameter(
                    param.name,
                    option.valueForDisplay || option.value,
                    option.id,
                  );
              }}
            />
          );
        })}
      </div>
      <div />
      <div className="whitespace-pre-wrap text-sm">{param.description}</div>
    </>
  );
};
