"use server";

import { SqlQuerySpec } from "@azure/cosmos";
import { userHashedId } from "../auth-page/helpers";
import {
  AddAuthorityCompany,
  DeleteAuthortyCompany,
  FindAuthorityCompanys,
  FindSelectAuthorityCompanyByID,
  UpsertAuthorityCompany,
} from "../common/services/authority-company-service";
import {
  AddAuthorityEmployee,
  DeleteAuthortyEmployee,
  FindAuthorityUsers,
  FindSelectAuthorityEmployeeByID,
  UpsertAuthorityEmployee,
} from "../common/services/authority-employee-service";
import { FindAuthorityID } from "../common/services/authority-service";
import {
  companySearch,
  FindCompaniesByIDs,
} from "../common/services/company-service";
import { ConfigContainer, HistoryContainer } from "../common/services/cosmos";
import {
  employeeSearch,
  FindEmployeeByID,
  FindEmployeeByIDs,
} from "../common/services/employee-service";
import { uniqueId } from "../common/util";
import { getDocumentFileParamUrl } from "./chatbot-document/chatbot-document-file";
import {
  AuthorityCompanyInfo,
  AuthorityEmployeeInfo,
  ChatBotModel,
  ChunkSizeModel,
  DocumentModel,
  DocumentTabData,
  Model,
} from "./Chatbot-model";
import { FindChatbotByID } from "./Chatbot-service";

/**　排他チェック返却値 */
interface CheckResult {
  check: boolean;
  message: string;
  errkind: string;
}

/** ユーザー、組織存在チェックの戻り値  */
interface ExistenceResult {
  check: boolean;
  message: string;
  deletedUsers: string[];
  deletedCompanies: string[];
}

/**
 * モーダル初期表示処理(新規)
 */
export const initializingNewModal = async () => {
  try {
    // プルダウン用の権限情報を取得
    const authorityKind = await FindAuthorityID();

    // プルダウン用のチャンクサイズ情報を取得
    const chunkSize = await getChunkSize();

    const dispData = authorityKind.response.map(({ id, label }) => ({
      id,
      label,
    }));
    const userId = (await userHashedId()).toString();

    const userResponse = await FindEmployeeByID(userId);

    const model = await getModel();

    const userData = {
      employeeName:
        userResponse.response?.id + " " + userResponse.response?.employeeName,
      id: userResponse.response?.id,
    };

    return { dispData, userData, model, chunkSize };
  } catch (error) {
    console.error("エラーが発生しました", error);
    throw error;
  }
};

/**
 * チャットボットに設定されている権限取得
 */
export const getTemplateAuthority = async (chatbotId: string) => {
  try {
    // チャットボットに設定されている権限（ユーザー）取得
    const userAuthoritys = await FindAuthorityUsers(chatbotId);
    // チャットボットに設定されている権限（組織）取得
    const companyAuthoritys = await FindAuthorityCompanys(chatbotId);

    // ユーザー情報を画面に表示できる形に編集
    const usersData: AuthorityEmployeeInfo[] =
      userAuthoritys.response?.map(
        ({ id, employeeName, employeeId, permissionId }) => ({
          id: id,
          employeeName: employeeId + " " + employeeName,
          permissionId: permissionId,
          errFlg: false,
        }),
      ) ?? [];

    // 組織情報を画面に表示できる形に編集
    const companyData: AuthorityCompanyInfo[] =
      companyAuthoritys.response?.map(
        ({ id, departmentCode, departmentName, permissionId }) => ({
          id: id,
          departmentName: departmentCode + " " + departmentName,
          permissionId: permissionId,
          errFlg: false,
        }),
      ) ?? [];

    return { usersData, companyData };
  } catch (error) {
    console.error("エラーが発生しました", error);
    throw error;
  }
};

/**
 * ドキュメントデータを取得
 */
export const getDocumentData = async (chatbotId: string) => {
  try {
    // 返却値
    const documentDataResult: DocumentTabData[] = [];
    // チャットボットに設定されているドキュメントを取得
    const documentData = await getDocument(chatbotId);

    if (documentData && documentData.response) {
      documentData.response.forEach((data) => {
        const documentTabData: DocumentTabData = {
          document: {
            id: data.id,
            type: data.type,
            userId: data.userId,
            createdAt: data.createdAt,
            chatbotId: data.chatbotId,
            parentFolderId: data.parentFolderId,
            documentName: data.documentName,
            lastUpdateAt: data.lastUpdateAt,
            documentSize: data.documentSize,
            isOriginalLink: data.isOriginalLink,
            standardLink: data.standardLink,
            originalLink: data.originalLink,
            isError: data.isError,
            errorMessage: data.errorMessage,
            documentPath: data.documentPath,
          },
          folderFlg: data.type === "FOLDER_DOCUMENT" ? true : false,
          dispStatus: "old",
          selectFlg: false,
          standardLinkApiUrl:
            data.type === "FILE_DOCUMENT"
              ? getDocumentFileParamUrl({
                  chatbotId: chatbotId,
                  documentId: data.id,
                })
              : undefined,
        };

        documentDataResult.push(documentTabData);
      });
    }

    return documentDataResult;
  } catch (error) {
    console.error("エラーが発生しました", error);
    throw error;
  }
};

/**
 * 権限タブユーザー検索
 */
export const searchAuthorityUsers = async (searchText: string) => {
  try {
    const employeeResult = await employeeSearch(searchText);

    const searchData: AuthorityEmployeeInfo[] =
      employeeResult.response?.map(({ id, employeeName }) => ({
        id: "",
        employeeName: id + " " + employeeName,
        permissionId: "",
        errFlg: false,
      })) ?? [];
    return searchData;
  } catch (error) {
    throw error;
  }
};

/**
 * 権限タブ組織検索
 */
export const searchAuthorityCompany = async (searchText: string) => {
  try {
    const companyResult = await companySearch(searchText);

    const searchData: AuthorityCompanyInfo[] =
      companyResult.response?.map(({ departmentCode, departmentName }) => ({
        id: "",
        departmentName: departmentCode + " " + departmentName,
        permissionId: "",
        errFlg: false,
      })) ?? [];
    return searchData;
  } catch (error) {
    throw error;
  }
};

/**
 * 登録前排他チェック（編集画面）
 */
export const exclusionCheck = async (
  chatBotId: string,
  lastUpdDate: string,
) => {
  try {
    // 返却値
    const result: CheckResult = {
      check: true,
      message: "",
      errkind: "",
    };

    // テンプレート存在チェック
    const chatBot = await FindChatbotByID(chatBotId);
    // 見つからない場合エラーを返す
    if (chatBot.status == "NOT_FOUND") {
      result.check = false;
      result.message = "ECHATBOT0001";
      result.errkind = "1";
      return result;
    }

    // 更新されていないかチェック
    if (lastUpdDate !== chatBot?.response?.lastUpdateAt) {
      result.check = false;
      result.message = "ECHATBOT0015";
      result.errkind = "2";
      return result;
    }
    return result;
  } catch (error) {
    console.error("エラーが発生しました", error);
    throw error;
  }
};
/**
 * ユーザー、組織存在チェック
 */
export const existenceCheck = async (users: string[], companies: string[]) => {
  try {
    // 返却値
    const result: ExistenceResult = {
      check: true,
      message: "",
      deletedUsers: [],
      deletedCompanies: [],
    };

    // ユーザーが存在するかチェック
    const userCheck = await FindEmployeeByIDs(users);
    const existingUserIds = userCheck.response?.map((user) => user.id) || [];

    // 削除されたユーザーを特定
    result.deletedUsers = users.filter(
      (userId) => !existingUserIds.includes(userId),
    );

    // 組織が存在するかチェック
    const companyCheck = await FindCompaniesByIDs(companies);
    const existingCompanyIds =
      companyCheck.response?.map((company) => company.departmentCode) || [];

    // 削除された組織を特定
    result.deletedCompanies = companies.filter(
      (companyId) => !existingCompanyIds.includes(companyId),
    );

    return result;
  } catch (error) {
    throw error;
  }
};
/**
 * 登録処理
 */
export const insChatBot = async (
  chatbotData: ChatBotModel,
  insertCompany: AuthorityCompanyInfo[],
  insertUsers: AuthorityEmployeeInfo[],
  insDocument: DocumentTabData[],
) => {
  try {
    // ユーザー情報取得
    const userId = (await userHashedId()).toString();
    const userResponse = await FindEmployeeByID(userId);
    const lastUpdUser =
      (userResponse.response?.id ?? "") +
      " " +
      (userResponse.response?.employeeName ?? "");

    const status = insDocument.length == 0 ? "" : "processing";
    // チャットボット新規登録
    const chatbotInsertData = await insertChatbot(
      chatbotData,
      lastUpdUser,
      userId,
      status,
    );
    // 権限（ユーザー）登録
    await AddAuthorityEmployee(
      chatbotInsertData.response?.id ?? "",
      insertUsers,
      userId,
    );
    // 権限（組織）登録
    await AddAuthorityCompany(
      chatbotInsertData.response?.id ?? "",
      insertCompany,
      userId,
    );
    // ドキュメント登録
    if (insDocument.length > 0) {
      await addDocument(
        chatbotInsertData.response?.id ?? "",
        insDocument,
        userId,
      );
    }

    return chatbotInsertData.response?.id;
  } catch (error) {
    throw error;
  }
};

/**
 * 更新処理
 */
export const updChatBot = async (
  chatbotData: ChatBotModel,
  insertCompany: AuthorityCompanyInfo[],
  insertUsers: AuthorityEmployeeInfo[],
  insDocument: DocumentTabData[],
  deletedCompanyInfo: string[],
  deletedEmployeeInfo: string[],
) => {
  try {
    // ユーザー情報取得
    const userId = (await userHashedId()).toString();
    const userResponse = await FindEmployeeByID(userId);
    const lastUpdUser =
      (userResponse.response?.id ?? "") +
      " " +
      (userResponse.response?.employeeName ?? "");

    const status =
      insDocument.length === 0 ||
      insDocument.every((doc) => doc.dispStatus === "old")
        ? ""
        : "processing";

    // チャットボット更新
    await updateChatbot(chatbotData, lastUpdUser, status);

    // 権限(組織)更新
    await UpsertAuthorityCompany(chatbotData.id, insertCompany, userId);
    // 権限（ユーザー）更新
    await UpsertAuthorityEmployee(chatbotData.id, insertUsers, userId);
    // 権限（組織）削除（削除されたものがあれば）
    if (deletedCompanyInfo && deletedCompanyInfo.length > 0) {
      await DeleteAuthortyCompany(deletedCompanyInfo);
    }
    // 権限（ユーザー）削除（削除されたものがあれば）
    if (deletedEmployeeInfo && deletedEmployeeInfo.length > 0) {
      await DeleteAuthortyEmployee(deletedEmployeeInfo);
    }
    // ドキュメント登録 削除はAzureFunction
    if (insDocument.length > 0) {
      await addDocument(chatbotData.id ?? "", insDocument, userId);
    }
  } catch (error) {
    throw error;
  }
};

/**
 * 会話開始ボタン表示判定
 */
export const dispTalkStart = async (chatBotId: string) => {
  try {
    const userId = (await userHashedId()).toString();
    const userResponse = await FindEmployeeByID(userId);
    if (!userResponse.response?.department_code_8) {
      return false;
    }
    // チャットボット権限チェック
    const employeeResult = await FindSelectAuthorityEmployeeByID(
      chatBotId,
      userId,
    );
    const departmentResult = await FindSelectAuthorityCompanyByID(
      userResponse.response?.department_code_8,
      chatBotId,
    );

    if (
      employeeResult.status == "NOT_FOUND" &&
      departmentResult.status == "NOT_FOUND"
    ) {
      return false;
    }

    const ducumentData = await getDocument(chatBotId);
    if (!ducumentData.response?.some((doc) => doc.type === "FILE_DOCUMENT")) {
      return false;
    }

    return true;
  } catch (error) {
    throw error;
  }
};

/**
 * 標準リンク押下
 */
// const IMAGE_CONTAINER_NAME =
//   process.env.AZURE_STORAGE_CHATBOT_CONTAINER_NAM ?? "chatbot";
// const IMAGE_API_PATH = `${process.env.NEXTAUTH_URL}/api/chatbot`;
// export const getDocumenttParamUrl = (documentPath: string) => {
//   const searchParams = new URLSearchParams(documentPath);
//   const paramsStr = searchParams.toString();
//   return `${IMAGE_API_PATH}?${paramsStr}`;
// };

/**  cosmosDB 取得関数 */
/**
 * モデル取得処理
 */
export const getModel = async () => {
  try {
    const query = `
    SELECT TOP 20 *
    FROM root r
    WHERE r.type = @type
    AND r.enabled
    AND r.enabledAtChatbot
    ORDER BY r.sortNo
    `;

    const parameters = [
      {
        name: "@type",
        value: "MODEL",
      },
    ];

    const querySpec: SqlQuerySpec = {
      query,
      parameters,
    };

    // 取得
    const { resources } = await ConfigContainer()
      .items.query<Model>(querySpec)
      .fetchAll();

    // 返却値
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};

/**
 *　チャンクサイズ取得処理
 */
export const getChunkSize = async () => {
  try {
    const query = `
    SELECT *
    FROM root r
    WHERE r.type = @type
    ORDER BY r.sortNo
    `;

    const parameters = [
      {
        name: "@type",
        value: "CHUNK_SIZE",
      },
    ];

    const querySpec: SqlQuerySpec = {
      query,
      parameters,
    };

    // 取得
    const { resources } = await ConfigContainer()
      .items.query<ChunkSizeModel>(querySpec)
      .fetchAll();

    // 返却値
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * ドキュメント取得処理
 */
export const getDocument = async (chatbotId: string) => {
  try {
    const query = `
    SELECT  *
    FROM root r
    WHERE (r.type = @type1 OR  r.type =  @type2)
    AND r.chatbotId = @chatbotId
    `;

    const parameters = [
      {
        name: "@type1",
        value: "FILE_DOCUMENT",
      },
      {
        name: "@type2",
        value: "FOLDER_DOCUMENT",
      },
      {
        name: "@chatbotId",
        value: chatbotId,
      },
    ];

    const querySpec: SqlQuerySpec = {
      query,
      parameters,
    };

    // 取得
    const { resources } = await HistoryContainer()
      .items.query<DocumentModel>(querySpec)
      .fetchAll();

    // 返却値
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * チャットボット登録処理
 * @param chatbotData
 * @param userName
 * @returns
 */
export const insertChatbot = async (
  chatbotData: ChatBotModel,
  userName: string,
  userId: string,
  status: string,
) => {
  try {
    const modelToInsert = {
      id: uniqueId(),
      type: "CHATBOT",
      userId: userId,
      createdAt: new Date().toISOString(),
      lastUpdateAt: new Date().toISOString(),
      lastUpdateUser: userName,
      status: status,
      errorMessage: "",
      chatbotName: chatbotData.chatbotName,
      description: chatbotData.description,
      modelId: chatbotData.modelId,
      modelName: chatbotData.modelName,
      chunkSizeId: chatbotData.chunkSizeId,
      token: chatbotData.token,
      overlap: chatbotData.overlap,
    };

    const { resource } = await HistoryContainer().items.upsert(modelToInsert);

    if (resource) {
      return {
        status: "OK",
        response: resource,
      };
    }
  } catch (error) {
    throw error;
  }
};

/**
 * チャットボット更新処理
 * @param chatbotData
 * @param userName
 * @returns
 */
export const updateChatbot = async (
  chatbotData: ChatBotModel,
  userName: string,
  status: string,
) => {
  try {
    const modelToUpdate = {
      id: chatbotData.id,
      type: "CHATBOT",
      userId: chatbotData.userId,
      createdAt: chatbotData.createdAt,
      lastUpdateAt: new Date().toISOString(),
      lastUpdateUser: userName,
      status: status,
      errorMessage: "",
      chatbotName: chatbotData.chatbotName,
      description: chatbotData.description,
      modelId: chatbotData.modelId,
      modelName: chatbotData.modelName,
      chunkSizeId: chatbotData.chunkSizeId,
      token: chatbotData.token,
      overlap: chatbotData.overlap,
    };

    const { resource } = await HistoryContainer().items.upsert(modelToUpdate);

    if (resource) {
      return {
        status: "OK",
        response: resource,
      };
    }
  } catch (error) {
    throw error;
  }
};

/**
 * ドキュメント新規追加
 * @param cahtBotId 追加対象ID
 * @param authorityInfo 追加する権限
 */
export const addDocument = async (
  cahtBotId: string,
  documentInfo: DocumentTabData[],
  userId: string,
) => {
  try {
    // 追加する権限情報を一括で処理
    const results = await Promise.all(
      documentInfo.map(async (info) => {
        const documentToSave: DocumentModel = {
          id: info.document.id,
          type: info.document.type,
          userId: info.document.userId === "" ? userId : info.document.userId,
          createdAt:
            info.document.createdAt === ""
              ? new Date().toISOString()
              : info.document.createdAt,
          chatbotId: cahtBotId,
          parentFolderId: info.document.parentFolderId,
          lastUpdateAt: new Date().toISOString(),
          documentName: info.document.documentName,
          documentSize: info.document.documentSize,
          isOriginalLink: info.document.isOriginalLink,
          standardLink: info.document.standardLink,
          originalLink: info.document.originalLink,
          isError: info.document.isError,
          errorMessage: info.document.errorMessage,
          documentPath: info.document.documentPath,
        };

        // 登録
        const { resource } =
          await HistoryContainer().items.upsert(documentToSave);

        if (resource) {
          return {
            status: "OK",
            response: resource,
          };
        }
      }),
    );

    // 成功・失敗の結果をまとめて返却
    return {
      status: "OK",
      responses: results,
    };
  } catch (error) {
    throw error;
  }
};
