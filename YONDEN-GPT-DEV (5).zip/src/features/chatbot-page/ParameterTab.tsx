import React, { useEffect } from "react";
import { showError } from "../globals/global-message-store";
import ComboBox from "../ui/combbox";
import { cn } from "../ui/lib";
import { useResponsive } from "../ui/responsive";
import { useChatbotContext } from "./ChatbotContext";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { Button } from "@/features/ui/button";
import { Input } from "@/features/ui/input";
import { Separator } from "@/features/ui/separator";

const ParameterTab: React.FC = () => {
  const {
    chatbot,
    setChatbot,
    chunkSize,
    selectedChunkLabel,
    setSelectedChunkLabel,
    openMode,
    errTabsContents,
  } = useChatbotContext();

  const { isMobile } = useResponsive();
  // エラーメッセージ
  const errMessage = useErrorMessage();
  // 初期表示処理
  useEffect(() => {
    const initialLabel = chatbot.chunkSizeId
      ? chunkSize.find((item) => item.id === chatbot.chunkSizeId)?.label || ""
      : chunkSize[0]?.label || "";

    setSelectedChunkLabel(initialLabel);
  }, [chatbot.chunkSizeId, chunkSize, setSelectedChunkLabel]);

  // チャンクサイズ選択時の処理
  const chunkSizeChange = (selectedLabel: string) => {
    const selectedChunk = chunkSize.find(
      (item) => item.label === selectedLabel,
    );
    if (selectedChunk) {
      setChatbot((prevChatbot) => ({
        ...prevChatbot,
        chunkSizeId: selectedChunk.id,
      }));
    }
    setSelectedChunkLabel(selectedLabel);
  };

  const tokenChange = (newToken: string) => {
    setChatbot((prevChatbot) => ({
      ...prevChatbot,
      token: newToken,
    }));
  };

  const overlapChange = (newOverlap: string) => {
    setChatbot((prevChatbot) => ({
      ...prevChatbot,
      overlap: newOverlap,
    }));
  };

  return (
    <div className="w-full font-medium">
      <div className={cn("flex flex-col", isMobile ? "gap-y-3" : "")}>
        <div
          className={cn(
            "flex items-center justify-between",
            isMobile ? "mt-3 flex-col items-start gap-1" : "px-4",
          )}
        >
          <div className={`flex ${isMobile ? "text-sm" : ""}`}>
            チャンクサイズ
          </div>
          {errTabsContents.chunkSize.err ? (
            <Button
              icon="i-material-symbols-warning-outline-rounded text-red-500 h-4 w-4"
              variant="icon"
              className="ml-1 flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1"
              onClick={() => showError(errMessage["ECHATBOT0016"])}
            />
          ) : (
            <div className={`h-4 w-4 ${isMobile ? "hidden" : ""}`} />
          )}
          <ComboBox
            items={chunkSize}
            idField={"id"}
            textField={"label"}
            className={cn(isMobile ? "w-[66%] text-sm" : "w-[50%]")}
            onSelectId={(id) => {
              setChatbot((prevChatbot) => ({
                ...prevChatbot,
                chunkSizeId: id,
              }));
            }}
            selectedItem={selectedChunkLabel}
            onSelectText={chunkSizeChange}
            disabled={openMode === "参照"}
          />
        </div>

        <div
          className={cn(
            "my-3 flex items-center justify-between px-4",
            isMobile ? "gap- flex-col items-start gap-1 px-0" : "",
            selectedChunkLabel === "トークン数で分割" ? "visible" : "invisible",
          )}
        >
          <div className={`flex ${isMobile ? "text-sm" : ""}`}>
            トークン数（1～8192）
            <span
              className={`i-material-symbols-asterisk-rounded ml-1 h-3 w-3 bg-red-600 ${isMobile || openMode == "参照" ? "invisible" : "visible"} ${selectedChunkLabel === "トークン数で分割" ? "visible" : "invisible"} `}
            />
            {errTabsContents.token.err ? (
              <Button
                icon="i-material-symbols-warning-outline-rounded text-red-500 h-4 w-4"
                variant="icon"
                className="ml-1 flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1"
                onClick={() =>
                  showError(errMessage[errTabsContents.token.message ?? ""])
                }
              />
            ) : (
              <div className="h-4 w-4" />
            )}
          </div>
          <div className="flex items-center gap-1">
            <Button
              text="－"
              onClick={() => {
                const newTokenValue = Math.max(1, Number(chatbot.token) - 1);
                tokenChange(newTokenValue.toString());
              }}
              className="h-10 w-10 bg-gray-200 text-2xl text-black"
              disabled={openMode === "参照"}
            />
            <Input
              className="w-20 text-center"
              value={chatbot.token}
              numberOnly={true}
              maxLength={4}
              onInputText={(value) => {
                const numericValue = Number(value);
                if (
                  !isNaN(numericValue) &&
                  numericValue >= 0 &&
                  numericValue <= 9999
                ) {
                  tokenChange(value);
                }
              }}
              disabled={openMode === "参照"}
            />
            <Button
              text="+"
              onClick={() => {
                const newTokenValue = Math.min(8192, Number(chatbot.token) + 1);
                tokenChange(newTokenValue.toString());
              }}
              className="h-10 w-10 bg-gray-200 text-2xl text-black"
              disabled={openMode === "参照"}
            />
          </div>
        </div>

        {!isMobile && <Separator />}

        <div
          className={cn(
            "my-3 flex items-center justify-between px-4",
            isMobile ? "flex-col items-start px-0" : "",
            selectedChunkLabel === "ページ単位で分割" ||
              selectedChunkLabel === "章ごとに分割"
              ? "invisible"
              : "visible",
          )}
        >
          <div className={`flex ${isMobile ? "text-sm" : "items-center"}`}>
            オーバーラップ数（1～8192）
            <span
              className={`i-material-symbols-asterisk-rounded ml-1 h-3 w-3 bg-red-600 ${isMobile || openMode == "参照" ? "invisible" : "visible"} ${selectedChunkLabel === "トークン数で分割" ? "visible" : "invisible"} `}
            />
            {errTabsContents.overlap.err ? (
              <Button
                icon="i-material-symbols-warning-outline-rounded text-red-500 h-4 w-4"
                variant="icon"
                className="ml-1 flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1"
                onClick={() =>
                  showError(errMessage[errTabsContents.overlap.message ?? ""])
                }
              />
            ) : (
              <div className="h-4 w-4" />
            )}
          </div>
          <div className="flex items-center gap-1">
            <Button
              text="－"
              onClick={() => {
                const newOverlapValue = Math.max(
                  1,
                  Number(chatbot.overlap) - 1,
                );
                overlapChange(newOverlapValue.toString());
              }}
              className="h-10 w-10 bg-gray-200 text-2xl text-black"
              disabled={openMode === "参照"}
            />
            <Input
              className="w-20 text-center"
              value={chatbot.overlap}
              numberOnly={true}
              maxLength={4}
              onInputText={(value) => {
                const numericValue = Number(value);
                if (
                  !isNaN(numericValue) &&
                  numericValue >= 0 &&
                  numericValue <= 9999
                ) {
                  overlapChange(value);
                }
              }}
              disabled={openMode === "参照"}
            />
            <Button
              text="+"
              onClick={() => {
                const newOverlapValue = Math.min(
                  8192,
                  Number(chatbot.overlap) + 1,
                );
                overlapChange(newOverlapValue.toString());
              }}
              className="h-10 w-10 bg-gray-200 text-2xl text-black"
              disabled={openMode === "参照"}
            />
          </div>
        </div>
        {!isMobile && (
          <div className="ml-4 text-[11px] font-medium">
            ※オーバーラップは、トークン数の10～30%程度が効果的と言われています。
            <br />
            　オーバーラップは、チャンクサイズよりも小さい値を設定してください
            <br />
            <br />
            ■チャンクサイズ
            <br />
            入力した長文を分割して処理しますが、分割サイズ（文字の長さ）をトークン単位選択できます。
            <br />
            なお、英字の場合は1文字：1～2トークン、日本語の場合は1文字：1～3トークンです。
            <br />
            <br />
            ■トークン数
            <br />
            長文を分割する際のサイズ（文字列の長さ）を任意のトークン数に設定できます。
            <br />
            なお、英字の場合は1文字：1～2トークン、日本語の場合は1文字：1～3トークンです。
            <br />
            <br />
            ■オーバーラップ
            <br />
            分割した前後2つの文字列の重複サイズを任意のトークン数に設定できます。
            <br />
            数値を大きくすることで、前後の文脈を考慮しやすくなりますが大きすぎると要約の精度が低下します。
          </div>
        )}
      </div>
    </div>
  );
};

export default ParameterTab;
