"use server";

import { SqlQuerySpec } from "@azure/cosmos";
import { userHashedId } from "../auth-page/helpers";
import { checkAdmin } from "../common/checkAdmin";
import {
  ModelParameterModel,
  ModelParameterOptionModel,
} from "../common/model/config/model-model";
import { ServerActionResponse } from "../common/server-action-response";
import {
  DeleteAuthortyCompany,
  FindAuthorityCompanyByID,
  FindAuthorityCompanys,
  FindSelectAuthorityCompanyByID,
} from "../common/services/authority-company-service";
import {
  DeleteAuthortyEmployee,
  FindAuthorityEmployeeByID,
  FindAuthorityUsers,
  FindSelectAuthorityEmployeeByID,
} from "../common/services/authority-employee-service";
import { FindAuthorityID } from "../common/services/authority-service";
import { FindEmployeeByID } from "../common/services/employee-service";
import { ChatBotModel, DocumentModel, Model } from "./Chatbot-model";
import {
  ConfigContainer,
  HistoryContainer,
} from "@/features/common/services/cosmos";
import { uniqueId } from "@/features/common/util";

/** 検索条件 */
interface SearchTerms {
  text: string;
  sort?: string;
  tab: number;
}

/** もっと見るボタン */
interface ViewMore {
  viewCount: number;
  visible: boolean;
}

interface MenuFlg {
  /** チャットボットID */
  chatBotId: string;
  /** 編集ボタン表示フラグ */
  isOption: boolean;
  /** 会話開始ボタン表示フラグ */
  isTalkStart: boolean;
}

/**権限チェック返却値 */
interface CheckResult {
  check: boolean;
  message: string;
}

/**
 * 条件に該当するチャットボット一覧を取得
 * @param searchTerms 検索条件
 * @param viewMore 表示件数情報
 */
export const fetchChatBot = async (
  searchTerms: SearchTerms,
  viewMore: ViewMore,
) => {
  try {
    // プロンプトテンプレートの処理を流用
    // タブの選択状態を取得
    const tabLabel = getTabLabel(searchTerms.tab);

    // 返却用viewMore
    const updatedViewMore = { ...viewMore };

    // 社員情報を取得
    const userId = (await userHashedId()).toString();
    const userResponse = await FindEmployeeByID(userId);
    if (!(userResponse && userResponse.status == "OK")) {
      return;
    }

    // ユーザーもしくはユーザーが所属する組織が管理者か
    const admin = await checkAdmin(userResponse.response!);

    // 権限情報を取得
    const authorityKind = await FindAuthorityID();

    // 共有のID取得
    const shareAuthorityKind = authorityKind.response.filter(
      (item) => item.value === "share",
    );
    const menuFlg: MenuFlg[] = [];
    let chatBotResponse;

    if (authorityKind.response && authorityKind.status === "OK") {
      // タブに応じて権限の種類を取得
      if (tabLabel !== "all") {
        const selectAuthorityKind = authorityKind.response.filter(
          (item) => item.value === tabLabel,
        );
        const authorityValue = selectAuthorityKind[0]?.id;

        // ユーザー権限と組織権限を取得
        const userParmission = await FindAuthorityEmployeeByID(
          userId,
          authorityValue,
        );
        const companyParmission = await FindAuthorityCompanyByID(
          userResponse.response?.department_code_8 ?? "",
          authorityValue,
        );

        // ユーザー権限と組織権限からテンプレートIDを取得し重複を削除
        const chatBotId = Array.from(
          new Set([
            ...(userParmission.response?.map((item) => item.parentId) || []),
            ...(companyParmission.response?.map((item) => item.parentId) || []),
          ]),
        );

        // チャットボット一覧を取得
        chatBotResponse = await FindChatbots(
          searchTerms.text,
          searchTerms.sort || "",
          viewMore.viewCount + 1,
          chatBotId,
        );
      } else {
        // 全てのチャットボットを取得
        chatBotResponse = await FindChatbots(
          searchTerms.text,
          searchTerms.sort || "",
          viewMore.viewCount + 1,
        );
      }

      // データ数が viewMore.viewCount より多い場合
      if (
        chatBotResponse.response &&
        chatBotResponse.response.length > viewMore.viewCount
      ) {
        // もっと見るボタンを表示
        updatedViewMore.visible = true;
        // データを1件削除
        chatBotResponse.response.pop();
      } else {
        updatedViewMore.visible = false;
      }

      if (chatBotResponse.response) {
        for (const item of chatBotResponse.response) {
          // 権限判定
          // 会話ボタン判定
          const employeeAuthority = await FindSelectAuthorityEmployeeByID(
            item.id,
            userId,
          );
          const companyAuthority = await FindSelectAuthorityCompanyByID(
            userResponse.response?.department_code_8 ?? "",
            item.id,
          );

          // チャットボットにドキュメント（ファイル）が登録されているか
          let existenceFlg = false;
          const ducumentData = await getDocument(item.id);
          if (
            ducumentData.response?.some((doc) => doc.type === "FILE_DOCUMENT")
          ) {
            existenceFlg = true;
          }

          // 会話開始ボタン表示制御
          const isTalkStart =
            item.status !== "processing" &&
            existenceFlg &&
            (employeeAuthority.status !== "NOT_FOUND" ||
              companyAuthority.status !== "NOT_FOUND");
          // 編集ボタン判定
          let employee = false;
          let company = false;

          if (
            employeeAuthority.response &&
            employeeAuthority.response?.length > 0
          ) {
            employee =
              employeeAuthority.response[0].permissionId !==
              shareAuthorityKind[0].id;
          }
          if (
            companyAuthority.response &&
            companyAuthority.response?.length > 0
          ) {
            company = companyAuthority.response.some(
              (item) => item.permissionId !== shareAuthorityKind[0].id,
            );
          }

          const isOption = (admin.admin ?? false) || employee || company;

          menuFlg.push({
            chatBotId: item.id,
            isOption: isOption,
            isTalkStart: isTalkStart,
          });
        }
      } else {
        return;
      }

      return { chatBotResponse, menuFlg, viewMore: updatedViewMore };
    }
  } catch (error) {
    throw error;
  }
};

/**
 * 存在権限チェック
 * @param chatBotId チャットボットID
 */
export const referenceOpen = async (
  chatBotId: string,
  adminCheckFlag = true,
) => {
  try {
    // 返却値
    const result: CheckResult = {
      check: true,
      message: "",
    };

    // 社員情報を取得
    const userId = (await userHashedId()).toString();

    // 社員情報とチャットボット情報を取得
    const [userResponse, chatbotResponse] = await Promise.all([
      FindEmployeeByID(userId),
      FindChatbotByID(chatBotId),
    ]);

    // 見つからない場合エラーを返す
    if (chatbotResponse.status == "NOT_FOUND") {
      result.check = false;
      result.message = "ECHATBOT0001";
      return result;
    }

    // 所属する組織またはユーザーがYONDEN-GPT全体の権限も持っているかチェック
    if (!userResponse.response?.department_code_8) {
      result.check = false;
      result.message = "ECOMMON0001";
      return result;
    }
    const admin = await checkAdmin(userResponse.response);
    // 管理者権限を持っている場合はチェックを終了
    // 全体権限確認フラグがfalseの場合は続行
    if (adminCheckFlag && admin.admin) {
      return result;
    }

    // チャットボット権限チェック
    const [employeeResult, departmentResult] = await Promise.all([
      FindSelectAuthorityEmployeeByID(chatBotId, userId),
      FindSelectAuthorityCompanyByID(
        userResponse.response.department_code_8,
        chatBotId,
      ),
    ]);

    // ユーザー、ユーザーが属する組織両方に権限が設定されていない場合はエラーメッセージを返す
    if (
      employeeResult.status === "NOT_FOUND" &&
      departmentResult.status === "NOT_FOUND"
    ) {
      return { check: false, message: "ECHATBOT0002" };
    }

    return result;
  } catch (error) {
    throw error;
  }
};

/**
 * チャットボット用モデル使用可否チェック
 * - 使用可能、かつチャットボットで指定可能であれば true
 */
export const modelCheckForChatbot = async (
  /** チャットボットに設定されているモデルID */
  modelId: string,
) => {
  try {
    // 返却値
    const result: CheckResult = {
      check: true,
      message: "",
    };
    // モデルが使用可能か
    const modelInfo = await getSelectModelForChatbot(modelId);
    if (modelInfo) {
      if (modelInfo.status == "NOT_FOUND") {
        result.check = false;
        result.message = "ECHATBOT0003";
        return result;
      }
    } else {
      result.check = false;
      result.message = "ECOMMON0001";
      return result;
    }
    return result;
  } catch (error) {
    throw error;
  }
};

/**
 * チャットボットに紐づく権限を削除
 */
export const DeleteAuthorty = async (chatBotId: string) => {
  try {
    // 権限（ユーザー）の取得
    const userAuthoritys = await FindAuthorityUsers(chatBotId);
    // 権限（組織）の取得
    const companyAuthority = await FindAuthorityCompanys(chatBotId);

    // idのみを取得
    const userAuthoritysId =
      userAuthoritys.response?.map((item) => item.id) || [];
    const companyAuthoritysId =
      companyAuthority.response?.map((item) => item.id) || [];

    // 権限（ユーザー）削除
    if (userAuthoritysId.length > 0) {
      await DeleteAuthortyEmployee(userAuthoritysId);
    }
    // 権限（組織）削除
    if (companyAuthoritysId.length > 0) {
      await DeleteAuthortyCompany(companyAuthoritysId);
    }
  } catch (error) {
    throw error;
  }
};

/**
 *  ドキュメント取得しAzureFuctionのパラメータにする
 * -
 */
export const createUpdIndexParam = async (chatbotId: string) => {
  try {
    const documentData = await getDocument(chatbotId);

    const paramData = documentData.response?.map((item) => ({
      documentId: item.id,
      processType: "delete",
    }));

    return paramData;
  } catch (error) {
    throw error;
  }
};

/**
 * 選択中のタブを文字列に変換
 * @param tab
 * @returns
 */
const getTabLabel = (tab: number): string => {
  switch (tab) {
    case 1:
      return "admin";
    case 2:
      return "edit";
    case 3:
      return "share";
    default:
      return "all";
  }
};

/** cosmosDB取得関数 */
/**
 * チャットボット検索処理
 * @param searchText 検索ワード
 * @param sortValue 並べ順
 * @returns 結果:OK or ERROR
 */
export const FindChatbots = async (
  searchText: string,
  sortValue: string,
  count: number,
  chatBotId?: string[],
) => {
  try {
    if (chatBotId && chatBotId.length === 0) {
      return {
        status: "OK",
        response: [],
      };
    }
    // ソート順
    const sort =
      sortValue === "更新日順" ? "r.lastUpdateAt DESC" : "r.chatbotName ASC";

    // 基本のクエリ
    let query = `
      SELECT TOP @count *
      FROM root r
      WHERE r.type = @type
    `;

    // searchTextが存在する場合のみ条件を追加
    const parameters = [
      {
        name: "@type",
        value: "CHATBOT",
      },
      {
        name: "@count",
        value: count,
      },
    ];

    if (searchText) {
      query += `
        AND (
          UPPER(r.chatbotName) LIKE UPPER(@searchText)
          OR UPPER(r.description) LIKE UPPER(@searchText)
        )
      `;
      parameters.push({
        name: "@searchText",
        value: `%${searchText}%`,
      });
    }
    if (chatBotId && chatBotId.length > 0) {
      // IN句に入れるプレースホルダーを生成
      const inClausePlaceholders = chatBotId
        .map((_, index) => `@id${index}`)
        .join(", ");
      query += ` AND r.id IN (${inClausePlaceholders})`;

      // 各プレースホルダーに対してパラメータを追加
      chatBotId.forEach((id, index) => {
        parameters.push({ name: `@id${index}`, value: id });
      });
    }

    // ソート条件の追加
    query += `ORDER BY ${sort}`;

    // クエリ仕様
    const querySpec: SqlQuerySpec = {
      query,
      parameters,
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<ChatBotModel>(querySpec)
      .fetchAll();

    // 返却値
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * チャットボットに設定されているModel情報を取得
 * - 使用可能、かつチャットボットで指定可能なもののみ取得
 */
export const getSelectModelForChatbot = async (modelId: string) => {
  try {
    const query = `
    SELECT *
    FROM root r
    WHERE r.type = @type
    AND r.id = @modelId
    AND r.enabled
    AND r.enabledAtChatbot
    `;

    const parameters = [
      {
        name: "@type",
        value: "MODEL",
      },
      {
        name: "@modelId",
        value: modelId,
      },
    ];

    const querySpec: SqlQuerySpec = {
      query,
      parameters,
    };

    // 取得
    const { resources } = await ConfigContainer()
      .items.query<Model>(querySpec)
      .fetchAll();

    // 結果が0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
      };
    }

    // 返却値
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};
/**
 * チャットボット新規登録処理
 * @param name テンプレート名
 * @param description テンプレート内容
 * @param userName ユーザ名
 * @returns 結果 OK or ERROR
 */
export const CreateChatbot = async (
  name: string,
  description: string,
  userName: string,
) => {
  try {
    // 登録内容
    const modelToSave = {
      id: uniqueId(),
      name: name,
      description: description,
      isPublished: false,
      userId: userName,
      createdAt: new Date(),
      type: "CHATBOT",
    };

    // 登録
    const { resource } = await HistoryContainer().items.create(modelToSave);

    // 返却値
    if (resource) {
      return {
        status: "OK",
        response: resource,
      };
    } else {
      return {
        status: "ERROR",
        errors: [
          {
            message: "Error creating prompt",
          },
        ],
      };
    }
  } catch (error) {
    // 適当
    return {
      status: "ERROR",
      errors: [
        {
          message: `Error creating prompt: ${error}`,
        },
      ],
    };
  }
};

/**
 * チャットボット削除処理
 * @param chatbotId 対象チャットボットID
 * @returns 結果 OK or ERROR
 */
export const DeleteChatbot = async (chatbotId: string) => {
  try {
    // 削除対象のチャットボットを取得
    const chatbotResponse = await FindChatbotByID(chatbotId);

    if (chatbotResponse.status === "OK") {
      const { resource: deletedChatbot } = await HistoryContainer()
        .item(chatbotId, chatbotResponse.response.userId)
        .delete();

      return {
        status: "OK",
        response: deletedChatbot,
      };
    }
  } catch (error) {
    throw error;
  }
};

/**
 * チャットボット検索処理
 * @param id 検索対象テンプレートID
 * @returns 結果 OK or ERRPR
 */
export const FindChatbotByID = async (id: string) => {
  try {
    // パラメータ
    const querySpec: SqlQuerySpec = {
      query: "SELECT * FROM root r WHERE r.type=@type AND r.id=@id",
      parameters: [
        {
          name: "@type",
          value: "CHATBOT",
        },
        {
          name: "@id",
          value: id,
        },
      ],
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<ChatBotModel>(querySpec)
      .fetchAll();

    // 0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "Chatbot not found",
          },
        ],
      };
    }

    return {
      status: "OK",
      response: resources[0],
    };
  } catch (error) {
    throw error;
  }
};

/**
 * チャットボット更新処理
 * @param id 対象チャットボットID
 * @param name
 * @param description
 * @param userName
 * @returns
 */
export const UpdateChatbot = async (
  id: string,
  name: string,
  description: string,
  userName: string,
) => {
  try {
    const chatbotResponse = await FindChatbotByID(id);

    if (chatbotResponse.status == "OK") {
      const modelToUpdate = {
        id: chatbotResponse.response.id,
        name: name,
        description: description,
        isPublished: chatbotResponse.response.isPublished,
        userId: userName,
        createdAt: new Date(),
        type: "CHATBOT",
      };

      const { resource } = await HistoryContainer().items.upsert(modelToUpdate);

      if (resource) {
        return {
          status: "OK",
          response: resource,
        };
      }

      return {
        status: "ERROR",
        errors: [
          {
            message: "更新エラー",
          },
        ],
      };
    }

    return chatbotResponse;
  } catch (error) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `更新処理でエラー: ${error}`,
        },
      ],
    };
  }
};

/**
 * スレッド(チャットボット)作成時のパラメータを取得
 * @param parameterName　対象パラーメータ名
 * @returns 結果 OK or ERRPR
 */
export const findModelParameter = async (
  parameterName: string,
): Promise<ServerActionResponse<ModelParameterModel>> => {
  try {
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT * FROM root r WHERE r.type=@type AND r.modelId=@modelId AND r.name=@name",
      parameters: [
        {
          name: "@type",
          value: "MODEL_PARAMETER",
        },
        {
          name: "@modelId",
          value: "#chatbot#",
        },
        {
          name: "@name",
          value: parameterName,
        },
      ],
    };

    // 検索
    const { resources } = await ConfigContainer()
      .items.query<ModelParameterModel>(querySpec)
      .fetchAll();

    // 0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "Model parameter not found",
          },
        ],
      };
    }

    return {
      status: "OK",
      response: resources[0] || undefined,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `Error finding model parameter: ${error}`,
        },
      ],
    };
  }
};

/**
 * スレッド(チャットボット)作成時の
 * 会話のスタイルのパラメータ選択肢を取得
 * @returns 結果 OK or ERRPR
 */
export const findStrictnessParameterOptions = async () => {
  try {
    // モデルパラメーターIDを取得
    const modelParameterResponse = await findModelParameter("strictness");
    if (modelParameterResponse.status !== "OK") {
      return modelParameterResponse;
    }
    const id = modelParameterResponse.response?.id;
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT * FROM root r WHERE r.type=@type AND r.modelParameterId=@modelParameterId ORDER BY r.sortNo",
      parameters: [
        {
          name: "@type",
          value: "MODEL_PARAMETER_OPTION",
        },
        {
          name: "@modelParameterId",
          value: id || "",
        },
      ],
    };

    // 検索
    const { resources } = await ConfigContainer()
      .items.query<ModelParameterOptionModel>(querySpec)
      .fetchAll();

    // 0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "Model parameter option not found",
          },
        ],
      };
    }

    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `Error finding model parameter option: ${error}`,
        },
      ],
    };
  }
};
/**
 * スレッド(チャットボット)作成時の
 * 添付ファイルのＯＣＲのパラメータ選択肢を取得
 * @returns 結果 OK or ERRPR
 */
export const findOcrParameterOptions = async () => {
  try {
    // モデルパラメーターIDを取得
    const modelParameterResponse = await findModelParameter("ocr");
    if (modelParameterResponse.status !== "OK") {
      return modelParameterResponse;
    }
    const id = modelParameterResponse.response?.id;
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT * FROM root r WHERE r.type=@type AND r.modelParameterId=@modelParameterId ORDER BY r.sortNo",
      parameters: [
        {
          name: "@type",
          value: "MODEL_PARAMETER_OPTION",
        },
        {
          name: "@modelParameterId",
          value: id || "",
        },
      ],
    };

    // 検索
    const { resources } = await ConfigContainer()
      .items.query<ModelParameterOptionModel>(querySpec)
      .fetchAll();

    // 0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "Model parameter option not found",
          },
        ],
      };
    }

    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `Error finding model parameter option: ${error}`,
        },
      ],
    };
  }
};
/**
 * スレッド(チャットボット)作成時のパラメータ選択肢を取得
 * @param id optionId
 * @returns 結果 OK or ERRPR
 */
export const findModelParameterOptionById = async (id: string) => {
  try {
    const querySpec: SqlQuerySpec = {
      query: "SELECT * FROM root r WHERE r.type=@type AND r.id=@id ",
      parameters: [
        {
          name: "@type",
          value: "MODEL_PARAMETER_OPTION",
        },
        {
          name: "@id",
          value: id,
        },
      ],
    };

    // 検索
    const { resources } = await ConfigContainer()
      .items.query<ModelParameterOptionModel>(querySpec)
      .fetchAll();

    // 0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "Model parameter option not found",
          },
        ],
      };
    }

    return {
      status: "OK",
      response: resources[0],
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `Error finding model parameter option: ${error}`,
        },
      ],
    };
  }
};

/**
 * ドキュメント取得処理
 */
export const getDocument = async (chatbotId: string) => {
  try {
    const query = `
    SELECT  *
    FROM root r
    WHERE (r.type = @type1 OR  r.type =  @type2)
    AND r.chatbotId = @chatbotId
    `;

    const parameters = [
      {
        name: "@type1",
        value: "FILE_DOCUMENT",
      },
      {
        name: "@type2",
        value: "FOLDER_DOCUMENT",
      },
      {
        name: "@chatbotId",
        value: chatbotId,
      },
    ];

    const querySpec: SqlQuerySpec = {
      query,
      parameters,
    };

    // 取得
    const { resources } = await HistoryContainer()
      .items.query<DocumentModel>(querySpec)
      .fetchAll();

    // 返却値
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};
