import React from "react";
import { DocumentTabData } from "./Chatbot-model";
import { Window } from "@/features/ui/window";

interface OverwriteDialogProps {
  open: boolean;
  onClose: () => void;
  currentItem: DocumentTabData;
  existingItem: DocumentTabData;
  remainingDuplicates: DocumentTabData[];
  onSkip: () => void;
  onSkipAll: () => void;
  onReplace: () => void;
  onReplaceAll: () => void;
  breadcrumbs: BreadcrumbItem[];
}

interface BreadcrumbItem {
  label: string;
  id: string;
}

const OverwriteDialog: React.FC<OverwriteDialogProps> = ({
  open,
  onClose,
  currentItem,
  existingItem,
  onSkip,
  onSkipAll,
  onReplace,
  onReplaceAll,
  breadcrumbs,
}) => {
  // 日付をフォーマット
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日`;
  };

  // パンくずリストの表示
  const breadcrumbPath = breadcrumbs.map((item) => item.label).join(" > ");

  // ファイルサイズ変換
  const formatSize = (size: number) => {
    if (size === undefined) {
      return "";
    } else if (size >= 1024 * 1024 * 1024) {
      return `${(size / (1024 * 1024 * 1024)).toFixed(2)} GB`;
    } else if (size >= 1024 * 1024) {
      return `${(size / (1024 * 1024)).toFixed(2)} MB`;
    } else if (size >= 1024) {
      return `${(size / 1024).toFixed(2)} KB`;
    } else {
      return `${size} バイト`;
    }
  };

  return (
    <Window
      title="ファイルの置換またはスキップ"
      open={open}
      onOpenChange={onClose}
      primaryButtonText="全て置換する"
      primary2ButtonText="置換する"
      secondaryButtonText="スキップする"
      secondary2ButtonText="全てスキップする"
      onClickPrimary={() => {
        onReplaceAll();
        onClose();
      }}
      onClickPrimary2={() => {
        onReplace();
      }}
      onClickSecondary={() => {
        onSkip();
      }}
      onClickSecondary2={() => {
        onSkipAll();
        onClose();
      }}
    >
      <p>
        「<strong>{currentItem.document.documentName}</strong>
        」は既に存在します。
      </p>
      <p>パンくずリストの現在の表示: {breadcrumbPath}</p>
      <div className="flex justify-between">
        <div>
          <h4>■現在のファイル</h4>
          <p>更新日時：{formatDate(existingItem.document.lastUpdateAt)}</p>
          <p>サイズ：{formatSize(existingItem.document.documentSize)} バイト</p>
        </div>
        <div>
          <h4>■新しいファイル</h4>
          <p>更新日時：{formatDate(currentItem.document.lastUpdateAt)}</p>
          <p>サイズ：{formatSize(currentItem.document.documentSize)} バイト</p>
        </div>
      </div>
    </Window>
  );
};

export default OverwriteDialog;
