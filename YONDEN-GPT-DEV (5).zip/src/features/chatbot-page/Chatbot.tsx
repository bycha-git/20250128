"use client";

import React, { FC, useEffect, useRef, useState } from "react";
import { countWord } from "../common/countWord";
import { redirectToPage } from "../common/redirect-helpers";
import ComboBox from "../ui/combbox";
import CustomDropdownMenu from "../ui/DropdownMenu";
import { LoadingIndicator } from "../ui/loading";
import { useResponsive } from "../ui/responsive";
import { ChatbotModal } from "./CahtBotModal";
import { ChatBotModel } from "./Chatbot-model";
import {
  createUpdIndexParam,
  DeleteAuthorty,
  DeleteChatbot,
  fetchChatBot,
  FindChatbotByID,
  modelCheckForChatbot,
  referenceOpen,
} from "./Chatbot-service";
import { fetchIndexUpdate } from "./chatbot-services/index-update-api/index-update-api-client";
import { IndexUpdateAPIContent } from "./chatbot-services/index-update-api/models";
import { ChatbotThreadNewWindow } from "./chatbot-thread-new-window";
import { ChatbotContextProvider } from "./ChatbotContext";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { loadingOverlayStore } from "@/features/common/store/loading-overlay-store";
import { showError } from "@/features/globals/global-message-store";
import { Button } from "@/features/ui/button";
import { useConfirm } from "@/features/ui/confirm";
import { Input } from "@/features/ui/input";
import { Separator } from "@/features/ui/separator";

// 定数
export const VIEW_COUNT = 20;

interface SearchTerms {
  tab: number;
  text: string;
  sort: string | undefined;
}

interface ViewMore {
  /** 一覧表示件数 */
  viewCount: number;
  /** もっと見るボタン表示有無 */
  visible: boolean;
}

interface Info {
  chatbotData: ChatBotModel;
  mode: string;
  visible: boolean;
}

/** ボタン表示非表示 */
interface MenuFlg {
  /** チャットボットID */
  chatBotId: string;
  /** 編集ボタン表示フラグ */
  isOption: boolean;
  /** 会話開始ボタン表示フラグ */
  isTalkStart: boolean;
}

// タブ名称
const buttons = [
  { text: "すべて" },
  { text: "管理者" },
  { text: "編集権限＋共有" },
  { text: "共有のみ" },
];
// 並べ替え
const sortValue = [
  { id: 1, text: "更新日順" },
  { id: 2, text: "名前順" },
];
//　削除・編集ボタン
const menuItems = [
  { iconClass: "i-tabler-pencil-minus", label: "編集" },
  { iconClass: "i-lucide-trash-2", label: "削除" },
];

// 削除メニューのみ表示する
const deleteItem = [{ iconClass: "i-lucide-trash-2", label: "削除" }];

export const Chatbot: FC = () => {
  const { isMobile } = useResponsive();
  // 画面間 - 情報
  const [info, setInfo] = useState<Info>({
    chatbotData: {
      id: "",
      type: "CHATBOT",
      userId: "",
      createdAt: "",
      lastUpdateAt: "",
      lastUpdateUser: "",
      status: "",
      errorMessage: "",
      chatbotName: "",
      description: "",
      modelId: "",
      modelName: "",
      chunkSizeId: "",
      token: "",
      overlap: "",
    },
    mode: "",
    visible: false,
  });
  // 検索条件
  const [searchTerms, setSearchTerms] = useState<SearchTerms>({
    tab: 0, // 選択タブ
    text: "", // 検索ワード
    sort: "更新日順", // ソート順
  });
  // 会話開始画面が開かれているか
  const [windowOpen, setWindowOpen] = useState(false);
  // 会話開始画面に渡すパラメータ
  const [threadparams, setThreadParams] = useState({
    chatbotId: "",
    chatbotName: "",
    modelId: "",
  });
  // もっと見る
  const [viewMore, setViewMore] = useState<ViewMore>({
    viewCount: VIEW_COUNT, // 一覧表示件数
    visible: false, // もっと見るボタン・表示
  });
  // どのメニューが開かれているか
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  // メニューフラグ
  const [menuFlg, setMenuFlg] = useState<MenuFlg[] | undefined>([]);
  // チャットボット一覧
  const [chatBotsData, setChatBotsData] = useState<ChatBotModel[]>([]);
  const debounceTimeout = useRef<NodeJS.Timeout | null>(null);

  // 初期化制御
  const [researchFlg, setResearchFlg] = useState(false);

  // もっと見るボタンロードフラグ
  const [loading, setLoading] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);

  // エラーメッセージ
  const errMessage = useErrorMessage();
  const currentRequestId = useRef(0);
  /**
   * 初期化処理
   */
  const clear = () => {
    setSearchTerms({
      ...searchTerms,
      tab: 0, // 選択タブ
      text: "", // 検索ワード
      sort: "更新日順", // ソート順
    });
    setViewMore({
      ...viewMore,
      viewCount: VIEW_COUNT, // 一覧表示件数
      visible: false, // もっと見るボタン・表示
    });
    setResearchFlg(!researchFlg);
  };

  /**
   * チャットボット削除
   * 課題 - 削除時の画面更新
   * @param chatbotId 対象チャットボットID
   */
  const { confirm } = useConfirm();
  const runConfirm = async (chatbotId: string) => {
    // 選択したチャットボットデータを取得
    try {
      const selectChatBot = chatBotsData.filter(
        (item) => item.id === chatbotId,
      );
      const result = await confirm({
        text: (
          <>
            <strong>{selectChatBot[0].chatbotName}</strong>
            を削除します。
          </>
        ),
        title: "チャットボットを削除しますか？",
        okButtonText: "削除する",
        cancelButtonText: "キャンセルする",
      });

      if (result) {
        // 削除処理
        loadingOverlayStore.startLoading();
        const checkResult = await referenceOpen(chatbotId);
        if (checkResult?.check) {
          // ドキュメント情報取得
          const deleteDocument = await createUpdIndexParam(chatbotId);

          // ドキュメントが登録されている場合のみ、AzureFuctionを呼び出す
          if (deleteDocument && deleteDocument?.length > 0) {
            // リクエストデータの準備
            const formData = new FormData();

            // パラメータ設定
            const indexUpdateContent: IndexUpdateAPIContent = {
              chatbotId: chatbotId,
              documentInfo: deleteDocument,
              isModified: false,
            };
            formData.append("content", JSON.stringify(indexUpdateContent));

            try {
              // AzureFunction へのリクエスト送信
              await fetchIndexUpdate({
                chatbotId,
                formData,
              });
            } catch (error) {
              throw error;
            }
          }
          // index-update 時にチャットボットの有無を確認しているので
          // index-update を済ませてから削除処理を行う
          loadingOverlayStore.startLoading();
          // チャットボットを削除
          await DeleteChatbot(chatbotId);
          // 権限情報を削除
          await DeleteAuthorty(chatbotId);
          // 再描画
          setResearchFlg(!researchFlg);
        } else {
          // エラーメッセージを表示
          showError(errMessage[checkResult?.message]);
          clear();
          return;
        }
      }
    } catch (error) {
      showError(errMessage["ECOMMON0001"]);
    } finally {
      loadingOverlayStore.stopLoading();
    }
  };

  /**
   * ポップアップ表示
   * @param chatbotId 対象チャットボットID
   * @param mode モード
   */
  const openModal = async (chatbotId: string, mode: string) => {
    try {
      loadingOverlayStore.startLoading();
      if (chatbotId) {
        if (mode == "参照") {
          // 表示チェック
          const checkResult = await referenceOpen(chatbotId);
          if (checkResult?.check) {
            // 対象チャットボット・取得
            const chatbotResponse = await FindChatbotByID(chatbotId);

            if (chatbotResponse.response) {
              // 表示内容・セット
              setInfo({
                ...info,
                chatbotData: {
                  id: chatbotResponse.response.id,
                  type: chatbotResponse.response.type,
                  userId: chatbotResponse.response.userId,
                  createdAt: chatbotResponse.response.createdAt,
                  lastUpdateAt: chatbotResponse.response.lastUpdateAt,
                  lastUpdateUser: chatbotResponse.response.lastUpdateUser,
                  status: chatbotResponse.response.status,
                  errorMessage: chatbotResponse.response.errorMessage,
                  chatbotName: chatbotResponse.response.chatbotName,
                  description: chatbotResponse.response.description,
                  modelId: chatbotResponse.response.modelId,
                  modelName: chatbotResponse.response.modelName,
                  chunkSizeId: chatbotResponse.response.chunkSizeId,
                  token: chatbotResponse.response.token,
                  overlap: chatbotResponse.response.overlap,
                },
                mode: mode,
                visible: true,
              });
            }
          } else {
            // エラーメッセージを表示
            showError(errMessage[checkResult?.message]);
            // 初期化処理
            clear();
            return;
          }
        } else if (mode === "編集") {
          // 表示チェック
          const checkResult = await referenceOpen(chatbotId);
          if (checkResult?.check) {
            // 対象チャットボット・取得
            const chatbotResponse = await FindChatbotByID(chatbotId);

            if (chatbotResponse.response) {
              // 表示内容・セット
              setInfo({
                ...info,
                chatbotData: {
                  id: chatbotResponse.response.id,
                  type: chatbotResponse.response.type,
                  userId: chatbotResponse.response.userId,
                  createdAt: chatbotResponse.response.createdAt,
                  lastUpdateAt: chatbotResponse.response.lastUpdateAt,
                  lastUpdateUser: chatbotResponse.response.lastUpdateUser,
                  status: chatbotResponse.response.status,
                  errorMessage: chatbotResponse.response.errorMessage,
                  chatbotName: chatbotResponse.response.chatbotName,
                  description: chatbotResponse.response.description,
                  modelId: chatbotResponse.response.modelId,
                  modelName: chatbotResponse.response.modelName,
                  chunkSizeId: chatbotResponse.response.chunkSizeId,
                  token: chatbotResponse.response.token,
                  overlap: chatbotResponse.response.overlap,
                },
                mode: mode,
                visible: true,
              });
            }
          } else {
            // エラーメッセージを表示
            showError(errMessage[checkResult?.message]);
            // 初期化処理
            clear();
            return;
          }
        }
      } else {
        setInfo({
          ...info,
          chatbotData: {
            id: "",
            type: "CHATBOT",
            userId: "",
            createdAt: "",
            lastUpdateAt: "",
            lastUpdateUser: "",
            status: "",
            errorMessage: "",
            chatbotName: "",
            description: "",
            modelId: "",
            modelName: "",
            chunkSizeId: "",
            token: "",
            overlap: "",
          },
          mode: mode,
          visible: true,
        });
      }
    } catch (error) {
      showError(errMessage["ECOMMON0001"]);
    } finally {
      loadingOverlayStore.stopLoading();
    }
  };

  /**
   * 会話開始画面表示判定
   * @param chatbotId 対象チャットボットID
   * @param chatbotName 対象チャットボット名
   * @param modelId 対象チャットボットモデルID
   */
  const talkStartCheck = async (
    chatbotId: string,
    chatbotName: string,
    modelId: string,
  ) => {
    try {
      loadingOverlayStore.startLoading();
      // 存在権限チェック
      const checkResult = await referenceOpen(chatbotId, false);
      if (checkResult?.check) {
        // モデル使用可否チェック
        const modelEnable = await modelCheckForChatbot(modelId);
        if (modelEnable.check) {
          // 会話開始画面を開く
          setThreadParams({
            chatbotId: chatbotId,
            chatbotName: chatbotName,
            modelId: modelId,
          });
          setWindowOpen(true);
        } else {
          // エラーメッセージを表示
          showError(errMessage[modelEnable?.message]);
          return;
        }
      } else {
        // エラーメッセージを表示
        showError(errMessage[checkResult?.message]);
        // 初期化処理
        clear();
        return;
      }
    } catch (error) {
      showError(errMessage["ECOMMON0001"]);
    } finally {
      loadingOverlayStore.stopLoading();
    }
  };

  /**
   * チャットボット一覧表示処理
   */
  useEffect(() => {
    if (!loading) {
      setSearchLoading(true);
      setChatBotsData([]);
      setViewMore({
        ...viewMore,
        visible: false,
      });
    }
    currentRequestId.current += 1;
    console.log("レンダリング回数", currentRequestId);
    try {
      if (debounceTimeout.current) {
        clearTimeout(debounceTimeout.current);
      }
      debounceTimeout.current = setTimeout(async () => {
        const searchData = await fetchChatBot(searchTerms, viewMore);
        setChatBotsData(searchData?.chatBotResponse.response || []);
        setMenuFlg(searchData?.menuFlg);
        setViewMore({
          ...viewMore,
          visible: searchData?.viewMore?.visible ?? false,
        });
        setSearchLoading(false);
        setLoading(false);
      }, 1000);
    } catch (error) {
      setSearchLoading(false);
      setLoading(false);
      showError(errMessage["ECOMMON0001"]);
    }
  }, [searchTerms, viewMore.viewCount, info.visible, researchFlg]);

  // 日付データをフォーマット
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const hours = String(date.getHours());
    const minutes = String(date.getMinutes()).padStart(2, "0");

    return `最終更新：${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()} ${hours}:${minutes}`;
  };

  // --- レンダリング ---
  return (
    <div className="relative flex h-full w-full flex-col items-start gap-4 bg-white-01 p-2 md:gap-6 md:p-5 md:pb-0 lg:p-10 lg:pb-0">
      {/* ヘッダ */}
      <div className="mx-auto w-full xl:w-[77%]">
        <header className="item-center flex w-full flex-col gap-2 md:flex-row">
          <div className="flex items-center justify-between text-lg font-medium text-black-01 md:text-5xl">
            <div className="flex items-center">
              <span className="w-50 h-50 i-material-symbols-upload-file-outline-rounded mr-2 mt-2.5 hidden md:block" />
              チャットボット
            </div>

            <Button
              variant="icon"
              onClick={() => {
                redirectToPage("chat");
              }}
              icon={"i-material-symbols-close-small-rounded h-6 w-6"}
              className="block md:hidden"
            />
          </div>

          <div className="flex-grow" />
          <Button
            color="default"
            text="新しいチャットボット"
            onClick={() => openModal("", "新規")}
            icon={"i-material-symbols-add"}
            className="hidden md:block"
          />
        </header>

        <div className="ml-0 md:ml-16">
          {/* テキスト */}
          <div className="mt-4 hidden text-[22px] text-gray-03 md:block">
            社内規程等の独自ドキュメントをアップロードすることで、YONDEN-GPTがそれを基にした回答を提供します。
          </div>

          {/* 検索ボックス */}
          <div className="flex w-full md:mt-6 md:w-[90%]">
            <Input
              className="h-8 w-full md:h-10"
              placeholder="チャットボットを検索する"
              icon={"i-ooui-search h-5 w-5 md:h-6 md:w-6"}
              text={searchTerms.text}
              onInputText={(text) => {
                setSearchTerms({
                  ...searchTerms,
                  text: text,
                });
                setViewMore({
                  ...viewMore,
                  viewCount: VIEW_COUNT,
                });
              }}
            />
          </div>
        </div>

        {/* タブ・並べ替え */}
        <div className="mt-3 flex w-full items-center gap-4 md:mt-5">
          <div className="flex flex-nowrap gap-4 overflow-x-auto">
            {buttons.map((button, index) => (
              <Button
                key={index}
                className={`${
                  searchTerms.tab === index ? "bg-gray-300" : "bg-white-01"
                } flex-shrink-0 !rounded-md text-sm font-bold text-black md:text-base`}
                color="default"
                text={button.text}
                onClick={() => {
                  setSearchTerms({
                    ...searchTerms,
                    tab: index,
                  });
                  setViewMore({
                    ...viewMore,
                    viewCount: VIEW_COUNT,
                  });
                }}
              />
            ))}
          </div>
          <div className="ml-auto flex flex-shrink-0 items-center gap-2">
            <div className="hidden text-xl font-bold text-black-01 md:block">
              並べ替え
            </div>
            <ComboBox
              items={sortValue}
              selectedItem={searchTerms.sort}
              onSelectText={(value) =>
                setSearchTerms({
                  ...searchTerms,
                  sort: value,
                })
              }
              idField={"id"}
              textField={"text"}
            />
          </div>
        </div>
      </div>

      <Separator className="hidden md:block" />

      {/* チャットボット一覧表示 */}
      <div className="flex w-full flex-col items-center gap-3 overflow-y-auto md:gap-5">
        {searchLoading && (
          <div className="flex w-full items-center justify-center py-4">
            <LoadingIndicator isLoading={searchLoading} />
          </div>
        )}

        {chatBotsData.map((chatBot, index) => {
          const isOption =
            menuFlg?.some(
              (menu) => menu.chatBotId === chatBot.id && menu.isOption,
            ) ?? false;
          const isTalkStart =
            menuFlg?.some(
              (menu) => menu.chatBotId === chatBot.id && menu.isTalkStart,
            ) ?? false;

          return (
            <div
              key={index}
              className="relative grid w-full gap-1 rounded-md border border-solid border-[#c8c8c8] bg-white-01 p-2 md:p-4 xl:w-[77%]"
              onClick={
                isMobile
                  ? () => {
                      openModal(chatBot.id, "参照");
                    }
                  : undefined
              }
            >
              {/* タイトルとボタン配置 */}
              <div className="flex flex-row items-center justify-between">
                <div className="truncate font-bold text-black-01 md:text-[22px] md:font-bold">
                  {countWord(chatBot.chatbotName, 35)}
                </div>

                {/* ボタン: スマホ時は参照ボタンのみ、他は非表示 */}
                <div className="flex items-center">
                  <div className="hidden text-xs md:block md:text-base">
                    {formatDate(chatBot.lastUpdateAt)}
                  </div>
                  {/* 参照ボタン */}
                  <Button
                    title="参照"
                    className="!flex !justify-center !rounded-md !bg-white-01"
                    variant="icon"
                    icon="i-material-symbols-info-outline-rounded text-black w-6 h-6 md:w-8 md:h-8"
                    onClick={() => {
                      openModal(chatBot.id, "参照");
                    }}
                    size="sm"
                  />

                  {/* 会話開始ボタン */}
                  <Button
                    title="チャットボットと会話する"
                    className={`hidden !justify-center !rounded-md !bg-white-01 md:!flex md:px-0 ${
                      isTalkStart ? "" : "invisible"
                    }`}
                    variant="icon"
                    icon="i-material-symbols-chat-add-on-outline-rounded text-black w-8 h-8"
                    onClick={() => {
                      talkStartCheck(
                        chatBot.id,
                        chatBot.chatbotName,
                        chatBot.modelId,
                      );
                    }}
                    size="sm"
                  />

                  {/* 削除・編集ボタン */}
                  <CustomDropdownMenu
                    className={`hidden md:flex ${isOption ? "" : "invisible"}`}
                    items={
                      chatBot.status === "processing" ? deleteItem : menuItems
                    }
                    open={activeMenuId === chatBot.id}
                    onOpenChange={(open) => {
                      setActiveMenuId(open ? chatBot.id : null);
                    }}
                    onItemClick={(label, index) => {
                      if (label === "編集") {
                        openModal(chatBot.id, "編集");
                      } else {
                        runConfirm(chatBot.id);
                      }
                    }}
                    side="bottom"
                    align="end"
                    sideOffset={0}
                    alignOffset={-65}
                    triggerElement={
                      <Button
                        title="オプション"
                        className={`hidden !justify-center !rounded-md !bg-white-01 md:!flex ${isOption ? "" : "invisible"}`}
                        variant="icon"
                        icon="i-ooui-ellipsis text-black w-8 h-8"
                        size="sm"
                      />
                    }
                  />
                </div>
              </div>

              {/* 説明 */}
              <div className="col-span-full flex flex-1 flex-col gap-2 md:gap-4">
                <div className="text-sm text-gray-03 md:text-base">
                  {countWord(chatBot.description, 70)}
                </div>
              </div>

              {/* ステータス表示をボタンの下に配置 */}
              <div className="col-span-full flex w-full items-center justify-start md:justify-end">
                {chatBot.status === "processing" ? (
                  <div className="flex items-center whitespace-nowrap rounded bg-blue-50 px-2 py-1 text-blue-600">
                    <span className="i-material-symbols-refresh-rounded h-4 w-4 md:mr-1 md:h-5 md:w-5"></span>
                    <span className="hidden text-xs md:block md:text-base">
                      作成中
                    </span>
                  </div>
                ) : chatBot.status === "error" ? (
                  isMobile ? (
                    // モバイル時はボタンを表示
                    <Button
                      icon="i-material-symbols-warning-outline-rounded text-red-500 h-4 w-4"
                      variant="icon"
                      className="ml-1 flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        showError(chatBot.errorMessage);
                      }}
                    />
                  ) : (
                    // デフォルト表示
                    <div className="flex items-center rounded bg-red-50 px-2 py-1 text-red-600">
                      <span className="i-material-symbols-warning-outline-rounded h-4 w-4 md:mr-1 md:h-5 md:w-5"></span>
                      <span className="hidden text-xs md:block md:text-base">
                        {chatBot.errorMessage}
                      </span>
                    </div>
                  )
                ) : null}
                <div className="ml-auto block text-xs md:hidden md:text-base">
                  {formatDate(chatBot.lastUpdateAt)}
                </div>
              </div>
            </div>
          );
        })}

        {/* もっと見る */}
        {viewMore.visible && (
          <>
            {loading ? (
              <div className="flex w-full items-center justify-center py-4">
                <LoadingIndicator isLoading={loading} />
              </div>
            ) : (
              <Button
                text="もっと見る"
                variant={"more"}
                className="mb-4 w-full xl:w-[77%]"
                onClick={() => {
                  setViewMore({
                    ...viewMore,
                    viewCount: viewMore.viewCount + VIEW_COUNT,
                  });
                  setLoading(true);
                }}
              />
            )}
          </>
        )}
      </div>

      {/* 作成・編集・新規作成画面 */}
      {info.visible && (
        <ChatbotContextProvider initialChatbotData={info.chatbotData}>
          <ChatbotModal
            visible={info.visible}
            closeModal={() => {
              setInfo({ ...info, visible: false });
            }}
            chatbotData={info.chatbotData}
            mode={info.mode}
            openModal={openModal}
            initialize={clear}
          />
        </ChatbotContextProvider>
      )}
      {/**会話開始画面 */}
      <ChatbotThreadNewWindow
        open={windowOpen}
        onOpenChange={setWindowOpen}
        chatbot={threadparams}
        clear={clear}
      />
    </div>
  );
};
