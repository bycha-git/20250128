import { Label } from "@radix-ui/react-dropdown-menu";
import React, { useEffect, useState } from "react";
import { RadioGroup, RadioGroupItem } from "../ui/radio-group";
import { DocumentTabData } from "./Chatbot-model";
import { useChatbotContext } from "./ChatbotContext";
import { Input } from "@/features/ui/input";
import { Window } from "@/features/ui/window";
interface LinkProps {
  open: boolean;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
  selectDocument: DocumentTabData | undefined;
}

export const Link: React.FC<LinkProps> = ({
  open,
  setOpen,
  selectDocument,
}) => {
  const [selectedValue, setSelectedValue] = useState(() =>
    selectDocument?.document.isOriginalLink ? "original" : "standard",
  );

  const [inputValue, setInputValue] = useState<string>("");
  const { setIsModalVisible, setDocumentTableData } = useChatbotContext();

  useEffect(() => {
    if (selectedValue === "standard") {
      setInputValue(selectDocument?.document.standardLink ?? "");
    } else if (selectedValue === "original") {
      setInputValue(selectDocument?.document.originalLink ?? "");
    }
  }, [selectedValue, selectDocument]);

  // ドキュメントのリンク情報を更新
  const updateDocumentLink = () => {
    if (!selectDocument) return;

    setDocumentTableData((prevData) =>
      prevData.map((data) =>
        data.document.id === selectDocument.document.id
          ? {
              ...data,
              document: {
                ...data.document,
                ...(selectedValue === "standard"
                  ? { standardLink: inputValue, isOriginalLink: false }
                  : { originalLink: inputValue, isOriginalLink: true }),
              },
            }
          : data,
      ),
    );
  };

  return (
    <main className="flex flex-1 flex-col items-start gap-7 p-3">
      <Window
        title={selectDocument?.document.documentName ?? ""}
        open={open}
        showClose={false}
        onOpenChange={(newOpen) => {
          setOpen(newOpen);
          if (!newOpen) {
            setIsModalVisible(true);
          }
        }}
        primaryButtonText={"登録する"}
        primaryButtonDisabled={
          selectedValue === "standard" &&
          selectDocument?.document.standardLink.trim() === ""
        }
        secondaryButtonText={"キャンセルする"}
        onClickPrimary={() => {
          updateDocumentLink();
          setOpen(false);
        }}
        onClickSecondary={() => {
          setIsModalVisible(true);
          setOpen(false);
        }}
        className="h-[270px] w-[600px]"
      >
        <RadioGroup
          value={selectedValue}
          onValueChange={setSelectedValue}
          className="flex"
        >
          <Label className="flex items-center space-x-2">
            <RadioGroupItem value="standard" />
            <span>標準リンクを使用</span>
          </Label>

          <Label className="flex items-center space-x-2">
            <RadioGroupItem value="original" />
            <span>独自リンクを使用</span>
          </Label>
        </RadioGroup>

        <div className="mt-5 flex items-center">
          <div className="flex items-center">
            <Label className="whitespace-nowrap pr-3">リンク</Label>
            {selectedValue === "original" && (
              <span className="i-material-symbols-asterisk-rounded mx-1 h-3 w-3 bg-red-600" />
            )}
          </div>
          <div className="w-full">
            <Input
              className="ml-2.5 w-full rounded border border-gray-300"
              type="text"
              placeholder={"ドキュメントのリンクを記入してください"}
              value={inputValue}
              onInputText={(e) => setInputValue(e)}
              disabled={selectedValue === "standard"}
              maxLength={4096}
            />
          </div>
        </div>
      </Window>
    </main>
  );
};
