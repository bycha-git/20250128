import axios, { AxiosProgressEvent } from "axios";
import { loadingOverlayStore } from "@/features/common/store/loading-overlay-store";

export const fetchIndexUpdate = async ({
  chatbotId,
  formData,
}: {
  chatbotId: string;
  formData: FormData;
}) => {
  loadingOverlayStore.startLoading("アップロード中");
  try {
    // fetch だとアップロード進捗を取れないため XMLHTTPRequest (axios) を使用
    const res = await axios.post(
      `/api/chatbot-index-update/${chatbotId}`,
      formData,
      {
        onUploadProgress(progressEvent) {
          loadingOverlayStore.updateLoadingMessage(
            getProgressMessage(progressEvent),
          );
        },
      },
    );
    return res;
  } catch (e) {
    throw e;
  } finally {
    loadingOverlayStore.stopLoading();
  }
};

const getProgressMessage = (progress: AxiosProgressEvent) => {
  if (!progress.total || progress.loaded === progress.total) {
    return "";
  }
  return `アップロード中 (${toMB(progress.loaded)} / ${toMB(progress.total)})`;
};

const toMB = (bytes: number) => {
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
};
