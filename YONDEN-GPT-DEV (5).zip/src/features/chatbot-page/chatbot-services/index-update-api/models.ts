import * as v from "valibot";

/** インデックス更新リクエスト (サーバで読み取る必要があるもののみ) */
export const IndexUpdateAPIContentSchema = v.looseObject({
  /** チャットボットID */
  chatbotId: v.string(),
});

/** インデックス更新リクエスト (サーバで読み取る必要があるもののみ) */
export type IndexUpdateAPIContent = v.InferInput<
  typeof IndexUpdateAPIContentSchema
>;

/** インデックス更新用ファイル一覧 */
export const IndexUpdateAPIBlobListSchema = v.array(v.string());

/** インデックス更新用ファイル一覧 */
export type IndexUpdateAPIBlobList = v.InferInput<
  typeof IndexUpdateAPIBlobListSchema
>;
