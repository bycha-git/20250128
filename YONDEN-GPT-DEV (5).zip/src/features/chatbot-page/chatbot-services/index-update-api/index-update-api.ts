import "server-only";

import { ReadableStream as NodeReadableStream } from "node:stream/web";
import { Readable } from "stream";
import { Busboy } from "@fastify/busboy";
import { NextRequest, NextResponse } from "next/server";
import * as v from "valibot";
import { uploadDocumentFileStreamToStore } from "../../chatbot-document/chatbot-document-file";
import {
  IndexUpdateAPIBlobList,
  IndexUpdateAPIBlobListSchema,
  IndexUpdateAPIContent,
  IndexUpdateAPIContentSchema,
} from "./models";
import { userSession } from "@/features/auth-page/helpers";
import { FindChatbotByID } from "@/features/chatbot-page/Chatbot-service";
import {
  getDefaultAPIBadRequestErrorResponse,
  getDefaultAPIServerErrorResponse,
  getDefaultAPIUnauthorizedErrorResponse,
} from "@/features/common/api-helpers";
import { runAzureFunc } from "@/features/common/services/azure-functions";
import { UserData } from "@/types/next-auth";

/** チャットボット インデックス更新 */
export const chatbotIndexUpdateAPIEntry = async (
  req: NextRequest,
  params: { chatbotId: string },
) => {
  console.log("/api/chatbot-index-update");
  console.log("request content-length:", req.headers.get("content-length"));
  const chatbotId = params.chatbotId ?? "";

  const user = await userSession();
  if (!user) {
    // middleware を使わないので手動認証
    return getDefaultAPIUnauthorizedErrorResponse();
  }

  try {
    return await indexUpdateAPI(user, chatbotId, req, req.signal);
  } catch (e) {
    const error = e instanceof Error ? e : new Error(String(e));
    console.error("🔴 Error on indexUpdateAPI:", error);
    return getDefaultAPIServerErrorResponse();
  }
};

const indexUpdateAPI = async (
  user: Required<UserData>,
  chatbotId: string,
  req: NextRequest,
  signal: AbortSignal,
) => {
  const userId = user.id;

  // TODO: ボディ内容のチャットボットに書き込む権限があるか確認
  const chatbotResponse = await FindChatbotByID(chatbotId);
  if (chatbotResponse.status !== "OK" || !chatbotResponse.response) {
    console.error(chatbotResponse.errors?.[0].message);
    return getDefaultAPIServerErrorResponse();
  }
  // const chatbot = chatbotResponse.response;

  // メッセージと添付ファイルの読込開始
  return await new Promise((resolve, reject) => {
    try {
      indexUpdateAPIReadFormData({
        req,
        chatbotId,
        resolve,
        signal,
      });
    } catch (e) {
      reject(e instanceof Error ? e : new Error(String(e)));
    }
  });
};

const indexUpdateAPIReadFormData = ({
  req,
  chatbotId,
  resolve,
  signal,
}: {
  req: NextRequest;
  chatbotId: string;
  resolve: (value: NextResponse) => void;
  signal: AbortSignal;
}): void => {
  const body = req.body;
  if (!(body instanceof NodeReadableStream)) {
    throw new Error("req.body is not a ReadableStream from node:stream/web");
  }
  const inputStream: NodeReadableStream = body;
  const readable = Readable.fromWeb(inputStream);

  let contentJson: string | undefined = undefined;
  type Attachment = {
    documentPath: string;
    uploading: boolean;
    uploaded: boolean;
  };
  let attachments: Attachment[] = [];
  const attachmentsMapByFilePath = new Map<string, Attachment>();
  let blobList: IndexUpdateAPIBlobList = [];

  // multipart/form-data のパースをストリーミングで行う
  const busboy = new Busboy({
    headers: {
      "content-type": req.headers.get("content-type") ?? "",
    },
  });

  signal.addEventListener("abort", (): void => {
    console.log("🔴 indexUpdateAPIReadFormData: abort");
    busboy.removeAllListeners();
    resolve(getDefaultAPIBadRequestErrorResponse());
  });

  busboy.on("field", (fieldname, value): void => {
    console.log("📄 field:", fieldname);
    // ここでは、同期処理のみ行うこと
    // (非同期処理を行うと、 file に先を越される可能性がある)
    if (fieldname === "content") {
      const unsafeContentJson = value;
      if (!unsafeContentJson || typeof unsafeContentJson !== "string") {
        console.error("🔴 content が文字列でない");
        busboy.removeAllListeners();
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }

      // chatbotId だけ解釈
      let content: IndexUpdateAPIContent;
      try {
        const unsafeContent: unknown = JSON.parse(unsafeContentJson);
        content = v.parse(IndexUpdateAPIContentSchema, unsafeContent);
      } catch (e) {
        console.error("🔴 content のパース失敗:", e);
        busboy.removeAllListeners();
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }
      if (content.chatbotId !== chatbotId) {
        console.error("🔴 chatbotId 不一致");
        busboy.removeAllListeners();
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }

      contentJson = unsafeContentJson;
    } else if (fieldname === "blobList") {
      const unsafeBlobListJson = value;
      if (!unsafeBlobListJson || typeof unsafeBlobListJson !== "string") {
        console.error("🔴 blobList が文字列でない");
        busboy.removeAllListeners();
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }

      try {
        const unsafeBlobList: unknown = JSON.parse(unsafeBlobListJson);
        blobList = v.parse(IndexUpdateAPIBlobListSchema, unsafeBlobList);
      } catch (e) {
        console.error("🔴 blobList のパース失敗:", e);
        busboy.removeAllListeners();
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }

      attachments = blobList.map((documentPath) => {
        const attachment = {
          documentPath,
          uploading: false,
          uploaded: false,
        };
        attachmentsMapByFilePath.set(documentPath, attachment);
        return attachment;
      });
    } else {
      console.error("🔴 不明なフィールド:", fieldname);
      busboy.removeAllListeners();
      resolve(getDefaultAPIBadRequestErrorResponse());
    }
  });

  busboy.on(
    "file",
    (fieldnameRaw, readable, filename, encoding, mimetype): void => {
      const fieldName = decodeURIComponent(fieldnameRaw);
      console.log("📁 file:", fieldName, filename, mimetype);
      if (!fieldName.startsWith("blob:")) {
        console.error("🔴 content, blob 以外のパラメータを検出");
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }
      if (!contentJson) {
        console.error("🔴 content より先に blob を検出");
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }
      const documentPath = fieldName.replace("blob:", "");
      const attachment = attachmentsMapByFilePath.get(documentPath);
      if (!attachment) {
        console.error("🔴 blobList に存在しない blob を検出");
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }
      if (attachment.uploading || attachment.uploaded) {
        console.error("🔴 重複した blob を検出");
        resolve(getDefaultAPIBadRequestErrorResponse());
        return;
      }
      attachment.uploading = true;
      uploadDocumentFileStreamToStore(
        {
          chatbotId,
          documentPath,
        },
        readable,
        mimetype,
      )
        .then(() => {
          console.log("📤 file uploaded:", filename);
          attachment.uploading = false;
          attachment.uploaded = true;

          const allUploaded = attachments.every((a) => a.uploaded);
          if (allUploaded) {
            console.log("🏁 ファイルアップロード完了");
            finalize();
          }
        })
        .catch((e) => {
          console.error("🔴 Error on uploading file:", e);
          resolve(getDefaultAPIServerErrorResponse());
        });
    },
  );

  busboy.on("finish", (): void => {
    console.log("🏁 finish");
    if (!contentJson) {
      console.error("🔴 content が存在しない");
      resolve(getDefaultAPIBadRequestErrorResponse());
      return;
    }
    const allUploadedOrUploading = attachments.every(
      (a) => a.uploaded || a.uploading,
    );
    if (!allUploadedOrUploading) {
      console.error("🔴 ファイル不足");
      resolve(getDefaultAPIBadRequestErrorResponse());
      return;
    }
    // attachments が存在しない場合そのまま終了
    if (attachments.length === 0) {
      finalize();
    }
  });

  /** インデックス更新を実行 */
  const finalize = async (): Promise<void> => {
    if (!contentJson) {
      console.error("🔴 content より先に終了を検出");
      resolve(getDefaultAPIBadRequestErrorResponse());
      return;
    }

    const attachmentsOnlyUploaded = attachments.filter(
      (attachment) => attachment.uploaded,
    );

    if (attachmentsOnlyUploaded.length !== blobList.length) {
      console.error(
        "🔴 blobList と実際のファイル数の差を検出",
        attachmentsOnlyUploaded,
        blobList,
      );
      resolve(getDefaultAPIBadRequestErrorResponse());
      return;
    }

    const functionsUrl = process.env.AZURE_FUNCTIONS_INDEX_UPDATE_URL;
    const accessKey = process.env.AZURE_FUNCTIONS_INDEX_UPDATE_KEY;

    if (functionsUrl && accessKey) {
      // Azure Function にリクエスト (非同期)
      void runIndexUpdate({
        contentJson,
        functionsUrl,
        accessKey,
      });
    } else {
      // TODO: 有効化
      // resolve(getDefaultAPIServerErrorResponse());
      // return;
    }

    resolve(
      new NextResponse(`{"status":"OK"}`, {
        headers: {
          "Cache-Control": "no-store",
          "Content-Type": "application/json",
          // Connection: "keep-alive",
          // "Content-Type": "text/event-stream",
        },
      }),
    );
  };

  busboy.on("error", (err) => {
    console.error("🔴 busboyエラー:", err);
    resolve(getDefaultAPIServerErrorResponse(String(err)));
  });

  readable.pipe(busboy);
};

const runIndexUpdate = async ({
  contentJson,
  functionsUrl,
  accessKey,
}: {
  contentJson: string;
  functionsUrl: string;
  accessKey: string;
}) => {
  try {
    const response = await runAzureFunc<string>(
      functionsUrl,
      accessKey,
      contentJson,
    );
    console.log("🟢 Azure Function からのレスポンス:", response);
    // return new NextResponse(response);
  } catch (e) {
    console.error("🔴 Azure Function 呼び出しエラー:", e);
    // return getDefaultAPIServerErrorResponse();
  }
};
