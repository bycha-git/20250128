import React, { useEffect, useState } from "react";
import { showError } from "../globals/global-message-store";
import { useResponsive } from "../ui/responsive";
import SearchInput from "../ui/searchInput";
import { Separator } from "../ui/separator";
import {
  searchAuthorityCompany,
  searchAuthorityUsers,
} from "./CahtBotModal-service";
import { useChatbotContext } from "./ChatbotContext";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { Button } from "@/features/ui/button";
import ComboBox from "@/features/ui/combbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/features/ui/table";

const authorityTabs = [{ text: "組織" }, { text: "ユーザー" }];

const AuthorityTab: React.FC = ({}) => {
  const {
    companySearchResults,
    setCompanySearchResults,
    employeeSearchResults,
    setEmployeeSearchResults,
    authorityCompanyInfo,
    setAuthorityCompanyInfo,
    setAuthorityEmployeeInfo,
    authorityEmployeeInfo,
    openMode,
    adminId,
    authority,
  } = useChatbotContext();
  const [selectedTab, setSelectedTab] = useState(0);

  const { isMobile } = useResponsive();
  // エラーメッセージ
  const errMessage = useErrorMessage();
  // タブが切り替わった時の検索結果をクリア
  useEffect(() => {
    setCompanySearchResults([]);
    setEmployeeSearchResults([]);
  }, [selectedTab]);
  /**
   * 検索処理
   */
  let activeRequest = 0;
  const search = async (searchText: string) => {
    try {
      activeRequest++;
      const currentRequest = activeRequest;

      if (!searchText.trim()) {
        selectedTab === 0
          ? setCompanySearchResults([])
          : setEmployeeSearchResults([]);
        return;
      }

      if (selectedTab === 0) {
        const srarchCompanyData =
          (await searchAuthorityCompany(searchText)) ?? [];
        if (currentRequest === activeRequest) {
          setCompanySearchResults(srarchCompanyData);
        }
      } else {
        const searchEmployeeData =
          (await searchAuthorityUsers(searchText)) ?? [];
        if (currentRequest === activeRequest) {
          setEmployeeSearchResults(searchEmployeeData);
        }
      }
    } catch (error) {
      console.log(error);
      showError(errMessage["ECOMMON0001"]);
    }
  };

  /**
   * 検索条件が選択されたときの処理
   */
  const selectItem = (item) => {
    if (selectedTab === 0) {
      // 既に追加されていないか確認
      if (
        !authorityCompanyInfo.some(
          (info) => info.departmentName === item.departmentName,
        )
      ) {
        setAuthorityCompanyInfo((prevState) => [
          ...prevState,
          { ...item, permissionId: adminId },
        ]);
      }
    } else {
      if (
        !authorityEmployeeInfo.some(
          (info) => info.employeeName === item.employeeName,
        )
      ) {
        setAuthorityEmployeeInfo((prevState) => [
          ...prevState,
          { ...item, permissionId: adminId },
        ]);
      }
    }
  };

  /**
   * 権限タブ（コンボボックス変更時）
   */
  const combboxSelected = (selectedLabel: string, index: number) => {
    // authority 配列から選択されたラベルに対応するidを検索
    const selectedAuthority = authority.find(
      (item) => item.label === selectedLabel,
    );

    // 見つかった場合はそのidを設定
    const permissionId = selectedAuthority?.id || "";

    if (selectedTab === 0) {
      // 組織タブの場合
      setAuthorityCompanyInfo((prevState) => {
        const newAuthorityInfo = [...prevState];
        newAuthorityInfo[index].permissionId = permissionId;
        return newAuthorityInfo;
      });
    } else {
      // ユーザータブの場合
      setAuthorityEmployeeInfo((prevState) => {
        const newAuthorityInfo = [...prevState];
        newAuthorityInfo[index].permissionId = permissionId;
        return newAuthorityInfo;
      });
    }
  };

  /** 権限タブ×ボタン押下処理 */
  const deleteRow = (index: number) => {
    if (selectedTab === 0) {
      // 組織タブから行を削除
      setAuthorityCompanyInfo((prevState) => {
        return prevState.filter((_, i) => i !== index);
      });
    } else {
      // ユーザータブから行を削除
      setAuthorityEmployeeInfo((prevState) => {
        return prevState.filter((_, i) => i !== index);
      });
    }
  };

  return (
    <div className="flex min-h-0 w-full flex-col">
      <div className="flex items-center">
        {authorityTabs.map((button, index) => (
          <Button
            key={index}
            color="default"
            text={button.text}
            onClick={() => setSelectedTab(index)}
            className={`${selectedTab === index ? "bg-gray-200" : "bg-white"} ${
              isMobile ? "text-sm font-bold" : "font-bold"
            } rounded-md px-4 py-2 text-black hover:bg-gray-100`}
          />
        ))}
      </div>
      <SearchInput
        placeholder={
          openMode === "参照"
            ? ""
            : selectedTab === 0
              ? "権限を付与する組織を選択してください"
              : "権限を付与するユーザーを選択してください"
        }
        onSearch={search}
        searchResults={
          selectedTab === 0 ? companySearchResults : employeeSearchResults
        }
        idField={selectedTab === 0 ? "departmentName" : "employeeName"}
        textField={selectedTab === 0 ? "departmentName" : "employeeName"}
        onSelectItem={selectItem}
        className={isMobile ? "hidden" : "mt-2 w-[70%]"}
        selectedItems={
          selectedTab === 0 ? authorityCompanyInfo : authorityEmployeeInfo
        }
        noResultText={selectedTab === 0 ? "該当組織なし" : "該当ユーザーなし"}
        disabled={openMode === "参照"}
      />
      {isMobile && <Separator className="mt-1" />}
      <div className="mt-1.5 min-h-0 w-full flex-1 overflow-auto">
        <Table className="min-h-0">
          <TableHeader>
            <TableRow className={isMobile ? "hidden" : ""}>
              <TableHead className="w-[48%]">名前</TableHead>
              <TableHead className="w-[0%]"></TableHead>
              <TableHead className="w-[37%]">権限</TableHead>
              <TableHead className="w-[0%]"></TableHead>
            </TableRow>
          </TableHeader>

          {selectedTab === 0 ? (
            <TableBody className="overflow-y-auto">
              {authorityCompanyInfo.map((item, index) => (
                <TableRow key={`${item.id}-${index}`}>
                  <TableCell
                    className="p-2 align-middle"
                    title={item.departmentName}
                  >
                    <div className="line-clamp-2 leading-normal">
                      {item.departmentName}
                    </div>
                  </TableCell>

                  <TableCell className="py-0.5">
                    {!item.errFlg ? (
                      <div className="h-6 w-full" />
                    ) : (
                      <Button
                        icon="i-material-symbols-warning-outline-rounded text-red-500 h-5 w-5"
                        variant="icon"
                        className="flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1"
                        onClick={() =>
                          showError(errMessage[item.errorMessageId])
                        }
                      />
                    )}
                  </TableCell>

                  <TableCell className="py-0.5">
                    <ComboBox
                      items={authority}
                      idField="id"
                      textField="label"
                      className={`w-full overflow-hidden text-ellipsis whitespace-nowrap text-sm ${
                        isMobile ? "text-left" : "text-center"
                      }`}
                      selectedItem={
                        authority.find((auth) => auth.id === item.permissionId)
                          ?.label || ""
                      }
                      onSelectText={(value) => {
                        combboxSelected(value, index);
                      }}
                      disabled={openMode === "参照"}
                    />
                  </TableCell>

                  <TableCell
                    className={isMobile ? "hidden" : "py-0.5 text-right"}
                  >
                    {openMode !== "参照" && (
                      <Button
                        icon="i-material-symbols-close-small-rounded h-5 w-5"
                        variant="icon"
                        onClick={() => deleteRow(index)}
                      />
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          ) : (
            <TableBody className="overflow-y-auto">
              {authorityEmployeeInfo.map((item, index) => (
                <TableRow key={`${item.id}-${index}`}>
                  <TableCell
                    className="p-2 align-middle"
                    title={item.employeeName}
                  >
                    <div className="line-clamp-2 leading-normal">
                      {item.employeeName}
                    </div>
                  </TableCell>

                  <TableCell className="py-0.5">
                    {!item.errFlg ? (
                      <div className="h-6 w-full" />
                    ) : (
                      <Button
                        icon="i-material-symbols-warning-outline-rounded text-red-500 h-5 w-5"
                        variant="icon"
                        className="flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1"
                        onClick={() =>
                          showError(errMessage[item.errorMessageId])
                        }
                      />
                    )}
                  </TableCell>

                  <TableCell className="py-0.5">
                    <ComboBox
                      items={authority}
                      idField="id"
                      textField="label"
                      className={`w-full overflow-hidden text-ellipsis whitespace-nowrap text-sm ${
                        isMobile ? "text-left" : "text-center"
                      }`}
                      selectedItem={
                        authority.find((auth) => auth.id === item.permissionId)
                          ?.label || ""
                      }
                      onSelectText={(value) => {
                        combboxSelected(value, index);
                      }}
                      disabled={openMode === "参照"}
                    />
                  </TableCell>

                  <TableCell
                    className={isMobile ? "hidden" : "py-0.5 text-right"}
                  >
                    {openMode !== "参照" && (
                      <Button
                        icon="i-material-symbols-close-small-rounded h-5 w-5"
                        variant="icon"
                        onClick={() => deleteRow(index)}
                      />
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          )}
        </Table>
      </div>
    </div>
  );
};

export default AuthorityTab;
