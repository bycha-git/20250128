import { SqlQuerySpec } from "@azure/cosmos";
import { ChatbotDocumentFileAPIData } from "./models";
import {
  CHATBOT_ATTRIBUTE,
  ChatbotModelSchema,
} from "@/features/common/model/history/chatbot-model";
import {
  DocumentModelSchema,
  FILE_DOCUMENT_ATTRIBUTE,
} from "@/features/common/model/history/document-model";
import { getOnlyParsed } from "@/features/common/schema-validation";
import { ServerActionResponseOrThrow } from "@/features/common/server-action-response";
import { HistoryContainer } from "@/features/common/services/cosmos";

export const findChatbotDocumentFileAPIData = async ({
  chatbotId,
  documentId,
}: {
  /** チャットボットID */
  chatbotId: string;
  /** ドキュメントID */
  documentId: string;
}): Promise<ServerActionResponseOrThrow<ChatbotDocumentFileAPIData>> => {
  try {
    const querySpec: SqlQuerySpec = {
      query: `
SELECT * FROM root r
WHERE
  (
    (r.type = @typeFileDocument)
    AND r.chatbotId = @chatbotId
    AND r.id = @documentId
  )
  OR
  (
    r.type = @typeChatbot
    AND r.id = @chatbotId
  )
`,
      parameters: [
        {
          name: "@typeFileDocument",
          value: FILE_DOCUMENT_ATTRIBUTE,
        },
        {
          name: "@typeChatbot",
          value: CHATBOT_ATTRIBUTE,
        },
        {
          name: "@chatbotId",
          value: chatbotId,
        },
        {
          name: "@documentId",
          value: documentId,
        },
      ],
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();

    const chatbotSafeResources = getOnlyParsed(resources, ChatbotModelSchema);
    const documentSafeResources = getOnlyParsed(resources, DocumentModelSchema);

    // 結果0件
    if (
      chatbotSafeResources.length === 0 ||
      documentSafeResources.length === 0
    ) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "",
          },
        ],
      };
    }

    const chatbot = chatbotSafeResources[0];
    const document = documentSafeResources[0];

    return {
      status: "OK",
      response: {
        chatbot,
        document,
      },
    };
  } catch (error) {
    console.error("🔴 チャットボットドキュメント権限取得エラー", error);
    throw error;
  }
};
