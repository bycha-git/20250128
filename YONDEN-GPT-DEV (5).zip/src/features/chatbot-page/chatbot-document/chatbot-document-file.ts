import { Readable } from "node:stream";
import {
  GetDocumentFileFromBlobParam,
  GetDocumentFileParam,
  GetDocumentFileParamSchema,
} from "./models";
import { ServerActionResponse } from "@/features/common/server-action-response";
import {
  getBlob,
  uploadBlobStream,
} from "@/features/common/services/azure-storage";
import { GetBlobResult } from "@/features/common/services/azure-storage-models";

const CHATBOT_CONTAINER_NAME =
  process.env.AZURE_STORAGE_CHATBOT_CONTAINER_NAME ?? "chatbot";
const IMAGE_API_PATH = `${process.env.NEXTAUTH_URL}/api/chatbot-document-file`;

export const getDocumentBlobStorePath = ({
  chatbotId,
  documentPath,
}: GetDocumentFileFromBlobParam): string => {
  return `${chatbotId}/${documentPath}`;
};

export const uploadDocumentFileStreamToStore = async (
  params: GetDocumentFileFromBlobParam,
  readable: Readable,
  mimeType: string,
) => {
  const blobPath = getDocumentBlobStorePath(params);
  return await uploadBlobStream(
    CHATBOT_CONTAINER_NAME,
    blobPath,
    mimeType,
    readable,
  );
};

export const getDocumentFileFromStore = async (
  params: GetDocumentFileFromBlobParam,
): Promise<ServerActionResponse<GetBlobResult>> => {
  const blobPath = params.documentPath;
  return await getBlob(CHATBOT_CONTAINER_NAME, blobPath);
};

export const parseDocumentFileParam = (urlStr: string) => {
  if (urlStr.startsWith("/")) {
    urlStr = `http://localhost${urlStr}`;
  }
  const url = new URL(urlStr);
  const chatbotId = url.searchParams.get("c");
  const documentId = url.searchParams.get("d");
  const unsafeParams = {
    chatbotId,
    documentId,
  };

  const parsedParams = GetDocumentFileParamSchema.safeParse(unsafeParams);
  return parsedParams;
};

export const getDocumentFileParamUrl = (params: GetDocumentFileParam) => {
  const paramsObj = {
    c: params.chatbotId,
    d: params.documentId,
  };
  const searchParams = new URLSearchParams(paramsObj);
  const paramsStr = searchParams.toString();

  return `${IMAGE_API_PATH}?${paramsStr}`;
};
