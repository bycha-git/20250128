import contentDisposition from "content-disposition";
import { NextApiRequest, NextApiResponse } from "next";
import { findChatbotDocumentFileAPIData } from "./chat-document-file-service";
import {
  getDocumentFileFromStore,
  parseDocumentFileParam,
} from "./chatbot-document-file";
import { GetDocumentFileFromBlobParam, GetDocumentFileParam } from "./models";
import { userSession } from "@/features/auth-page/helpers";
import {
  getDefaultAPIRouteBadRequestErrorResponse,
  getDefaultAPIRouteForbiddenErrorResponse,
  getDefaultAPIRouteNotFoundErrorResponse,
  getDefaultAPIRouteServerErrorResponse,
  getDefaultAPIRouteUnauthorizedErrorResponse,
} from "@/features/common/api-helpers";
import { checkAdmin } from "@/features/common/checkAdmin";
import { FindSelectAuthorityCompanyByID } from "@/features/common/services/authority-company-service";
import { FindSelectAuthorityEmployeeByID } from "@/features/common/services/authority-employee-service";
import { FindEmployeeByID } from "@/features/common/services/employee-service";

/** チャットボットのドキュメント (標準リンク) ファイル取得API */
export const chatbotDocumentAPIGETHandler = async (
  req: NextApiRequest,
  res: NextApiResponse,
): Promise<void> => {
  // パラメータ取得
  const urlPath = req.url;
  if (!urlPath) {
    return getDefaultAPIRouteBadRequestErrorResponse(res);
  }
  // パース
  const parsedParams = parseDocumentFileParam(urlPath);
  if (!parsedParams.success) {
    return getDefaultAPIRouteBadRequestErrorResponse(res);
  }
  const params = parsedParams.data;

  try {
    // 実行
    return await chatbotDocumentAPI(params, req, res);
  } catch (error) {
    console.error("chatbotDocumentAPI エラー:", error);
    return getDefaultAPIRouteServerErrorResponse(res);
  }
};

/** チャットボットのドキュメント (標準リンク) ファイル取得APIのロジック */
const chatbotDocumentAPI = async (
  params: GetDocumentFileParam,
  req: NextApiRequest,
  res: NextApiResponse,
): Promise<void> => {
  // ユーザーID取得
  const user = await userSession(req, res);
  if (!user) {
    return getDefaultAPIRouteUnauthorizedErrorResponse(res);
  }
  const userId = user.id;
  // 社員情報取得
  const employeeResponse = await FindEmployeeByID(userId);
  if (employeeResponse.status !== "OK") {
    console.error(
      "社員情報取得エラー: ",
      employeeResponse.errors?.[0]?.message,
    );
    return getDefaultAPIRouteServerErrorResponse(res);
  }
  const employee = employeeResponse.response!;

  // 管理者かどうか取得
  const adminResponse = await checkAdmin(employee);
  if (adminResponse.status !== "OK") {
    console.error("管理者チェックエラー");
    return getDefaultAPIRouteServerErrorResponse(res);
  }
  const isAdmin = adminResponse.admin;

  const [apiDataResponse, employeeAuthority, companyAuthority] =
    await Promise.all([
      // 各種データ
      findChatbotDocumentFileAPIData({
        chatbotId: params.chatbotId,
        documentId: params.documentId,
      }),
      // ユーザのチャットボット閲覧権限確認
      isAdmin
        ? Promise.resolve({
            status: "OK" as const,
          })
        : FindSelectAuthorityEmployeeByID(params.chatbotId, userId),
      // 組織のチャットボット閲覧権限確認
      isAdmin
        ? Promise.resolve({
            status: "OK" as const,
          })
        : FindSelectAuthorityCompanyByID(
            employee.department_code_8,
            params.chatbotId,
          ),
    ]);

  // OK でも NOT_FOUND でもない場合の確認は不要 (3つとも throw しているため)
  if (apiDataResponse.status === "NOT_FOUND") {
    // 組織/ユーザーともに権限なし
    return getDefaultAPIRouteNotFoundErrorResponse(
      res,
      "チャットボットまたはドキュメント",
    );
  }

  if (
    employeeAuthority.status === "NOT_FOUND" &&
    companyAuthority.status === "NOT_FOUND"
  ) {
    // 組織/ユーザーともに権限なし
    return getDefaultAPIRouteForbiddenErrorResponse(res);
  }

  const apiData = apiDataResponse.response;
  const chatbot = apiData.chatbot;
  const document = apiData.document;

  if (chatbot.id !== document.chatbotId) {
    console.error(
      "🔴 チャットボットドキュメント取得エラー: " +
        "chatbot.id !== document.chatbotId",
    );
    return getDefaultAPIRouteBadRequestErrorResponse(res);
  }

  if (!document.documentPath) {
    console.error(
      "🔴 チャットボットドキュメント取得エラー: " + "!document.documentPath",
    );
    return getDefaultAPIRouteServerErrorResponse(res);
  }

  const blobParam: GetDocumentFileFromBlobParam = {
    chatbotId: chatbot.id,
    documentPath: document.documentPath ?? "",
  };

  const fileResponse = await getDocumentFileFromStore(blobParam);

  if (fileResponse.status === "OK") {
    const fileResult = fileResponse.response;
    const stream: NodeJS.ReadableStream = fileResult.stream;

    // レスポンスヘッダーをセット
    // TODO: キャッシュ関係
    res.setHeader(
      "Content-Type",
      fileResult.contentType || "application/octet-stream",
    );
    if (fileResult.contentLength !== undefined) {
      res.setHeader("Content-Length", fileResult.contentLength.toString());
    }
    // ドキュメントは常にダウンロードされてほしいので type=attachment
    res.setHeader(
      "Content-Disposition",
      contentDisposition(document.documentName, {
        type: "attachment",
      }),
    );

    // ストリームをパイプしてレスポンスを返す
    stream.pipe(res);
  } else if (fileResponse.status === "NOT_FOUND") {
    return getDefaultAPIRouteNotFoundErrorResponse(res, "ファイル");
  } else {
    return getDefaultAPIRouteServerErrorResponse(res);
  }
};
