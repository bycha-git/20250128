import { z } from "zod";
import { ChatbotModel } from "@/features/common/model/history/chatbot-model";
import { DocumentModel } from "@/features/common/model/history/document-model";

export const GetDocumentFileParamSchema = z.object({
  /**
   * チャットボットID
   * - 初手で権限チェックとチャットボット存在チェックを行うため設定
   */
  chatbotId: z.string(),
  /** ドキュメントID */
  documentId: z.string(),
});

export type GetDocumentFileParam = z.infer<typeof GetDocumentFileParamSchema>;

export interface GetDocumentFileFromBlobParam {
  chatbotId: string;
  documentPath: string;
}

export interface ChatbotDocumentFileAPIData {
  chatbot: ChatbotModel;
  document: DocumentModel;
}
