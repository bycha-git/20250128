import { useEffect, useState } from "react";
import { showError } from "../globals/global-message-store";
import { Button } from "../ui/button";
import { useConfirm } from "../ui/confirm";
import { LoadingIndicator } from "../ui/loading";
import { useResponsive } from "../ui/responsive";
import {
  VerticalTabs,
  VerticalTabsContent,
  VerticalTabsList,
  VerticalTabsTrigger,
} from "../ui/VerticalTabs";
import AuthorityTab from "./AuthorityTab";
import BasicInfoTab from "./BasicInfoTab";
import {
  dispTalkStart,
  exclusionCheck,
  existenceCheck,
  getDocumentData,
  getTemplateAuthority,
  initializingNewModal,
  insChatBot,
  updChatBot,
} from "./CahtBotModal-service";
import { ChatBotModel, DocumentTabData } from "./Chatbot-model";
import { modelCheckForChatbot, referenceOpen } from "./Chatbot-service";
import { fetchIndexUpdate } from "./chatbot-services/index-update-api/index-update-api-client";
import {
  IndexUpdateAPIBlobList,
  IndexUpdateAPIContent,
} from "./chatbot-services/index-update-api/models";
import { ChatbotThreadNewWindow } from "./chatbot-thread-new-window";
import { useChatbotContext } from "./ChatbotContext";
import DocumentTab from "./DocumentTab";
import ParameterTab from "./ParameterTab";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { loadingOverlayStore } from "@/features/common/store/loading-overlay-store";
import { Window } from "@/features/ui/window";

interface ChatbotModalProps {
  closeModal: () => void;
  openModal: (id: string, mode: string) => void;
  initialize: () => void;
  chatbotData: ChatBotModel;
  mode: string;
  visible: boolean;
  talkStartVisible?: boolean;
}

export const ChatbotModal = ({
  closeModal,
  openModal,
  initialize,
  chatbotData,
  mode,
  visible,
  talkStartVisible = true,
}: ChatbotModalProps) => {
  const {
    chatbot,
    setChatbot,
    chunkSize,
    setChunkSize,
    authorityEmployeeInfo,
    setAuthorityEmployeeInfo,
    authorityCompanyInfo,
    setAuthorityCompanyInfo,
    initialAuthorityEmployeeInfo,
    setInitialAuthorityEmployeeInfo,
    initialAuthorityCompanyInfo,
    setInitialAuthorityCompanyInfo,
    openMode,
    setOpenMode,
    setAuthority,
    setAdminId,
    adminId,
    setModels,
    setDocumentTableData,
    documentTableData,
    isModalVisible,
    setIsModalVisible,
    setErrTabsContents,
    selectedChunkLabel,
    setSelectedChunkLabel,
  } = useChatbotContext();

  // ローディングフラグ
  const [isLoading, setIsLoading] = useState(true);
  // 確認ダイアログ
  const { confirm } = useConfirm();
  // モバイルフラグ
  const { isMobile } = useResponsive();
  // モバイル時の会話開始ボタン表示フラグ
  const [isMobileTalkStart, setIsMobileTalkStart] = useState(true);
  // エラーメッセージ
  const errMessage = useErrorMessage();
  //　タブごとのエラーアイコン表示
  const [errTabs, setErrTabs] = useState({
    basicInfo: false,
    document: false,
    parameter: false,
    authority: false,
  });

  // 選択中のタブ
  const [selectedTab, setSelectedTab] = useState("基本情報");

  // 会話開始画面が開かれているか
  const [windowOpen, setWindowOpen] = useState(false);
  // 会話開始画面に渡すパラメータ
  const [threadparams, setThreadParams] = useState({
    chatbotId: "",
    chatbotName: "",
    modelId: "",
  });

  // パラメータタブの初期状態
  const [parameterTabState, setParameterTabState] = useState({
    chunkSize: "",
    token: "",
    overlap: "",
  });

  // モーダルが開かれたときに初期表示を呼び出す
  useEffect(() => {
    initialization();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- 初期表示のため
  }, []);

  /** モーダル開き直し */
  const reOpen = () => {
    closeModal();
    openModal(chatbot.id, mode);
  };

  /** 一覧を初期化してモーダルを閉じる */
  const listRedraw = () => {
    initialize();
    closeModal();
  };
  /** 初期化処理 */
  const initialization = async () => {
    try {
      setIsModalVisible(visible);
      setOpenMode(mode);

      const initaliData = await initializingNewModal();
      setAuthority(initaliData?.dispData ?? []);

      setChunkSize(initaliData?.chunkSize.response ?? []);

      if (initaliData?.model.response) {
        setModels(initaliData.model.response);
      }

      const adminAuthority = initaliData?.dispData.find(
        (item) => item.label === "管理者",
      );
      // 管理者のIDを取得
      const adminPermissionId = adminAuthority?.id || "";
      setAdminId(adminPermissionId);

      // 新規作成
      if (mode == "新規") {
        const initialModel = initaliData?.model.response?.find(
          (model) => model.isInitialAtChatbot,
        );
        const initialId = initialModel?.id ?? "";
        const initialName = initialModel?.name ?? "";
        const chunkSizeId = initaliData?.chunkSize?.response?.[0]?.id ?? "";

        // チャットボットの初期状態を設定
        setChatbot((prevChatbot) => ({
          ...prevChatbot,
          token: "2000",
          overlap: "250",
          modelId: initialId,
          modelName: initialName,
          chunkSizeId: chunkSizeId,
        }));

        // ユーザーを管理者で登録
        setAuthorityEmployeeInfo([
          {
            id: initaliData?.userData.id,
            employeeName: initaliData?.userData.employeeName,
            permissionId: adminPermissionId,
            errFlg: false,
          },
        ]);
        // 各タブの初期値を設定
        setDocumentTableData([]);
      } else {
        // チャットボットに設定されている権限を取得
        const authoritys = await getTemplateAuthority(chatbot.id);
        // ドキュメントから現在設定されているファイル/フォルダを取得
        const documentData = await getDocumentData(chatbot.id);

        // パラメータタブの初期状態を取得
        setParameterTabState(() => ({
          chunkSize: chatbot.chunkSizeId,
          token: chatbot.token,
          overlap: chatbot.overlap,
        }));
        const initialLabel = chatbot.chunkSizeId
          ? initaliData?.chunkSize.response.find(
              (item) => item.id === chatbot.chunkSizeId,
            )?.label || ""
          : initaliData?.chunkSize.response[0]?.label || "";

        setSelectedChunkLabel(initialLabel);

        // ドキュメントにエラーがあるか
        const errorInDocumentData = documentData.some(
          (item) => item.document.isError,
        );
        setErrTabs((prev) => ({
          ...prev,
          document: errorInDocumentData,
        }));

        // 重複を避けて表示用データに設定
        setAuthorityEmployeeInfo((prev) => [
          ...prev.filter(
            (item) =>
              !authoritys?.usersData?.some((newItem) => newItem.id === item.id),
          ),
          ...(authoritys?.usersData ?? []),
        ]);
        setAuthorityCompanyInfo((prev) => [
          ...prev.filter(
            (item) =>
              !authoritys?.companyData?.some(
                (newItem) => newItem.id === item.id,
              ),
          ),
          ...(authoritys?.companyData ?? []),
        ]);

        // 初期データ保持（削除判定用）も重複を避けて設定
        setInitialAuthorityEmployeeInfo((prev) => [
          ...prev.filter(
            (item) =>
              !authoritys?.usersData?.some((newItem) => newItem.id === item.id),
          ),
          ...(authoritys?.usersData ?? []),
        ]);
        setInitialAuthorityCompanyInfo((prev) => [
          ...prev.filter(
            (item) =>
              !authoritys?.companyData?.some(
                (newItem) => newItem.id === item.id,
              ),
          ),
          ...(authoritys?.companyData ?? []),
        ]);
        setDocumentTableData((prev) => [
          ...prev.filter(
            (item) =>
              !documentData.some(
                (newItem) => newItem.document.id === item.document.id,
              ),
          ),
          ...documentData,
        ]);

        // ユーザー、組織存在チェック
        const users = (authoritys?.usersData ?? [])
          .map((item) => item.employeeName?.split(" ")[0])
          .filter((name): name is string => name !== undefined);

        const companies = (authoritys?.companyData ?? [])
          .map((item) => item.departmentName?.split(" ")[0])
          .filter((name): name is string => name !== undefined);

        const checkResult = await existenceCheck(users, companies);

        // 削除されたユーザーにエラーアイコンを表示
        if (checkResult.deletedUsers.length > 0) {
          setAuthorityEmployeeInfo((prev) =>
            prev.map((item) => {
              const userId = item.employeeName?.split(" ")[0] ?? "";
              if (checkResult.deletedUsers.includes(userId)) {
                return {
                  ...item,
                  errFlg: true,
                  errorMessageId: "ECHATBOT0014",
                };
              }
              return item;
            }),
          );
        }

        // 削除された組織にエラーアイコンを表示
        if (checkResult.deletedCompanies.length > 0) {
          setAuthorityCompanyInfo((prev) =>
            prev.map((item) => {
              const companyId = item.departmentName?.split(" ")[0] ?? "";
              if (checkResult.deletedCompanies.includes(companyId)) {
                return {
                  ...item,
                  errFlg: true,
                  errorMessageId: "ECHATBOT0013",
                };
              }
              return item;
            }),
          );
        }

        if (
          checkResult.deletedUsers.length > 0 ||
          checkResult.deletedCompanies.length > 0
        ) {
          setErrTabs((prev) => ({
            ...prev,
            authority: true,
          }));
        }

        // モバイル時に会話開始ボタン表示判定
        if (isMobile) {
          if (!talkStartVisible) {
            setIsMobileTalkStart(false);
          }
          // 表示チェック
          const authoritycheck = await dispTalkStart(chatbot.id);
          if (!authoritycheck) {
            setIsMobileTalkStart(false);
          }
        }
      }

      setIsLoading(false);
    } catch {
      showError(errMessage["ECOMMON0001"]);
    }
  };

  /** 登録ボタン押下処理 */
  const RegistClick = async () => {
    try {
      // 必須チェック
      const basicInfoError = chatbot.chatbotName.trim() === "";
      const descriptionError = chatbot.description.trim() === "";
      let overlapError = chatbot.overlap.trim() === "";
      let tokenError = chatbot.token.trim() === "";

      // チャンクサイズに選択よっては必須チェックなし
      if (selectedChunkLabel !== "トークン数で分割") {
        tokenError = false;
      }
      if (
        selectedChunkLabel === "ページ単位で分割" ||
        selectedChunkLabel === "章ごとに分割"
      ) {
        overlapError = false;
      }

      // 権限タブ管理者チェック
      const companyAdmin = authorityCompanyInfo.some(
        (info) => info.permissionId === adminId,
      );
      const employeeAdmin = authorityEmployeeInfo.some(
        (info) => info.permissionId === adminId,
      );
      const adminResult = companyAdmin || employeeAdmin;

      // 全体のエラー判定
      const hasErrors =
        basicInfoError ||
        descriptionError ||
        overlapError ||
        tokenError ||
        !adminResult;

      // エラー状態とエラーメッセージを一括設定
      setErrTabs((prev) => ({
        basicInfo: basicInfoError || descriptionError,
        parameter: overlapError || tokenError,
        authority: !adminResult,
        document: prev.document,
      }));

      setErrTabsContents({
        name: {
          err: basicInfoError,
          message: basicInfoError ? "ECHATBOT0004" : "",
        },
        description: {
          err: descriptionError,
          message: descriptionError ? "ECHATBOT0004" : "",
        },
        overlap: {
          err: overlapError,
          message: overlapError
            ? !chatbot.overlap
              ? "ECHATBOT0004"
              : "ECHATBOT0007"
            : "",
        },
        token: {
          err: tokenError,
          message: tokenError
            ? !chatbot.token
              ? "ECHATBOT0004"
              : "ECHATBOT0008"
            : "",
        },
        chunkSize: { err: false },
        model: { err: false },
      });

      if (adminResult) {
        // エラーがない場合エラーアイコンを削除
        setAuthorityCompanyInfo((prev) =>
          prev.map((item) => ({
            ...item,
            errFlg: false,
            errorMessageId: "",
          })),
        );

        setAuthorityEmployeeInfo((prev) =>
          prev.map((item) => ({
            ...item,
            errFlg: false,
            errorMessageId: "",
          })),
        );
      }

      // エラーがある場合は処理を中断
      if (hasErrors) {
        showError(errMessage["ECHATBOT0006"]);

        if (!adminResult) {
          // 組織の全データにエラーアイコンを表示
          setAuthorityCompanyInfo((prev) =>
            prev.map((item) => ({
              ...item,
              errFlg: true,
              errorMessageId: "ECHATBOT0005",
            })),
          );

          // ユーザーの全データにエラーアイコンを表示
          setAuthorityEmployeeInfo((prev) =>
            prev.map((item) => ({
              ...item,
              errFlg: true,
              errorMessageId: "ECHATBOT0005",
            })),
          );
        }
        return;
      }

      // 単独チェック
      if (!(Number(chatbot.overlap) > 0 && Number(chatbot.overlap) < 8193)) {
        setErrTabs((prev) => ({
          ...prev,
          parameter: true,
        }));
        setErrTabsContents((prev) => ({
          ...prev,
          overlap: { err: true, message: "ECHATBOT0007" },
        }));

        showError(errMessage["ECHATBOT0009"]);
        return;
      }

      if (selectedChunkLabel === "トークン数で分割") {
        if (!(Number(chatbot.token) > 0 && Number(chatbot.token) < 8193)) {
          setErrTabs((prev) => ({
            ...prev,
            parameter: true,
          }));
          setErrTabsContents((prev) => ({
            ...prev,
            token: { err: true, message: "ECHATBOT0008" },
          }));

          showError(errMessage["ECHATBOT0009"]);
          return;
        }
      }

      // 相関チェック
      if (selectedChunkLabel === "既定値（2000トークンごと）") {
        if (!(2000 > Number(chatbot.overlap))) {
          setErrTabs((prev) => ({
            ...prev,
            parameter: true,
          }));
          setErrTabsContents((prev) => ({
            ...prev,
            chunkSize: { err: true },
          }));
          showError(errMessage["ECHATBOT0009"]);
          return;
        }
      }

      if (selectedChunkLabel === "トークン数で分割") {
        if (!(Number(chatbot.token) > Number(chatbot.overlap))) {
          setErrTabs((prev) => ({
            ...prev,
            parameter: true,
          }));
          setErrTabsContents((prev) => ({
            ...prev,
            chunkSize: { err: true },
          }));
          showError(errMessage["ECHATBOT0009"]);
          return;
        }
      }

      // モーダルを一時的に非表示にする
      setIsModalVisible(false);

      // 確認ダイアログの表示
      const result = await confirm({
        text: (
          <>
            <strong>{chatbot.chatbotName}を登録します。</strong>
          </>
        ),
        title: "チャットボットを登録しますか？",
        okButtonText: "登録する",
        cancelButtonText: "キャンセルする",
      });

      if (result) {
        // 登録確認ダイアログ　登録ボタン押下
        loadingOverlayStore.startLoading();
        if (mode == "編集") {
          const checkResult = await exclusionCheck(
            chatbot.id,
            chatbot.lastUpdateAt,
          );
          if (!checkResult?.check) {
            if (checkResult?.errkind === "1") {
              // 存在チェックエラーの場合　モーダルを閉じる
              showError(errMessage[checkResult?.message]);
              listRedraw();
              return;
            } else {
              // 排他チェックエラーの場合　画面を開き直す
              showError(errMessage[checkResult?.message]);
              reOpen();
            }
            return;
          }
        }
        // モデル使用可否
        const modelUseCheck = await modelCheckForChatbot(chatbot.modelId);

        // ユーザー、組織存在チェック
        const users = authorityEmployeeInfo
          .map((item) => item.employeeName?.split(" ")[0])
          .filter((name): name is string => name !== undefined);
        const companies = authorityCompanyInfo
          .map((item) => item.departmentName?.split(" ")[0])
          .filter((name): name is string => name !== undefined);

        const checkResult = await existenceCheck(users, companies);

        // 削除されたユーザーにエラーアイコンを表示
        if (checkResult.deletedUsers.length > 0) {
          setAuthorityEmployeeInfo((prev) =>
            prev.map((item) => {
              const userId = item.employeeName?.split(" ")[0] ?? "";
              if (checkResult.deletedUsers.includes(userId)) {
                return {
                  ...item,
                  errFlg: true,
                  errorMessageId: "ECHATBOT0014",
                };
              }
              return item;
            }),
          );
        }

        // 削除された組織にエラーアイコンを表示
        if (checkResult.deletedCompanies.length > 0) {
          setAuthorityCompanyInfo((prev) =>
            prev.map((item) => {
              const companyId = item.departmentName?.split(" ")[0] ?? "";
              if (checkResult.deletedCompanies.includes(companyId)) {
                return {
                  ...item,
                  errFlg: true,
                  errorMessageId: "ECHATBOT0013",
                };
              }
              return item;
            }),
          );
        }

        if (!modelUseCheck.check) {
          setErrTabs((prev) => ({
            ...prev,
            basicInfo: true,
          }));
          setErrTabsContents((prev) => ({
            ...prev,
            model: { err: true },
          }));
        }

        // 削除されたデータがある場合、エラーを表示して登録処理を中断
        if (
          checkResult.deletedUsers.length > 0 ||
          checkResult.deletedCompanies.length > 0
        ) {
          showError(errMessage["ECHATBOT0017"]);
        }

        if (
          checkResult.deletedUsers.length > 0 ||
          checkResult.deletedCompanies.length > 0 ||
          !modelUseCheck.check
        ) {
          setIsModalVisible(true);
          return;
        }

        let chatbotId = "";
        /** upsert用にファイルの内容を消したドキュメントデータ */
        const documentTableDataForUpsertChatbot: DocumentTabData[] =
          documentTableData.map((data) => ({
            ...data,
            originalFile: undefined,
          }));

        // 登録 / 更新処理
        if (chatbotData.id !== "") {
          // 更新処理
          const deletedCompanyInfo = initialAuthorityCompanyInfo
            .filter(
              (initialItem) =>
                !authorityCompanyInfo.some(
                  (currentItem) => currentItem.id === initialItem.id,
                ),
            )
            .map((item) => item.id)
            .filter((id): id is string => id !== undefined);

          const deletedEmployeeInfo = initialAuthorityEmployeeInfo
            .filter(
              (initialItem) =>
                !authorityEmployeeInfo.some(
                  (currentItem) => currentItem.id === initialItem.id,
                ),
            )
            .map((item) => item.id)
            .filter((id): id is string => id !== undefined);

          await updChatBot(
            chatbot,
            authorityCompanyInfo,
            authorityEmployeeInfo,
            documentTableDataForUpsertChatbot,
            deletedCompanyInfo,
            deletedEmployeeInfo,
          );
          chatbotId = chatbot.id;
        } else {
          // 新規登録処理
          chatbotId =
            (await insChatBot(
              chatbot,
              authorityCompanyInfo,
              authorityEmployeeInfo,
              documentTableDataForUpsertChatbot,
            )) ?? "";
        }
        // パラメータタブが変更されたか判定
        const isModified = isParameterTabModified();
        if (documentTableData.length > 0 || isModified) {
          // AzureFunction (インデックス更新) のリクエストデータ作成

          // リクエストデータの準備
          const formData = new FormData();

          // documentInfoの追加
          const documentInfo = documentTableData
            .filter((item) => item.dispStatus !== "old")
            .map((item) => ({
              documentId: item.document.id,
              processType: item.dispStatus,
            }));

          const indexUpdateContent: IndexUpdateAPIContent = {
            chatbotId: chatbotId,
            documentInfo: documentInfo,
            isModified: isModified,
          };
          formData.append("content", JSON.stringify(indexUpdateContent));
          // 順番をファイルより手前にするため、先にセット
          formData.append("blobList", "");

          // ファイルデータの追加
          const blobList: IndexUpdateAPIBlobList = [];
          documentTableData.forEach((item) => {
            if (item.originalFile && item.blobFilePath !== undefined) {
              // ファイル名に通常使われない "/" が入っているので
              // 一応URLエンコードをかけておく
              blobList.push(item.blobFilePath);
              const key = encodeURIComponent(`blob:${item.blobFilePath}`);
              formData.append(key, item.originalFile);
            }
          });
          // 先にセットした　blobList を上書き
          formData.set("blobList", JSON.stringify(blobList));

          console.log("formData", [...formData.entries()]);
          try {
            // Azure Function へのリクエスト送信
            await fetchIndexUpdate({
              chatbotId,
              formData,
            });
            // レスポンスを特に処理しない場合、ここで終了
          } catch (error) {
            console.error("エラーが発生しました:", error);
            throw error;
          }
        }
        closeModal();
      } else {
        setIsModalVisible(true);
      }
    } catch (error) {
      showError(errMessage["ECOMMON0001"]);
    } finally {
      loadingOverlayStore.stopLoading();
    }
  };

  /** キャンセルボタン押下処理 */
  const cancelClick = async () => {
    // モーダルを一時的に非表示にする
    setIsModalVisible(false);
    // 必須チェック
    const result = await confirm({
      title: "登録をキャンセルします。よろしいですか？",
      okButtonText: "登録画面に戻る",
      cancelButtonText: "キャンセルする",
    });
    if (result) {
      // モーダルに戻る
      setIsModalVisible(true);
    } else {
      // モーダル画面を閉じる
      closeModal();
    }
  };

  /** 会話開始ボタン押下時 */
  const talkStartCheck = async () => {
    try {
      loadingOverlayStore.startLoading();
      // 存在権限チェック
      const checkResult = await referenceOpen(chatbot.id, false);
      if (checkResult?.check) {
        // モデル使用可否チェック
        const modelEnable = await modelCheckForChatbot(chatbot.modelId);
        if (modelEnable.check) {
          // 会話開始画面を開く
          setThreadParams({
            chatbotId: chatbot.id,
            chatbotName: chatbot.chatbotName,
            modelId: chatbot.modelId,
          });
          setWindowOpen(true);
        } else {
          // エラーメッセージを表示
          showError(errMessage[modelEnable?.message]);
          return;
        }
      } else {
        // エラーメッセージを表示
        showError(errMessage[checkResult?.message]);
        // 初期化処理
        return;
      }
    } catch (error) {
      showError(errMessage["ECOMMON0001"]);
    } finally {
      loadingOverlayStore.stopLoading();
    }
  };

  /** パラメータタブの値が変更されているか判定 */
  const isParameterTabModified = () => {
    // 新規作成の場合はtrue
    if (openMode === "新規") {
      return true;
    }

    const initialLabel = parameterTabState.chunkSize
      ? chunkSize.find((item) => item.id === parameterTabState.chunkSize)
          ?.label || ""
      : chunkSize[0]?.label || "";
    if (initialLabel !== selectedChunkLabel) {
      return true;
    }

    switch (selectedChunkLabel) {
      case "ページ単位で分割":
      case "章ごとに分割":
        return false;

      case "既定値（2000トークンごと）":
        return chatbot.overlap !== parameterTabState.overlap;
      case "トークン数で分割":
        return (
          chatbot.overlap !== parameterTabState.overlap ||
          chatbot.token !== parameterTabState.token
        );
      default:
        return false;
    }
  };

  return (
    isModalVisible && (
      <Window
        title={"チャットボット"}
        titleRightText={
          mode !== "新規" ? "最終更新者：" + chatbot.lastUpdateUser : ""
        }
        subTitle={
          isMobile && mode !== "新規"
            ? "最終更新者：" + chatbot.lastUpdateUser
            : ""
        }
        mobileFlg={isMobile}
        open={visible}
        showClose={false}
        onOpenChange={closeModal}
        primaryButtonText={mode === "参照" ? undefined : "登録する"}
        secondaryButtonText={
          isMobile && openMode === "参照"
            ? undefined
            : openMode !== "参照"
              ? "キャンセルする"
              : "閉じる"
        }
        onClickPrimary={mode === "参照" ? closeModal : RegistClick}
        onClickSecondary={mode === "参照" ? closeModal : cancelClick}
        className={
          isMobile
            ? "h-screen w-full gap-1 rounded-none p-2"
            : "h-[580px] w-[800px]"
        }
      >
        {isLoading ? (
          <div className="flex h-full w-full items-center justify-center">
            <LoadingIndicator isLoading={isLoading} />
          </div>
        ) : (
          <VerticalTabs
            value={selectedTab}
            onValueChange={(value) => setSelectedTab(value)}
            className={
              isMobile
                ? "flex h-full min-h-0 flex-col"
                : "flex h-full min-h-0 min-w-0"
            }
          >
            <VerticalTabsList
              className={
                isMobile
                  ? "mt-3 flex w-full flex-nowrap justify-start overflow-x-auto text-xs"
                  : "gap-1.2 w-[25.5%] text-black"
              }
            >
              <VerticalTabsTrigger
                value="基本情報"
                iconClass="i-material-symbols-settings-outline-rounded h-6 w-6"
                className={`${
                  isMobile ? "mr-2" : "mb-2"
                } flex items-center text-base ${
                  errTabs.basicInfo ? "bg-red-100" : ""
                } data-[state=active]:${errTabs.basicInfo ? "bg-red-100" : ""}`}
              >
                基本情報
                {errTabs.basicInfo && (
                  <span className="i-material-symbols-warning-outline-rounded ml-auto h-5 w-5 text-red-500"></span>
                )}
              </VerticalTabsTrigger>
              <VerticalTabsTrigger
                value="ドキュメント"
                iconClass="i-mdi-file-document-outline h-6 w-6"
                className={`${
                  isMobile ? "mr-2" : "mb-2"
                } flex items-center text-base ${
                  errTabs.document ? "bg-red-100" : ""
                } data-[state=active]:${errTabs.document ? "bg-red-100" : ""}`}
              >
                ドキュメント
                {errTabs.document && (
                  <span className="i-material-symbols-warning-outline-rounded ml-auto h-5 w-5 text-red-500"></span>
                )}
              </VerticalTabsTrigger>
              <VerticalTabsTrigger
                value="パラメーター"
                iconClass="i-material-symbols-display-settings-outline h-6 w-6"
                className={`${
                  isMobile ? "mr-2" : "mb-2"
                } flex items-center text-base ${
                  errTabs.parameter ? "bg-red-100" : ""
                } data-[state=active]:${errTabs.parameter ? "bg-red-100" : ""}`}
              >
                パラメーター
                {errTabs.parameter && (
                  <span className="i-material-symbols-warning-outline-rounded ml-auto h-5 w-5 text-red-500"></span>
                )}
              </VerticalTabsTrigger>
              <VerticalTabsTrigger
                value="権限"
                iconClass="i-tdesign-edit-2 h-6 w-6"
                className={`${
                  isMobile ? "mr-2" : "mb-2"
                } flex items-center text-base ${
                  errTabs.authority ? "bg-red-100" : ""
                } data-[state=active]:${errTabs.authority ? "bg-red-100" : ""}`}
              >
                権限
                {errTabs.authority && (
                  <span className="i-material-symbols-warning-outline-rounded ml-auto h-5 w-5 text-red-500"></span>
                )}
              </VerticalTabsTrigger>
            </VerticalTabsList>
            <div
              className={`${isMobile ? "my-2" : ""} flex h-full min-h-0 min-w-0 flex-1 flex-col`}
            >
              <VerticalTabsContent
                value="基本情報"
                border={false}
                className="h-full"
              >
                <BasicInfoTab />
              </VerticalTabsContent>
              <VerticalTabsContent
                value="ドキュメント"
                className="flex min-h-0 flex-1 px-2"
              >
                <DocumentTab />
              </VerticalTabsContent>
              <VerticalTabsContent
                value="パラメーター"
                border={false}
                className="h-full"
              >
                <ParameterTab />
              </VerticalTabsContent>
              <VerticalTabsContent
                value="権限"
                className="flex min-h-0 flex-1 px-2"
              >
                <AuthorityTab />
              </VerticalTabsContent>
            </div>

            {isMobile && openMode == "参照" && (
              <Button
                text="チャットボットと会話する"
                className={`mx-auto mt-3 ${isMobileTalkStart ? "visible" : "invisible"}`}
                onClick={() => {
                  talkStartCheck();
                }}
              />
            )}

            {/**会話開始画面 */}
            <ChatbotThreadNewWindow
              open={windowOpen}
              onOpenChange={setWindowOpen}
              chatbot={threadparams}
              clear={initialize}
            />
          </VerticalTabs>
        )}
      </Window>
    )
  );
};
