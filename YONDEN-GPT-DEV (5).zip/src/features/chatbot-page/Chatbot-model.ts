import { z } from "zod";
import { ChunkSizeModelSchema as CommonChunkSizeModelSchema } from "../common/model/config/chunk-size-model";
import { ModelModelSchema as CommonModelModelSchema } from "../common/model/config/model-model";
import { ChatbotModelSchema as CommonChatbotModelSchema } from "../common/model/history/chatbot-model";
import { DocumentModelSchema as CommonDocumentModelSchema } from "../common/model/history/document-model";

export const SEE_MORE_COUNT = 6;
export const SEE_TEMPLATE = 5;
export const MODAL_AUTHORITY_NEW = "新規";
export const MODAL_AUTHORITY_EDIT = "編集";
export const MODAL_AUTHORITY_REFERENCE = "参照";
export type ChatBotModel = z.infer<typeof ChatBotModelSchema>;
export type Model = z.infer<typeof ModelSchema>;
export type DocumentModel = z.infer<typeof DocumentSchema>;
export type ChunkSizeModel = z.infer<typeof ChunkSizeSchema>;

// 定数
export const VIEW_COUNT = 20;

/** 権限タブ.ユーザータブ管理 */
export interface AuthorityEmployeeInfo {
  id: string | undefined;
  employeeName: string | undefined;
  permissionId: string | undefined;
  errFlg: boolean;
  errorMessageId?: string;
}

/** 権限タブ.組織タブ管理 */
export interface AuthorityCompanyInfo {
  id: string | undefined;
  departmentName: string | undefined;
  permissionId: string | undefined;
  errFlg: boolean;
  errorMessageId?: string;
}

/** ドキュメントタブ管理 */
export interface DocumentTabData {
  document: DocumentModel;
  folderFlg: boolean;
  dispStatus: "add" | "update" | "delete" | "name_change" | "old";
  selectFlg: boolean;
  /** アップロードするファイル */
  originalFile?: File;
  /** BlobStorage 上のパス。 originalFile をセットする際同時に指定する */
  blobFilePath?: string;
  /** 標準リンクAPIのURL */
  standardLinkApiUrl?: string | undefined;
}

/** 権限プルダウン用 */
export interface AuthorityKind {
  id: string;
  label: string;
}
/** tabごとのエラー表示 */
export interface ErrTab {
  basicInfo: boolean;
  document: boolean;
}

/**
 * チャットボットモデル
 */
export const ChatBotModelSchema = CommonChatbotModelSchema;

/**
 * モデル
 */
export const ModelSchema = CommonModelModelSchema;

/**
 * チャンクサイズ
 */
export const ChunkSizeSchema = CommonChunkSizeModelSchema;

/**
 * ドキュメント
 */
export const DocumentSchema = CommonDocumentModelSchema;
