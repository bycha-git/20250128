import React, { useEffect, useState } from "react";
import { showError } from "../globals/global-message-store";
import { Button } from "../ui/button";
import ComboBox from "../ui/combbox";
import { cn } from "../ui/lib";
import { useResponsive } from "../ui/responsive";
import { Separator } from "../ui/separator";
import { useChatbotContext } from "./ChatbotContext";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { Input } from "@/features/ui/input";
import { Label } from "@/features/ui/label";
import { Textarea } from "@/features/ui/textarea";

const BasicInfoTab: React.FC = () => {
  const { chatbot, setChatbot, models, openMode, errTabsContents } =
    useChatbotContext();

  const [selectModelName, setSelectModelName] = useState<string>("");

  // モバイルフラグ
  const { isMobile } = useResponsive();
  // エラーメッセージ
  const errMessage = useErrorMessage();

  // 初期表示の設定
  useEffect(() => {
    let initialLabel;
    if (openMode == "新規") {
      initialLabel = models[0]?.name || "";
    } else {
      initialLabel =
        models.find((item) => item.id === chatbot.modelId)?.name || "";
    }
    setSelectModelName(initialLabel);
  }, [chatbot.modelId, models]);

  return (
    <div className="flex h-full w-full flex-col gap-2">
      <div className={cn("mb-2 flex gap-2", isMobile ? "flex-col" : "")}>
        <Label
          htmlFor="名前"
          className="mt-3 flex items-center whitespace-nowrap pr-3 md:mt-0 md:text-base"
        >
          名前
          <span
            className={`i-material-symbols-asterisk-rounded ml-1 h-3 w-3 bg-red-600 ${
              isMobile || openMode == "参照" ? "invisible" : "visible"
            }`}
          />
          <Button
            icon="i-material-symbols-warning-outline-rounded text-red-500 h-4 w-4"
            variant="icon"
            className={`ml-1 flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1 ${
              errTabsContents.name.err ? "visible" : "invisible"
            }`}
            onClick={() => showError(errMessage["ECHATBOT0004"])}
          />
        </Label>
        <Input
          className="md: box-border w-full border border-gray-300 p-2 md:ml-auto md:w-[97%]"
          placeholder="チャットボットの名前を記入してください"
          onInputText={(e) =>
            setChatbot({
              ...chatbot,
              chatbotName: e,
            })
          }
          value={chatbot.chatbotName}
          disabled={openMode === "参照"}
          maxLength={50}
        />
      </div>
      {!isMobile && <Separator />}

      <div
        className={cn(
          "my-2 flex gap-2",
          isMobile ? "h-[40%] flex-col" : "h-full",
        )}
      >
        <Label
          htmlFor="description"
          className="flex whitespace-nowrap pr-3 md:text-base"
        >
          説明文
          <span
            className={`i-material-symbols-asterisk-rounded ml-1 h-3 w-3 items-center bg-red-600 ${
              isMobile || openMode == "参照" ? "invisible" : "visible"
            }`}
          />
          <Button
            icon="i-material-symbols-warning-outline-rounded text-red-500 h-5 w-5"
            variant="icon"
            className={`ml-1 flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1 ${
              errTabsContents.description.err ? "visible" : "invisible"
            }`}
            onClick={() => showError(errMessage["ECHATBOT0004"])}
          />
        </Label>
        <Textarea
          className="box-border h-full w-full border border-gray-300 p-2 md:ml-auto md:h-full"
          placeholder="チャットボットの説明を記入してください"
          onInputText={(e) =>
            setChatbot({
              ...chatbot,
              description: e,
            })
          }
          value={chatbot.description}
          disabled={openMode === "参照"}
          maxLength={500}
        />
      </div>
      {!isMobile && <Separator />}
      <div className={cn("flex", isMobile ? "flex-col gap-2" : "")}>
        <Label
          htmlFor="description"
          className="flex items-center whitespace-nowrap pr-3 md:text-base"
        >
          指定するモデル
          {errTabsContents.model.err ? (
            <Button
              icon="i-material-symbols-warning-outline-rounded text-red-500 h-5 w-5"
              variant="icon"
              className="ml-1 flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1"
              onClick={() => errMessage["ECHATBOT0003"]}
            />
          ) : (
            <div className="h-4 w-4" />
          )}
        </Label>
        <ComboBox
          items={models}
          idField={"id"}
          textField={"name"}
          className={cn("text-sm", isMobile ? "w-[50%]" : "ml-auto")}
          onSelectId={(id) => {
            setChatbot((prevChatbot) => ({
              ...prevChatbot,
              modelId: id,
            }));
          }}
          onSelectText={(name) => {
            setChatbot((prevChatbot) => ({
              ...prevChatbot,
              modelName: name,
            }));
          }}
          selectedItem={selectModelName}
          disabled={openMode === "参照"}
          maxDisplayLength={15}
        />
      </div>
    </div>
  );
};

export default BasicInfoTab;
