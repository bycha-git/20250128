"use client";
import { FC, useState } from "react";
import { showError, showSuccess } from "../globals/global-message-store";
import { Button } from "../ui/button";
import { CheckboxWithLabel } from "../ui/checkbox-with-label";
import { useConfirm } from "../ui/confirm";
import { ConfirmWindow } from "../ui/confirm-window";
import { HtmlPreview } from "../ui/html-preview";
import { Input } from "../ui/input";
import { ForDesktop, ForMobile, useResponsive } from "../ui/responsive";
import { Window } from "../ui/window";
import {
  CreateTestData,
  DeleteTestData,
} from "./db-test-services/db-test-service";

// interface TestPageProps {
// }

export const TestPage: FC = () => {
  const [deleteId, setDeleteId] = useState<string>("");
  const [checked, setChecked] = useState<boolean>(false);

  const [open, setOpen] = useState<boolean>(false);
  // ウィンドウ状態表示 (動作の例示用)
  const [windowState, setWindowState] = useState<
    "open" | "close" | "cancel" | "ok" | "ok2" | "cancel2"
  >("close");

  const [confirmOpen, setConfirmOpen] = useState<boolean>(false);
  const [confirmState, setConfirmState] = useState<"ok" | "cancel">();

  /** 作成 */
  const createData = async () => {
    const result = await CreateTestData();
    console.log(result);
  };

  /** 削除 */
  const deleteData = async () => {
    console.log(`deleteId: "${deleteId}"`);
    const result = await DeleteTestData(deleteId);
    console.log(result);
  };

  /** 確認ウィンドウ表示 簡易呼び出しの実行 */
  const runConfirm = async () => {
    await runConfirm1();
    await runConfirm2();
    runConfirm3();
  };

  // confirm 関数を取得 (必須)
  const { confirm } = useConfirm();

  /** 確認ウィンドウ表示 簡易呼び出し */
  const runConfirm1 = async () => {
    const result = await confirm({
      // 本文。TSXで装飾も可能 (長めの装飾であれば ConfirmWindow を直接使った方がよい)
      text: (
        <>
          <strong>追加</strong>しますか？
        </>
      ),

      // ConfirmWindow と同様のオプションが使用可能 (使用しないことも可能)
      title: "確認",
      okButtonText: "OK!",
    });
    if (result) {
      showSuccess({
        title: "",
        description: "追加しました",
      });
    } else {
      showError("追加がキャンセルされました");
    }
  };

  /** 確認ウィンドウ表示 簡易呼び出し2 */
  const runConfirm2 = async () => {
    // 本文のみであれば、よりシンプルな書き方も可能
    const result = await confirm("削除しますか？");
    if (result) {
      showSuccess({
        title: "",
        description: "削除しました",
      });
    } else {
      showError("削除がキャンセルされました");
    }
  };

  /** 確認ウィンドウ表示 簡易呼び出し3 */
  const runConfirm3 = () => {
    // async 関数内でない場合の呼び方 (Promise の仕様を利用)
    confirm("○○しますか？").then((result) => {
      if (result) {
        showSuccess({
          title: "",
          description: "○○しました",
        });
      } else {
        showError("○○がキャンセルされました");
      }
    });

    // この呼び方の場合、確認を待たずに以下の処理が実行されることに注意
    console.log("以下の処理");
  };

  return (
    <main className="flex flex-1 flex-col gap-3 p-3">
      <div className="flex">
        <Button onClick={() => createData()}>作成</Button>
      </div>
      <div className="flex">
        ID:
        <Input
          placeholder="削除するID"
          value={deleteId}
          onChange={(e) => setDeleteId(e.target.value)}
        />
        <Button onClick={() => deleteData()}>削除</Button>
      </div>
      <div className="flex">
        <Button
          onClick={() => {
            console.log("エラー表示");
            showError("エラーが発生しました", () => {
              console.log("再読み込み");
            });
          }}
        >
          エラー表示
        </Button>
      </div>

      {/* チェックボックス */}
      <div className="flex">
        <CheckboxWithLabel
          label="チェックボックス"
          checked={checked}
          onCheckedChange={(e) => setChecked(e)}
        />
      </div>

      {/* 通常ウィンドウ */}
      <div className="flex">
        <Button
          onClick={() => {
            setWindowState("open");
            setOpen(true);
          }}
        >
          ウィンドウ表示
        </Button>
        <Window
          title={"汎用ウィンドウ"}
          titleRightText="右テキスト"
          open={open}
          onOpenChange={(open) => {
            if (open && windowState !== "open") {
              setWindowState("open");
            }
            if (!open && windowState === "open") {
              // ここで return すると、ボタン以外でウィンドウを閉じさせないことが出来る
              // 方法が分かりづらいので要検討かも
              // return;

              setWindowState("close");
            }
            setOpen(open);
          }}
          // 空文字または省略した場合、ボタン自体を表示しない
          primaryButtonText={"保存"}
          secondaryButtonText={"キャンセル"}
          onClickPrimary={() => {
            setWindowState("ok");
            setOpen(false);
          }}
          onClickSecondary={() => {
            setWindowState("cancel");
            setOpen(false);
          }}
          // ボタンを増やした
          primary2ButtonText={"保存2"}
          secondary2ButtonText={"キャンセル2"}
          onClickPrimary2={() => {
            setWindowState("ok2");
            setOpen(false);
          }}
          onClickSecondary2={() => {
            setWindowState("cancel2");
            setOpen(false);
          }}
          // ウィンドウサイズ設定例
          className="w-full max-w-lg"
        >
          <p>
            汎用ウィンドウです。
            <br />
            下のボタンは、置くことも置かないこともできます。
          </p>
          <p>ウィンドウサイズは、 className を用いて各自で調整してください。</p>
        </Window>
        <div>ウィンドウ状態: {windowState}</div>
      </div>

      {/* 確認ウィンドウ */}
      <div className="flex">
        <Button
          onClick={() => {
            setConfirmState(undefined);
            setConfirmOpen(true);
          }}
        >
          確認ウィンドウ表示
        </Button>
        <ConfirmWindow
          title={"削除しますか？"}
          open={confirmOpen}
          onOpenChange={setConfirmOpen}
          okButtonText={"削除"}
          // cancelButtonText={"キャンセル"}
          onClickOk={() => {
            showSuccess({
              title: "削除完了",
              description: "削除しました",
            });
            setConfirmState("ok");
          }}
          onClickCancel={() => {
            showError("キャンセルされました");
            setConfirmState("cancel");
          }}
        >
          削除を押すと、削除されます。
          <br />
          (テスト文章なので、削除されません)
        </ConfirmWindow>
        <div>結果: {confirmState}</div>
      </div>

      {/* 確認ウィンドウ (簡易呼び出し2) */}
      <div className="flex">
        <Button onClick={runConfirm}>
          確認ウィンドウ表示 (`await confirm()`)
        </Button>
      </div>

      {/* HTML プレビュー */}
      <div className="flex">
        <HtmlPreview
          stylingHtml={`
            <style>html { background-color: orange; color: white }</style>
          `}
          htmlValue={"<h1>HTML プレビュー</h1><p>プレビューです</p>"}
          className="border border-gray-03"
        />
      </div>

      <ResponsiveTest />
    </main>
  );
};

const ResponsiveTest = () => {
  const { isDesktop, isMobile } = useResponsive();
  return (
    <fieldset className="flex flex-col gap-2 rounded-lg border border-black p-2">
      <legend className="mx-2 px-1 text-lg">レスポンシブ テスト</legend>
      <div className="flex flex-col gap-2 border border-gray-400 p-2 md:flex-row">
        <div className="border border-gray-400">tailwindのクラスのみで</div>
        <div className="border border-gray-400">縦横を切替</div>
      </div>
      <div>
        <div className="hidden md:block">
          tailwindのクラスのみで表示切替 (PCのみ表示)
        </div>
        <div className="md:hidden">
          tailwindのクラスのみで表示切替 (モバイルのみ表示)
        </div>
      </div>
      <div>
        <div>
          isDesktop:{" "}
          <span className={isDesktop ? "font-bold" : ""}>
            {isDesktop.toString()}
          </span>
        </div>
        <div>
          isMobile:{" "}
          <span className={isMobile ? "font-bold" : ""}>
            {isMobile.toString()}
          </span>
        </div>
      </div>
      <ForDesktop>
        <div>PCサイズでのみ表示されてる領域</div>
      </ForDesktop>
      <ForMobile>
        <div>モバイルサイズでのみ表示されてる領域</div>
      </ForMobile>
    </fieldset>
  );
};
