"use server";
import "server-only";
import { TEST_DATA, TestDataModel } from "./model";
import { userHashedId } from "@/features/auth-page/helpers";
import { ServerActionResponse } from "@/features/common/server-action-response";
import { ConfigContainer } from "@/features/common/services/cosmos";
import { uniqueId } from "@/features/common/util";

/** TestDataを挿入 */
export const CreateTestData = async (): Promise<
  ServerActionResponse<TestDataModel>
> => {
  const userId = await userHashedId();
  const modelToSave: TestDataModel = {
    id: uniqueId(),
    type: TEST_DATA,
    name: "yeahThread",
    userId: userId,
    tags: [
      {
        tagId: "A",
        name: "yeahTag1",
      },
      {
        tagId: "B",
        name: "yeahTag2",
      },
    ],
  };
  return await UpsertTestData(modelToSave);
};

export const UpsertTestData = async (
  testModel: TestDataModel,
): Promise<ServerActionResponse<TestDataModel>> => {
  try {
    const modelToSave: TestDataModel = {
      ...testModel,
      // id: uniqueId(),
      // createdAt: new Date(),
      // type: MESSAGE_ATTRIBUTE,
      // isDeleted: false,
    };

    const { resource } =
      await ConfigContainer().items.upsert<TestDataModel>(modelToSave);

    if (resource) {
      return {
        status: "OK",
        response: resource,
      };
    }

    return {
      status: "ERROR",
      errors: [
        {
          message: `Chat message not found`,
        },
      ],
    };
  } catch (e) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `${e}`,
        },
      ],
    };
  }
};

export const DeleteTestData = async (
  testId: string,
): Promise<ServerActionResponse<void>> => {
  const userId = await userHashedId();
  try {
    // item() で1つのアイテムを指定する際、2引数目のパーティションキーは必須そう
    // 読み込む
    const data = await ConfigContainer()
      .item(testId, userId)
      .read<TestDataModel>();
    console.log("data: ", data);
    // 削除
    const response = await ConfigContainer()
      .item(testId, userId)
      .delete<TestDataModel>();
    if (response) {
      return {
        status: "OK",
        response: undefined,
      };
    }
    return {
      status: "ERROR",
      errors: [{ message: `Test data not found` }],
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};
