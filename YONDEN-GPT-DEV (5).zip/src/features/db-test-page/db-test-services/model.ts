export const TEST_DATA = "test_data";

export interface TestDataModel {
  id: string;
  type: typeof TEST_DATA;
  name: string;
  tags: Array<TagModel>;
  userId: string;
}

export interface TagModel {
  tagId: string;
  name: string;
}
