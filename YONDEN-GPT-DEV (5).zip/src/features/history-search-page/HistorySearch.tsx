"use client";

import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  HISTORY_SEARCH_VIEW_COUNT,
  HistorySearchMessage,
} from "./History-model";
import {
  FindChatbots,
  findHistory,
  FindMessage,
  FindModels,
  GetMessageCount,
} from "./History-service";
import { MessageArea } from "./MessageArea";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { ChatList } from "@/features/chat-menu/chat-list";
import { ChatListItemProps } from "@/features/chat-menu/chat-list-item";
import { ThreadModel } from "@/features/common/model/history/thread-model";
import { showError } from "@/features/globals/global-message-store";
import { Button } from "@/features/ui/button";
import CheckedCombBox from "@/features/ui/CheckedCombBox";
import { Input } from "@/features/ui/input";
import { ScrollArea } from "@/features/ui/scroll-area";
import SearchCheckedCombBox from "@/features/ui/SearchCheckedCombBox";
import { Separator } from "@/features/ui/separator";

interface FilterItem {
  id: string;
  name?: string;
  chatbotName?: string;
}
export const HistorySearch = () => {
  // ステートの定義
  // 検索inputに入力されている文字列
  const [searchText, setSearchText] = useState<string>("");
  // モデルリスト
  const [modelList, setModelList] = useState<FilterItem[]>([]);
  // チェックされているモデル
  const [selectModel, setSelectModel] = useState<FilterItem[]>([]);
  // モデルフィルタ
  const modelFilter = useMemo(
    () => selectModel.map((item) => item.id),
    [selectModel],
  );
  // プルダウンの検索結果(チャットボットリスト)
  const [chatBotSearchResults, setChatBotSearchResults] = useState<
    FilterItem[]
  >([]);
  // チェックされているチャットボット
  const [selectChatBot, setSelectChatBot] = useState<FilterItem[]>([]);
  // チャットボットフィルタ
  const chatbotFilter = useMemo(
    () => selectChatBot.map((item) => item.id),
    [selectChatBot],
  );
  // 取得メッセージ一覧
  const [messages, setMessages] = useState<HistorySearchMessage[]>([]);
  // スレッド一覧
  const [threadList, setThreadList] = useState<ChatListItemProps[]>([]);
  // 選択中のスレッドID
  const [selectThreadId, setSelectThreadId] = useState<string>("");
  // 検索フラグ
  const [searchFlag, setSeachFlag] = useState<boolean>(false);
  // メッセージ表示数
  const [viewCount, setViewCount] = useState(HISTORY_SEARCH_VIEW_COUNT);
  // エラーメッセージ
  const errMessage = useErrorMessage();

  // メッセージ総件数
  const totalMessageCount = useRef(0);

  // フィルターが一つでもonになっているか
  const isFilterChecked = selectModel.length > 0 || selectChatBot.length > 0;

  // フィルターをクリアする関数
  const clearFilters = () => {
    setSelectModel([]);
    setSelectChatBot([]);
  };

  // 選択された項目を一つにまとめる
  const selectedItems = [
    ...selectModel.map((item) => ({ type: "model", value: item })),
    ...selectChatBot.map((item) => ({ type: "chatbot", value: item })),
  ];

  // 選択項目を削除する
  const removeSelectedItem = (type: string, value: string) => {
    if (type === "model") {
      setSelectModel((prev) => prev.filter((item) => item.id !== value));
    } else if (type === "chatbot") {
      setSelectChatBot((prev) => prev.filter((item) => item.id !== value));
    }
  };

  // チャットボットリストの検索処理
  const chatBotSearch = async (query: string, searchLimit: number) => {
    try {
      if (!query) return setChatBotSearchResults([]);
      const chatbots = await FindChatbots(query, searchLimit);
      setChatBotSearchResults(chatbots.response || []);
    } catch (error) {
      showError(errMessage["ECOMMON0001"]);
    }
  };

  // スレッド一覧検索処理
  const handleHistorySearch = useCallback(
    async (
      query?: string,
      modelFilter?: string[],
      chatbotFilter?: string[],
    ) => {
      try {
        if (!query) return;
        if (!searchFlag) setSeachFlag(!searchFlag);
        if (selectThreadId) setSelectThreadId("");
        setViewCount(HISTORY_SEARCH_VIEW_COUNT);

        // メッセージ件数を取得する
        const messageCount = await GetMessageCount(
          query,
          modelFilter,
          chatbotFilter,
        );

        totalMessageCount.current = messageCount.response ?? 0;

        const history = await findHistory(query, modelFilter, chatbotFilter);

        setThreadList(history.response || []);
      } catch (error) {
        showError(errMessage["ECOMMON0001"]);
      }
    },
    [searchFlag, selectThreadId],
  );

  // クリアボタン押下時の処理
  const handleClear = () => {
    if (searchFlag) setSeachFlag(!searchFlag);
    setMessages([]);
    setThreadList([]);
  };

  // スレッド選択時の処理
  const selectThread = (
    item: ThreadModel,
    _: React.MouseEvent<HTMLElement, MouseEvent>,
  ) => {
    setViewCount(HISTORY_SEARCH_VIEW_COUNT);
    if (selectThreadId == item.id) {
      setSelectThreadId("");
      const newThreadList = threadList.map((thread) => {
        return { item: { ...thread.item }, active: false };
      });
      setThreadList(newThreadList);
    } else {
      setSelectThreadId(item.id);
      const newThreadList = threadList.map((thread) => {
        return { item: { ...thread.item }, active: thread.item.id == item.id };
      });
      setThreadList(newThreadList);
    }
  };

  // 初期表示時にモデルリストを取得
  useEffect(() => {
    const getModels = async () => {
      try {
        const models = await FindModels();

        setModelList(models.response || []);
      } catch (error) {
        showError(errMessage["ECOMMON0001"]);
      }
    };
    getModels();
  }, []);

  // 検索フラグがtrueの間はフィルタが変更されるたびに全体の再検索を実行する
  useEffect(() => {
    if (searchFlag) {
      handleHistorySearch(searchText, modelFilter, chatbotFilter);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chatbotFilter, modelFilter]);

  // メッセージ一覧検索処理
  useEffect(() => {
    const getMessage = async (
      searchText: string,
      threadId: string,
      limit: number,
    ) => {
      try {
        // メッセージ件数を取得する
        const messageCount = await GetMessageCount(
          searchText,
          modelFilter,
          chatbotFilter,
          selectThreadId,
        );

        totalMessageCount.current = messageCount.response ?? 0;

        const messages = await FindMessage(
          searchText,
          modelFilter,
          chatbotFilter,
          threadId,
          limit,
        );

        setMessages(messages.response || []);
      } catch (error) {
        showError(errMessage["ECOMMON0001"]);
      }
    };
    if (searchText && threadList)
      getMessage(searchText, selectThreadId, viewCount);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewCount, selectThreadId, threadList]);

  return (
    <div className="flex w-full justify-center bg-white">
      <div className="flex h-full w-full">
        {/* サイドバー */}
        <ScrollArea className="h-full w-[17rem] min-w-60 max-w-[30vw]">
          <aside className="h-full bg-gray-01">
            <ChatList listItems={threadList} onListItemClick={selectThread} />
          </aside>
        </ScrollArea>

        <div className="flex flex-1 flex-col">
          <div className="flex flex-1 flex-col p-5">
            {/* 検索ワード入力 */}
            <div className="flex w-full items-start gap-4 bg-white px-11 pb-5">
              <Input
                placeholder="検索ワードを入力してください。"
                className="h-12 w-full"
                size={1000}
                removeIcon="i-material-symbols-close-small-rounded h-8 w-8"
                serchIcon="i-material-symbols-search-rounded h-8 w-8"
                onSearch={() => {
                  handleHistorySearch(searchText, modelFilter, chatbotFilter);
                }}
                onClear={handleClear}
                text={searchText}
                onInputText={(value) => setSearchText(value)}
                // maxLength={50}
              />
            </div>

            {/* フィルター */}
            <div className="flex items-center px-11">
              <div className="flex items-center text-2xl">
                <span className="i-material-symbols-filter-list-rounded pr-1"></span>
                フィルター
              </div>
            </div>

            {/* コンボボックス */}
            <div className="mt-4 flex items-center gap-4 px-11">
              {/* モデルリストのチェックボックス */}
              <CheckedCombBox
                items={modelList}
                selectedItems={selectModel}
                onSelectItem={(item) => setSelectModel(item)}
                placeholder="モデル名を選択してください。"
                idField="id"
                textField="name"
                className="w-80"
              />

              {/* チャットボットリストの検索機能付きチェックボックス */}
              <SearchCheckedCombBox
                selectedItems={selectChatBot}
                onSelectItem={(item) => setSelectChatBot(item)}
                placeholder="チャットボットを選択してください。"
                searchResults={chatBotSearchResults}
                onSearch={chatBotSearch}
                idField="id"
                textField="chatbotName"
                icon="i-material-symbols-search-rounded h-5 w-5"
                className="w-[325px]"
                maxLength={50}
                noResultText="該当チャットボットなし"
                initialSearchLimit={HISTORY_SEARCH_VIEW_COUNT}
              />

              {/* フィルターをクリア */}
              {isFilterChecked && (
                <div className="ml-4">
                  <Button
                    variant="link"
                    className="p-0 text-blue-500 underline"
                    onClick={(e) => {
                      e.preventDefault();
                      clearFilters();
                    }}
                  >
                    フィルターをクリア
                  </Button>
                </div>
              )}
            </div>

            {/* 選択された項目を表示 */}
            <ScrollArea className="h-28 overflow-y-auto">
              {selectedItems.length > 0 && (
                <div className="mt-4 flex flex-wrap items-center gap-2 px-11">
                  {selectedItems.map((item, index) => (
                    <span
                      key={`selected-${index}`}
                      className="flex items-center rounded bg-gray-200 px-2 py-1 text-sm"
                    >
                      {item.value.name || item.value.chatbotName}
                      <Button
                        variant="ghost"
                        size="sm"
                        className="ml-1 p-0 text-gray-500 hover:text-gray-700"
                        onClick={() =>
                          removeSelectedItem(item.type, item.value.id)
                        }
                      >
                        ×
                      </Button>
                    </span>
                  ))}
                </div>
              )}
            </ScrollArea>
            <div className="flex h-6 w-full justify-end px-10">
              {searchFlag && (
                <span>
                  検索結果：
                  {totalMessageCount.current}件
                </span>
              )}
            </div>
            <Separator />
          </div>
          {/* メッセージ一覧 */}
          <ScrollArea className="h-full overflow-y-auto">
            <MessageArea
              messages={messages}
              viewCount={viewCount}
              setViewCount={setViewCount}
            />
          </ScrollArea>
        </div>
      </div>
    </div>
  );
};
