"use server";

import { SqlQuerySpec } from "@azure/cosmos";
import { findAttachmentsAndMergeByMessagesForCurrentUser } from "../chat-view/chat-services/attachment/chat-attachment-service";
import { MessageModel } from "../common/model/history/message-model";
import {
  HISTORY_SEARCH_VIEW_COUNT,
  HistorySearchMessage,
} from "./History-model";
import { userHashedId } from "@/features/auth-page/helpers";
import { ThreadModel } from "@/features/common/model/history/thread-model";
import {
  ConfigContainer,
  HistoryContainer,
} from "@/features/common/services/cosmos";

/**
 * メッセージ、スレッド検索
 * @param searchText 検索条件
 * @param modelList モデルIDリスト
 * @param chatbotList チャットボットIDリスト
 * @returns 結果:OK or ERROR
 */
export const findHistory = async (
  searchText: string,
  modelList: string[] = [],
  chatbotList: string[] = [],
) => {
  try {
    // スレッド一覧取得
    const threads = await FindThread(searchText, modelList, chatbotList);
    if (threads.status !== "OK") return { ...threads };

    // メッセージ一覧取得
    const messages = await FindMessage(searchText, modelList, chatbotList);
    if (messages.status !== "OK") return { ...messages };
    // スレッド一覧をマージ
    const threadList = [
      ...(threads.response || []),
      ...(messages.threadList?.filter((thread) => {
        return !threads.response?.map((t) => t.id).includes(thread.id);
      }) || []),
    ].map((thread) => {
      return { item: thread };
    });
    return {
      status: "OK",
      response: threadList,
    };
  } catch (error) {
    throw error;
  }
};
/**
 * スレッド検索処理
 * @param searchText 検索ワード
 * @param modelList モデルフィルター
 * @param chatbotList チャットボットフィルター
 * @param ids スレッドIDリスト
 * @returns 結果:OK or ERROR
 */
const FindThread = async (
  searchText: string = "",
  modelList: string[] = [],
  chatbotList: string[] = [],
  ids: string[] = [],
) => {
  try {
    // 検索単語リスト
    const serchTextList = searchText
      .split(/\s/)
      .map((text) => `UPPER(r.name) LIKE UPPER('%${text}%') `);
    const where = "AND " + serchTextList.join("\nAND ");
    // モデルフィルター
    const modelFilter = modelList.length
      ? `r.modelId IN ("${modelList.join('","')}")`
      : "";
    // チャットボットフィルター
    const chatbotFilter = chatbotList.length
      ? `r.chatbotId IN ("${chatbotList.join('","')}")`
      : "";
    const filterQuery =
      modelFilter && chatbotFilter
        ? `AND (${modelFilter} OR ${chatbotFilter})`
        : modelFilter || chatbotFilter
          ? "AND " + modelFilter + chatbotFilter
          : "";
    // ID
    const idCondition = ids.length ? `AND r.id IN ("${ids.join('","')}")` : "";
    // パラメータ
    const querySpec: SqlQuerySpec = {
      query: `
        SELECT *
        FROM root r
        WHERE r.type IN (@type1,@type2)
          AND r.userId = @userId
          ${filterQuery}
          ${idCondition}
          ${where}
      `,
      parameters: [
        {
          name: "@type1",
          value: "MODEL_THREAD",
        },
        {
          name: "@type2",
          value: "CHATBOT_THREAD",
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
      ],
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query(querySpec)
      .fetchAll();

    // 返却値
    return {
      status: "OK",
      response: resources,
      querySpec: querySpec,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * メッセージ件数取得処理
 * @param searchText 検索ワード
 * @param modelList 選択されたモデルIDリスト
 * @param chatbotList 選択されたチャットボットIDリスト
 * @param threadId 選択されたスレッドID
 * @returns 結果:OK or ERROR
 */
export const GetMessageCount = async (
  searchText: string,
  modelList: string[] = [],
  chatbotList: string[] = [],
  threadId?: string,
) => {
  try {
    // 検索単語リスト
    const serchTextList = searchText.split(/\s/).map((text) => {
      return `UPPER(r.content) LIKE UPPER('%${text}%') `;
    });
    const textSerchQuery = searchText
      ? "AND " + serchTextList.join("\nAND ")
      : "";
    //モデル、チャットボットフィルターのSQL文を作成
    const modelFilter = modelList.length
      ? `r.modelId IN ("${modelList.join('","')}")`
      : "";
    const chatbotFilter = chatbotList.length
      ? `r.chatbotId IN ("${chatbotList.join('","')}")`
      : "";
    const filterQuery =
      modelFilter && chatbotFilter
        ? `AND (${modelFilter} OR ${chatbotFilter})`
        : modelFilter || chatbotFilter
          ? "AND " + modelFilter + chatbotFilter
          : "";
    const threadFilter = threadId ? `AND r.threadId = "${threadId}"` : "";

    // パラメータ
    const querySpec: SqlQuerySpec = {
      query: `
        SELECT
        VALUE COUNT(1)
        FROM root r
        WHERE
          r.type = @type
          AND r.userId = @userId
          AND NOT r.isDeleted
          ${filterQuery}
          ${threadFilter}
          ${textSerchQuery}
        ORDER BY r.lastMessageAt DESC
      `,
      parameters: [
        {
          name: "@type",
          value: "MESSAGE",
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
      ],
    };

    // メッセージ検索
    const { resources: count } = await HistoryContainer()
      .items.query<number>(querySpec)
      .fetchAll();

    // 返却値
    return {
      status: "OK",
      response: count[0],
      querySpec: querySpec,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * メッセージ検索処理
 * @param searchText 検索ワード
 * @param modelList 選択されたモデルIDリスト
 * @param chatbotList 選択されたチャットボットIDリスト
 * @param threadId 選択されたスレッドID
 * @returns 結果:OK or ERROR
 */
export const FindMessage = async (
  searchText: string,
  modelList: string[] = [],
  chatbotList: string[] = [],
  threadId?: string,
  limit?: number,
) => {
  try {
    // 取得上限を設定
    const searchLimit = limit ? `TOP ${limit + 1}` : "";
    // 検索単語リスト
    const serchTextList = searchText.split(/\s/).map((text) => {
      return `UPPER(r.content) LIKE UPPER('%${text}%') `;
    });
    const textSerchQuery = searchText
      ? "AND " + serchTextList.join("\nAND ")
      : "";
    //モデル、チャットボットフィルターのSQL文を作成
    const modelFilter = modelList.length
      ? `r.modelId IN ("${modelList.join('","')}")`
      : "";
    const chatbotFilter = chatbotList.length
      ? `r.chatbotId IN ("${chatbotList.join('","')}")`
      : "";
    const filterQuery =
      modelFilter && chatbotFilter
        ? `AND (${modelFilter} OR ${chatbotFilter})`
        : modelFilter || chatbotFilter
          ? "AND " + modelFilter + chatbotFilter
          : "";
    const threadFilter = threadId ? `AND r.threadId = "${threadId}"` : "";

    // パラメータ
    const querySpec: SqlQuerySpec = {
      query: `
        SELECT
        ${searchLimit}
        *
        FROM root r
        WHERE
          r.type = @type
          AND r.userId = @userId
          AND NOT r.isDeleted
          ${filterQuery}
          ${threadFilter}
          ${textSerchQuery}
        ORDER BY r.lastMessageAt DESC
      `,
      parameters: [
        {
          name: "@type",
          value: "MESSAGE",
        },
        {
          name: "@userId",
          value: await userHashedId(),
        },
      ],
    };

    // メッセージ検索
    const { resources: messageResources } = await HistoryContainer()
      .items.query<MessageModel>(querySpec)
      .fetchAll();
    if (messageResources.length === 0) {
      return {
        status: "OK",
        response: messageResources,
        querySpec: querySpec,
        threadList: [],
      };
    }
    const messageWithAttachmentsResponse =
      await findAttachmentsAndMergeByMessagesForCurrentUser(messageResources);
    if (messageWithAttachmentsResponse.status !== "OK") {
      return messageWithAttachmentsResponse;
    }
    const messageWithAttachments = messageWithAttachmentsResponse.response;

    // スレッド情報を取得
    // スレッドの検索条件を取得
    const threadIds = messageResources.map((message) => message.threadId);
    // スレッド情報取得
    const threads = await FindThread("", [], [], threadIds);
    if (threads.status !== "OK") return { ...threads };
    const threadObj: { [id: string]: ThreadModel } = {};
    threads.response?.forEach((thread: ThreadModel) => {
      threadObj[thread.id] = thread;
    });

    // メッセージにモデル、チャットボット、スレッド名を保存 (添付ファイル、画像)
    const messages: HistorySearchMessage[] = messageWithAttachments
      .map((message) => {
        const thread = threadObj[message.messageData.threadId];
        // 異常なデータ (isDeleted = false にも拘わらず対象のスレッドが存在しない)
        // 存在はし得るのでしっかり無視する
        if (!thread) return undefined;
        // モデル名
        const modelName =
          thread.type === "MODEL_THREAD" ? thread.modelName : "";
        // チャットボット名
        const chatbotName =
          thread.type === "CHATBOT_THREAD" ? thread.chatbotName : "";
        // スレッド名
        const threadName = thread?.name || "";

        return {
          messageData: message.messageData,
          attachments: message.attachments,
          modelName: modelName,
          chatbotName: chatbotName,
          threadName: threadName,
        };
      })
      .filter((message) => message !== undefined);

    // 返却値
    return {
      status: "OK",
      response: limit
        ? messages
        : messages.slice(0, HISTORY_SEARCH_VIEW_COUNT + 1),
      querySpec: querySpec,
      threadList: limit ? [] : threads.response || [],
    };
  } catch (error) {
    throw error;
  }
};

/**
 * モデルリスト取得
 * @returns 結果:OK or ERROR
 */
export const FindModels = async () => {
  try {
    // パラメータ
    const querySpec: SqlQuerySpec = {
      query: `
        SELECT *
        FROM root r
        WHERE r.type = @type
      `,
      parameters: [
        {
          name: "@type",
          value: "MODEL",
        },
      ],
    };

    // 検索
    const { resources } = await ConfigContainer()
      .items.query(querySpec)
      .fetchAll();

    // 返却値
    return {
      status: "OK",
      response: resources,
      querySpec: querySpec,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * チャットボット検索
 * @param searchText チャットボット検索条件
 * @param limit 検索上限
 * @returns 結果:OK or ERROR
 */
export const FindChatbots = async (
  searchText: string = "",
  limit: number | null = null,
) => {
  try {
    const serchLimit = limit ? `TOP ${limit + 1}` : "";
    // パラメータ
    const querySpec: SqlQuerySpec = {
      query: `
        SELECT
        ${serchLimit}
        *
        FROM root r
        WHERE r.type = @type
          AND (
            UPPER(r.chatbotName) LIKE UPPER(@searchText)
            OR UPPER(r.description) LIKE UPPER(@searchText)
          )
      `,
      parameters: [
        {
          name: "@type",
          value: "CHATBOT",
        },
        {
          name: "@searchText",
          value: `%${searchText}%`,
        },
      ],
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query(querySpec)
      .fetchAll();

    // 返却値
    return {
      status: "OK",
      response: resources,
      querySpec: querySpec,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * 添付ファイル取得
 * @param ids メッセージIDリスト
 * @returns 結果:OK or ERROR
 */
export const FindAttachment = async (ids: string[] = []) => {
  try {
    // パラメータ
    const querySpec: SqlQuerySpec = {
      query: `
        SELECT
        *
        FROM root r
        WHERE r.type IN (@type1,@type2)
          AND r.messageId IN ("${ids.join('","')}")
      `,
      parameters: [
        {
          name: "@type1",
          value: "ATTACHMENT_FILE",
        },
        {
          name: "@type2",
          value: "ATTACHMENT_IMAGE",
        },
      ],
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query(querySpec)
      .fetchAll();

    // 返却値
    return {
      status: "OK",
      response: resources,
      querySpec: querySpec,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `Error retrieving attachment: ${error}`,
        },
      ],
    };
  }
};
