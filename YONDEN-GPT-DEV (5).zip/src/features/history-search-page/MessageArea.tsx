import Link from "next/link";
import { MessageContent } from "../chat-view/chat-messages/message-content";
import { RoleIconAssistant } from "../ui/chat/role-icon/role-icon-assistant";
import { RoleIconUser } from "../ui/chat/role-icon/role-icon-user";
import {
  HISTORY_SEARCH_VIEW_COUNT,
  HistorySearchMessage,
} from "./History-model";
import { countWord } from "@/features/common/countWord";
import { Button } from "@/features/ui/button";

export const MessageArea = (props: {
  messages: Array<HistorySearchMessage>;
  viewCount: number;
  setViewCount: (count: number) => void;
}) => {
  const { messages, viewCount, setViewCount } = props;

  // クリップボードにコピー
  const copyToClipbord = (text: string) => {
    navigator.clipboard.writeText(text);
  };
  return (
    <>
      {messages?.map((message, i) => {
        const { messageData } = message;
        const assistantName = messageData.modelId
          ? (message.modelName ?? "")
          : messageData.chatbotId
            ? (message.chatbotName ?? "")
            : "";

        if (i < viewCount)
          return (
            <div
              className={`grid grid-cols-4 ${
                i % 2 == 0 ? "bg-white" : "bg-gray-hover"
              } px-32 py-5`}
              key={messageData.id}
            >
              {/* 送信者（ユーザ or assistant） */}
              <div className="col-span-full flex items-center gap-3 text-lg font-bold">
                {messageData.role === "user" && (
                  <>
                    <RoleIconUser />
                    あなた
                  </>
                )}
                {messageData.role === "assistant" && (
                  <>
                    <RoleIconAssistant />
                    {assistantName}
                  </>
                )}
              </div>
              {/* メッセージ内容 */}
              <div className="col-span-full mb-5 mt-2 text-gray-600">
                <MessageContent message={message} />
              </div>
              {/* TODO 添付ファイルダウンロードボタン表示 */}
              {/* コピーボタン */}
              <div className="col-start-1 pl-1 pt-1">
                <Button
                  title="クリップボードにコピー"
                  variant="ghost"
                  className="h-fit w-fit p-0 text-gray-500 hover:text-gray-700"
                  onClick={() => copyToClipbord(messageData.content)}
                >
                  <span className="i-material-symbols-content-copy-outline-rounded h-6 w-6" />
                </Button>
              </div>
              <div className="col-start-3 -col-end-1 text-right text-gray-500">
                {/* スレッドリンク */}
                <span>
                  スレッド名：
                  <Link
                    href={`/chat/${messageData.threadId}`}
                    className="text-blue-400 underline"
                  >
                    {countWord(message.threadName, 15)}
                  </Link>
                </span>
                <br />
                {/* 送信日時 */}
                <span>
                  送信日時：
                  {new Date(messageData.createdAt)?.toLocaleDateString(
                    "ja-JP",
                    {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    },
                  )}
                </span>
              </div>
            </div>
          );
      })}
      {/* もっと見るボタン */}
      {viewCount < messages.length && (
        <div className="w-full p-5">
          <Button
            className="!flex !w-full !justify-center !self-stretch !rounded-3xl !border !border-solid !border-[#c8c8c8] !bg-white-01 text-black"
            color="default"
            text="もっと見る"
            onClick={() => setViewCount(viewCount + HISTORY_SEARCH_VIEW_COUNT)}
          />
        </div>
      )}
    </>
  );
};
