import { MessageWithServerAttachments } from "../chat-view/models";

// 定数
/**
 * 1回でのメッセージ表示件数
 * (この件数より多く見つかった場合「もっと見る」表示)
 */
export const HISTORY_SEARCH_VIEW_COUNT = 20;

// エラーメッセージ
// TODO: 取得
export const EHISTORY0001 = "・チャット履歴の取得に失敗しました。";
export const EHISTORY0002 = "・モデルリストの取得に失敗しました。";
export const EHISTORY0003 = "・チャットボットリストの取得に失敗しました。";
export const EHISTORY0004 = "・メッセージの取得に失敗しました。";
export const EHISTORY9999 = "・例外エラーメッセージ";

export interface HistorySearchMessage extends MessageWithServerAttachments {
  /** スレッド名 */
  threadName: string;
  /** モデル名 */
  modelName: string;
  /** チャットボット名 */
  chatbotName: string;
}
