"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { cva } from "class-variance-authority";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { showSuccess } from "../globals/global-message-store";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../ui/form";
import { cn } from "../ui/lib";
import { RadioGroup, RadioGroupItem } from "../ui/radio-group";
import { ScrollArea } from "../ui/scroll-area";

const FormSchema = z.object({
  type: z.enum(["className", "spanTag"], {
    required_error: "必須です",
  }),
});
type FormValues = z.infer<typeof FormSchema>;
type Type = FormValues["type"];

export const IconsPage = () => {
  const form = useForm<z.infer<typeof FormSchema>>({
    resolver: zodResolver(FormSchema),
    defaultValues: { type: "className" },
  });
  const type = form.watch("type");

  return (
    <ScrollArea className="flex flex-col">
      <Form {...form}>
        <form className="space-y-6 border-gray-01">
          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem className="space-y-2">
                <FormLabel>アイコンクリックでコピーするもの</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="flex space-x-3"
                    orientation="horizontal"
                  >
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="className" />
                      </FormControl>
                      <FormLabel className="font-normal">クラス名</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="spanTag" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        {"<span /> タグ"}
                      </FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </form>
      </Form>
      <div className="grid grid-cols-5 gap-y-4">
        {icons.map((icon, i) => (
          <IconPreview key={i} icon={icon} type={type} />
        ))}
      </div>
    </ScrollArea>
  );
};

const icons = [
  "Kind=Add",
  "Kind=Add (File)",
  "Kind=Add (Folder)",
  "Kind=Arrow",
  "Kind=Asterisk",
  "Kind=Attachment",
  "Kind=Bookmark",
  "Kind=Bookmark (Remove)",
  "Kind=Camera",
  "Kind=Cancel",
  "Kind=Chat",
  "Kind=Chat (Move)",
  "Kind=Chatbot",
  "Kind=Check",
  "Kind=Clipboard",
  "Kind=Delete",
  "Kind=Down",
  "Kind=Edit",
  "Kind=File",
  "Kind=Filter",
  "Kind=Folder",
  "Kind=Home",
  "Kind=Image",
  "Kind=Info",
  "Kind=Link",
  "Kind=Lock",
  "Kind=Log Out",
  "Kind=Menu",
  "Kind=Mic",
  "Kind=Mic (Off)",
  "Kind=Minus",
  "Kind=Option",
  "Kind=Parameter",
  "Kind=Persona",
  "Kind=Progress",
  "Kind=Prompt",
  "Kind=Refresh",
  "Kind=Search",
  "Kind=Search (History)",
  "Kind=Send",
  "Kind=Settings",
  "Kind=Share",
  "Kind=Stop",
  "Kind=User",
  "Kind=Warning",
] as const;

type IconKind = (typeof icons)[number];

const iconPreviewVariants = cva("", {
  variants: {
    icon: {
      "Kind=Add": "i-material-symbols-add",
      "Kind=Add (File)": "i-mdi-file-document-add-outline",
      "Kind=Add (Folder)": "i-mdi-folder-add-outline",
      "Kind=Arrow": "i-material-symbols-keyboard-arrow-down-rounded",
      "Kind=Asterisk": "i-material-symbols-asterisk-rounded",
      "Kind=Attachment": "i-material-symbols-attach-file-rounded",
      "Kind=Bookmark": "i-material-symbols-bookmark-star-outline-rounded",
      "Kind=Bookmark (Remove)": "i-material-symbols-bookmark-outline-rounded",
      "Kind=Camera": "i-material-symbols-photo-camera-outline-rounded",
      "Kind=Cancel": "i-material-symbols-close-small-rounded",
      "Kind=Chat": "i-material-symbols-chat-add-on-outline-rounded",
      "Kind=Chat (Move)": "i-material-symbols-chat-paste-go-outline-rounded",
      "Kind=Chatbot": "i-material-symbols-upload-file-outline-rounded",
      "Kind=Check": "i-material-symbols-check-small-rounded",
      "Kind=Clipboard": "i-material-symbols-content-copy-outline-rounded",
      "Kind=Delete": "i-material-symbols-delete-outline-rounded",
      "Kind=Down": "i-material-symbols-arrow-downward-alt-rounded",
      "Kind=Edit": "i-tdesign-edit-2",
      "Kind=File": "i-mdi-file-document-outline",
      "Kind=Filter": "i-material-symbols-filter-list-rounded",
      "Kind=Folder": "i-mdi-folder-outline",
      "Kind=Home": "i-material-symbols-home-outline-rounded",
      "Kind=Image": "i-material-symbols-imagesmode-outline-rounded",
      "Kind=Info": "i-material-symbols-info-outline-rounded",
      "Kind=Link": "i-material-symbols-link-rounded",
      "Kind=Lock": "i-heroicons-solid-lock-closed",
      "Kind=Log Out": "i-material-symbols-logout-rounded",
      "Kind=Menu": "i-material-symbols-menu-rounded",
      "Kind=Mic": "i-material-symbols-mic",
      "Kind=Mic (Off)": "i-material-symbols-mic-off",
      "Kind=Minus": "i-majesticons-minus",
      "Kind=Option": "i-mdi-dots-horizontal",
      "Kind=Parameter": "i-material-symbols-display-settings-outline",
      "Kind=Persona": "i-mdi-target",
      "Kind=Progress": "i-material-symbols-progress-activity",
      "Kind=Prompt": "i-material-symbols-book-2-outline-rounded",
      "Kind=Refresh": "i-material-symbols-refresh-rounded",
      "Kind=Search": "i-material-symbols-search-rounded",
      "Kind=Search (History)": "i-material-symbols-manage-search-rounded",
      "Kind=Send": "i-tabler-send",
      "Kind=Settings": "i-material-symbols-settings-outline-rounded",
      "Kind=Share": "i-material-symbols-share",
      "Kind=Stop": "i-material-symbols-stop-circle-outline-rounded",
      "Kind=User": "i-bx-user",
      "Kind=Warning": "i-material-symbols-warning-outline-rounded",
    },
  },
});

const IconPreview = ({ icon, type }: { icon: IconKind; type: Type }) => {
  const className = iconPreviewVariants({ icon });
  return (
    <div
      className="flex flex-col items-center"
      onClick={() => {
        const copyText =
          type === "spanTag" ? `<span className="${className}" />` : className;
        navigator.clipboard.writeText(copyText);
        showSuccess({
          title: "コピーしました",
          description: copyText,
        });
      }}
    >
      <div className="h-12 w-12 text-center text-2xl">
        <span className={cn(className, "h-12 w-12 text-center text-2xl")} />
      </div>
      <div className="text-s">{icon}</div>
      <div className="text-[0.5rem]">{className}</div>
    </div>
  );
};
