import { ReactNode } from "react";
import { cn } from "../ui/lib";
import { toast } from "@/hooks/use-toast";

interface MessageProp {
  title: string;
  description: ReactNode;
}

export const showError = (error: string | undefined) => {
  toast({
    variant: "destructive",
    className: cn(
      "fixed right-0 top-0 flex border-red-400 bg-red-400 opacity-100 md:right-4 md:top-4 md:max-w-[420px]",
    ),
    description: error || "エラーが発生しました。",
    // action: reload ? (
    //   <ToastAction
    //     altText="Try again"
    //     onClick={() => {
    //       reload();
    //     }}
    //   >
    //     Try again
    //   </ToastAction>
    // ) : undefined,
  });
};
export const showSuccess = (message: MessageProp) => {
  toast(message);
};
