import Link from "next/link";
import { FC } from "react";
import { ButtonLinkVariant } from "../ui/button";
import { cn } from "@/ui/lib";

interface MenuLinkProps {
  href: string;
  ariaLabel: string;
  children: React.ReactNode;
}

export const MenuLink: FC<MenuLinkProps> = (props) => {
  return (
    <Link
      className={cn(ButtonLinkVariant, "text-white")}
      href={props.href}
      aria-label={props.ariaLabel}
    >
      {props.children}
    </Link>
  );
};
