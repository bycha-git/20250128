import { MenuIcon } from "./menu-icon";
import { MenuLink } from "./menu-link";
import { UserProfile } from "./user-profile";
import { Menu, MenuBar, MenuItem, MenuItemContainer } from "@/ui/menu";

export const MainMenu = async () => {
  return (
    <Menu className="hidden md:flex">
      <MenuBar>
        <MenuItemContainer>
          <MenuItem tooltip="ホーム" asChild>
            <MenuLink href="/chat" ariaLabel="ホーム">
              <MenuIcon className="i-material-symbols-home-outline-rounded" />
            </MenuLink>
          </MenuItem>
          <MenuItem tooltip="チャットボット">
            <MenuLink href="/chatbot" ariaLabel="チャットボット">
              <MenuIcon className="i-material-symbols-upload-file-outline-rounded" />
            </MenuLink>
          </MenuItem>
          <MenuItem tooltip="プロンプトテンプレート">
            <MenuLink href="/prompttemplate" ariaLabel="プロンプトテンプレート">
              <MenuIcon className="i-material-symbols-book-2-outline-rounded" />
            </MenuLink>
          </MenuItem>
          <MenuItem tooltip="チャット履歴検索">
            <MenuLink href="/historysearch" ariaLabel="チャット履歴検索">
              <MenuIcon className="i-material-symbols-manage-search-rounded" />
            </MenuLink>
          </MenuItem>
        </MenuItemContainer>
        <MenuItemContainer>
          <MenuItem tooltip="プロフィール">
            <UserProfile />
          </MenuItem>
        </MenuItemContainer>
      </MenuBar>
    </Menu>
  );
};
