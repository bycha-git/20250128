import { forwardRef, HTMLAttributes } from "react";
import { cn } from "../ui/lib";

type Props = HTMLAttributes<HTMLSpanElement>;

export const MenuIcon = forwardRef<HTMLSpanElement, Props>(
  (props: HTMLAttributes<HTMLSpanElement>, ref) => (
    <span
      ref={ref}
      {...props}
      className={cn("h-9 w-9 text-white", props.className)}
    />
  ),
);
MenuIcon.displayName = "MenuIcon";
