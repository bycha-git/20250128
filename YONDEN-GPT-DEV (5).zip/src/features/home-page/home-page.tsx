"use client";

import Image from "next/image";
import React from "react";
import { ScrollArea } from "../ui/scroll-area";
import bxVisionPic from "@/image/bx-vision.png";

export const HomePage = () => {
  return (
    <>
      <Header />
      <MessagesArea />
    </>
  );
};

const Header = () => <header className="border-b border-gray-03" />;

const MessagesArea = () => (
  <main className="contents w-full">
    <ScrollArea className="col-span-full h-full w-full overflow-auto">
      <div className="flex min-h-full flex-col items-center justify-center gap-[2rem] lg:gap-[3.5rem]">
        <h1 className="text-center text-[12dvw] font-bold text-orange-02 md:text-[4rem] lg:text-[5rem]">
          YONDEN-GPT
        </h1>
        <Image
          className="w-[80dvw] max-w-full object-contain opacity-50 md:h-80 md:w-[unset]"
          alt="よんでんグループBXビジョン"
          src={bxVisionPic}
          priority={false}
        />
      </div>
    </ScrollArea>
  </main>
);
