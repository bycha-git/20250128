"use server";

import { userHashedId } from "../auth-page/helpers";
import {
  AddAuthorityCompany,
  DeleteAuthortyCompany,
  FindAuthorityCompanys,
  UpsertAuthorityCompany,
} from "../common/services/authority-company-service";
import {
  AddAuthorityEmployee,
  DeleteAuthortyEmployee,
  FindAuthorityUsers,
  UpsertAuthorityEmployee,
} from "../common/services/authority-employee-service";
import { FindAuthorityID } from "../common/services/authority-service";
import {
  companySearch,
  FindCompaniesByIDs,
} from "../common/services/company-service";
import { HistoryContainer } from "../common/services/cosmos";
import {
  employeeSearch,
  FindEmployeeByID,
  FindEmployeeByIDs,
} from "../common/services/employee-service";
import { uniqueId } from "../common/util";
import { PromptModel } from "./Prompt-model";
import { FindPromptByID } from "./Prompt-service";

interface AuthorityEmployeeInfo {
  id: string | undefined;
  employeeName: string | undefined;
  permissionId: string | undefined;
  errFlg: boolean;
  errorMessageId?: string;
}

interface AuthorityCompanyInfo {
  id: string | undefined;
  departmentName: string | undefined;
  permissionId: string | undefined;
  errFlg: boolean;
  errorMessageId?: string;
}

// 排他チェック返却値
interface CheckResult {
  check: boolean;
  message: string;
  errkind: string;
}

// ユーザー、組織存在チェックの戻り値
interface ExistenceResult {
  check: boolean;
  message: string;
  deletedUsers: string[];
  deletedCompanies: string[];
}

/**
 * モーダル初期表示処理(新規)
 */
export const initializingModal = async () => {
  try {
    // userIdを取得
    const userId = (await userHashedId()).toString();
    // プルダウン用の権限情報を取得
    const authorityKind = await FindAuthorityID();

    const dispData = authorityKind.response.map(({ id, label }) => ({
      id,
      label,
    }));

    const userResponse = await FindEmployeeByID(userId);

    const userData = {
      employeeName:
        userResponse.response?.id + " " + userResponse.response?.employeeName,
      id: userResponse.response?.id,
    };

    return { dispData, userData };
  } catch (error) {
    throw error;
  }
};

/**
 * プロンプトテンプレート権限取得
 */
export const getTemplateAuthority = async (promptId: string) => {
  try {
    // プロンプトテンプレートに設定されている権限（ユーザー）取得
    const userAuthoritys = await FindAuthorityUsers(promptId);

    // プロンプトテンプレートに設定されている権限（組織）取得
    const companyAuthoritys = await FindAuthorityCompanys(promptId);

    // ユーザー情報を画面に表示できる形に編集
    const usersData: AuthorityEmployeeInfo[] =
      userAuthoritys.response?.map(
        ({ id, employeeName, employeeId, permissionId }) => ({
          id: id,
          employeeName: employeeId + " " + employeeName,
          permissionId: permissionId,
          errFlg: false,
        }),
      ) ?? [];

    // 組織情報を画面に表示できる形に編集
    const companyData: AuthorityCompanyInfo[] =
      companyAuthoritys.response?.map(
        ({ id, departmentCode, departmentName, permissionId }) => ({
          id: id,
          departmentName: departmentCode + " " + departmentName,
          permissionId: permissionId,
          errFlg: false,
        }),
      ) ?? [];

    return { usersData, companyData };
  } catch (error) {
    throw error;
  }
};

/**
 * 権限タブユーザー検索
 */
export const searchAuthorityUsers = async (searchText: string) => {
  try {
    const employeeResult = await employeeSearch(searchText);

    const searchData: AuthorityEmployeeInfo[] =
      employeeResult.response?.map(({ id, employeeName }) => ({
        id: "",
        employeeName: id + " " + employeeName,
        permissionId: "",
        errFlg: false,
      })) ?? [];
    return searchData;
  } catch (error) {
    throw error;
  }
};

/**
 * 権限タブ組織検索
 */
export const searchAuthorityCompany = async (searchText: string) => {
  try {
    const companyResult = await companySearch(searchText);

    const searchData: AuthorityCompanyInfo[] =
      companyResult.response?.map(({ departmentCode, departmentName }) => ({
        id: "",
        departmentName: departmentCode + " " + departmentName,
        permissionId: "",
        errFlg: false,
      })) ?? [];
    return searchData;
  } catch (error) {
    throw error;
  }
};

/**
 * 登録前排他チェック（編集画面）
 */
export const exclusionCheck = async (promptId: string, lastUpdDate: string) => {
  try {
    // 返却値
    const result: CheckResult = {
      check: true,
      message: "",
      errkind: "",
    };

    // テンプレート存在チェック
    const prompt = await FindPromptByID(promptId);
    // 見つからない場合エラーを返す
    if (prompt.status == "NOT_FOUND") {
      result.check = false;
      result.message = "ETEMPLATE0001";
      result.errkind = "1";
      return result;
    }
    if (prompt.status !== "OK") {
      result.check = false;
      result.message = "ECOMMON0001";
      result.errkind = "";
      return result;
    }

    // 更新されていないかチェック
    if (lastUpdDate !== prompt.response.lastUpdateAt) {
      result.check = false;
      result.message = "ETEMPLATE0006";
      result.errkind = "2";
      return result;
    }
    return result;
  } catch (error) {
    throw error;
  }
};

/**
 * ユーザー、組織存在チェック
 */
export const existenceCheck = async (users: string[], companies: string[]) => {
  try {
    // 返却値
    const result: ExistenceResult = {
      check: true,
      message: "",
      deletedUsers: [],
      deletedCompanies: [],
    };

    // ユーザーが存在するかチェック
    const userCheck = await FindEmployeeByIDs(users);
    const existingUserIds = userCheck.response?.map((user) => user.id) || [];

    // 削除されたユーザーを特定
    result.deletedUsers = users.filter(
      (userId) => !existingUserIds.includes(userId),
    );

    // 組織が存在するかチェック
    const companyCheck = await FindCompaniesByIDs(companies);
    const existingCompanyIds =
      companyCheck.response?.map((company) => company.departmentCode) || [];

    // 削除された組織を特定
    result.deletedCompanies = companies.filter(
      (companyId) => !existingCompanyIds.includes(companyId),
    );

    return result;
  } catch (error) {
    throw error;
  }
};

/**
 * 登録
 */
export const templateInsert = async (
  insertCompany: AuthorityCompanyInfo[],
  insertUsers: AuthorityEmployeeInfo[],
  prompt: PromptModel,
  lastUpdateUser: string,
) => {
  try {
    // userIdを取得
    const userId = (await userHashedId()).toString();
    // ログイン情報はべた書き
    const insertData = await CreatePrompt(
      prompt.templateName,
      prompt.template,
      userId,
      lastUpdateUser,
    );

    // 権限（ユーザー）登録
    await AddAuthorityEmployee(
      insertData.response?.id ?? "",
      insertUsers,
      userId,
    );
    // 権限（組織）登録
    await AddAuthorityCompany(
      insertData.response?.id ?? "",
      insertCompany,
      userId,
    );
  } catch (error) {
    throw error;
  }
};

/**
 * 更新
 */
export const templateUpsert = async (
  insertCompany: AuthorityCompanyInfo[],
  insertUsers: AuthorityEmployeeInfo[],
  prompt: PromptModel,
  deletedCompanyInfo: string[],
  deletedEmployeeInfo: string[],
  lastUpdateUser: string,
) => {
  try {
    // userIdを取得
    const userId = (await userHashedId()).toString();
    // テンプレート更新
    await upsertPrompt(prompt, userId, lastUpdateUser);
    // 権限(組織)更新
    await UpsertAuthorityCompany(prompt.id, insertCompany, userId);
    // 権限（ユーザー）更新
    await UpsertAuthorityEmployee(prompt.id, insertUsers, userId);
    // 権限（組織）削除（削除されたものがあれば）
    if (deletedCompanyInfo && deletedCompanyInfo.length > 0) {
      await DeleteAuthortyCompany(deletedCompanyInfo);
    }
    // 権限（ユーザー）削除（削除されたものがあれば）
    if (deletedEmployeeInfo && deletedEmployeeInfo.length > 0) {
      await DeleteAuthortyEmployee(deletedEmployeeInfo);
    }
  } catch (error) {
    throw error;
  }
};

/** cosmosDB処理 */

/**
 * プロンプトテンプレート新規登録処理
 * @param name テンプレート名
 * @param description テンプレート内容
 * @param userName ユーザ名
 * @returns 結果 OK or ERROR
 */
export const CreatePrompt = async (
  name: string,
  description: string,
  userName: string,
  lastUpdateUser: string,
) => {
  try {
    // TODO idの登録方法
    // 登録内容
    const modelToSave = {
      id: uniqueId(),
      type: "TEMPLATE",
      userId: userName,
      createdAt: new Date().toISOString(),
      lastUpdateAt: new Date().toISOString(),
      lastUpdateUser: lastUpdateUser,
      numberOfChoices: 0,
      templateName: name,
      template: description,
    };

    // 登録
    const { resource } = await HistoryContainer().items.create(modelToSave);

    // 返却値
    if (resource) {
      return {
        status: "OK",
        response: resource,
      };
    }
  } catch (error) {
    throw error;
  }
};

/**
 * プロンプトテンプレート更新処理
 * @param prompt 更新用データ
 * @param id 更新後の名前

 * @returns 更新結果
 */
export const upsertPrompt = async (
  prompt: PromptModel,
  userId: string,
  lastUpdateUser: string,
) => {
  try {
    const promptResponse = await FindPromptByID(prompt.id);

    if (promptResponse.status == "OK") {
      const modelToUpdate: PromptModel = {
        id: promptResponse.response.id,
        type: "TEMPLATE",
        userId: promptResponse.response.userId,
        createdAt: promptResponse.response.createdAt,
        lastUpdateAt: new Date().toISOString(),
        lastUpdateUser: lastUpdateUser,
        numberOfChoices: promptResponse.response.numberOfChoices,
        templateName: prompt.templateName,
        template: prompt.template,
      };

      const { resource } = await HistoryContainer().items.upsert(modelToUpdate);

      if (resource) {
        return {
          status: "OK",
          response: resource,
        };
      }
    }

    return promptResponse;
  } catch (error) {
    throw error;
  }
};
