"use client";

import React, { useEffect, useRef, useState } from "react";
import { LoadingIndicator } from "../ui/loading";
import { PromptModel, VIEW_COUNT } from "./Prompt-model";
import {
  DeleteAuthorty,
  DeletePrompt,
  fetchPrompts,
  FindPromptByID,
  referenceOpen,
} from "./Prompt-service";
import { TemplateBasic } from "./TemplateBasicWindow";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { countWord } from "@/features/common/countWord";
import { loadingOverlayStore } from "@/features/common/store/loading-overlay-store";
import { showError } from "@/features/globals/global-message-store";
import { Button } from "@/features/ui/button";
import ComboBox from "@/features/ui/combbox";
import { useConfirm } from "@/features/ui/confirm";
import CustomDropdownMenu from "@/features/ui/DropdownMenu";
import { Input } from "@/features/ui/input";
import { Separator } from "@/features/ui/separator";

interface SearchTerms {
  tab: number;
  text: string;
  sort: string | undefined;
}

interface MenuFlg {
  parentId: string;
  isAdmin: boolean;
}

interface ViewMore {
  viewCount: number;
  visible: boolean;
}

interface Info {
  promptData: PromptModel;
  mode: string;
  visible: boolean;
}

// タブ名称
const buttons = [
  { text: "すべて" },
  { text: "管理者" },
  { text: "編集権限＋共有" },
  { text: "共有のみ" },
];

// 並び順
const combboxValue = [
  { id: 1, text: "更新日順" },
  { id: 2, text: "名前順" },
];

/**
 * MainLogic
 * @returns 画面表示内容
 */
export const PromptTemplate = () => {
  // menuに渡すアイコンとテキスト
  const menuItems = [
    { iconClass: "i-tdesign-edit-2 h-5 w-5", label: "編集" },
    {
      iconClass: "i-material-symbols-delete-outline-rounded h-5 w-5",
      label: "削除",
    },
  ];

  // 画面間 - 情報
  const [info, setInfo] = useState<Info>({
    promptData: {
      id: "",
      type: "TEMPLATE",
      userId: "",
      createdAt: "",
      lastUpdateAt: "",
      lastUpdateUser: "",
      numberOfChoices: 0,
      templateName: "",
      template: "",
    },
    mode: "",
    visible: false,
  });
  // 検索条件
  const [searchTerms, setSearchTerms] = useState<SearchTerms>({
    tab: 0, // 選択タブ
    text: "", // 検索ワード
    sort: "更新日順", // ソート順
  });
  // もっと見る
  const [viewMore, setViewMore] = useState<ViewMore>({
    viewCount: VIEW_COUNT, // 一覧表示件数
    visible: false, // もっと見るボタン・表示
  });
  // どのメニューが開かれているか
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  // テンプレート一覧
  const [promptsData, setPromptsData] = useState<PromptModel[]>([]);
  // 削除フラグ
  const [deleteFlg, setDeleteFlg] = useState(false);
  // メニューフラグ
  const [menuFlg, setMenuFlg] = useState<MenuFlg[] | undefined>([]);
  // key制御
  const [modalKey, setModalKey] = useState(0);
  const debounceTimeout = useRef<NodeJS.Timeout | null>(null);
  // もっと見るボタンロードフラグ
  const [loading, setLoading] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);

  // エラーメッセージ
  const errMessage = useErrorMessage();

  /**
   * 初期化処理
   */
  const clear = () => {
    setSearchTerms({
      ...searchTerms,
      tab: 0, // 選択タブ
      text: "", // 検索ワード
      sort: "更新日順", // ソート順
    });
    setViewMore({
      ...viewMore,
      viewCount: VIEW_COUNT, // 一覧表示件数
      visible: false, // もっと見るボタン・表示
    });
    setDeleteFlg(!deleteFlg);
  };

  /**
   * ポップアップ表示
   * @param promptId 対象プロンプトID
   * @param mode モード
   */
  const openModal = async (promptId: string, mode: string) => {
    try {
      loadingOverlayStore.startLoading();
      setModalKey((prevKey) => prevKey + 1);
      if (promptId) {
        if (mode === "参照") {
          // 表示チェック
          const checkResult = await referenceOpen(promptId);
          if (checkResult?.check) {
            // 参照画面を表示
            const promptResponse = await FindPromptByID(promptId);
            setInfo({
              ...info,
              promptData: promptResponse.response,
              mode: mode,
              visible: true,
            });
          } else {
            // エラーメッセージを表示
            showError(errMessage[checkResult?.message]);
            // 初期化
            clear();
            return;
          }
        } else if (mode === "編集") {
          // 表示チェック
          const checkResult = await referenceOpen(promptId);
          console.log("checkResult ??", checkResult);
          if (checkResult?.check) {
            // 参照画面を表示
            const promptResponse = await FindPromptByID(promptId);
            setInfo({
              ...info,
              promptData: promptResponse.response,
              mode: mode,
              visible: true,
            });
          } else {
            // エラーメッセージを表示
            showError(errMessage[checkResult?.message]);
            // 初期化
            clear();
            return;
          }
        }
      } else {
        // 新規作成ホップアップを表示
        setInfo({
          ...info,
          promptData: {
            id: "",
            type: "TEMPLATE",
            userId: "",
            createdAt: "",
            lastUpdateAt: "",
            lastUpdateUser: "",
            numberOfChoices: 0,
            templateName: "",
            template: "",
          },
          mode: mode,
          visible: true,
        });
      }
    } catch (error) {
      showError(errMessage["ECOMMON0001"]);
    } finally {
      loadingOverlayStore.stopLoading();
    }
  };

  /**
   * プロンプトテンプレート削除
   * @param promptId 対象プロンプトテンプレートID
   */
  const { confirm } = useConfirm();
  const runConfirm = async (promptId: string) => {
    try {
      // 削除対象対象プロンプトテンプレート・取得
      const selectPrompt = promptsData.filter((item) => item.id === promptId);

      const result = await confirm({
        text: (
          <>
            <strong>{selectPrompt[0].templateName}</strong> を削除します。
          </>
        ),
        title: "テンプレートを削除しますか？",
        okButtonText: "削除する",
        cancelButtonText: "キャンセルする",
      });

      if (result) {
        // 存在、権限チェック
        const checkResult = await referenceOpen(promptId);
        if (checkResult?.check) {
          // 権限を削除
          await DeleteAuthorty(promptId);
          // テンプレートを削除
          await DeletePrompt(promptId);

          // 再描画
          setDeleteFlg(!deleteFlg);
        } else {
          // エラーメッセージを表示
          showError(errMessage[checkResult?.message]);
          clear();
          return;
        }
      }
    } catch (error) {
      showError(errMessage["ECOMMON0001"]);
    }
  };

  /**
   * テンプレート一覧表示処理
   * 各Stateの状態を検知
   */
  useEffect(() => {
    if (!loading) {
      setSearchLoading(true);
      setPromptsData([]);
      setViewMore({
        ...viewMore,
        visible: false,
      });
    }
    const fetchData = async () => {
      try {
        if (debounceTimeout.current) {
          clearTimeout(debounceTimeout.current);
        }

        debounceTimeout.current = setTimeout(async () => {
          const searchData = await fetchPrompts(searchTerms, viewMore);
          setPromptsData(searchData?.promptsResponse?.response || []);
          setMenuFlg(searchData?.menuFlg);
          setViewMore({
            ...viewMore,
            visible: searchData?.viewMore?.visible ?? false,
          });
          setSearchLoading(false);
          setLoading(false);
        }, 1000);
      } catch (error) {
        setSearchLoading(false);
        setLoading(false);
        showError(errMessage["ECOMMON0001"]);
      }
    };

    fetchData();

    return () => {
      if (debounceTimeout.current) {
        clearTimeout(debounceTimeout.current);
      }
    };
  }, [searchTerms, viewMore.viewCount, info.visible, deleteFlg]);

  // 日付データをフォーマット
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");

    return `最終更新：${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()} ${hours}:${minutes}`;
  };

  // --- レンダリング ---
  return (
    <div className="relative flex h-full w-full flex-col items-start gap-6 bg-white-01 p-4 md:p-5 md:pb-0 lg:p-10 lg:pb-0">
      <div className="mx-auto w-full xl:w-[77%]">
        <header className="flex w-full items-center gap-2">
          <div className="flex items-center text-4xl font-medium text-black-01 md:text-5xl">
            <span className="i-material-symbols-book-2-outline-rounded mr-2 h-10 w-10 md:h-12 md:w-12"></span>
            プロンプトテンプレート
          </div>
          <div className="flex-grow" />
          <Button
            color="default"
            variant="default"
            onClick={() => openModal("", "新規")}
          >
            {"＋新しいテンプレート"}
          </Button>
        </header>

        <div className="ml-4 md:ml-16">
          <div className="mt-4 text-base text-gray-03 md:text-[22px]">
            YONDEN-GPTと対話する際の定型フォーマットです。テンプレートの所定の項目を変更するだけで、
            <br className="hidden lg:block" />
            YONDEN-GPTから最適な回答を引き出すことができます。
          </div>
          {/* 検索ボックス */}
          <div className="mt-6 flex w-full md:w-[90%]">
            <Input
              className="w-full"
              placeholder="テンプレートを検索する"
              icon={"i-material-symbols-search-rounded h-6 md:h-8 w-6 md:w-8"}
              text={searchTerms.text}
              onInputText={(e) => {
                setSearchTerms({
                  ...searchTerms,
                  text: e,
                });
                setViewMore({
                  ...viewMore,
                  viewCount: VIEW_COUNT,
                });
              }}
              maxLength={50}
            />
          </div>
        </div>

        {/* タブ・並べ替え */}
        <div className="mt-5 flex w-full flex-col items-start gap-4 md:flex-row md:items-center">
          <div className="flex flex-nowrap gap-4 overflow-x-auto">
            {buttons.map((button, index) => (
              <Button
                key={index}
                className={`!flex-[0_0_auto] ${
                  searchTerms.tab === index ? "bg-gray-300" : "bg-white-01"
                } !rounded-md font-bold text-black`}
                color="default"
                text={button.text}
                onClick={() => {
                  setSearchTerms({
                    ...searchTerms,
                    tab: index,
                  });
                  setViewMore({
                    ...viewMore,
                    viewCount: VIEW_COUNT,
                  });
                }}
              />
            ))}
          </div>
          <div className="ml-auto flex flex-shrink-0 items-center gap-2">
            <div className="font-bold text-black-01 md:text-xl">並べ替え</div>
            <ComboBox
              items={combboxValue}
              selectedItem={searchTerms.sort}
              onSelectText={(value) =>
                setSearchTerms({
                  ...searchTerms,
                  sort: value,
                })
              }
              idField={"id"}
              textField={"text"}
            />
          </div>
        </div>
      </div>

      <Separator />

      {/* プロンプトテンプレート一覧表示 */}
      <div className="flex w-full flex-col items-center gap-5 overflow-y-auto">
        {searchLoading && (
          <div className="flex w-full items-center justify-center py-4">
            <LoadingIndicator isLoading={searchLoading} />
          </div>
        )}
        {promptsData.map((prompt, index) => {
          const isAdminForPrompt =
            menuFlg?.some(
              (menuItem) => menuItem.parentId === prompt.id && menuItem.isAdmin,
            ) ?? false;

          return (
            <div
              key={index}
              className="relative grid w-full grid-cols-1 gap-4 rounded-md border border-solid border-[#c8c8c8] bg-white-01 p-4 md:grid-cols-[1fr_max-content] md:gap-2 xl:w-[77%]"
            >
              <div className="text-base font-bold text-black-01 md:text-[22px]">
                {countWord(prompt.templateName, 35)}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="text-xs md:text-base">
                  {formatDate(prompt.lastUpdateAt)}
                </div>

                {/* 参照ボタン */}
                <Button
                  title="参照"
                  className="!flex !justify-center !rounded-md !bg-white-01"
                  color="default"
                  icon="i-material-symbols-info-outline-rounded text-black w-6 md:w-8 h-6 md:h-8"
                  onClick={() => openModal(prompt.id, "参照")}
                  size="sm"
                />
                {/* 条件に一致する場合のみ「・・・」ボタンを表示 */}
                {isAdminForPrompt ? (
                  <CustomDropdownMenu
                    className="ml-10 mt-7"
                    items={menuItems}
                    open={activeMenuId === prompt.id}
                    onOpenChange={(open) => {
                      setActiveMenuId(open ? prompt.id : null);
                    }}
                    onItemClick={(label, index) => {
                      if (index === 0) {
                        openModal(prompt.id, "編集");
                      } else {
                        runConfirm(prompt.id);
                      }
                    }}
                    side="bottom"
                    align="end"
                    sideOffset={-30}
                    alignOffset={-60}
                    triggerElement={
                      <Button
                        className="!justify-center !rounded-md !bg-white-01"
                        color="default"
                        icon="i-ooui-ellipsis text-black w-6 md:w-8 h-6 md:h-8"
                        size="sm"
                      />
                    }
                  />
                ) : (
                  <div className="w-10 md:w-14" />
                )}
              </div>

              <div className="col-span-full text-sm text-gray-03 md:text-base">
                {countWord(prompt.template, 70)}
              </div>
            </div>
          );
        })}

        {/* もっと見る */}
        {viewMore.visible && (
          <>
            {loading ? (
              <div className="flex w-full items-center justify-center py-4">
                <LoadingIndicator isLoading={loading} />
              </div>
            ) : (
              <Button
                text="もっと見る"
                variant={"more"}
                className="mb-4 w-full xl:w-[77%]"
                onClick={() => {
                  setViewMore({
                    ...viewMore,
                    viewCount: viewMore.viewCount + VIEW_COUNT,
                  });
                  setLoading(true);
                }}
              />
            )}
          </>
        )}
      </div>
      {/* 作成・編集・新規作成画面 */}
      {info.visible && (
        <TemplateBasic
          key={modalKey}
          closeModal={() => setInfo({ ...info, visible: false })}
          openModal={openModal}
          initialize={clear}
          promptData={info.promptData}
          mode={info.mode}
        />
      )}
    </div>
  );
};
