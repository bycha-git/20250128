import { z } from "zod";
import { TemplateModelSchema } from "../common/model/history/template-model";

export type PromptModel = z.infer<typeof PromptModelSchema>;

// 定数
export const VIEW_COUNT = 20;

/**
 * プロンプトテンプレートモデル
 */
export const PromptModelSchema = TemplateModelSchema;
