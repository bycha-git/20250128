"use server";
interface SearchTerms {
  text: string;
  sort?: string;
  tab: number;
}

export interface ViewMore {
  viewCount: number;
  visible: boolean;
}

interface MenuFlg {
  parentId: string;
  isAdmin: boolean;
}

/**権限チェック返却値 */
interface CheckResult {
  check: boolean;
  message: string;
  promptData?: PromptModel | undefined;
}

import { SqlQuerySpec } from "@azure/cosmos";
import { userHashedId } from "../auth-page/helpers";
import { checkAdmin } from "../common/checkAdmin";
import { getOnlyParsed } from "../common/schema-validation";
import { ServerActionResponse } from "../common/server-action-response";
import {
  DeleteAuthortyCompany,
  FindAuthorityCompanyByID,
  FindAuthorityCompanys,
  FindSelectAuthorityCompanyByID,
} from "../common/services/authority-company-service";
import {
  DeleteAuthortyEmployee,
  FindAuthorityEmployeeByID,
  FindAuthorityUsers,
  FindSelectAuthorityEmployeeByID,
} from "../common/services/authority-employee-service";
import { FindAuthorityID } from "../common/services/authority-service";
import { FindEmployeeByID } from "../common/services/employee-service";
import { PromptModel, PromptModelSchema } from "./Prompt-model";
import { HistoryContainer } from "@/features/common/services/cosmos";
import { uniqueId } from "@/features/common/util";

/** プロンプトテンプレート一覧と作成・編集・参照と分けたほうがいいかも */

/**
 * プロンプトテンプレート検索処理
 * @param searchText 検索ワード
 * @param sortValue 並べ順
 * @returns 結果:OK or ERROR
 */
export const FindPrompts = async (
  searchText: string,
  sortValue: string,
  count: number,
  promptId?: string[],
) => {
  try {
    // ソート順
    const sort =
      sortValue === "更新日順" ? "r.lastUpdateAt DESC" : "r.templateName ASC";

    // クエリ文字列の構築
    let query = `
      SELECT TOP @count *
      FROM root r
      WHERE r.type=@type
        AND (
          UPPER(r.templateName) LIKE UPPER(@searchText)
          OR UPPER(r.template) LIKE UPPER(@searchText)
        )
    `;

    // プロンプトIDの条件追加
    const parameters = [
      { name: "@type", value: "TEMPLATE" },
      { name: "@searchText", value: `%${searchText}%` },
      { name: "@count", value: count },
    ];

    // 対象プロンプトIDの配列が渡されているが、対象が0件な場合: 何も返さない
    if (promptId && promptId.length === 0) {
      return {
        status: "OK",
        response: [],
      };
    }

    // IN句に入れるプレースホルダーを生成
    if (promptId && promptId.length > 0) {
      const inClausePlaceholders = promptId
        .map((_, index) => `@id${index}`)
        .join(", ");
      query += ` AND r.id IN (${inClausePlaceholders})`;

      // 各プレースホルダーに対してパラメータを追加
      promptId.forEach((id, index) => {
        parameters.push({ name: `@id${index}`, value: id });
      });
    }

    // ソート順追加
    query += ` ORDER BY ${sort}`;

    const querySpec: SqlQuerySpec = { query, parameters };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<PromptModel>(querySpec)
      .fetchAll();

    // 返却値
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    // エラーハンドリング
    throw error;
  }
};

/**
 * プロンプトテンプレート新規登録処理
 * @param name テンプレート名
 * @param description テンプレート内容
 * @param userName ユーザ名
 * @returns 結果 OK or ERROR
 */
export const CreatePrompt = async (
  name: string,
  description: string,
  userName: string,
) => {
  try {
    // TODO idの登録方法
    // 登録内容
    const modelToSave: PromptModel = {
      id: uniqueId(),
      type: "TEMPLATE",
      userId: userName,
      createdAt: new Date().toString(),
      lastUpdateAt: new Date().toString(),
      lastUpdateUser: userName,
      numberOfChoices: 0,
      templateName: name,
      template: description,
    };

    // 登録
    const { resource } = await HistoryContainer().items.create(modelToSave);

    // 返却値
    if (resource) {
      return {
        status: "OK",
        response: resource,
      };
    } else {
      return {
        status: "ERROR",
        errors: [
          {
            message: "Error creating prompt",
          },
        ],
      };
    }
  } catch (error) {
    // 適当
    return {
      status: "ERROR",
      errors: [
        {
          message: `Error creating prompt: ${error}`,
        },
      ],
    };
  }
};

/**
 * プロンプトテンプレート削除処理
 * @param promptId 対象テンプレートID
 * @returns 結果 OK or ERROR
 */
export const DeletePrompt = async (promptId: string) => {
  try {
    // 削除対象のプロンプトテンプレートを取得
    const promptResponse = await FindPromptByID(promptId);

    if (promptResponse.status === "OK") {
      const { resource: deletedPrompt } = await HistoryContainer()
        .item(promptId, promptResponse.response.userId)
        .delete();

      return {
        status: "OK",
        response: deletedPrompt,
      };
    }
    return promptResponse;
  } catch (error) {
    throw error;
  }
};

/**
 * プロンプトテンプレート検索処理
 * @param id 検索対象テンプレートID
 * @returns 結果 OK or ERRPR
 */
export const FindPromptByID = async (
  id: string,
): Promise<ServerActionResponse<PromptModel>> => {
  try {
    // パラメータ
    const querySpec: SqlQuerySpec = {
      query: "SELECT * FROM root r WHERE r.type=@type AND r.id=@id",
      parameters: [
        {
          name: "@type",
          value: "TEMPLATE",
        },
        {
          name: "@id",
          value: id,
        },
      ],
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();

    const safeResources = getOnlyParsed(resources, PromptModelSchema);

    // 0件の場合
    if (safeResources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "Prompt not found",
          },
        ],
      };
    }

    return {
      status: "OK",
      response: safeResources[0],
    };
  } catch (error) {
    throw error;
  }
};

/**
 * プロンプトテンプレート更新処理
 * @param id 更新対象のテンプレートID
 * @param name 更新後の名前
 * @param description 更新後の中身
 * @param userName 更新者
 * @returns 更新結果
 */
export const UpdatePrompt = async (
  id: string,
  name: string,
  description: string,
  userName: string,
) => {
  try {
    const promptResponse = await FindPromptByID(id);

    if (promptResponse.status == "OK") {
      const modelToUpdate: PromptModel = {
        id: promptResponse.response.id,
        type: "TEMPLATE",
        userId: promptResponse.response.userId,
        createdAt: promptResponse.response.createdAt,
        lastUpdateAt: new Date().toString(),
        lastUpdateUser: userName,
        numberOfChoices: promptResponse.response.numberOfChoices,
        templateName: name,
        template: description,
      };

      const { resource } = await HistoryContainer().items.upsert(modelToUpdate);

      if (resource) {
        return {
          status: "OK",
          response: resource,
        };
      }

      return {
        status: "ERROR",
        errors: [
          {
            message: "更新エラー",
          },
        ],
      };
    }

    return promptResponse;
  } catch (error) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `更新処理でエラー: ${error}`,
        },
      ],
    };
  }
};

/**
 * fetchPrompts - プロンプト一覧を取得
 *
 * @returns プロンプトデータとメニューフラグ
 */
export const fetchPrompts = async (
  /** 検索条件 */
  searchTerms: SearchTerms,
  /** 表示件数情報 */
  viewMore: ViewMore,
) => {
  try {
    // タブの選択状態を取得
    const tabLabel = getTabLabel(searchTerms.tab);

    // 返却用viewMore
    const updatedViewMore = { ...viewMore };

    // 社員情報を取得
    const userId = (await userHashedId()).toString();
    const userResponse = await FindEmployeeByID(userId);
    if (!(userResponse && userResponse.status == "OK")) {
      return;
    }

    // ユーザーもしくはユーザーが所属する組織が管理者か（データがおかしい）
    const admin = await checkAdmin(userResponse.response!);

    // 権限情報を取得
    const authorityKind = await FindAuthorityID();

    // 共有のID取得
    const shareAuthorityKind = authorityKind.response.filter(
      (item) => item.value === "share",
    );

    const menuFlg: MenuFlg[] = [];
    let promptsResponse;

    if (authorityKind.response && authorityKind.status === "OK") {
      if (tabLabel !== "all") {
        // tabの選択状態で権限IDを取得
        const selectAuthorityKind =
          tabLabel === "homeAnyPermission"
            ? []
            : authorityKind.response.filter((item) => item.value === tabLabel);
        // 空であれば全権限が検索される
        const authorityValue = selectAuthorityKind[0]?.id || "";

        // 権限（ユーザー）から条件に該当するデータを取得
        const userParmission = await FindAuthorityEmployeeByID(
          userId,
          authorityValue,
        );

        // 権限（組織）から条件に該当するデータを取得
        const companyParmission = await FindAuthorityCompanyByID(
          userResponse.response?.department_code_8 ?? "",
          authorityValue,
        );
        // 権限（ユーザー）と権限（組織）からテンプレートIDを取得し重複を削除
        const templateId = Array.from(
          new Set([
            ...(userParmission.response?.map((item) => item.parentId) || []),
            ...(companyParmission.response?.map((item) => item.parentId) || []),
          ]),
        );

        // 指定された権限のデータを取得
        promptsResponse = await FindPrompts(
          searchTerms.text,
          searchTerms.sort || "",
          viewMore.viewCount + 1,
          templateId,
        );
      } else {
        // 権限に関係なく全件取得
        promptsResponse = await FindPrompts(
          searchTerms.text,
          searchTerms.sort || "",
          viewMore.viewCount + 1,
        );
      }

      // データ数が viewMore.viewCount より多い場合
      if (
        promptsResponse.response &&
        promptsResponse.response.length > viewMore.viewCount
      ) {
        // もっと見るボタンを表示
        updatedViewMore.visible = true;
        // データを1件削除
        promptsResponse.response.pop();
      } else {
        updatedViewMore.visible = false;
      }
      if (promptsResponse.response && tabLabel !== "homeAnyPermission") {
        for (const item of promptsResponse.response) {
          // 編集ボタン表示判定
          const employeeAuthority = await FindSelectAuthorityEmployeeByID(
            item.id,
            userId,
          );
          const companyAuthority = await FindSelectAuthorityCompanyByID(
            userResponse.response?.department_code_8 ?? "",
            item.id,
          );

          let employee = false;
          let company = false;

          // 権限（ユーザー）に共有以外の権限が設定されていればtrue
          if (
            employeeAuthority.response &&
            employeeAuthority.response?.length > 0
          ) {
            employee =
              employeeAuthority.response[0].permissionId !==
              shareAuthorityKind[0].id;
          }
          // 権限（組織）に共有以外の権限が設定されていればtrue
          if (
            companyAuthority.response &&
            companyAuthority.response?.length > 0
          ) {
            company = companyAuthority.response.some(
              (item) => item.permissionId !== shareAuthorityKind[0].id,
            );
          }

          const isOption = (admin.admin ?? false) || employee || company;
          menuFlg.push({
            parentId: item.id,
            isAdmin: isOption,
          });
        }
      } else if (!promptsResponse.response) {
        return;
      }
    }

    return { promptsResponse, menuFlg, viewMore: updatedViewMore };
  } catch (error) {
    throw error;
  }
};

/**
 * 存在権限チェック処理
 * @param promptId プロンプトId
 */
export const referenceOpen = async (
  promptId: string,
  adminCheckFlag = true,
): Promise<CheckResult> => {
  try {
    // 返却値
    const result: CheckResult = {
      check: true,
      message: "",
      promptData: undefined,
    };

    // 社員情報を取得
    const userId = (await userHashedId()).toString();

    // 社員情報とプロンプトテンプレート情報を取得
    const [userResponse, promptResponse] = await Promise.all([
      FindEmployeeByID(userId),
      FindPromptByID(promptId),
    ]);

    // 見つからない場合エラーを返す
    if (promptResponse.status == "NOT_FOUND") {
      result.check = false;
      result.message = "ETEMPLATE0001";
      return result;
    }
    if (promptResponse.status !== "OK") {
      result.check = false;
      result.message = "ECOMMON0001";
      return result;
    }
    result.promptData = promptResponse.response;

    // 所属する組織またはユーザーがYONDEN-GPT全体の権限も持っているかチェック
    if (!userResponse.response?.department_code_8) {
      result.check = false;
      result.message = "ECOMMON0001";
      return result;
    }
    const admin = await checkAdmin(userResponse.response);

    // 持っている場合処理を終了
    // 全体権限確認フラグがfalseの場合は続行
    if (adminCheckFlag && admin.admin) {
      return result;
    }

    // テンプレート権限チェック
    const [employeeResult, departmentResult] = await Promise.all([
      FindSelectAuthorityEmployeeByID(promptId, userId),
      FindSelectAuthorityCompanyByID(
        userResponse.response.department_code_8,
        promptId,
      ),
    ]);

    // ユーザー、ユーザーが属する組織両方に権限が設定されていない場合はエラーメッセージを返す
    if (
      employeeResult.status == "NOT_FOUND" &&
      departmentResult.status == "NOT_FOUND"
    ) {
      result.check = false;
      result.message = "ETEMPLATE0002";
      return result;
    }

    return result;
  } catch (error) {
    throw error;
  }
};

/**
 * プロンプトテンプレートに紐づく権限を削除
 */
export const DeleteAuthorty = async (promptId: string) => {
  try {
    // 権限（ユーザー）の取得
    const userAuthoritys = await FindAuthorityUsers(promptId);
    // 権限（組織）の取得
    const companyAuthority = await FindAuthorityCompanys(promptId);

    // idのみを取得
    const userAuthoritysId =
      userAuthoritys.response?.map((item) => item.id) || [];
    const companyAuthoritysId =
      companyAuthority.response?.map((item) => item.id) || [];

    // 権限（ユーザー）削除
    if (userAuthoritysId.length > 0) {
      await DeleteAuthortyEmployee(userAuthoritysId);
    }
    // 権限（組織）削除
    if (companyAuthoritysId.length > 0) {
      await DeleteAuthortyCompany(companyAuthoritysId);
    }
  } catch (error) {
    throw error;
  }
};

/**
 * 選択中のタブを文字列に変換
 * @param tab
 * @returns
 */
const getTabLabel = (tab: number) => {
  switch (tab) {
    case 1:
      return "admin";
    case 2:
      return "edit";
    case 3:
      return "share";
    case -1:
      // ホーム用 (いずれかの権限があるものを表示)
      return "homeAnyPermission";
    default:
      // 権限なしを含めて全件表示
      return "all";
  }
};
