"use client";

import React, { useEffect, useState } from "react";
import { showError } from "../globals/global-message-store";
import { LoadingIndicator } from "../ui/loading";
import SearchInput from "../ui/searchInput";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { PromptModel } from "./Prompt-model";
import {
  exclusionCheck,
  existenceCheck,
  getTemplateAuthority,
  initializingModal,
  searchAuthorityCompany,
  searchAuthorityUsers,
  templateInsert,
  templateUpsert,
} from "./PromptModal-service";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { Button } from "@/features/ui/button";
import ComboBox from "@/features/ui/combbox";
import { Input } from "@/features/ui/input";
import { Label } from "@/features/ui/label";
import { Separator } from "@/features/ui/separator";
import { Textarea } from "@/features/ui/textarea";
import {
  VerticalTabs,
  VerticalTabsContent,
  VerticalTabsList,
  VerticalTabsTrigger,
} from "@/features/ui/VerticalTabs";
import { Window } from "@/features/ui/window";

/** 画面間パラメータ */
interface TemplateBasicProps {
  closeModal: () => void;
  promptData: PromptModel;
  mode: string;
  openModal: (id: string, mode: string) => void;
  initialize: () => void;
}

/** 権限（ユーザー）画面表示用データ */
interface AuthorityEmployeeInfo {
  id: string | undefined;
  employeeName: string | undefined;
  permissionId: string | undefined;
  errFlg: boolean;
  errorMessageId?: string;
}

/** 権限（組織）画面表示用データ */
interface AuthorityCompanyInfo {
  id: string | undefined;
  departmentName: string | undefined;
  permissionId: string | undefined;
  errFlg: boolean;
  errorMessageId?: string;
}

/** 権限プルダウン用 */
interface AuthorityKind {
  id: string;
  label: string;
}

// タブ名称
const authorityTabs = [{ text: "組織" }, { text: "ユーザー" }];

/** TODO ログイン情報周り */
export const TemplateBasic = ({
  closeModal,
  openModal,
  initialize,
  promptData,
  mode,
}: TemplateBasicProps) => {
  // 登録/更新用 ユーザー名
  const [lastUpdateUser, setLastUpdateUser] = useState<string>("");
  // 選択対象のプロンプトテンプレート
  const [prompt, setPrompt] = useState<PromptModel>(promptData);
  // 管理者ID保持用
  const [adminId, setAdminId] = useState<string>();
  // テンプレート名エラー制御
  const [nameHighlight, setNameHighlight] = useState(false);
  // テンプレート説明エラー制御
  const [descriptionHighlight, setDescriptionHighlight] = useState(false);
  // 権限タブエラー表示
  const [authorityTabError, setAuthorityTabError] = useState(false);
  // 権限タブ.組織タブ表示データ
  const [authorityCompanyInfo, setAuthorityCompanyInfo] = useState<
    AuthorityCompanyInfo[]
  >([]);
  // 権限タブ.ユーザータブ表示データ
  const [authorityEmployeeInfo, setAuthorityEmployeeInfo] = useState<
    AuthorityEmployeeInfo[]
  >([]);
  // 初期の権限情報（組織）
  const [initialAuthorityCompanyInfo, setInitialAuthorityCompanyInfo] =
    useState<AuthorityCompanyInfo[]>([]);
  // 初期の権限情報（ユーザー）
  const [initialAuthorityEmployeeInfo, setInitialAuthorityEmployeeInfo] =
    useState<AuthorityEmployeeInfo[]>([]);
  // 最終更新日（編集画面のみ表示）
  const [titleText, setTitileText] = useState<string>("");
  // 権限プルダウン
  const [authority, setAuthority] = useState<AuthorityKind[]>([]);
  // 権限タブ　組織　ユーザー切り替え
  const [selectedTab, setSelectedTab] = useState(0);
  // 検索結果（組織）
  const [companySearchResults, setCompanySearchResults] = useState<
    AuthorityCompanyInfo[]
  >([]);
  // 検索結果（社員）
  const [employeeSearchResults, setEmployeeSearchResults] = useState<
    AuthorityEmployeeInfo[]
  >([]);
  // ローディングフラグ
  const [isLoading, setIsLoading] = useState(true);
  // エラーメッセージ
  const errMessage = useErrorMessage();

  // 画面起動時に初期化処理を呼び出す
  useEffect(() => {
    initialization();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- 初期表示のため
  }, []);

  /** 初期化処理 */
  const initialization = async () => {
    try {
      // 初期表示用データ（権限プルダウン、ユーザー情報）取得
      const initaliData = await initializingModal();
      setAuthority(initaliData?.dispData ?? []);
      // 管理者の権限を持つデータを検索
      const adminAuthority = initaliData?.dispData.find(
        (item) => item.label === "管理者",
      );

      // 管理者のIDを取得
      const adminPermissionId = adminAuthority?.id || "";
      setAdminId(adminPermissionId);
      setLastUpdateUser(initaliData?.userData.employeeName);
      if (mode === "新規") {
        // ユーザーを管理者で登録
        setAuthorityEmployeeInfo([
          {
            id: initaliData?.userData.id,
            employeeName: initaliData?.userData.employeeName,
            permissionId: adminPermissionId,
            errFlg: false,
          },
        ]);
      } else {
        // モーダル左上に表示する最終更新者
        setTitileText("最終更新者：" + prompt.lastUpdateUser);

        // プロンプトテンプレートに設定されている権限を取得
        const authoritys = await getTemplateAuthority(prompt.id);

        const authorityUser = authoritys?.usersData ?? [];
        const authorityCompany = authoritys?.companyData ?? [];

        setAuthorityEmployeeInfo((prev) => [...(authoritys?.usersData ?? [])]);
        setAuthorityCompanyInfo((prev) => [...(authoritys?.companyData ?? [])]);
        // 初期データ保持（削除判定用）
        setInitialAuthorityEmployeeInfo((prev) => [
          ...(authoritys?.usersData ?? []),
        ]);
        setInitialAuthorityCompanyInfo((prev) => [
          ...(authoritys?.companyData ?? []),
        ]);
        // ユーザー、組織存在チェック
        const users = authorityUser
          .map((item) => item.employeeName?.split(" ")[0])
          .filter((name): name is string => name !== undefined);
        const companies = authorityCompany
          .map((item) => item.departmentName?.split(" ")[0])
          .filter((name): name is string => name !== undefined);
        // 削除されているユーザー組織がないかチェック
        const checkResult = await existenceCheck(users, companies);

        // 削除されたユーザーにエラーアイコンを表示
        if (checkResult.deletedUsers.length > 0) {
          setAuthorityEmployeeInfo((prev) =>
            prev.map((item) => {
              const userId = item.employeeName?.split(" ")[0];
              if (checkResult.deletedUsers.includes(userId)) {
                return {
                  ...item,
                  errFlg: true,
                  errorMessageId: "ETEMPLATE0008",
                };
              }
              return item;
            }),
          );
          setAuthorityTabError(true);
        }

        // 削除された組織にエラーアイコンを表示
        if (checkResult.deletedCompanies.length > 0) {
          setAuthorityCompanyInfo((prev) =>
            prev.map((item) => {
              const companyId = item.departmentName?.split(" ")[0];
              if (checkResult.deletedCompanies.includes(companyId)) {
                return {
                  ...item,
                  errFlg: true,
                  errorMessageId: "ETEMPLATE0007",
                };
              }
              return item;
            }),
          );
          setAuthorityTabError(true);
        }
      }
      setIsLoading(false);
    } catch (error) {
      showError(errMessage["ECOMMON0001"]);
    }
  };

  /** モーダル開き直し */
  const reOpen = () => {
    closeModal();
    openModal(promptData.id, mode);
  };

  /** 一覧を初期化してモーダルを閉じる */
  const listRedraw = () => {
    initialize();
    closeModal();
  };

  /** 権限タブ×ボタン押下処理 */
  const deleteRow = (index: number) => {
    if (selectedTab === 0) {
      // 組織タブから行を削除
      setAuthorityCompanyInfo((prevState) => {
        return prevState.filter((_, i) => i !== index);
      });
    } else {
      // ユーザータブから行を削除
      setAuthorityEmployeeInfo((prevState) => {
        return prevState.filter((_, i) => i !== index);
      });
    }
  };

  /**
   * 権限タブ（コンボボックス変更時）
   */
  const combboxSelected = (selectedLabel: string, index: number) => {
    // authority 配列から選択されたラベルに対応するidを検索
    const selectedAuthority = authority.find(
      (item) => item.label === selectedLabel,
    );

    // 見つかった場合はそのidを設定
    const permissionId = selectedAuthority?.id || "";

    if (selectedTab === 0) {
      // 組織タブの場合
      setAuthorityCompanyInfo((prevState) => {
        const newAuthorityInfo = [...prevState];
        newAuthorityInfo[index].permissionId = permissionId;
        return newAuthorityInfo;
      });
    } else {
      // ユーザータブの場合
      setAuthorityEmployeeInfo((prevState) => {
        const newAuthorityInfo = [...prevState];
        newAuthorityInfo[index].permissionId = permissionId;
        return newAuthorityInfo;
      });
    }
  };

  /**
   * 検索処理
   */
  let activeRequest = 0;
  const search = async (searchText: string) => {
    activeRequest++;
    const currentRequest = activeRequest;

    if (!searchText.trim()) {
      selectedTab === 0
        ? setCompanySearchResults([])
        : setEmployeeSearchResults([]);
      return;
    }
    try {
      if (selectedTab === 0) {
        const srarchCompanyData =
          (await searchAuthorityCompany(searchText)) ?? [];
        if (currentRequest === activeRequest) {
          setCompanySearchResults(srarchCompanyData);
        }
      } else {
        const searchEmployeeData =
          (await searchAuthorityUsers(searchText)) ?? [];
        if (currentRequest === activeRequest) {
          setEmployeeSearchResults(searchEmployeeData);
        }
      }
    } catch (error) {
      showError(errMessage["ECOMMON0001"]);
    }
  };

  /**
   * 検索条件が選択されたときの処理
   */
  const selectItem = (item) => {
    if (selectedTab === 0) {
      // 既に追加されていないか確認
      if (
        !authorityCompanyInfo.some(
          (info) => info.departmentName === item.departmentName,
        )
      ) {
        setAuthorityCompanyInfo((prevState) => [
          ...prevState,
          { ...item, permissionId: adminId },
        ]);
      }
    } else {
      if (
        !authorityEmployeeInfo.some(
          (info) => info.employeeName === item.employeeName,
        )
      ) {
        setAuthorityEmployeeInfo((prevState) => [
          ...prevState,
          { ...item, permissionId: adminId },
        ]);
      }
    }
  };

  /**
   * 登録ボタン押下
   * @returns
   */
  const RegistClick = async () => {
    try {
      // 必須チェック
      // 管理者が設定されているか
      const companyAdmin = authorityCompanyInfo.some(
        (info) => info.permissionId === adminId,
      );
      const employeeAdmin = authorityEmployeeInfo.some(
        (info) => info.permissionId === adminId,
      );
      const adminResult = companyAdmin || employeeAdmin;

      if (adminResult) {
        // エラーがない場合エラーアイコンを削除
        setAuthorityTabError(false);

        setAuthorityCompanyInfo((prev) =>
          prev.map((item) => ({
            ...item,
            errFlg: false,
            errorMessageId: undefined,
          })),
        );

        setAuthorityEmployeeInfo((prev) =>
          prev.map((item) => ({
            ...item,
            errFlg: false,
            errorMessageId: undefined,
          })),
        );
      }
      const nameHighlight = prompt.templateName.trim() === "";
      const descriptionHighlight = prompt.template.trim() === "";

      // 必須チェックエラーがあった場合,登録処理は行わない
      if (nameHighlight || descriptionHighlight || !adminResult) {
        showError(errMessage["ETEMPLATE0005"]);

        setNameHighlight(nameHighlight);
        setDescriptionHighlight(descriptionHighlight);
        setAuthorityTabError(!adminResult);
        if (!adminResult) {
          setAuthorityTabError(true);

          // 組織の全てのデータにエラーアイコンを表示
          setAuthorityCompanyInfo((prev) =>
            prev.map((item) => ({
              ...item,
              errFlg: true,
              errorMessageId: "ETEMPLATE0004",
            })),
          );

          // ユーザーの全てのデータにエラーアイコンを表示
          setAuthorityEmployeeInfo((prev) =>
            prev.map((item) => ({
              ...item,
              errFlg: true,
              errorMessageId: "ETEMPLATE0004",
            })),
          );
          return;
        }
        return;
      }

      // 編集画面の場合のチェック
      if (mode == "編集") {
        const checkResult = await exclusionCheck(
          prompt.id,
          prompt.lastUpdateAt,
        );
        if (!checkResult?.check) {
          if (checkResult?.errkind === "1") {
            // 存在チェックエラーの場合　モーダルを閉じる
            showError(errMessage[checkResult?.message]);
            listRedraw();
          } else {
            // 排他チェックエラーの場合　モーダルを閉じる
            showError(errMessage[checkResult?.message]);
            reOpen();
          }

          return;
        }
      }

      // ユーザー、組織存在チェック
      const users = authorityEmployeeInfo
        .map((item) => item.employeeName?.split(" ")[0])
        .filter((name): name is string => name !== undefined);
      const companies = authorityCompanyInfo
        .map((item) => item.departmentName?.split(" ")[0])
        .filter((name): name is string => name !== undefined);

      const checkResult = await existenceCheck(users, companies);

      // 削除されたユーザーにエラーアイコンを表示
      if (checkResult.deletedUsers.length > 0) {
        setAuthorityEmployeeInfo((prev) =>
          prev.map((item) => {
            const userId = item.employeeName?.split(" ")[0];
            if (checkResult.deletedUsers.includes(userId)) {
              return { ...item, errFlg: true, errorMessageId: "ETEMPLATE0008" };
            }
            return item;
          }),
        );
      }

      // 削除された組織にエラーアイコンを表示
      if (checkResult.deletedCompanies.length > 0) {
        setAuthorityCompanyInfo((prev) =>
          prev.map((item) => {
            const companyId = item.departmentName?.split(" ")[0];
            if (checkResult.deletedCompanies.includes(companyId)) {
              return { ...item, errFlg: true, errorMessageId: "ETEMPLATE0007" };
            }
            return item;
          }),
        );
      }

      // 削除されたデータがある場合、エラーを表示して登録処理を中断
      if (
        checkResult.deletedUsers.length > 0 ||
        checkResult.deletedCompanies.length > 0
      ) {
        setAuthorityTabError(true);
        showError(errMessage["ETEMPLATE0009"]);
        return;
      }

      setAuthorityTabError(false);

      // 登録または更新処理
      if (mode === "新規") {
        await templateInsert(
          authorityCompanyInfo,
          authorityEmployeeInfo,
          prompt,
          lastUpdateUser,
        );
        closeModal();
      } else {
        // 削除対象の取得
        const deletedCompanyInfo = initialAuthorityCompanyInfo
          .filter(
            (initialItem) =>
              !authorityCompanyInfo.some(
                (currentItem) => currentItem.id === initialItem.id,
              ),
          )
          .map((item) => item.id)
          .filter((id): id is string => id !== undefined);

        const deletedEmployeeInfo = initialAuthorityEmployeeInfo
          .filter(
            (initialItem) =>
              !authorityEmployeeInfo.some(
                (currentItem) => currentItem.id === initialItem.id,
              ),
          )
          .map((item) => item.id)
          .filter((id): id is string => id !== undefined);

        // 更新処理・削除処理
        await templateUpsert(
          authorityCompanyInfo,
          authorityEmployeeInfo,
          prompt,
          deletedCompanyInfo,
          deletedEmployeeInfo,
          lastUpdateUser,
        );
        closeModal();
      }
    } catch (error) {
      throw error;
    }
  };

  return (
    <Window
      title={"テンプレート"}
      titleRightText={titleText}
      open={true}
      showClose={true}
      onOpenChange={closeModal}
      primaryButtonText={mode === "参照" ? undefined : "登録する"}
      secondaryButtonText={mode === "参照" ? "閉じる" : "キャンセルする"}
      onClickPrimary={mode === "参照" ? closeModal : RegistClick}
      onClickSecondary={closeModal}
      className="h-[520px] w-[800px]"
    >
      {isLoading ? (
        <div className="flex h-full w-full items-center justify-center">
          <LoadingIndicator isLoading={isLoading} />
        </div>
      ) : (
        <VerticalTabs
          defaultValue="基本情報"
          className="flex h-full min-h-0"
          orientation="vertical"
        >
          {/* タブリスト */}
          <VerticalTabsList className="text-black">
            <VerticalTabsTrigger
              value="基本情報"
              iconClass="i-material-symbols-settings-outline-rounded h-6 w-6"
              className={`mb-2 flex items-center text-base ${
                nameHighlight || descriptionHighlight ? "bg-red-100" : ""
              } data-[state=active]:${nameHighlight || descriptionHighlight ? "bg-red-100" : ""}`}
            >
              基本情報
              <span
                className={`i-material-symbols-warning-outline-rounded ml-auto h-5 w-5 text-red-500 ${
                  nameHighlight || descriptionHighlight
                    ? "visible"
                    : "invisible"
                }`}
              ></span>
            </VerticalTabsTrigger>
            <VerticalTabsTrigger
              value="権限"
              iconClass="i-tdesign-edit-2 h-6 w-6"
              className={`flex items-center text-base ${
                authorityTabError ? "bg-red-100" : ""
              } data-[state=active]:${authorityTabError ? "bg-red-100" : ""}`}
            >
              権限
              <span
                className={`i-material-symbols-warning-outline-rounded ml-auto h-5 w-5 text-red-500 ${
                  authorityTabError ? "visible" : "invisible"
                }`}
              ></span>
            </VerticalTabsTrigger>
          </VerticalTabsList>

          <div className="flex h-full min-h-0 w-full flex-1">
            <VerticalTabsContent value="基本情報" border={false}>
              <div className="flex h-full w-full flex-col gap-6">
                {/* 名前セクション */}
                <div className="flex w-full items-center gap-4">
                  {/* 名前ラベル */}
                  <Label
                    htmlFor="名前"
                    className="flex items-center whitespace-nowrap"
                  >
                    名前
                    <span className="i-material-symbols-asterisk-rounded h-3 w-3 bg-red-600" />
                    <div
                      className={`ml-1 flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1 ${
                        nameHighlight ? "visible" : "invisible"
                      }`}
                    >
                      <Button
                        icon="i-material-symbols-warning-outline-rounded text-red-500 h-4 w-4"
                        variant="icon"
                        onClick={() => showError(errMessage["ETEMPLATE0003"])}
                      />
                    </div>
                  </Label>

                  {/* 名前入力欄 */}
                  <Input
                    className="ml-auto w-[80%] rounded border border-gray-300 py-1"
                    placeholder="テンプレートの名前を記入してください"
                    onInputText={(e) =>
                      setPrompt({
                        ...prompt,
                        templateName: e,
                      })
                    }
                    value={prompt.templateName}
                    disabled={mode === "参照"}
                    maxLength={50}
                  />
                </div>

                <Separator />

                <div className="flex h-full items-start gap-4">
                  {/* 説明ラベル */}
                  <Label
                    htmlFor="description"
                    className="flex items-center gap-2 whitespace-nowrap"
                  >
                    {/* 説明テキスト部分 */}
                    <div className="flex flex-col">
                      <span>テンプレート文</span>
                      <span>（1,000文字まで）</span>
                    </div>
                    <span className="i-material-symbols-asterisk-rounded h-3 w-3 bg-red-600" />
                    <div
                      className={`flex h-6 w-6 items-center justify-center rounded bg-red-200 ${
                        descriptionHighlight ? "visible" : "invisible"
                      }`}
                    >
                      <Button
                        icon="i-material-symbols-warning-outline-rounded text-red-500 h-5 w-5"
                        variant="icon"
                        onClick={() => showError(errMessage["ETEMPLATE0003"])}
                      />
                    </div>
                  </Label>

                  {/* 説明入力欄 */}
                  <Textarea
                    className="h-[80%] flex-1 rounded border border-gray-300 py-2"
                    placeholder="テンプレートを記入してください"
                    onInputText={(e) =>
                      setPrompt({
                        ...prompt,
                        template: e,
                      })
                    }
                    value={prompt.template}
                    disabled={mode === "参照"}
                    maxLength={1000}
                  />
                </div>
              </div>
            </VerticalTabsContent>

            <VerticalTabsContent value="権限" className="min-h-0">
              <div className="flex min-h-0 w-full flex-col">
                <div className="flex items-center">
                  {authorityTabs.map((button, index) => (
                    <Button
                      key={index}
                      color="default"
                      text={button.text}
                      onClick={() => setSelectedTab(index)}
                      className={`${
                        selectedTab === index ? "bg-gray-200" : "bg-white"
                      } rounded-md px-4 py-2 font-bold text-black hover:bg-gray-100`}
                    />
                  ))}
                </div>

                <SearchInput
                  placeholder={
                    mode === "参照"
                      ? ""
                      : selectedTab === 0
                        ? "権限を付与する組織を選択してください"
                        : "権限を付与するユーザーを選択してください"
                  }
                  onSearch={search}
                  searchResults={
                    selectedTab === 0
                      ? companySearchResults
                      : employeeSearchResults
                  }
                  idField={
                    selectedTab === 0 ? "departmentName" : "employeeName"
                  }
                  textField={
                    selectedTab === 0 ? "departmentName" : "employeeName"
                  }
                  onSelectItem={selectItem}
                  className="mt-2 w-[70%]"
                  selectedItems={
                    selectedTab === 0
                      ? authorityCompanyInfo
                      : authorityEmployeeInfo
                  }
                  noResultText={
                    selectedTab === 0 ? "該当組織なし" : "該当ユーザーなし"
                  }
                  disabled={mode === "参照"}
                />
                <div className="mt-1.5 min-h-0 w-full overflow-auto">
                  <Table className="min-h-0">
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[48%]">名前</TableHead>
                        <TableHead className="w-[0%]"></TableHead>
                        <TableHead className="w-[35%]">権限</TableHead>
                        <TableHead className="w-[0%]"></TableHead>
                      </TableRow>
                    </TableHeader>
                    {selectedTab === 0 ? (
                      <TableBody>
                        {authorityCompanyInfo.map((item, index) => (
                          <TableRow key={`${item.id}-${index}`}>
                            <TableCell
                              className="p-2 align-middle"
                              title={item.departmentName}
                            >
                              <div className="line-clamp-2 leading-normal">
                                {item.departmentName}
                              </div>
                            </TableCell>
                            <TableCell className="py-0.5">
                              {!item.errFlg ? (
                                <div className="h-6 w-full" />
                              ) : (
                                <Button
                                  icon="i-material-symbols-warning-outline-rounded text-red-500 h-5 w-5"
                                  variant="icon"
                                  className="flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1"
                                  onClick={() =>
                                    showError(errMessage[item.errorMessageId])
                                  }
                                />
                              )}
                            </TableCell>

                            <TableCell className="py-0.5">
                              <ComboBox
                                items={authority}
                                idField="id"
                                textField="label"
                                className="w-full text-sm"
                                selectedItem={
                                  authority.find(
                                    (auth) => auth.id === item.permissionId,
                                  )?.label || ""
                                }
                                onSelectText={(value) => {
                                  combboxSelected(value, index);
                                }}
                                disabled={mode === "参照"}
                              />
                            </TableCell>

                            <TableCell className="py-0.5 text-right">
                              {mode !== "参照" && (
                                <Button
                                  icon="i-material-symbols-close-small-rounded h-5 w-5"
                                  variant="icon"
                                  onClick={() => deleteRow(index)}
                                />
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    ) : (
                      <TableBody>
                        {authorityEmployeeInfo.map((item, index) => (
                          <TableRow key={`${item.id}-${index}`}>
                            <TableCell
                              className="p-2 align-middle"
                              title={item.employeeName}
                            >
                              <div className="line-clamp-2 leading-normal">
                                {item.employeeName}
                              </div>
                            </TableCell>

                            <TableCell className="py-0.5">
                              {!item.errFlg ? (
                                <div className="h-6 w-full" />
                              ) : (
                                <Button
                                  icon="i-material-symbols-warning-outline-rounded text-red-500 h-5 w-5"
                                  variant="icon"
                                  className="flex h-6 w-6 items-center justify-center rounded bg-red-200 p-1"
                                  onClick={() =>
                                    showError(errMessage[item.errorMessageId])
                                  }
                                />
                              )}
                            </TableCell>

                            <TableCell className="py-0.5">
                              <ComboBox
                                items={authority}
                                idField="id"
                                textField="label"
                                className="w-full text-sm"
                                selectedItem={
                                  authority.find(
                                    (auth) => auth.id === item.permissionId,
                                  )?.label || ""
                                }
                                onSelectText={(value) => {
                                  combboxSelected(value, index);
                                }}
                                disabled={mode === "参照"}
                              />
                            </TableCell>

                            <TableCell className="py-0.5 text-right">
                              {mode !== "参照" && (
                                <Button
                                  icon="i-material-symbols-close-small-rounded h-5 w-5"
                                  variant="icon"
                                  onClick={() => deleteRow(index)}
                                />
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    )}
                  </Table>
                </div>
              </div>
            </VerticalTabsContent>
          </div>
        </VerticalTabs>
      )}
    </Window>
  );
};
