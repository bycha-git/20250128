import { cva } from "class-variance-authority";
import { PropsWithChildren } from "react";

interface Props extends PropsWithChildren {
  /** ファイル名 */
  name: string;
  /** タイプ */
  type: "file" | "image";
  /** URL。指定した場合クリックでダウンロード可能になる */
  src?: string;
}

const attachmentIconVariants = cva("relative h-6 w-6", {
  variants: {
    type: {
      file: "i-material-symbols-attach-file-rounded",
      image: "i-material-symbols-imagesmode-outline-rounded",
    },
  },
});

export const ChatMessageAttachment = ({ src, name, type, children }: Props) => {
  return (
    <div className="m-1 inline-flex h-fit items-center gap-2 rounded-md bg-gray-01 p-1">
      <div className={attachmentIconVariants({ type })} />
      {src && (
        <a
          className="inline-block flex-1 break-all pr-2 text-sm"
          href={src}
          target="_blank"
        >
          {name}
        </a>
      )}
      {!src && <div className="flex-1 break-all text-sm">{name}</div>}
      {children}
    </div>
  );
};
