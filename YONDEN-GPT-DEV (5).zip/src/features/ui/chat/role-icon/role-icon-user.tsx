import { cn } from "../../lib";

interface Props {
  className?: string;
}

export const RoleIconUser = ({ className }: Props) => {
  return (
    <span
      className={cn("relative h-6 w-6 rounded-[25%] bg-orange-03", className)}
    >
      <span className={cn("i-bx-user h-full w-full bg-white")} />
    </span>
  );
};
