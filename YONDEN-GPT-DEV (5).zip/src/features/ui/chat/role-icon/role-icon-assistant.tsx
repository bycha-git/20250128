import Image from "next/image";
import { cn } from "../../lib";
import yondenLogo from "@/image/yonden-logo.png";

interface Props {
  className?: string;
}

export const RoleIconAssistant = ({ className }: Props) => {
  return (
    <Image
      className={cn(
        "aspect-square h-6 w-6 rounded-[25%] bg-white object-contain",
        className,
      )}
      src={yondenLogo}
      alt=""
      width={48}
      quality={100}
    />
  );
};
