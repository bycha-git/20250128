import { MouseEventHandler } from "react";

interface Props {
  /** 画像のURL */
  src: string;
  /** 画像のalt */
  alt?: string;
  className?: string;
}

export const ChatMessageImage = (props: Props) => {
  const imgClick: MouseEventHandler<HTMLImageElement> = async (evt) => {
    // 親のダウンロード処理は発動しない
    evt.stopPropagation();
    const target = evt.target;
    if (target instanceof HTMLImageElement && target.src) {
      const a = document.createElement("a");
      a.href = target.src;
      // download 属性は同じオリジン（ドメイン）またはblob URLでしか発動しない
      // https://developer.mozilla.org/ja/docs/Web/HTML/Element/a#download
      a.download = "";
      a.click();
    }
  };

  return (
    // 画像をそのまま右クリックでダウンロードしたいため、最適化等を行わない
    // eslint-disable-next-line @next/next/no-img-element
    <img
      className={props.className}
      src={props.src}
      alt={props.alt}
      onClick={imgClick}
      // memo: tabindex を付けただけではキーボードでclickできない
      tabIndex={0}
    />
  );
};
