import * as Popover from "@radix-ui/react-popover";
import React, { useEffect, useState } from "react";
import { countWord } from "../common/countWord";

/**
 * items 表示するアイテム
 * placeholder プレースホルダーなければ items の先頭の text を表示
 * className 任意のクラスを設定
 * onSelectItem 現在選択しているアイテムを返す
 * icon アイコンのクラス名を文字列として渡す（任意）
 * selectedItems 外部から渡された選択済みの text の配列
 * idField IDのフィールド名
 * textField テキストのフィールド名
 */
interface CheckedCombBoxProps<T> {
  items: T[];
  placeholder?: string;
  className?: string;
  onSelectItem?: (selectedItems: T[]) => void;
  icon?: string;
  selectedItems?: T[];
  idField: keyof T;
  textField: keyof T;
}

const CheckedCombBox = <T extends object>({
  items,
  placeholder,
  className,
  onSelectItem,
  icon,
  selectedItems: propSelectedItems,
  idField,
  textField,
}: CheckedCombBoxProps<T>) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedItems, setSelectedItems] = useState<T[]>(
    propSelectedItems || [],
  );
  const selectedItemIds = selectedItems.map((item) => item[idField]);

  useEffect(() => {
    setSelectedItems(propSelectedItems || []);
  }, [propSelectedItems]);

  const selectItems = (item: T) => {
    const updatedItems = selectedItemIds.includes(item[idField])
      ? selectedItems.filter(
          (selectedItem) => selectedItem[idField] !== item[idField],
        )
      : [...selectedItems, item];
    setSelectedItems(updatedItems);
    if (onSelectItem) {
      onSelectItem(updatedItems);
    }
  };

  return (
    <div className={`relative inline-block ${className}`}>
      <Popover.Root open={isOpen} onOpenChange={setIsOpen}>
        <Popover.Trigger asChild>
          <button className="flex w-full cursor-pointer items-center justify-between rounded-md border border-gray-300 bg-white px-4 py-2 text-left text-gray-800">
            <span className="opacity-50">{placeholder}</span>
            <span className="ml-2">
              <i
                className={
                  icon ||
                  (isOpen
                    ? "i-material-symbols-keyboard-arrow-up-rounded"
                    : "i-material-symbols-keyboard-arrow-down-rounded")
                }
              />
            </span>
          </button>
        </Popover.Trigger>
        <Popover.Content
          className="z-10 max-h-40 w-full overflow-y-auto rounded-md border border-gray-300 bg-white p-0 shadow-lg"
          sideOffset={5}
          align="start"
          onOpenAutoFocus={(e) => e.preventDefault()}
        >
          <div className="m-0 list-none p-0">
            {items.map((item) => (
              <label
                key={String(item[idField])}
                className="flex cursor-pointer items-center px-4 py-2 text-gray-800"
              >
                <input
                  type="checkbox"
                  checked={selectedItemIds.includes(item[idField])}
                  onChange={() => selectItems(item)}
                  className="mr-2 h-4 w-4 border focus:ring-0 focus:ring-offset-0"
                />
                {countWord(String(item[textField]), 15)}
              </label>
            ))}
          </div>
        </Popover.Content>
      </Popover.Root>
    </div>
  );
};

export default CheckedCombBox;
