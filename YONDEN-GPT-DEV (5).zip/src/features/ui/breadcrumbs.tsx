import React from "react";

interface BreadcrumbItem {
  label: string;
  id: string;
}

interface BreadcrumbsProps {
  items: BreadcrumbItem[];
  onClick: (id: string) => void;
  className?: string;
}

const Breadcrumbs: React.FC<BreadcrumbsProps> = ({ items, onClick }) => {
  return (
    <nav className="flex items-center space-x-2 text-sm text-black">
      {items.map((item, index) => (
        <span key={item.id} className="flex items-center">
          <div
            className="cursor-pointer hover:underline"
            onClick={() => onClick(item.id)}
          >
            {item.label}
          </div>
          {index < items.length - 1 && <span className="mx-1">{">"}</span>}
        </span>
      ))}
    </nav>
  );
};

export default Breadcrumbs;
