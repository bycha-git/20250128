import { FC } from "react";

interface Props {
  isLoading: boolean;
}

export const LoadingIndicator: FC<Props> = (props) => {
  if (!props.isLoading) return null;

  return (
    <span
      aria-label="読み込み中"
      className="i-material-symbols-progress-activity h-6 w-6 animate-spin"
    />
  );
};
