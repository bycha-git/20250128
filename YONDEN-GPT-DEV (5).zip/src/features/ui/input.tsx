import * as React from "react";
import { cn } from "@/ui/lib";

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  /**type */
  type?: string;
  /** アイコンクラスを渡すと右端に表示される */
  icon?: string;
  /** アイコンクラスを渡すとクリアボタンを表示する */
  removeIcon?: string;
  /** アイコンクラスを渡すと検索ボタンを表示する */
  serchIcon?: string;
  /** 検索ボタンが押されたときのイベント */
  onSearch?: () => void;
  /** 現在の文字列を返す */
  onInputText?: (value: string) => void;
  /** クリアボタンが押されたときのイベント */
  onClear?: () => void;
  /** 初期表示文字列 */
  text?: string | number;
  /**非活性 */
  disabled?: boolean;
  /** 半角数字のみ入力可能にする */
  numberOnly?: boolean;
  /** 最大文字数 */
  maxLength?: number;
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  (
    {
      className,
      type = "text",
      icon,
      placeholder,
      removeIcon,
      serchIcon,
      onSearch,
      onInputText,
      onClear,
      text = "",
      disabled = false,
      numberOnly = false,
      maxLength,
      ...props
    },
    ref,
  ) => {
    const [inputValue, setInputValue] = React.useState(text);

    // textの変更を監視してinputValueを更新
    React.useEffect(() => {
      setInputValue(text);
    }, [text]);

    // アイコンやボタンが存在するかをチェック
    const hasRightElement = icon || removeIcon || serchIcon;

    const clear = () => {
      setInputValue("");
      if (ref && typeof ref === "object" && ref.current) {
        ref.current.value = ""; // 値をクリア
      }
      if (onInputText) {
        onInputText(""); // 親コンポーネントにクリア通知
      }
      if (onClear) {
        onClear(); // クリアボタンが押されたことを通知
      }
    };

    const inputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      let value = e.target.value;

      // 半角数字のみの場合、入力を制限
      if (numberOnly) {
        const regex = /^[0-9]*$/;
        if (!regex.test(value)) {
          return; // 数字以外の入力を無視
        }
      }

      // 最大文字数を超える場合は切り詰める
      if (maxLength && value.length > maxLength) {
        value = value.slice(0, maxLength);
      }

      setInputValue(value);
      if (onInputText) {
        onInputText(value); // 親コンポーネントに現在の文字列を渡す
      }
    };

    const enterKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === "Enter") {
        search();
      }
    };

    const search = () => {
      if (onSearch) {
        onSearch();
      }
    };

    return (
      <div className="relative flex w-full items-center">
        <input
          type={type}
          placeholder={placeholder}
          value={inputValue}
          disabled={disabled}
          onChange={inputChange}
          onKeyDown={enterKeyDown}
          className={cn(
            "box-border flex h-10 rounded-md border border-input bg-white px-3 py-2 text-sm",
            hasRightElement ? "pr-10" : "",
            disabled && "opacity-50",
            className,
          )}
          ref={ref}
          {...props}
        />
        {icon && (
          <span
            className={`absolute inset-y-1 right-3 mt-0.5 flex items-center ${icon} text-black`}
          />
        )}
        {removeIcon && (
          <button
            type="button"
            className={`absolute inset-y-1 right-16 flex items-center ${removeIcon} text-black`}
            onClick={clear}
          ></button>
        )}
        {serchIcon && (
          <button
            type="button"
            className={`absolute inset-y-1 right-2 flex items-center ${serchIcon} text-black`}
            onClick={search}
          ></button>
        )}
      </div>
    );
  },
);
Input.displayName = "Input";

export { Input };
