"use client";

import { PropsWithChildren, ReactNode, useCallback } from "react";
import { cn } from "./lib";
import { Window } from "./window";

interface Props extends PropsWithChildren {
  /** ウィンドウタイトル */
  title?: string;
  /** ウィンドウタイトルの右に表示される文字列 */
  titleRightText?: string;
  /** 色付きの主ボタンに表示される文字列 */
  okButtonText?: ReactNode;
  /** 色なしの副ボタンに表示される文字列 */
  cancelButtonText?: ReactNode;
  /** 表示中かどうか */
  open: boolean;
  /** 表示中かどうかの状態が切り替わった */
  onOpenChange: (open: boolean) => void;
  /** 主ボタンがクリックされた */
  onClickOk: () => void | Promise<void>;
  /** 副ボタンがクリックされた */
  onClickCancel?: () => void | Promise<void>;
  className?: string;
}

/** タイトル省略時にアクセシビリティ的に使うタイトル */
const DEFAULT_HIDDEN_TITLE = "確認";

/**
 * 確認ウィンドウ
 *
 * - 通常の Window と違い、必ず閉じるボタンを表示せず、ダイアログ外クリック等でのウィンドウ閉じも行えない。
 */
export const ConfirmWindow = ({
  title,
  children,
  okButtonText = "OK",
  cancelButtonText = "キャンセル",
  open,
  onOpenChange,
  onClickOk,
  onClickCancel,
  className,
}: Props) => {
  const onClickPrimary = useCallback(() => {
    const res = onClickOk();
    if (res instanceof Promise) {
      return res.finally(() => onOpenChange(false));
    } else {
      onOpenChange(false);
    }
  }, [onClickOk, onOpenChange]);
  const onClickSecondary = useCallback(() => {
    const res = onClickCancel?.();
    if (res instanceof Promise) {
      return res.finally(() => onOpenChange(false));
    } else {
      onOpenChange(false);
    }
  }, [onClickCancel, onOpenChange]);
  return (
    <Window
      title={title || DEFAULT_HIDDEN_TITLE}
      hiddenTitle={!title}
      primaryButtonText={okButtonText}
      secondaryButtonText={cancelButtonText}
      open={open}
      onOpenChange={onOpenChange}
      showClose={false}
      closedBehavior="none"
      onClickPrimary={onClickPrimary}
      onClickSecondary={onClickSecondary}
      className={cn("w-fit min-w-96 max-w-xl whitespace-pre-line", className)}
    >
      {children}
    </Window>
  );
};
