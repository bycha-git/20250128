import { FC, useActionState } from "react";
import { ScrollArea } from "../scroll-area";
import { useMarkdownContext } from "./markdown-context";
import { Button } from "@/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/ui/sheet";

interface SliderProps {
  name: string;
  index: number;
  id: string;
}

export const CitationSlider: FC<SliderProps> = (props) => {
  const { onCitationClick } = useMarkdownContext();

  if (!onCitationClick) throw new Error("onCitationClick is null");

  const [node, formAction] = useActionState(onCitationClick, null);

  return (
    <form>
      <input type="hidden" name="id" value={props.id} />
      <Sheet>
        <SheetTrigger asChild>
          <Button
            variant="outline"
            size="sm"
            formAction={formAction}
            type="submit"
          >
            {props.index}
          </Button>
        </SheetTrigger>
        <SheetContent className="flex min-w-[480px] flex-col sm:w-[540px]">
          <SheetHeader>
            <SheetTitle>Citation</SheetTitle>
          </SheetHeader>
          <ScrollArea className="-mx-6 flex flex-1">
            <div className="whitespace-pre-wrap px-6">{node}</div>
          </ScrollArea>
        </SheetContent>
      </Sheet>
    </form>
  );
};
