import { Schema as MarkdocSchema } from "@markdoc/markdoc";

export const Details = ({
  children,
  filename,
}: {
  children: React.ReactNode;
  filename: string;
}) => {
  return (
    <details>
      <summary>{filename ?? "ファイル"}</summary>
      {children}
    </details>
  );
};

export const attachmentFile: MarkdocSchema = {
  render: "Details",
  attributes: {
    filename: { required: false, type: String },
  },
  children: ["paragraph"],
};
