import { Config as MarkdocConfig, Tag as MarkdocTag } from "@markdoc/markdoc";
import { fence } from "./code-block";
import { attachmentFile } from "./details";
import { paragraph } from "./paragraph";

export const simpleConfig: MarkdocConfig = {
  nodes: {
    paragraph,
    fence,
    // 単純な改行を <br> に変換
    // https://github.com/markdoc/markdoc/discussions/338
    softbreak: {
      transform: () => new MarkdocTag("br"),
    },
  },
  tags: {
    "attachment-file": attachmentFile,
  },
};
