import * as Markdoc from "@markdoc/markdoc";
import React, { FC } from "react";
import { CodeBlock } from "./code-block";
import { simpleConfig } from "./config-simple";
import { Details } from "./details";
import { Paragraph } from "./paragraph";

interface Props {
  content: string;
}

export const MarkdownSimple: FC<Props> = (props) => {
  const ast = Markdoc.parse(props.content);

  const content = Markdoc.transform(ast, {
    ...simpleConfig,
  });

  const WithContext = () => (
    <>
      {Markdoc.renderers.react(content, React, {
        components: {
          Paragraph,
          CodeBlock,
          Details,
        },
      })}
    </>
  );

  return <WithContext />;
};
