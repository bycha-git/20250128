import { cva } from "class-variance-authority";
import { cn } from "./lib";

interface Props {
  className?: string;
  /** アイコン種類 */
  variant: "newModelChat" | "newChatbotChat" | "profile";
}

const mobileMenuIconInsideVariants = cva("h-full w-full bg-white", {
  variants: {
    variant: {
      newModelChat: "i-material-symbols-add",
      newChatbotChat: "i-material-symbols-chat-add-on-outline-rounded",
      profile: "i-bx-user",
    },
  },
});

export const MobileMenuIcon = ({ className, variant }: Props) => {
  return (
    <span
      className={cn("relative h-5 w-5 rounded-[25%] bg-black-01", className)}
    >
      <span className={mobileMenuIconInsideVariants({ variant })} />
    </span>
  );
};
