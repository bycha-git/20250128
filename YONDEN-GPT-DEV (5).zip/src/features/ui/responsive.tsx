"use client";

import dynamic from "next/dynamic";
import { useResponsive as useResponsiveHook } from "@/hooks/use-responsive";

/**
 * PC/モバイル間でJS側の処理を切り替える場合に用いるHooks
 * - ※ 新規の場合は `hooks` フォルダ内のものを使ってください
 *   - 最終的には一斉に置き換えるので、現状使っているものを手動で置き換える必要はありません
 */
// TODO: src/hooks/use-responsive.tsx に一本化 (import 構造の都合上)
export const useResponsive = useResponsiveHook;

/** 子要素がPCでのみ表示されるコンポーネント */
// Hydration Error 対策
// https://github.com/yocontra/react-responsive/blob/v10.0.0/README.md#server-side-rendering
export const ForDesktop = dynamic(
  () => import("./responsive-internal").then((mod) => mod.ForDesktopInternal),
  {
    // TODO: 要検討
    // - 現状は真っ白になる。外での Suspense は効かなさそう
    // - 全部に loading を当てはめると、画面によってはローディングスピナーが複数表示される
    // loading: () => <PageLoader />,
    ssr: false,
  },
);

/** 子要素がモバイルでのみ表示されるコンポーネント */
export const ForMobile = dynamic(
  () => import("./responsive-internal").then((mod) => mod.ForMobileInternal),
  {
    // loading: () => <PageLoader />,
    ssr: false,
  },
);
