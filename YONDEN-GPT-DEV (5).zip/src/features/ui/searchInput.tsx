import * as Popover from "@radix-ui/react-popover";
import React, { useEffect, useState } from "react";
import { cn } from "./lib";

interface SearchInputProps<T> {
  /** プレースホルダー */
  placeholder?: string;
  /** レイアウト */
  className?: string;
  /** 検索結果からデータを選択したときに呼び出される */
  onSelectItem?: (selectedItem: T) => void;
  /** 現在選択されているデータ */
  selectedItems?: T[];
  /** 入力値を返す */
  onSearch?: (query: string, searchLimit: number) => Promise<void> | void;
  /** 検索結果として表示するデータ */
  searchResults?: T[];
  /** データの識別フィールド名 */
  idField: keyof T;
  /** データの表示フィールド名 */
  textField: keyof T;
  /** 最大入力桁数 */
  maxLength?: number;
  /** 検索結果がない場合に表示するテキスト */
  noResultText?: string;
  /** 初期状態での検索結果の最大表示件数 */
  initialSearchLimit?: number;
  /** 無効化フラグ */
  disabled?: boolean;
}

const SearchInput = <T extends object>({
  placeholder,
  className,
  onSelectItem,
  selectedItems,
  onSearch,
  searchResults = [],
  idField,
  textField,
  maxLength,
  noResultText,
  initialSearchLimit = 20,
  disabled = false,
}: SearchInputProps<T>) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchConditions, setSearchConditions] = useState("");
  const [searchLimit, setSearchLimit] = useState(initialSearchLimit);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setSearchLimit(initialSearchLimit);
    }
  }, [initialSearchLimit, isOpen]);

  const select = (item: T) => {
    if (disabled) return;
    if (onSelectItem) {
      onSelectItem(item);
    }
  };

  const searchChange = async (query: string) => {
    if (disabled) return;
    setSearchConditions(query);

    if (onSearch) {
      setIsLoading(true);
      await onSearch(query, searchLimit);
      setIsLoading(false);
    }

    if (!isOpen) {
      setIsOpen(true);
    }
  };

  const scrollBottom = async () => {
    if (disabled) return;
    if (searchResults.length > searchLimit) {
      setSearchLimit((prev) => prev + initialSearchLimit);
      if (onSearch) {
        await onSearch(searchConditions, searchLimit + initialSearchLimit);
      }
    }
  };

  return (
    <Popover.Root open={!disabled && isOpen} onOpenChange={setIsOpen}>
      {/* 検索欄 */}
      <Popover.Trigger asChild>
        <div className={`relative inline-block ${className}`}>
          <input
            type="text"
            value={searchConditions}
            onChange={(e) => searchChange(e.target.value)}
            placeholder={placeholder}
            className={cn(
              "w-full rounded-md border border-gray-300 px-3 py-2 pr-10 focus:outline-none focus:ring focus:ring-indigo-200",
              disabled && "opacity-50",
            )}
            onClick={() => {
              if (!disabled) setIsOpen(true);
            }}
            maxLength={maxLength}
            disabled={disabled}
          />
          <span className="absolute right-4 top-3">
            <i className={"i-material-symbols-search-rounded"} />
          </span>
        </div>
      </Popover.Trigger>

      {/* プルダウン（検索結果を表示） */}
      {!disabled && (
        <Popover.Portal>
          <Popover.Content
            className="z-50 max-h-40 w-full overflow-y-auto rounded-md border border-gray-300 bg-white p-0 shadow-lg"
            sideOffset={5}
            align="start"
            onOpenAutoFocus={(e) => e.preventDefault()}
            onWheel={(e) => e.stopPropagation()}
            onScroll={(e) => {
              const target = e.target as HTMLElement;
              if (
                target.scrollHeight - target.scrollTop <=
                target.clientHeight
              ) {
                scrollBottom();
              }
            }}
          >
            <div className="m-0 list-none p-0">
              {isLoading ? (
                <div className="px-4 py-2 text-gray-500">検索中...</div>
              ) : searchConditions.trim() === "" ? null : searchResults.length >
                0 ? (
                searchResults.map(
                  (item, i) =>
                    i < searchLimit && (
                      <div
                        key={String(item[idField])}
                        className="flex cursor-pointer items-center px-4 py-2 hover:bg-gray-100"
                        onClick={() => select(item)}
                      >
                        <span
                          className="flex-1"
                          title={String(item[textField])}
                        >
                          {String(item[textField])}
                        </span>
                        {selectedItems &&
                          selectedItems.some(
                            (selectedItem) =>
                              String(selectedItem[idField]) ===
                              String(item[idField]),
                          ) && (
                            <i className="i-material-symbols-check-small-rounded ml-2 h-5 w-5" />
                          )}
                      </div>
                    ),
                )
              ) : (
                <div className="px-4 py-2 text-gray-500">
                  {noResultText || "検索結果がありません"}
                </div>
              )}
            </div>
          </Popover.Content>
        </Popover.Portal>
      )}
    </Popover.Root>
  );
};

export default SearchInput;
