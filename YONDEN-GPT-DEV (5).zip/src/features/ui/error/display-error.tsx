"use client";

import { FC, useEffect } from "react";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { showError } from "@/features/globals/global-message-store";

export const DisplayError: FC<{ errors: Array<{ message: string }> }> = (
  props,
) => {
  const errMessage = useErrorMessage();
  useEffect(() => {
    for (const err of props.errors) {
      showError(errMessage[err.message]);
    }
  }, [errMessage, props.errors]);

  return <div />;
};
