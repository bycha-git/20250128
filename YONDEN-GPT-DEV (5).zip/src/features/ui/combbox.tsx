import * as Popover from "@radix-ui/react-popover";
import React, { useEffect, useState } from "react";
import { cn } from "./lib";

/**
 * ComboBox コンポーネント
 * items 表示するアイテムのリスト
 * placeholder プレースホルダー
 * className クラス名
 * onSelectText 選択したテキストの配列を返す
 * onSelectId 選択したIDの配列を返す
 * icon アイコンのクラス名（任意）
 * selectedItems 外部で管理される選択済みのアイテムのテキスト
 * idField オブジェクトのIDフィールド名
 * textField オブジェクトのテキストフィールド名
 * disabled 活性非活性を制御
 * maxDisplayLength 最大表示桁数（超えたら…を表示）
 */

interface ComboBoxProps<T> {
  items: T[];
  placeholder?: string;
  className?: string;
  onSelectText?: (selectedItem: string) => void;
  onSelectId?: (selectedId: string) => void;
  icon?: string;
  selectedItem?: string;
  idField: keyof T;
  textField: keyof T;
  disabled?: boolean;
  maxDisplayLength?: number;
}

const ComboBox = <T extends object>({
  items,
  placeholder,
  className,
  onSelectText,
  onSelectId,
  icon,
  selectedItem: propSelectedItem,
  idField,
  textField,
  disabled = false,
  maxDisplayLength,
}: ComboBoxProps<T>) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<string | null>(
    propSelectedItem || null,
  );

  useEffect(() => {
    setSelectedItem(propSelectedItem || null);
  }, [propSelectedItem]);

  const truncateText = (text: string): string => {
    if (maxDisplayLength && text.length > maxDisplayLength) {
      return text.slice(0, maxDisplayLength) + "...";
    }
    return text;
  };

  const selectItem = (itemId: string, itemText: string) => {
    setSelectedItem(itemText);
    setIsOpen(false);

    if (onSelectText) onSelectText(itemText);
    if (onSelectId) onSelectId(itemId);
  };

  return (
    <div className={`relative inline-block ${className}`}>
      <Popover.Root open={isOpen} onOpenChange={setIsOpen}>
        <Popover.Trigger asChild>
          <button
            className={cn(
              "flex w-full cursor-pointer items-center justify-between rounded-md border border-gray-300 bg-white px-4 py-2 text-left text-gray-800",
              disabled && "opacity-50",
            )}
            disabled={disabled}
          >
            <span>
              {selectedItem
                ? truncateText(selectedItem)
                : placeholder
                  ? truncateText(placeholder)
                  : ""}
            </span>
            <span className="ml-2">
              <i
                className={
                  icon ||
                  (isOpen
                    ? "i-material-symbols-keyboard-arrow-up-rounded"
                    : "i-material-symbols-keyboard-arrow-down-rounded")
                }
              />
            </span>
          </button>
        </Popover.Trigger>
        {!disabled && (
          <Popover.Portal>
            <Popover.Content
              tabIndex={0}
              onWheel={(e) => e.stopPropagation()}
              onTouchMove={(e) => e.stopPropagation()}
              className="z-50 max-h-40 w-full max-w-[calc(100vw-2rem)] touch-auto overflow-y-auto overscroll-contain rounded-md border border-gray-300 bg-white p-0"
              sideOffset={5}
              align="start"
            >
              <div className="m-0 list-none p-0">
                {items.map((item) => (
                  <div
                    key={String(item[idField])}
                    onClick={() =>
                      selectItem(String(item[idField]), String(item[textField]))
                    }
                    className={`cursor-pointer truncate px-4 py-2 text-gray-800 ${
                      selectedItem === String(item[textField])
                        ? "bg-gray-200"
                        : "hover:bg-gray-100"
                    }`}
                  >
                    {truncateText(String(item[textField]))}
                  </div>
                ))}
              </div>
            </Popover.Content>
          </Popover.Portal>
        )}
      </Popover.Root>
    </div>
  );
};

export default ComboBox;
