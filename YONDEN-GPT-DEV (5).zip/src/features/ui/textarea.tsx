import * as React from "react";
import { cn } from "@/ui/lib";

export interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  /** 無効化フラグ */
  disabled?: boolean;
  /** 最大文字数 */
  maxLength?: number;
  /** 入力文字が変更されたときに呼ばれるコールバック */
  onInputText?: (value: string) => void;
}

const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, disabled = false, maxLength, onInputText, ...props }, ref) => {
    const [inputValue, setInputValue] = React.useState<string>("");

    const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      let value = e.target.value;

      // 最大文字数を超える場合は切り詰める
      if (maxLength && value.length > maxLength) {
        value = value.slice(0, maxLength);
      }

      setInputValue(value);
      if (onInputText) {
        onInputText(value); // 親コンポーネントに現在の文字列を渡す
      }
    };

    return (
      <textarea
        className={cn(
          "focus-visible:ring-offset-0flex box-border flex w-[90%] resize-none rounded-md border border-input bg-white px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:ring-ring focus-visible:ring-offset-0",
          disabled && "opacity-50",
          className,
        )}
        ref={ref}
        disabled={disabled}
        maxLength={maxLength}
        value={inputValue}
        onChange={handleInputChange}
        {...props}
      />
    );
  },
);
Textarea.displayName = "Textarea";

export { Textarea };
