"use client";

import DOMPurify from "dompurify";
import { FC, useEffect, useRef } from "react";

type Props = {
  /** スタイリング用の、無害化等がされないHTML */
  stylingHtml?: string;
  /** HTMLソース */
  htmlValue: string;
  /** 枠のスタイル (中の HTML には適用されない) */
  className?: string;
};

/**
 * HTMLプレビュー。無害化を行って表示する。
 * - 中のHTMLには、このアプリのスタイルが適用されない。
 *   (このアプリでは通常のHTMLのスタイルが無効化されており、HTMLが作りづらいと考えたため)
 *   - フォントについては適用している。
 */
export const HtmlPreview: FC<Props> = ({
  stylingHtml,
  htmlValue,
  className,
}: Props) => {
  // https://developer.mozilla.org/ja/docs/Web/HTTP/Headers/Content-Security-Policy
  // スタイルはインラインスタイル (<style/>, <span style="..."/>) のみ許可
  // 画像埋め込みを禁止
  // 上記以外 (JavaScriptなど) は Google Fonts を除いて禁止
  const cspPolicy = `
    default-src https://fonts.googleapis.com https://fonts.gstatic.com;
    style-src 'unsafe-inline' https://fonts.googleapis.com https://fonts.gstatic.com;
    img-src 'none';
  `;

  // できれば next/font を使いたいが、一先ず直で読み込む
  const fontStyle = `
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@100..900&display=swap" rel="stylesheet">
    <style>:root { font-family: 'Noto Sans JP', sans-serif; font-optical-sizing: auto; }</style>
  `;

  const htmlPrefix = `
    <!DOCTYPE html>
    <html lang="ja">
    <meta http-equiv="Content-Security-Policy" content="${cspPolicy}">
    ${fontStyle}
    ${stylingHtml ?? ""}
  `;

  const iframeRef = useRef<HTMLIFrameElement>(null);
  // const timeoutRef = useRef<number>();

  useEffect(() => {
    // - DOMPurify は DOM が必要
    // - "use client" を指定してたとしても useEffect の外はサーバで実行されてしまうことがある
    // 上記により sanitize をこの中で実行
    // https://zenn.dev/kazuki23/articles/85f44708363f96

    // XSSにつながる要素を排除したHTMLソースを生成
    // JavaScriptや外部CSS読込タグなどが除外される
    const sanitizedHtmlValue = DOMPurify.sanitize(htmlValue);

    const srcDoc = `${htmlPrefix}${sanitizedHtmlValue}`;

    const iframe = iframeRef.current;
    if (!iframe) return;

    // iframe内に指定したHTMLを表示する
    // Chrome/Edgeで試した限り方法1でほぼ問題なさそうだが、
    // もし環境により表示されない等の問題が起こる場合は方法3などを試す

    // 方法1: innerHTML
    // 同時に挿入したmetaタグのCSPポリシーが効くことも確認済 (Chrome/Edge 125)
    const doc = iframe.contentDocument;
    if (doc && doc.documentElement) {
      doc.documentElement.innerHTML = srcDoc;
    }

    // 方法2: document.write
    // Edgeに「Avoid using document.write().」と警告されるので無し
    // doc?.open();
    // doc?.write(srcDoc);
    // doc?.close();

    // 方法3: srcdoc属性
    // 書き換えると iframe 内でナビゲーションが発生して iframe 全体が点滅する。
    // ただし書き換えなければ問題ない
    // // srcdoc 属性で iframe 内に表示する HTML を直接設定できるが、
    // // srcdoc を書き換えると iframe 内でナビゲーションが発生して
    // // iframe 全体が点滅してしまうため、
    // // 書き換える際は一時的に opacity を下げて若干目に優しくする
    // // (おそらく srcdoc を使わなければ点滅しない操作も可能なはず)
    // iframe.style.opacity = "0.25";

    // // 600msの間何も書かなければ半透明を解除
    // if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
    // timeoutRef.current = window.setTimeout(() => {
    //   // iframe内のHTMLを書き換え
    //   // ここでナビゲーションが発生するため点滅する
    //   // if (iframe.srcdoc !== srcDoc) iframe.srcdoc = srcDoc;
    //   const doc = iframe.contentDocument;
    //   if (doc) doc.documentElement.innerHTML = srcDoc;

    //   timeoutRef.current = window.setTimeout(() => {
    //     iframe.style.opacity = "1";
    //   }, 300);
    // }, 300);
  }, [htmlPrefix, htmlValue, iframeRef]);

  return (
    <iframe
      title=""
      ref={iframeRef}
      className={className}
      // sandbox
      // https://developer.mozilla.org/ja/docs/Web/HTML/Element/iframe#sandbox
      // allow-scripts を許可しない限りこの中でJavaScriptは実行されない
      // iframe.contentDocument の操作に allow-same-origin が必須
      sandbox="allow-same-origin"
      // href="about:blank"
    />
  );
};
