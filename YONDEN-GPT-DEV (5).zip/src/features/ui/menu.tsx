import { LucideProps } from "lucide-react";
import * as React from "react";
import { Button, ButtonLinkVariant, ButtonProps } from "./button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./tooltip";
import { cn } from "@/ui/lib";

const Menu = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("flex h-full", className)} {...props}>
    <TooltipProvider>{props.children}</TooltipProvider>
  </div>
));
Menu.displayName = "Menu";

const MenuBar = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn(
      "z-10 flex h-full w-16 flex-col items-stretch justify-between border-r p-2",
      "[background:linear-gradient(180deg,rgb(247,59,40)_0%,rgb(247,139,40)_100%)]",
      className,
    )}
    {...props}
  >
    <TooltipProvider>{props.children}</TooltipProvider>
  </div>
));
MenuBar.displayName = "MenuBar";

type AnchorProps = ButtonProps & {
  tooltip?: string;
};

const MenuItemContainer = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("flex flex-col", className)} {...props}>
    {props.children}
  </div>
));
MenuItemContainer.displayName = "MenuItemContainer";

const MenuItem = React.forwardRef<HTMLButtonElement, AnchorProps>(
  ({ className, variant = "ghost", size, asChild = false, ...props }, ref) => {
    return (
      <TooltipProvider delayDuration={0}>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={variant}
              {...props}
              className={cn(ButtonLinkVariant)}
              ref={ref}
            />
          </TooltipTrigger>
          <TooltipContent side="right">{props.tooltip}</TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  },
);
MenuItem.displayName = "MenuItem";

const menuIconProps: LucideProps = {
  size: 24,
  strokeWidth: 1.6,
};

export { Menu, MenuBar, menuIconProps, MenuItem, MenuItemContainer };
