"use client";

import { DialogDescription } from "@radix-ui/react-dialog";
import * as VisuallyHidden from "@radix-ui/react-visually-hidden";
import { cva } from "class-variance-authority";
import { PropsWithChildren, ReactNode, useCallback, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./dialog";
import { cn } from "./lib";
import { LoadingIndicator } from "./loading";
import { Separator } from "./separator";

interface Props extends PropsWithChildren {
  /** ウィンドウタイトル */
  title: string;
  /** ウィンドウタイトルの下に表示する文字列 レスポンシブ用 */
  subTitle?: string;
  /** タイトルを画面上は非表示にする (スクリーンリーダ等にはタイトルが伝わる) */
  hiddenTitle?: boolean;
  /** ウィンドウタイトルの右に表示される文字列 */
  titleRightText?: string;
  /** 色付きの主ボタンに表示される文字列. 省略した場合はボタンを表示しない */
  primaryButtonText?: ReactNode;
  /** 色なしの副ボタンに表示される文字列. 省略した場合はボタンを表示しない */
  secondaryButtonText?: ReactNode;
  /** 色付きの主ボタン2に表示される文字列. 省略した場合はボタンを表示しない */
  primary2ButtonText?: ReactNode;
  /** 色なしの副ボタン2に表示される文字列. 省略した場合はボタンを表示しない */
  secondary2ButtonText?: ReactNode;
  /** 表示中かどうか */
  open: boolean;
  /** 表示中かどうかの状態が切り替わった */
  onOpenChange: (open: boolean) => void;
  /**
   * 閉じるボタン (スマホ版) やウィンドウ外クリックを可能にする
   * @default true
   */
  showClose?: boolean;
  /**
   * 閉じるボタンやウィンドウ外をクリックした際の動作
   *
   * - `close`: onClickPrimary, onClickSecondary を実行せずに閉じる
   *   (showClose が true または未指定の場合のデフォルト)
   * - `primary`: onClickPrimary を実行する。主ボタンが押された扱いとする
   * - `secondary`: onClickSecondary を実行する。副ボタンが押された扱いとする
   * - `none`: 何もしない (showClose が false な場合のデフォルト)
   */
  closedBehavior?: "close" | "primary" | "secondary" | "none" | undefined;
  /** 主ボタンがクリックされた */
  onClickPrimary?: () => void | Promise<void>;
  /** 副ボタンがクリックされた */
  onClickSecondary?: () => void | Promise<void>;
  /** 主ボタン2がクリックされた */
  onClickPrimary2?: () => void | Promise<void>;
  /** 副ボタン2がクリックされた */
  onClickSecondary2?: () => void | Promise<void>;
  /** 主ボタンの活性非活性 */
  primaryButtonDisabled?: boolean;
  /** モバイルフラグ */
  mobileFlg?: boolean;
  className?: string;
}

export const Window = ({
  title,
  subTitle,
  hiddenTitle = false,
  titleRightText,
  children,
  primaryButtonText,
  primary2ButtonText,
  secondaryButtonText,
  secondary2ButtonText,
  open,
  showClose = true,
  closedBehavior: closedBehaviorProp,
  onOpenChange: onOpenChangeProp,
  onClickPrimary,
  onClickSecondary,
  onClickPrimary2,
  onClickSecondary2,
  primaryButtonDisabled = false,
  mobileFlg = false,
  className,
}: Props) => {
  const [loadingSecondary, setLoadingSecondary] = useState(false);
  const [loadingPrimary, setLoadingPrimary] = useState(false);
  const loading = loadingPrimary || loadingSecondary;

  const showTitle = title && !hiddenTitle;
  const showButtonArea = !!(
    primaryButtonText ||
    secondaryButtonText ||
    primary2ButtonText ||
    secondary2ButtonText
  );
  const closedBehavior = closedBehaviorProp ?? (showClose ? "close" : "none");
  const closedFunc =
    closedBehavior === "primary"
      ? onClickPrimary
      : closedBehavior === "secondary"
        ? onClickSecondary
        : undefined;

  const onOpenChange = useCallback(
    // 外から渡されている open が true な時に
    // 内側から false にしようとした場合、
    // 閉じるボタンまたはウィンドウ外がクリックされたと判定
    (newOpen: boolean) => {
      if (open && !newOpen && loading) return;

      if (open && !newOpen && closedBehavior !== "close") {
        closedFunc?.();
        return;
      }
      onOpenChangeProp(newOpen);
    },
    [open, closedBehavior, onOpenChangeProp, closedFunc, loading],
  );

  const doSecondary = useCallback(() => {
    const res = onClickSecondary?.();
    if (res instanceof Promise) {
      setLoadingSecondary(true);
      res.finally(() => setLoadingSecondary(false));
    }
  }, [onClickSecondary]);

  const doSecondary2 = useCallback(() => {
    const res = onClickSecondary2?.();
    if (res instanceof Promise) {
      setLoadingSecondary(true);
      res.finally(() => setLoadingSecondary(false));
    }
  }, [onClickSecondary2]);

  const doPrimary = useCallback(() => {
    const res = onClickPrimary?.();
    if (res instanceof Promise) {
      setLoadingPrimary(true);
      res.finally(() => setLoadingPrimary(false));
    }
  }, [onClickPrimary]);

  const doPrimary2 = useCallback(() => {
    const res = onClickPrimary2?.();
    if (res instanceof Promise) {
      setLoadingPrimary(true);
      res.finally(() => setLoadingPrimary(false));
    }
  }, [onClickPrimary2]);

  return (
    <Dialog modal={true} open={open} onOpenChange={onOpenChange}>
      <DialogContent
        aria-describedby={undefined}
        showClose={false}
        className={cn(
          "flex max-h-screen flex-col items-start gap-4 overflow-hidden rounded-3xl bg-white-01 p-5",
          className,
        )}
      >
        {/* 左上に×ボタンを表示 (スマホの場合) */}
        {mobileFlg && (
          <button
            onClick={() => onOpenChangeProp(false)}
            className="flex h-10 w-10 items-center justify-center font-bold"
          >
            ×
          </button>
        )}
        {showTitle && (
          <DialogHeader
            className={cn(
              "flex w-full",
              mobileFlg
                ? "flex-col items-center gap-2"
                : "flex-row items-center justify-between",
            )}
          >
            <DialogTitle>
              <div
                className={cn(
                  "relative self-stretch text-[22px] font-medium",
                  mobileFlg && "text-center font-bold",
                )}
              >
                {title}
              </div>
            </DialogTitle>
            {subTitle && (
              <DialogDescription className="text-center text-sm">
                {subTitle}
              </DialogDescription>
            )}

            {!mobileFlg && titleRightText && (
              <div className="font-normal">{titleRightText}</div>
            )}
          </DialogHeader>
        )}
        {hiddenTitle && (
          <VisuallyHidden.Root>
            <DialogTitle>{title}</DialogTitle>
          </VisuallyHidden.Root>
        )}
        {/* Separatorを非表示 (mobileFlgがtrueの場合) */}
        {!mobileFlg && showTitle && children && <Separator />}
        <div className="relative h-full min-h-0 flex-1 self-stretch font-normal">
          <fieldset className="contents" disabled={loading}>
            {children}
          </fieldset>
        </div>
        {showButtonArea && (
          <div className="relative flex w-full flex-[0_0_auto] items-start justify-end gap-5 self-stretch pt-1">
            {secondaryButtonText && (
              <Button onClick={doSecondary} disabled={loading}>
                <LoadingIndicator isLoading={loadingSecondary} />
                {secondaryButtonText}
              </Button>
            )}
            {secondary2ButtonText && (
              <Button onClick={doSecondary2} disabled={loading}>
                <LoadingIndicator isLoading={loadingSecondary} />
                {secondary2ButtonText}
              </Button>
            )}
            {primaryButtonText && (
              <Button
                primary
                onClick={doPrimary}
                disabled={loading || primaryButtonDisabled}
              >
                <LoadingIndicator isLoading={loadingPrimary} />
                {primaryButtonText}
              </Button>
            )}
            {primary2ButtonText && (
              <Button primary onClick={doPrimary2} disabled={loading}>
                <LoadingIndicator isLoading={loadingPrimary} />
                {primary2ButtonText}
              </Button>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

const buttonVariants = cva(
  "relative inline-flex h-11 items-center gap-1.5 rounded-3xl px-4 py-2.5 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      primary: {
        true: "bg-orange-03 font-bold text-white-01",
        false:
          "border border-solid border-[#c8c8c8] bg-white-01 font-medium text-black-01",
      },
    },
    defaultVariants: {
      primary: false,
    },
  },
);

interface ButtonProps extends PropsWithChildren {
  primary?: boolean;
  className?: string;
  disabled?: boolean;
  onClick?: () => void;
}

const Button = ({
  primary = false,
  className = "",
  disabled = false,
  onClick,
  children,
}: ButtonProps) => {
  return (
    <button
      type="button"
      className={cn(buttonVariants({ primary }), className)}
      onClick={onClick}
      disabled={disabled}
    >
      <div className="relative flex w-fit items-center gap-2 whitespace-nowrap text-center text-lg leading-[18px] tracking-[0]">
        {children}
      </div>
    </button>
  );
};
