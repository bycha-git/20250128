"use client";

import { useLoadingOverlay } from "../common/store/loading-overlay-store";
import { LoadingIndicator } from "./loading";
import { Window } from "./window";

/** 画面全体を覆ったローディング表示 */
export const LoadingOverlay = () => {
  const { isLoading } = useLoadingOverlay();

  return (
    <Window
      open={isLoading}
      onOpenChange={emptyFunc}
      title="読込中"
      hiddenTitle
      showClose={false}
    >
      <div className="flex flex-col items-center justify-center">
        <LoadingIndicator isLoading={isLoading} />
        <LoadingMessage />
      </div>
    </Window>
  );
};

// isLoading は更新されておらず loadingMessage のみ更新された場合に
// このコンポーネントだけが再描画される
const LoadingMessage = () => {
  const { loadingMessage } = useLoadingOverlay();

  return <p>{loadingMessage}</p>;
};

const emptyFunc = () => {};
