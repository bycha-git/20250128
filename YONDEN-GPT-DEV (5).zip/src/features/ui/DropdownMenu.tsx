import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import React, { useEffect, useState } from "react";
import { Separator } from "./separator";

interface CustomDropdownMenuProps {
  items: { iconClass: string; label: string; disabled?: boolean }[];
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  onItemClick: (label: string, index: number) => void;
  onCloseAutoFocus?: (event: Event) => void;
  className?: string;
  triggerElement: React.ReactElement;
  side?: "top" | "right" | "bottom" | "left";
  sideOffset?: number;
  alignOffset?: number;
  align?: "start" | "center" | "end";
}

const CustomDropdownMenu: React.FC<CustomDropdownMenuProps> = ({
  items,
  open,
  onOpenChange,
  onItemClick,
  onCloseAutoFocus,
  className,
  triggerElement,
  side = "right",
  sideOffset = 5,
  alignOffset = -5,
  align = "center",
}) => {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient) return null;

  return (
    <DropdownMenu.Root open={open} onOpenChange={onOpenChange}>
      <DropdownMenu.Trigger asChild>{triggerElement}</DropdownMenu.Trigger>
      <DropdownMenu.Content
        className={`z-50 flex flex-col rounded-md border border-gray-300 bg-white p-2 shadow-lg ${className}`}
        side={side}
        sideOffset={sideOffset}
        alignOffset={alignOffset}
        align={align}
        onCloseAutoFocus={onCloseAutoFocus}
      >
        {items.map((item, index) => (
          <React.Fragment key={index}>
            <DropdownMenu.Item
              onSelect={() => !item.disabled && onItemClick(item.label, index)}
              className={`flex cursor-pointer items-center gap-2 rounded-md px-2 py-1 hover:bg-gray-100 ${
                item.disabled ? "opacity-50" : ""
              }`}
              disabled={item.disabled}
            >
              <i className={`${item.iconClass} h-6 w-6 text-gray-800`} />
              <span className="text-sm font-bold text-gray-800">
                {item.label}
              </span>
            </DropdownMenu.Item>
            {index < items.length - 1 && <Separator className="my-1" />}
          </React.Fragment>
        ))}
      </DropdownMenu.Content>
    </DropdownMenu.Root>
  );
};

export default CustomDropdownMenu;
