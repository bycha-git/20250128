"use client";

import * as TabsPrimitive from "@radix-ui/react-tabs";
import * as React from "react";
import { cn } from "@/ui/lib";

const VerticalTabs = TabsPrimitive.Root;
const VerticalTabsList = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.List>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.List>
>(({ className, children, ...props }, ref) => (
  <TabsPrimitive.List
    ref={ref}
    className={cn("bg-muted bg-white p-1 text-black", className)}
    {...props}
  >
    {children}
  </TabsPrimitive.List>
));
VerticalTabsList.displayName = "VerticalTabsList";

const VerticalTabsTrigger = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.Trigger> & {
    iconClass?: string;
    text?: string;
  }
>(({ className, iconClass, text, children, ...props }, ref) => (
  <TabsPrimitive.Trigger
    ref={ref}
    className={cn(
      "flex items-center gap-2 px-3 py-2 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
      "justify-center md:justify-start",
      "flex-shrink-0 md:w-full",
      "rounded-lg data-[state=active]:bg-gray-200 data-[state=active]:text-gray-600 data-[state=active]:shadow-sm",
      className,
    )}
    {...props}
  >
    {iconClass && <i className={cn(iconClass, "text-lg")}></i>}
    {text || children}
  </TabsPrimitive.Trigger>
));
VerticalTabsTrigger.displayName = "VerticalTabsTrigger";

const VerticalTabsContent = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.Content> & {
    border?: boolean;
  }
>(({ className, children, border = true, ...props }, ref) => (
  <TabsPrimitive.Content
    ref={ref}
    className={cn(
      "flex min-h-0 flex-1 flex-col",
      "ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
      border && "rounded-md border border-gray-300 p-2",
      "data-[state=inactive]:hidden",
      className,
    )}
    {...props}
  >
    {children}
  </TabsPrimitive.Content>
));

VerticalTabsContent.displayName = "VerticalTabsContent";

export {
  VerticalTabs,
  VerticalTabsContent,
  VerticalTabsList,
  VerticalTabsTrigger,
};
