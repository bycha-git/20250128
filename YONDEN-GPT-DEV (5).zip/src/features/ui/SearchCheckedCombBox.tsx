import * as Popover from "@radix-ui/react-popover";
import React, { useEffect, useState } from "react";
import { countWord } from "../common/countWord";

/**
 * items プルダウンに表示するアイテム
 * placeholder プレースホルダーとして表示される検索欄のヒント
 * className 任意のクラスを設定
 * onSelectItem 現在選択しているアイテムを返す
 * icon アイコンのクラス名を文字列として渡す（任意）
 * selectedItems 外部から渡された選択済みアイテム
 * onSearch 検索条件を返却する
 * searchResults 外部から取得した検索結果
 * idField IDのフィールド名
 * textField テキストのフィールド名
 * maxLength 入力上限
 * initialSearchLimit 初期検索上限
 */
interface SearchCheckedCombBoxProps<T> {
  placeholder?: string;
  className?: string;
  onSelectItem?: (selectedIds: T[]) => void;
  icon?: string;
  selectedItems?: T[];
  onSearch?: (query: string, searchLimit: number) => Promise<void> | void;
  searchResults?: T[];
  idField: keyof T;
  textField: keyof T;
  maxLength?: number;
  noResultText?: string;
  initialSearchLimit: number;
}

const SearchCheckedCombBox = <T extends object>({
  placeholder = "検索条件を入力...",
  className,
  onSelectItem,
  icon,
  selectedItems: propSelectedItems,
  onSearch,
  searchResults = [],
  idField,
  textField,
  maxLength,
  noResultText,
  initialSearchLimit,
}: SearchCheckedCombBoxProps<T>) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedItems, setSelectedItems] = useState<T[]>(
    propSelectedItems || [],
  );
  const selectedItemIds = selectedItems.map(
    (selectedItem) => selectedItem[idField],
  );
  const [searchConditions, setSearchConditions] = useState("");
  const [searchLimit, setSearchLimit] = useState(initialSearchLimit);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setSelectedItems(propSelectedItems || []);
  }, [propSelectedItems]);
  useEffect(() => {
    if (!isOpen) {
      setSearchLimit(initialSearchLimit);
    }
  }, [initialSearchLimit, isOpen]);

  const select = (item: T) => {
    const updatedItems = selectedItemIds.includes(item[idField])
      ? selectedItems.filter(
          (selecteditem) => selecteditem[idField] !== item[idField],
        )
      : [...selectedItems, item];
    setSelectedItems(updatedItems);
    if (onSelectItem) {
      onSelectItem(updatedItems);
    }
  };

  const searchChange = async (query: string) => {
    setSearchConditions(query);
    if (onSearch) {
      setIsLoading(true);
      await onSearch(query, searchLimit);
      setIsLoading(false);
    }
    if (!isOpen) {
      setIsOpen(true);
    }
  };
  const scrollBottom = () => {
    if (searchResults.length > searchLimit) {
      setSearchLimit((prev) => prev + initialSearchLimit);
      if (onSearch) {
        onSearch(searchConditions, searchLimit + initialSearchLimit);
      }
    }
  };

  return (
    <Popover.Root open={isOpen} onOpenChange={setIsOpen}>
      {/* 検索欄 */}
      <Popover.Trigger asChild>
        <div className={`relative inline-block ${className}`}>
          <input
            type="text"
            value={searchConditions}
            onChange={(e) => searchChange(e.target.value)}
            placeholder={placeholder}
            className="w-full rounded-md border border-gray-300 px-3 py-2 pr-10 focus:outline-none focus:ring focus:ring-indigo-200"
            onClick={() => setIsOpen(true)}
            maxLength={maxLength}
          />
          <span className="absolute right-4 top-3">
            <i
              className={
                icon ||
                (isOpen
                  ? "i-material-symbols-keyboard-arrow-up-rounded"
                  : "i-material-symbols-keyboard-arrow-down-rounded")
              }
            />
          </span>
        </div>
      </Popover.Trigger>

      {/* プルダウン（検索結果を表示） */}
      <Popover.Content
        className="z-10 max-h-40 w-full overflow-y-auto rounded-md border border-gray-300 bg-white p-0 shadow-lg"
        sideOffset={5}
        align="start"
        onOpenAutoFocus={(e) => e.preventDefault()}
        onScroll={(e) => {
          const target = e.target as HTMLElement;
          if (target.scrollHeight - target.scrollTop <= target.clientHeight) {
            scrollBottom();
          }
        }}
      >
        <div className="m-0 list-none p-0">
          {isLoading ? (
            <div className="px-4 py-2 text-gray-500">検索中...</div>
          ) : searchConditions.trim() === "" ? null : searchResults.length >
            0 ? (
            searchResults.map(
              (item, i) =>
                i < searchLimit && (
                  <label
                    key={String(item[idField])}
                    className="flex cursor-pointer items-center px-4 py-2 text-gray-800"
                  >
                    <input
                      type="checkbox"
                      checked={selectedItemIds.includes(item[idField])}
                      onChange={() =>
                        // select(String(item[idField]), String(item[textField]))
                        select(item)
                      }
                      className="mr-2 h-4 w-4 border focus:ring-0 focus:ring-offset-0"
                    />
                    {countWord(String(item[textField]), 15)}
                  </label>
                ),
            )
          ) : (
            <div className="px-4 py-2 text-gray-500">
              {noResultText || "検索結果がありません"}
            </div>
          )}
        </div>
      </Popover.Content>
    </Popover.Root>
  );
};

export default SearchCheckedCombBox;
