import { FC, useId } from "react";
import { Checkbox } from "./checkbox";

interface Props {
  label: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
}

export const CheckboxWithLabel: FC<Props> = ({
  label,
  checked,
  onCheckedChange,
}) => {
  const id = useId();

  return (
    <div className="flex items-center gap-2">
      <Checkbox id={id} checked={checked} onCheckedChange={onCheckedChange} />
      <label htmlFor={id}>{label}</label>
    </div>
  );
};
