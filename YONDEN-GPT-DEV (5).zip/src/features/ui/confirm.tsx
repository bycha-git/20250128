"use client";

import {
  ComponentPropsWithoutRef,
  createContext,
  ReactNode,
  useCallback,
  useContext,
  useMemo,
  useState,
} from "react";
import { ConfirmWindow } from "./confirm-window";

type ConfirmArgs = Omit<
  ComponentPropsWithoutRef<typeof ConfirmWindow>,
  "open" | "onOpenChange"
> & {
  /** メッセージ本文 */
  text?: ReactNode;
};

type AsyncConfirmArgs = Omit<ConfirmArgs, "onClickOk" | "onClickCancel">;

type ConfirmContextProps = {
  /**
   * 確認画面を表示する。
   * - ボタンを押すと即ウィンドウが閉じられる
   */
  confirm: (_: AsyncConfirmArgs | string) => Promise<boolean>;
  /**
   * 確認画面を表示する。
   * - ボタンを押してから、 `返り値.close()` を呼び出すまでウィンドウが閉じられない
   */
  confirmWait: (_: AsyncConfirmArgs | string) => Promise<ConfirmWaitResult>;
};

type ConfirmWaitResult = {
  /** 確認結果 */
  ok: boolean;
  /** 確認ウィンドウを閉じる */
  close: () => void;
};

export const ConfirmContext = createContext<ConfirmContextProps>({
  confirm: async () => false,
  confirmWait: async () => ({ ok: false, close: () => {} }),
});

const ARGS_DELETE_TIMEOUT = 10000;

type ConfirmState = {
  /** 引数 */
  args: ConfirmArgs;
  /** 閉じた時刻 (開いている間は undefined とする) */
  closedTime?: number;
};

export const ConfirmProvider = ({ children }: { children: ReactNode }) => {
  const [confirmList, setConfirmList] = useState<ConfirmState[]>([]);

  const now = Date.now();
  const confirmListExcludeClosed =
    confirmList.length !== 0
      ? confirmList.filter(
          (confirmState) =>
            !confirmState.closedTime ||
            now - confirmState.closedTime < ARGS_DELETE_TIMEOUT,
        )
      : confirmList;
  if (confirmList.length !== confirmListExcludeClosed.length) {
    // レンダリングの度に、closedTime から ARGS_DELETE_TIMEOUT ミリ秒経っているものがあれば削除
    setConfirmList(confirmListExcludeClosed);
  }

  const confirm = useCallback(
    (arg: AsyncConfirmArgs | string) => {
      const args = typeof arg === "string" ? { text: arg } : arg;
      return new Promise<boolean>((resolve) => {
        const newConfirmState: ConfirmState = {
          args: {
            ...args,
            onClickOk: () => {
              resolve(true);
            },
            onClickCancel: () => {
              resolve(false);
            },
          },
        };
        setConfirmList((prev) => [...prev, newConfirmState]);
      });
    },
    [setConfirmList],
  );

  const confirmWait = useCallback(
    (
      arg: AsyncConfirmArgs | string,
    ): Promise<{
      ok: boolean;
      close: () => void;
    }> => {
      const args = typeof arg === "string" ? { text: arg } : arg;
      return new Promise((resolve) => {
        const newConfirmState: ConfirmState = {
          args: {
            ...args,
            onClickOk: () =>
              new Promise((onClickResolve) => {
                resolve({
                  ok: true,
                  close: onClickResolve,
                });
              }),
            onClickCancel: () =>
              new Promise((onClickResolve) => {
                resolve({
                  ok: false,
                  close: onClickResolve,
                });
              }),
          },
        };
        setConfirmList((prev) => [...prev, newConfirmState]);
      });
    },
    [setConfirmList],
  );

  const value = useMemo(
    () => ({
      confirm,
      confirmWait,
    }),
    [confirm, confirmWait],
  );

  return (
    <ConfirmContext.Provider value={value}>
      {children}
      {confirmList.map((confirmState, i) => {
        const { text, ...args } = confirmState.args;
        return (
          <ConfirmWindow
            key={i}
            {...args}
            open={!confirmState.closedTime}
            onOpenChange={(open) => {
              if (!open) {
                // closedTime をセットして閉じる
                const newConfirmState = {
                  ...confirmState,
                  closedTime: Date.now(),
                };
                const newList = [...confirmList];
                newList[i] = newConfirmState;
                setConfirmList(newList);
              }
            }}
          >
            {text}
          </ConfirmWindow>
        );
      })}
    </ConfirmContext.Provider>
  );
};

export const useConfirm = () => useContext(ConfirmContext);
