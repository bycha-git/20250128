"use client";

import { PropsWithChildren } from "react";
import { useResponsive } from "@/hooks/use-responsive";

/** 内部用 */
export const ForDesktopInternal = ({ children }: PropsWithChildren) => {
  const { isDesktop } = useResponsive();
  return isDesktop ? children : null;
};

/** 内部用 */
export const ForMobileInternal = ({ children }: PropsWithChildren) => {
  const { isMobile } = useResponsive();
  return isMobile ? children : null;
};
