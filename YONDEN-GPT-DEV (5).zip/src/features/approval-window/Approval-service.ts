"use server";

import { SqlQuerySpec } from "@azure/cosmos";
import { getCurrentUser, userHashedId } from "../auth-page/helpers";
import { ServerActionResponse } from "../common/server-action-response";
import { ApprovalContainer } from "../common/services/cosmos";
import { uniqueId } from "../common/util";

/**
 * 承認要否チェック処理
 *
 * @return 承認が必要ならtrue、不要ならfalse
 */
export const CheckApprovalNeeded = async () => {
  try {
    // このセッションで注意事項に承認済みかどうか
    const user = await getCurrentUser();
    if (user?.isApproved) {
      return false;
    }

    const findResult = await FindApproval();
    /** 承認要否 */
    let approvalNeededFlg = true;

    // 取得できた場合
    if (findResult) {
      // 乱数生成（0～9の整数）
      const random = Math.floor(Math.random() * 10).toString();

      // 下一桁が 1 の場合、承認要とする
      if (random === "1") {
        approvalNeededFlg = true;
      } else {
        approvalNeededFlg = false;
      }
    }

    // // TODO: できればサーバ側で session 更新したい
    // // (現状でも一応できているが、わざわざクライアントを挟んでいる)
    // if (!approvalNeededFlg) {
    //   // session 更新
    // }

    // 取得できなかった場合、承認要のまま返す
    return approvalNeededFlg;
  } catch {
    // TODO
    console.log("error");
  }
};

/**
 * 承認テーブル検索処理
 *
 * @returns 見つかったらtrue、見つからなかったらfalse
 */
export const FindApproval = async () => {
  try {
    // ユーザーID
    const userId = await userHashedId();

    // パラメータ
    const querySpec: SqlQuerySpec = {
      query: "SELECT * FROM root r WHERE r.userId=@userId",
      parameters: [
        {
          name: "@userId",
          value: userId,
        },
      ],
    };

    // 検索
    const { resources } = await ApprovalContainer()
      .items.query(querySpec)
      .fetchAll();

    if (resources.length === 0) {
      return false;
    } else {
      return true;
    }
  } catch {
    // TODO
    console.log("取得エラー");
    return false;
  }
};

/**
 * 承認データ登録処理
 */
export const RegistApproval = async (): Promise<
  ServerActionResponse<boolean>
> => {
  try {
    const userId = await userHashedId();

    // 登録内容
    const modelToSave = {
      id: uniqueId(),
      userId: userId,
      createdAt: new Date().toISOString(),
    };

    // 登録
    const { resource } = await ApprovalContainer().items.create(modelToSave);

    // 返却値
    if (resource) {
      return {
        status: "OK",
        response: true,
      };
    } else {
      return {
        status: "ERROR",
        errors: [
          {
            message: "Error creating approval",
          },
        ],
      };
    }
  } catch (error) {
    console.log("登録エラー");
    // 適当
    return {
      status: "ERROR",
      errors: [
        {
          message: `Error creating approval: ${error}`,
        },
      ],
    };
  }
};
