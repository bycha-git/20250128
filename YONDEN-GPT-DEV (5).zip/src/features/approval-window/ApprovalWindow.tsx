"use client";

import { useSession } from "next-auth/react";
import React, { FC, useCallback, useEffect, useState } from "react";
import { Button } from "../ui/button";
import { CheckboxWithLabel } from "../ui/checkbox-with-label";
import { HtmlPreview } from "../ui/html-preview";
import { useResponsive } from "../ui/responsive";
import { Window } from "../ui/window";
import { RegistApproval } from "./Approval-service";

type Props = {
  dispFlg: boolean;
  message: string;
};

export const ApprovalWindow: FC<Props> = ({ dispFlg, message }) => {
  const [checked, setChecked] = useState<boolean>(false);
  const [open, setOpen] = useState<boolean>(dispFlg);
  const { data: session, update: updateSession } = useSession();
  const user = session?.user;
  const { isDesktop, isMobile } = useResponsive();

  /** 始めるボタン押下時 */
  const handleClickStart = useCallback(async () => {
    if (!checked) return;

    // 承認テーブル登録
    await RegistApproval();

    // セッション更新
    // このセッションではもう承認画面を表示しない
    await updateSession({
      isApproved: true,
    });

    // 画面閉じる
    setOpen(false);
  }, [checked, updateSession]);

  // 承認不要の場合に isApproved を設定
  // (サーバ側でいい感じに更新できる API が無く、超遠回りになっている。
  // できればサーバ側で直で設定したい)
  useEffect(() => {
    console.log("ApprovalWindow useEffect", { dispFlg, user, updateSession });
    if (!dispFlg && user && !user.isApproved && updateSession) {
      updateSession({
        isApproved: true,
      });
    }
    // session.update() が毎回生成されている気がするので
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispFlg, user, !!updateSession]);

  // 承認画面表示
  return (
    <Window
      open={open}
      onOpenChange={setOpen}
      title="YONDEN-GPTの利用に関する注意事項"
      hiddenTitle={true}
      showClose={false}
      className={`${isMobile ? "h-full w-full rounded-none" : "h-[90%] w-7/12"}`}
    >
      <div className="flex h-full w-full flex-col items-center gap-3 bg-white md:gap-5">
        <header className="flex w-full flex-[0_0_auto] items-center gap-2 self-stretch px-1 py-0">
          <span className="i-material-symbols-warning-outline-rounded h-6 w-6 text-red-01 md:h-9 md:w-9" />
          <div className="w-fit font-medium leading-6 md:whitespace-nowrap md:text-2xl">
            YONDEN-GPTの利用に関する注意事項
          </div>
        </header>
        {open && (
          <HtmlPreview
            stylingHtml="
<style>
body {
--orange-02: rgba(255, 120, 80, 1);
--red-01: rgba(221, 82, 76, 1);
--white-01: rgba(255, 255, 255, 1);

background-color: var(--orange-02);
border-radius: 1rem;
padding: 1rem 1rem 1.5rem;
color: var(--white-01);
font-weight: 500;
line-height: 1.375rem;
}

h2 {
  color: var(--red-01);
  font-size: 1rem;
  font-weight: 500;
  background-color: var(--white-01);
  border-radius: 1.5rem;
  padding: 0.625rem 1.125rem;
  display: inline-block;
  margin: .5rem 0 0 0;
}

h2:first-of-type {
  margin: 0;
}

p {
  margin: .5rem 0;
}
</style>"
            htmlValue={message}
            className="h-full w-full rounded-[1rem] bg-transparent"
          />
        )}
        <div className="flex justify-center gap-5">
          <CheckboxWithLabel
            label="上記の注意事項に同意する"
            checked={checked}
            onCheckedChange={(e) => setChecked(e)}
          />
        </div>
        <div className="flex w-full justify-center gap-5 self-stretch">
          <Button disabled={!checked} onClick={handleClickStart}>
            始める
          </Button>
        </div>
      </div>
    </Window>
  );
};
