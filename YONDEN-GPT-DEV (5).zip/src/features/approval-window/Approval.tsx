import "server-only";

import { CheckApprovalNeeded } from "./Approval-service";
import { ApprovalWindow } from "./ApprovalWindow";

export const Approval = async () => {
  // サーバー上で承認要否チェック
  const checkApprovalNeededResult = (await CheckApprovalNeeded()) ?? true;
  const message = process.env.AZURE_APPROVAL_MESSAGE!;

  return (
    <ApprovalWindow dispFlg={checkApprovalNeededResult} message={message} />
  );
};
