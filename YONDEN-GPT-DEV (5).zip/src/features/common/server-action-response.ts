export type ServerActionError = {
  message: string;
};

export type ServerActionValidationError = {
  status: "ERROR" | "NOT_FOUND" | "UNAUTHORIZED" | "FORBIDDEN";
  errors: ServerActionError[];
};

export type ServerActionSuccess<T = any> = {
  status: "OK";
  response: T;
};

export type ServerActionResponse<T = any> =
  | ServerActionValidationError
  | ServerActionSuccess<T>;

/**
 * ERROR の代わりに throw する版の ServerActionResponse
 * - Next.js 的なやり方ではない
 */
export type ServerActionResponseOrThrow<T> = ServerActionResponse<T> & {
  status: "OK" | "NOT_FOUND";
};
