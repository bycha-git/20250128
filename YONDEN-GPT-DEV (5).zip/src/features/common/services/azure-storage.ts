import { Readable } from "stream";
import { BlobServiceClient, RestError } from "@azure/storage-blob";
import { ServerActionResponse } from "../server-action-response";
import { GetBlobResult } from "./azure-storage-models";

// initialize the blobServiceClient
const initBlobServiceClient = () => {
  const acc = process.env.AZURE_STORAGE_ACCOUNT_NAME;
  const key = process.env.AZURE_STORAGE_ACCOUNT_KEY;

  if (!acc || !key)
    throw new Error(
      "Azure Storage Account not configured correctly, check environment variables.",
    );
  const endpointSuffix =
    process.env.AZURE_STORAGE_ENDPOINT_SUFFIX || "core.windows.net";

  const connectionString = `DefaultEndpointsProtocol=https;AccountName=${acc};AccountKey=${key};EndpointSuffix=${endpointSuffix}`;

  const blobServiceClient =
    BlobServiceClient.fromConnectionString(connectionString);
  return blobServiceClient;
};

export const uploadBlob = async (
  containerName: string,
  blobName: string,
  blobData: Blob,
) => {
  const blobServiceClient = initBlobServiceClient();

  const containerClient = blobServiceClient.getContainerClient(containerName);
  const blockBlobClient = containerClient.getBlockBlobClient(blobName);

  // https://developer.mozilla.org/ja/docs/Web/API/Blob/type
  // > `blob.type` で信頼性が高いのは、画像、HTML 文書、音声、動画などの一般的なファイル形式のみです。
  // > 一般的ではないファイル拡張子は空文字列を返します。
  // 空文字の場合は汎用MIMEタイプを使用
  const contentType = blobData.type || "application/octet-stream";

  const response = await blockBlobClient.uploadData(
    // 型では Blob が許可されているが、 ArrayBuffer じゃないとエラーになった
    // →確実にメモリに展開されるので、ファイルが大きいと微妙
    await blobData.arrayBuffer(),
    {
      blobHTTPHeaders: {
        blobContentType: contentType,
      },
    },
  );

  // アップロード失敗時
  if (response.errorCode !== undefined) {
    throw new Error(`Error uploading blob to storage: ${response.errorCode}`);
  }
  return blockBlobClient.url;
};

export const uploadBlobStream = async (
  containerName: string,
  blobName: string,
  mimeType: string,
  readable: Readable,
) => {
  const blobServiceClient = initBlobServiceClient();

  const containerClient = blobServiceClient.getContainerClient(containerName);
  const blockBlobClient = containerClient.getBlockBlobClient(blobName);

  // https://developer.mozilla.org/ja/docs/Web/API/Blob/type
  // > `blob.type` で信頼性が高いのは、画像、HTML 文書、音声、動画などの一般的なファイル形式のみです。
  // > 一般的ではないファイル拡張子は空文字列を返します。
  // 空文字の場合は汎用MIMEタイプを使用
  const contentType = mimeType || "application/octet-stream";

  const response = await blockBlobClient.uploadStream(
    readable,
    8 * 1024 * 1024, // 8MB chunks (default)
    5, // default
    {
      blobHTTPHeaders: {
        blobContentType: contentType,
      },
    },
  );

  // アップロード失敗時
  if (response.errorCode !== undefined) {
    throw new Error(`Error uploading blob to storage: ${response.errorCode}`);
  }
  return blockBlobClient.url;
};

/** Blob Storage からファイルを取得 */
export const getBlob = async (
  containerName: string,
  blobPath: string,
): Promise<ServerActionResponse<GetBlobResult>> => {
  const blobServiceClient = initBlobServiceClient();

  const containerClient = blobServiceClient.getContainerClient(containerName);
  const blockBlobClient = containerClient.getBlockBlobClient(blobPath);

  try {
    const downloadBlockBlobResponse = await blockBlobClient.download(0);
    const readableStream: NodeJS.ReadableStream | undefined =
      downloadBlockBlobResponse.readableStreamBody;

    if (!readableStream) {
      return {
        status: "ERROR",
        errors: [
          {
            message: `Error downloading blob: ${blobPath}`,
          },
        ],
      };
    }

    const contentLength = downloadBlockBlobResponse.contentLength;
    const contentType = downloadBlockBlobResponse.contentType;

    const response: GetBlobResult = {
      stream: readableStream,
      contentLength,
      contentType,
    };

    return {
      status: "OK",
      response,
    };
  } catch (error) {
    if (error instanceof RestError && error.statusCode === 404) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: `Blob not found: ${blobPath}`,
          },
        ],
      };
    }

    return {
      status: "ERROR",
      errors: [
        {
          message: `Error downloading blob: ${blobPath}`,
        },
      ],
    };
  }
};

export const deleteBlob = async (containerName: string, blobPath: string) => {
  const blobServiceClient = initBlobServiceClient();

  const containerClient = blobServiceClient.getContainerClient(containerName);
  const blockBlobClient = containerClient.getBlockBlobClient(blobPath);

  await blockBlobClient.deleteIfExists();
};
