"use server";

import { SqlQuerySpec } from "@azure/cosmos";
import {
  ErrorMessageModel,
  ErrorMessageModelSchema,
} from "../model/config/errorMessage-model";
import { getOnlyParsed } from "../schema-validation";
import { ServerActionResponse } from "../server-action-response";
import { ConfigContainer } from "./cosmos";

/**
 * エラーメッセージを取得
 * @param messageIds メッセージIDまたはメッセージIDの配列
 */
export const FindErrorMessages = async (
  messageIds: string | string[],
): Promise<ServerActionResponse<Array<ErrorMessageModel>>> => {
  try {
    // messageIds が配列でない場合、単一要素の配列に変換
    const messageIdList = Array.isArray(messageIds) ? messageIds : [messageIds];

    const querySpec: SqlQuerySpec = {
      query: `SELECT * FROM root r WHERE r.type=@type AND ARRAY_CONTAINS(@errorCodes, r.messageId)`,
      parameters: [
        {
          name: "@type",
          value: "ERROR_MESSAGE",
        },
        {
          name: "@errorCodes",
          value: messageIdList,
        },
      ],
    };
    const { resources } = await ConfigContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();
    const safeResources = getOnlyParsed(resources, ErrorMessageModelSchema);
    if (safeResources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "・エラーが発生しました。",
          },
        ],
      };
    }
    return {
      status: "OK",
      response: safeResources,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * 全エラーメッセージを取得
 */
export const FindAllErrorMessages = async (): Promise<
  ServerActionResponse<Record<string, string>>
> => {
  try {
    const querySpec: SqlQuerySpec = {
      query: `SELECT r.messageId, r.message FROM root r WHERE r.type = @type`,
      parameters: [
        {
          name: "@type",
          value: "ERROR_MESSAGE",
        },
      ],
    };

    const { resources } = await ConfigContainer()
      .items.query<{ messageId: string; message: string }>(querySpec)
      .fetchAll();

    const result: Record<string, string> = resources.reduce(
      (acc, item) => {
        acc[item.messageId] = item.message;
        return acc;
      },
      {} as Record<string, string>,
    );

    return {
      status: "OK",
      response: result,
    };
  } catch (error) {
    throw error;
  }
};
