"use server";

import { SqlQuerySpec } from "@azure/cosmos";

interface FindSelectAuthorityCompanyResult {
  status: "OK" | "NOT_FOUND" | "ERROR";
  response?: AuthorityCompanyModel[];
  errors?: { message: string }[];
}
import {
  AUTHORITY_COMPANY_TYPE,
  AuthorityCompanyModel,
} from "../model/authority-company-model";
import { uniqueId } from "../util";
import { HistoryContainer } from "@/features/common/services/cosmos";

// 権限情報（組織）
interface AuthorityCompanyInfo {
  id: string | undefined;
  departmentName: string | undefined;
  permissionId: string | undefined;
  errFlg: boolean;
}

/**
 * 権限(組織)取得
 * @param departmentCode 組織コード
 * @param permissions 取得対象権限
 * @returns 取得結果
 */
export const FindAuthorityCompanyByID = async (
  departmentCode: string,
  permissions: string,
) => {
  try {
    let query = `
    SELECT
      *
    FROM
      root r
    WHERE
      r.type = @type
  `;
    const parameters = [
      {
        name: "@type",
        value: AUTHORITY_COMPANY_TYPE,
      },
    ];

    // departmentCodeが空でない場合、条件を追加
    if (departmentCode !== "") {
      query += `
      AND
      STARTSWITH(@departmentCode, r.departmentCode)
    `;
      parameters.push({
        name: "@departmentCode",
        value: departmentCode,
      });
    }

    // permissionsが空でない場合、条件を追加
    if (permissions !== "") {
      query += `
      AND
        r.permissionId = @permissionId
    `;
      parameters.push({
        name: "@permissionId",
        value: permissions,
      });
    }

    const querySpec: SqlQuerySpec = {
      query,
      parameters,
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<AuthorityCompanyModel>(querySpec)
      .fetchAll();

    // 権限なし
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
      };
    }

    // 権限あり
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * 指定されたparentIDの権限(組織)取得
 * @param parentId テンプレート/チャットボットID
 * @param employeeId ユーザID(従業員番号)
 * @returns 取得結果
 */
export const FindSelectAuthorityCompanyByID = async (
  departmentCode: string,
  promptId: string,
): Promise<FindSelectAuthorityCompanyResult> => {
  try {
    const querySpec: SqlQuerySpec = {
      query: `
        SELECT
          *
        FROM
          root r
        WHERE
          r.type = @type
          AND
            STARTSWITH(@departmentCode, r.departmentCode)
          AND
            r.parentId = @parentId
      `,
      parameters: [
        {
          name: "@type",
          value: AUTHORITY_COMPANY_TYPE,
        },
        {
          name: "@parentId",
          value: promptId,
        },
        {
          name: "@departmentCode",
          value: departmentCode,
        },
      ],
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<AuthorityCompanyModel>(querySpec)
      .fetchAll();

    // 権限なし
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
      };
    }

    // 権限あり
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * プロンプトテンプレート/チャットボットに設定されている権限(組織)取得
 * @param parentId テンプレート/チャットボットID
 * @returns 取得結果
 */
export const FindAuthorityCompanys = async (
  parentId: string,
): Promise<FindSelectAuthorityCompanyResult> => {
  try {
    const querySpec: SqlQuerySpec = {
      query: `
        SELECT
          *
        FROM
          root r
        WHERE
          r.type = @type
          AND
            r.parentId = @parentId
      `,
      parameters: [
        {
          name: "@type",
          value: AUTHORITY_COMPANY_TYPE,
        },
        {
          name: "@parentId",
          value: parentId,
        },
      ],
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<AuthorityCompanyModel>(querySpec)
      .fetchAll();

    // 権限なし
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
      };
    }

    // 権限あり
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * 権限(組織)取得
 * @param id id
 * @param type レコードタイ
 * @returns 取得結果
 */
export const FindAuthorityCompanyDeleteData = async (id: string) => {
  try {
    const query = `
    SELECT
      *
    FROM
      root r
    WHERE
      r.type = @type
    AND
      r.id = @id
  `;
    const parameters = [
      {
        name: "@type",
        value: AUTHORITY_COMPANY_TYPE,
      },
      {
        name: "@id",
        value: id,
      },
    ];

    const querySpec: SqlQuerySpec = {
      query,
      parameters,
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<AuthorityCompanyModel>(querySpec)
      .fetchAll();

    // 権限なし
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
      };
    }

    // 権限あり
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `権限(組織)取得でエラー:${error}`,
        },
      ],
    };
  }
};

/**
 * 新規追加処理
 * @param parentId 追加対象ID
 * @param authorityInfo 追加する権限
 */
export const AddAuthorityCompany = async (
  parentId: string,
  authorityInfo: AuthorityCompanyInfo[],
  userId: string,
) => {
  try {
    // 追加する権限情報を一括で処理
    const results = await Promise.all(
      authorityInfo.map(async (info) => {
        const [id, ...nameParts] = info.departmentName.split(" ");
        const departmentName = nameParts.join(" ");
        const modelToSave: AuthorityCompanyModel = {
          id: uniqueId(),
          type: "DEPARTMENT_PERMISSION",
          userId: userId,
          createdAt: new Date().toISOString(),
          parentId: parentId,
          departmentCode: id,
          departmentName: departmentName,
          permissionId: info.permissionId,
        };

        // 登録
        const { resource } = await HistoryContainer().items.create(modelToSave);

        if (resource) {
          return {
            status: "OK",
            response: resource,
          };
        }
      }),
    );

    // 成功・失敗の結果をまとめて返却
    return {
      status: "OK",
      responses: results,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * 新規追加・更新処理
 * @param parentId 追加対象ID
 * @param authorityInfo 追加する権限
 */
export const UpsertAuthorityCompany = async (
  parentId: string,
  authorityInfo: AuthorityCompanyInfo[],
  userId: string,
) => {
  try {
    // 追加または更新する権限情報を一括で処理
    const results = await Promise.all(
      authorityInfo.map(async (info) => {
        const [id, ...nameParts] = info.departmentName.split(" ");
        const departmentName = nameParts.join(" ");
        let modelToSave: AuthorityCompanyModel;

        if (info.id === "") {
          // 新規作成
          modelToSave = {
            id: uniqueId(),
            type: "DEPARTMENT_PERMISSION",
            userId: userId,
            createdAt: new Date().toISOString(),
            parentId: parentId,
            departmentCode: id,
            departmentName: departmentName,
            permissionId: info.permissionId ?? "",
          };
        } else {
          // 既存データの取得
          const existingRecord = await HistoryContainer()
            .items.query({
              query: "SELECT * FROM c WHERE c.type = @type AND c.id = @id",
              parameters: [
                { name: "@type", value: "DEPARTMENT_PERMISSION" },
                { name: "@id", value: info.id ?? "" },
              ],
            })
            .fetchAll();
          // 更新の場合、既存IDを使用し内容を上書き
          modelToSave = {
            id:
              existingRecord.resources.length > 0
                ? existingRecord.resources[0].id
                : uniqueId(),
            type: existingRecord.resources[0].type,
            userId: existingRecord.resources[0].userId,
            createdAt: existingRecord.resources[0].createdAt,
            parentId: existingRecord.resources[0].parentId,
            departmentCode: existingRecord.resources[0].departmentCode,
            departmentName: existingRecord.resources[0].departmentName,
            permissionId: info.permissionId ?? "",
          };
        }

        // upsert操作で保存
        const { resource } = await HistoryContainer().items.upsert(modelToSave);

        if (resource) {
          return {
            status: "OK",
            response: resource,
          };
        }
      }),
    );

    // 成功・失敗の結果をまとめて返却
    return {
      status: "OK",
      responses: results,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * 権限（組織）削除処理
 * @param authorityId 対象権限ID
 * @returns 結果 OK or ERROR
 */
export const DeleteAuthortyCompany = async (authorityId: string[]) => {
  try {
    const deleteResults = await Promise.all(
      authorityId.map(async (id) => {
        // 削除対象のプロンプトテンプレートを取得
        const promptResponse = await FindAuthorityCompanyDeleteData(id);

        if (promptResponse.status === "OK") {
          const { resource: deletedPrompt } = await HistoryContainer()
            .item(id, promptResponse.response[0].userId)
            .delete();

          return {
            status: "OK",
            response: deletedPrompt,
          };
        }
      }),
    );
    return deleteResults;
  } catch (error) {
    // 共通のエラーハンドリング
    throw error;
  }
};
