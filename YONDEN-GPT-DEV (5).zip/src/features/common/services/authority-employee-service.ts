"use server";

import { SqlQuerySpec } from "@azure/cosmos";
import {
  AUTHORITY_EMPLOYEE_TYPE,
  AuthorityEmployeeModel,
} from "../model/authority-employee-model";
import { uniqueId } from "../util";
import { HistoryContainer } from "@/features/common/services/cosmos";

// 権限情報（ユーザー）
interface AuthorityEmployeeInfo {
  id: string | undefined;
  employeeName: string | undefined;
  permissionId: string | undefined;
  errFlg: boolean;
}

/**
 * 権限(ユーザ)取得　一覧取得用
 * @param employeeId ユーザID(従業員番号)
 * @param permissions 取得対象の権限
 * @returns 取得結果
 */
export const FindAuthorityEmployeeByID = async (
  employeeId: string,
  permissions: string,
) => {
  try {
    let query = `
      SELECT *
      FROM root r
      WHERE r.type = @type
    `;
    const parameters = [
      {
        name: "@type",
        value: AUTHORITY_EMPLOYEE_TYPE,
      },
    ];

    // employeeIdが空でない場合は条件を追加
    if (employeeId) {
      query += " AND r.employeeId = @employeeId";
      parameters.push({
        name: "@employeeId",
        value: employeeId,
      });
    }

    // permissionsが空でない場合は条件を追加
    if (permissions) {
      query += " AND r.permissionId = @permissions";
      parameters.push({
        name: "@permissions",
        value: permissions,
      });
    }

    const querySpec: SqlQuerySpec = {
      query,
      parameters,
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<AuthorityEmployeeModel>(querySpec)
      .fetchAll();

    // 結果が0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
      };
    }

    // 結果がある場合
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * 指定されたparentIDの権限(ユーザ)取得
 * @param parentId テンプレート/チャットボットID
 * @param employeeId ユーザID(従業員番号)
 * @returns 取得結果
 */
export const FindSelectAuthorityEmployeeByID = async (
  parentId: string,
  employeeId: string,
) => {
  try {
    const query = `
      SELECT *
      FROM root r
      WHERE r.type = @type
      AND r.parentId = @parentId
      AND r.employeeId = @employeeId
    `;
    const parameters = [
      {
        name: "@type",
        value: AUTHORITY_EMPLOYEE_TYPE,
      },
      {
        name: "@parentId",
        value: parentId,
      },
      {
        name: "@employeeId",
        value: employeeId,
      },
    ];

    const querySpec: SqlQuerySpec = {
      query,
      parameters,
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<AuthorityEmployeeModel>(querySpec)
      .fetchAll();

    // 結果が0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
      };
    }

    // 結果がある場合
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * プロンプトテンプレート/チャットボットに設定されている権限（ユーザー）を取得
 * @param parentId テンプレート/チャットボットID
 * @returns 取得結果
 */
export const FindAuthorityUsers = async (parentId: string) => {
  try {
    const query = `
      SELECT *
      FROM root r
      WHERE r.type = @type
      AND r.parentId = @parentId
    `;
    const parameters = [
      {
        name: "@type",
        value: AUTHORITY_EMPLOYEE_TYPE,
      },
      {
        name: "@parentId",
        value: parentId,
      },
    ];

    const querySpec: SqlQuerySpec = {
      query,
      parameters,
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<AuthorityEmployeeModel>(querySpec)
      .fetchAll();

    // 結果が0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
      };
    }

    // 結果がある場合
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};
/**
 * 権限(組織)取得
 * @param id id
 * @param type レコードタイ
 * @returns 取得結果
 */
export const FindAuthorityEmployeeDeleteData = async (id: string) => {
  try {
    const query = `
    SELECT
      *
    FROM
      root r
    WHERE
      r.type = @type
    AND
      r.id = @id
  `;
    const parameters = [
      {
        name: "@type",
        value: AUTHORITY_EMPLOYEE_TYPE,
      },
      {
        name: "@id",
        value: id,
      },
    ];

    const querySpec: SqlQuerySpec = {
      query,
      parameters,
    };

    // 検索
    const { resources } = await HistoryContainer()
      .items.query<AuthorityEmployeeInfo>(querySpec)
      .fetchAll();

    // 権限なし
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
      };
    }

    // 権限あり
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `権限(組織)取得でエラー:${error}`,
        },
      ],
    };
  }
};
/**
 * 新規追加処理
 * @param promptId 追加対象のテンプレートID
 * @param authorityInfo 追加する権限
 */
export const AddAuthorityEmployee = async (
  promptId: string,
  authorityInfo: AuthorityEmployeeInfo[],
  userId: string,
) => {
  try {
    // 追加する権限情報を一括で処理
    const results = await Promise.all(
      authorityInfo.map(async (info) => {
        const [id, ...nameParts] = info.employeeName.split(" ");
        const employeeName = nameParts.join(" ");
        const modelToSave: AuthorityEmployeeModel = {
          id: uniqueId(),
          type: "USER_PERMISSION",
          userId: userId,
          createdAt: new Date().toISOString(),
          parentId: promptId,
          employeeId: id,
          employeeName: employeeName,
          permissionId: info.permissionId,
        };

        // 登録
        const { resource } = await HistoryContainer().items.create(modelToSave);

        if (resource) {
          return {
            status: "OK",
            response: resource,
          };
        }
      }),
    );

    // 成功・失敗の結果をまとめて返却
    return {
      status: "OK",
      responses: results,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * 新規追加・更新処理
 * @param parentId 追加対象ID
 * @param authorityInfo 追加する権限
 */
export const UpsertAuthorityEmployee = async (
  parentId: string,
  authorityInfo: AuthorityEmployeeInfo[],
  userId: string,
) => {
  try {
    // 追加または更新する権限情報を一括で処理
    const results = await Promise.all(
      authorityInfo.map(async (info) => {
        const [id, ...nameParts] = info.employeeName.split(" ");
        const employeeName = nameParts.join(" ");
        let modelToSave: AuthorityEmployeeModel;

        if (info.id === "") {
          // 新規作成
          modelToSave = {
            id: uniqueId(),
            type: "USER_PERMISSION",
            userId: userId,
            createdAt: new Date().toISOString(),
            parentId: parentId,
            employeeId: id,
            employeeName: employeeName,
            permissionId: info.permissionId ?? "",
          };
        } else {
          // 既存データの取得
          const existingRecord = await HistoryContainer()
            .items.query({
              query: "SELECT * FROM c WHERE c.type = @type AND c.id = @id",
              parameters: [
                { name: "@type", value: "USER_PERMISSION" },
                { name: "@id", value: info.id ?? "" },
              ],
            })
            .fetchAll();
          // 更新の場合、既存IDを使用し内容を上書き
          modelToSave = {
            id:
              existingRecord.resources.length > 0
                ? existingRecord.resources[0].id
                : uniqueId(),
            type: existingRecord.resources[0].type,
            userId: existingRecord.resources[0].userId,
            createdAt: existingRecord.resources[0].createdAt,
            parentId: existingRecord.resources[0].parentId,
            employeeId: existingRecord.resources[0].employeeId,
            employeeName: existingRecord.resources[0].employeeName,
            permissionId: info.permissionId ?? "",
          };
        }

        // upsert操作で保存
        const { resource } = await HistoryContainer().items.upsert(modelToSave);

        if (resource) {
          return {
            status: "OK",
            response: resource,
          };
        }
      }),
    );

    // 成功・失敗の結果をまとめて返却
    return {
      status: "OK",
      responses: results,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * 権限（社員）削除処理
 * @param employeeId 対象権限ID
 * @returns 結果 OK or ERROR
 */
export const DeleteAuthortyEmployee = async (employeeId: string[]) => {
  try {
    const deleteResults = await Promise.all(
      employeeId.map(async (id) => {
        // 削除対象のプロンプトテンプレートを取得
        const promptResponse = await FindAuthorityEmployeeDeleteData(id);

        if (promptResponse.status === "OK") {
          const { resource: deletedPrompt } = await HistoryContainer()
            .item(
              promptResponse.response[0].id,
              promptResponse.response[0].userId,
            )
            .delete();

          return {
            status: "OK",
            response: deletedPrompt,
          };
        }
      }),
    );
    return deleteResults;
  } catch (error) {
    throw error;
  }
};
