import { Blob as NodeBlob } from "buffer";
import { openAsBlob } from "fs";
import { stat } from "fs/promises";
import { NextRequest } from "next/server";
import { fetch as undiciFetch } from "undici";
import { ModelWithFuncInfoModel } from "../model/config/model-model";
import { ServerActionResponse } from "../server-action-response";

export interface AzureFuncModelRequest {
  threadId: string;
  messageId: string;
}

interface AzureFuncModelResponse {
  // TODO
  message: string;
}

interface SimpleFuncInfo {
  functionsUrl: string;
  accessKey: string;
}
export type FuncInfo = SimpleFuncInfo | ModelWithFuncInfoModel;

/** AzureFunction を実行 (GPT) */
export const runAzureFuncChat = async ({
  request,
  funcInfo,
}: {
  request: AzureFuncModelRequest;
  funcInfo: FuncInfo;
}): Promise<ServerActionResponse<string>> => {
  try {
    const response = await runAzureFunc<AzureFuncModelRequest>(
      funcInfo.functionsUrl,
      funcInfo.accessKey,
      request,
    );
    console.log("🟢 Azure Function からのレスポンス:", response);
    return {
      status: "OK",
      response,
    };
  } catch (e) {
    console.error("🔴 Azure Function 呼び出しエラー:", e);
    return {
      status: "ERROR",
      errors: [{ message: `${e}` }],
    };
  }
};

/** AzureFunction を実行 */
export const runAzureFunc = async <Request extends string | object>(
  url: string,
  key: string,
  req: Request | FormData,
): Promise<string> => {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    "x-functions-key": key,
  };
  let requestTextForLog: string;
  if (req instanceof FormData) {
    delete headers["Content-Type"];
    requestTextForLog = "FormData";
  } else {
    requestTextForLog = JSON.stringify(req);
  }
  console.log(
    "🟢 Azure Function にリクエストします。",
    "url:",
    url,
    "request:",
    requestTextForLog,
  );
  const res = await fetch(url, {
    method: "POST",
    headers,
    body:
      req instanceof FormData || typeof req === "string"
        ? req
        : JSON.stringify(req),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(
      `Azure Function のリクエストに失敗しました。 status: ${res.status} ${
        res.statusText
      }, content-length: ${res.headers.get("content-length")}, responseText: ${
        text
      }`,
    );
  }
  const text = await res.text();
  return text;
};

/** AzureFunction を実行 (テスト中) */
export const runAzureFuncTest = async (
  url: string,
  key: string,
  req: NextRequest,
  headers: Record<string, string> = {},
): Promise<string> => {
  // const body = req.body;
  // if (!(body instanceof NodeReadableStream)) {
  //   throw new Error("req.body is not a ReadableStream from node:stream/web");
  // }
  // const inputStream: NodeReadableStream = body;
  // const nodeReadable = Readable.fromWeb(inputStream);

  // const asyncIterator = streamToAsyncIterator(inputStream);

  // ng
  // const bodyAsyncIterator = inputStream.values();
  // const nodeInputStream = Readable.fromWeb(inputStream);]

  const bodyBuf = await req.blob();
  if (!(bodyBuf instanceof NodeBlob)) {
    throw new Error("req.body is not a Blob from node:buffer");
  }

  console.log("fetch");
  const res = await undiciFetch(url, {
    method: "POST",
    headers: {
      "x-functions-key": key,
      ...headers,
    },
    body: bodyBuf,
    // ストリームを渡す
    // body: nodeReadable,
    // body: req,
    duplex: "half",
  });
  if (!res.ok) {
    const text = await res.text();

    throw new Error(
      `Azure Function のリクエストに失敗しました。 status: ${res.status} ${
        res.statusText
      }, content-length: ${res.headers.get("content-length")}, responseText: ${
        text
      }`,
    );
  }
  const text = await res.text();
  return text;
};

/** AzureFunction を実行 (テスト中) */
export const runAzureFuncTestFromFile = async (
  url: string,
  key: string,
  tempFilePath: string,
  headers: Record<string, string> = {},
): Promise<string> => {
  // const readable = createReadStream(tempFilePath);

  const fileSize = await stat(tempFilePath).then((stats) => stats.size);

  // 注意：現時点では openAsBlob は 4GB 以上のファイルを正常に開けない
  // https://github.com/nodejs/node/issues/52585
  const blob = await openAsBlob(tempFilePath);
  if (!(blob instanceof NodeBlob)) {
    throw new Error("req.body is not a Blob from node:buffer");
  }
  // const buffer = await readFile(tempFilePath);

  if (blob.size !== fileSize) {
    // openAsBlob が対応していないファイルサイズ
    throw new Error(
      `openAsBlob が対応していない 4GB 以上のファイルを読み込もうとしました。`,
    );
  }

  console.log(
    "🟢 Azure Function にリクエストします。",
    "url:",
    url,
    "blobSize:",
    blob.size,
    "requestSize:",
    fileSize,
  );

  console.log("runAzureFuncTestFromFile start");
  const res = await undiciFetch(url, {
    method: "POST",
    headers: {
      "x-functions-key": key,
      ...headers,
    },
    // body: readable,
    body: blob,
    // duplex: "half",
  });
  if (!res.ok) {
    const text = await res.text();

    throw new Error(
      `Azure Function のリクエストに失敗しました。 status: ${res.status} ${
        res.statusText
      }, content-length: ${res.headers.get("content-length")}, responseText: ${
        text
      }`,
    );
  }
  const text = await res.text();
  return text;

  // const res = await axios
  //   .post(url, {
  //     method: "POST",
  //     headers: {
  //       // "x-functions-key": key,
  //       ...headers,
  //     },
  //     responseType: "text",
  //     // body: bodyBuf,
  //     // ストリームを渡す
  //     // body: nodeReadable,
  //     // body: readable,
  //     body: buffer,
  //     validateStatus: () => true,
  //   })
  //   .catch((e) => {
  //     if (e instanceof AxiosError) {
  //       const res = e.response;
  //       if (res) return res;
  //     }
  //     throw e;
  //   });
  // if (!res.status || res.status < 200 || res.status >= 300) {
  //   const text = res.data;

  //   throw new Error(
  //     `Azure Function のリクエストに失敗しました。 status: ${res.status} ${
  //       res.statusText
  //     }, content-length: ${res.headers["content-length"]}, responseText: ${
  //       text
  //     }`,
  //   );
  // }
  // const text = res.data;
  // return text;
};
