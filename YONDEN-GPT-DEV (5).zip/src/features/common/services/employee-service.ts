"use server";

import { SqlQuerySpec } from "@azure/cosmos";
import { EmployeeModel, EmployeeModelSchema } from "../model/employee-model";
import { getOnlyParsed } from "../schema-validation";
import { ServerActionResponse } from "../server-action-response";
import { EmployeeContainer } from "@/features/common/services/cosmos";

/**
 * 自身の情報を取得
 * @param userId ユーザID
 */
export const FindEmployeeByID = async (userId: string) => {
  try {
    // パラメータ
    const querySpec: SqlQuerySpec = {
      query: "SELECT * FROM root r WHERE r.id=@id",
      parameters: [
        {
          name: "@id",
          value: userId,
        },
      ],
    };

    // 検索
    const { resources: unsafeResources } = await EmployeeContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();

    const resources = getOnlyParsed(unsafeResources, EmployeeModelSchema);

    // 0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "ユーザーが見つかりません。",
          },
        ],
      };
    }

    // 返却
    return {
      status: "OK",
      response: resources[0],
    };
  } catch (error) {
    throw error;
  }
};

/**
 * ユーザープリンシパルネームから自身の情報を取得 (Entra IDログイン時に使用)
 * @param userId ユーザID
 */
export const findEmployeeByUserPrincipalName = async (
  userPrincipalName: string,
): Promise<ServerActionResponse<EmployeeModel>> => {
  try {
    // パラメータ
    const querySpec: SqlQuerySpec = {
      query: "SELECT * FROM root r WHERE r.userPrincipalName=@upn",
      parameters: [
        {
          name: "@upn",
          value: userPrincipalName,
        },
      ],
    };

    // 検索
    const { resources: unsafeResources } = await EmployeeContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();

    const resources = getOnlyParsed(unsafeResources, EmployeeModelSchema);

    // 0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "ユーザーが見つかりません。",
          },
        ],
      };
    }

    // 返却
    return {
      status: "OK",
      response: resources[0],
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `ユーザ取得でエラー：${error}`,
        },
      ],
    };
  }
};

/**
 * 指定されたユーザーIDの情報を取得
 * @param userIds ユーザーIDの配列
 */
export const FindEmployeeByIDs = async (userIds: string[]) => {
  try {
    // userIds が空でないことを確認
    if (!userIds || userIds.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "ユーザーIDが指定されていません。",
          },
        ],
      };
    }

    // IN句にパラメータを設定
    const inClause = userIds.map((_, index) => `@id${index}`).join(", ");

    // パラメータ
    const parameters = userIds.map((id, index) => ({
      name: `@id${index}`,
      value: id,
    }));

    const querySpec: SqlQuerySpec = {
      query: `SELECT * FROM root r WHERE r.id IN (${inClause})`,
      parameters: parameters,
    };

    // 検索
    const { resources } = await EmployeeContainer()
      .items.query<EmployeeModel>(querySpec)
      .fetchAll();

    // 0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "ユーザーが見つかりません。",
          },
        ],
      };
    }

    // 返却（複数のユーザー情報を返す）
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * 権限タブ検索SQL(社員)　新規
 */
export const employeeSearch = async (searchText: string) => {
  try {
    // パラメータ
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT * FROM root r WHERE UPPER(r.id) LIKE UPPER(@searchText) OR  UPPER(r.employeeName) LIKE UPPER(@searchText) ORDER BY r.id ",
      parameters: [
        {
          name: "@searchText",
          value: `%${searchText}%`,
        },
      ],
    };

    // 検索
    const { resources } = await EmployeeContainer()
      .items.query<EmployeeModel>(querySpec)
      .fetchAll();

    // 0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "ユーザーが見つかりません。",
          },
        ],
      };
    }

    // 返却
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};
