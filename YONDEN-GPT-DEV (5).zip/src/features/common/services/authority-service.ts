"use server";

import { SqlQuerySpec } from "@azure/cosmos";
import {
  PERMISSION_ATTRIBUTE,
  PermissionModelSchema,
} from "../model/config/permission-model";
import { getOnlyParsed } from "../schema-validation";
import { ConfigContainer } from "@/features/common/services/cosmos";

/**
 * 権限取得
 * @returns 取得結果
 */
export const FindAuthorityID = async () => {
  try {
    const querySpec: SqlQuerySpec = {
      query: `
        SELECT
          *
        FROM
          root r
        WHERE
          r.type = @type
      `,
      parameters: [
        {
          name: "@type",
          value: PERMISSION_ATTRIBUTE,
        },
      ],
    };

    // データ取得
    const { resources } = await ConfigContainer()
      .items.query<unknown>(querySpec)
      .fetchAll();

    // データが存在しない場合でも、空配列を設定
    const safeResources = resources
      ? getOnlyParsed(resources, PermissionModelSchema)
      : [];

    return {
      status: "OK",
      response: safeResources,
    };
  } catch (error) {
    throw error;
  }
};
