"use server";

import { SqlQuerySpec } from "@azure/cosmos";
import { CompanyModel } from "../model/company-model";
import { ServerActionResponse } from "../server-action-response";
import { DepartmentContainer } from "@/features/common/services/cosmos";

/**
 * 自身が所属する組織を取得
 * @param departmentCode 所属する組織コード
 */
export const FindCompanyByID = async (departmentCode: string) => {
  try {
    //　パラメータ
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT * FROM root r WHERE STARTSWITH(@departmentCode, r.departmentCode) ",
      parameters: [
        {
          name: "@departmentCode",
          value: departmentCode,
        },
      ],
    };

    // 検索
    const { resources } = await DepartmentContainer()
      .items.query<CompanyModel>(querySpec)
      .fetchAll();

    // 0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "組織無",
          },
        ],
      };
    }

    // 返却
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [
        {
          message: `組織取得でエラー：${error}`,
        },
      ],
    };
  }
};

/**
 * 自身が所属する組織が全体管理者かどうか取得
 * @param departmentCode 所属する組織コード
 */
export const findIsDepartmentAdmin = async (
  departmentCode: string,
): Promise<ServerActionResponse<boolean>> => {
  try {
    //　パラメータ
    const querySpec: SqlQuerySpec = {
      query: `
SELECT TOP 1 VALUE 1
FROM root r
WHERE
  STARTSWITH(@departmentCode, r.departmentCode)
  AND r.administrator
`,
      parameters: [
        {
          name: "@departmentCode",
          value: departmentCode,
        },
      ],
    };

    // 検索
    const { resources } = await DepartmentContainer()
      .items.query<number>(querySpec)
      .fetchAll();

    const isDepartmentAdmin = resources.length > 0;

    // 返却
    return {
      status: "OK",
      response: isDepartmentAdmin,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * 複数の組織を取得する
 * @param departmentCodea 所属する組織コード
 */
export const FindCompaniesByIDs = async (departmentCodes: string[]) => {
  try {
    // departmentCodes が空でないことを確認
    if (!departmentCodes || departmentCodes.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "組織コードが指定されていません。",
          },
        ],
      };
    }

    // IN句にパラメータを設定
    const inClause = departmentCodes
      .map((_, index) => `@code${index}`)
      .join(", ");

    // パラメータ
    const parameters = departmentCodes.map((code, index) => ({
      name: `@code${index}`,
      value: code,
    }));

    const querySpec: SqlQuerySpec = {
      query: `SELECT * FROM root r WHERE r.departmentCode IN (${inClause})`,
      parameters: parameters,
    };

    // 検索
    const { resources } = await DepartmentContainer()
      .items.query<CompanyModel>(querySpec)
      .fetchAll();

    // 0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "組織が見つかりません。",
          },
        ],
      };
    }

    // 返却（複数の組織情報を返す）
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};

/**
 * 権限タブ検索SQL(組織)　新規
 */
export const companySearch = async (searchText: string) => {
  try {
    // パラメータ
    const querySpec: SqlQuerySpec = {
      query:
        "SELECT  * FROM root r WHERE UPPER(r.departmentCode) LIKE UPPER(@searchText) OR  UPPER(r.departmentName) LIKE UPPER(@searchText) ORDER BY r.departmentCode ",
      parameters: [
        {
          name: "@searchText",
          value: `%${searchText}%`,
        },
      ],
    };

    // 検索
    const { resources } = await DepartmentContainer()
      .items.query<CompanyModel>(querySpec)
      .fetchAll();

    // 0件の場合
    if (resources.length === 0) {
      return {
        status: "NOT_FOUND",
        errors: [
          {
            message: "ユーザーが見つかりません。",
          },
        ],
      };
    }

    // 返却
    return {
      status: "OK",
      response: resources,
    };
  } catch (error) {
    throw error;
  }
};
