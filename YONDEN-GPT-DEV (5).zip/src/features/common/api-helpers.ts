import CIDR from "ip-cidr";
import { NextApiRequest, NextApiResponse } from "next";
import { NextResponse } from "next/server";
import { ServerAPIErrorMessageIDResponse } from "./api-models";
import {
  ServerActionResponse,
  ServerActionValidationError,
} from "./server-action-response";
import { ErrorMessagesKey } from "@/app/(authenticated)/errorMessageContext";

const DefaultAPIErrorResponseHeaders = {
  "Content-Type": "application/json; charset=utf-8",
};

const getErrorBody = (
  message: string,
  status: ServerActionValidationError["status"] = "ERROR",
  errors: ServerActionValidationError["errors"] = [],
): string => {
  const response: ServerActionResponse<unknown> = {
    status: status,
    errors: [{ message }, ...errors],
  };
  return JSON.stringify(response);
};

const getErrorMessageIdBody = (errorMessageId: ErrorMessagesKey): string => {
  const response: ServerAPIErrorMessageIDResponse = {
    status: "ERROR",
    errorMessageId: errorMessageId,
  };
  return JSON.stringify(response);
};

/**
 * - message が空文字または undefined なら標準のエラー文を返す
 */
export const getDefaultAPIBadRequestErrorResponse = (
  message?: string,
): NextResponse => {
  const body = getErrorBody(message || "エラーが発生しました。");
  return new NextResponse(body, {
    status: 400,
    headers: DefaultAPIErrorResponseHeaders,
  });
};

export const getDefaultAPIUnauthorizedErrorResponse = (): NextResponse => {
  const body = getErrorBody("エラーが発生しました。", "UNAUTHORIZED");
  return new NextResponse(body, {
    status: 401,
    headers: DefaultAPIErrorResponseHeaders,
  });
};

export const getDefaultAPIForbiddenErrorResponse = (
  message?: string,
): NextResponse => {
  const body = getErrorBody(message || "必要な権限がありません。", "FORBIDDEN");
  return new NextResponse(body, {
    status: 403,
    headers: DefaultAPIErrorResponseHeaders,
  });
};

export const getDefaultAPINotFoundErrorResponse = (
  resourceType = "リソース",
): NextResponse => {
  const body = getErrorBody(`${resourceType}が見つかりません。`, "NOT_FOUND");
  return new NextResponse(body, {
    status: 404,
    headers: DefaultAPIErrorResponseHeaders,
  });
};

export const getDefaultAPIServerErrorResponse = (
  message?: string,
): NextResponse => {
  const body = getErrorBody(
    "サーバーエラーが発生しました。 " + (message ? `(${message})` : ""),
  );
  return new NextResponse(body, {
    status: 500,
    headers: DefaultAPIErrorResponseHeaders,
  });
};

export const getDefaultAPIErrorMessageIdResponse = (
  errorMessageId?: ErrorMessagesKey,
): NextResponse => {
  const body = getErrorMessageIdBody(errorMessageId || "ECOMMON0001");
  return new NextResponse(body, {
    status: 400,
    headers: DefaultAPIErrorResponseHeaders,
  });
};

/**
 * - message が空文字または undefined なら標準のエラー文を返す
 */
export const getDefaultAPIRouteBadRequestErrorResponse = (
  res: NextApiResponse,
  message?: string,
): void => {
  const body = getErrorBody(message || "エラーが発生しました。");
  res.setHeaders(new Headers(DefaultAPIErrorResponseHeaders));
  res.status(400).send(body);
};

export const getDefaultAPIRouteUnauthorizedErrorResponse = (
  res: NextApiResponse,
): void => {
  const body = getErrorBody("エラーが発生しました。", "UNAUTHORIZED");
  res.setHeaders(new Headers(DefaultAPIErrorResponseHeaders));
  res.status(401).send(body);
};

export const getDefaultAPIRouteForbiddenErrorResponse = (
  res: NextApiResponse,
  message?: string,
): void => {
  const body = getErrorBody(message || "必要な権限がありません。", "FORBIDDEN");
  res.setHeaders(new Headers(DefaultAPIErrorResponseHeaders));
  res.status(403).send(body);
};

export const getDefaultAPIRouteNotFoundErrorResponse = (
  res: NextApiResponse,
  resourceType = "リソース",
): void => {
  const body = getErrorBody(`${resourceType}が見つかりません。`, "NOT_FOUND");
  res.setHeaders(new Headers(DefaultAPIErrorResponseHeaders));
  res.status(404).send(body);
};

export const getDefaultAPIRouteServerErrorResponse = (
  res: NextApiResponse,
  message?: string,
): void => {
  const body = getErrorBody(
    "サーバーエラーが発生しました。 " + (message ? `(${message})` : ""),
  );
  res.setHeaders(new Headers(DefaultAPIErrorResponseHeaders));
  res.status(500).send(body);
};

export const getDefaultAPIRouteErrorMessageIdResponse = (
  res: NextApiResponse,
  errorMessageId: ErrorMessagesKey,
): void => {
  const body = getErrorMessageIdBody(errorMessageId || "ECOMMON0001");
  res.setHeaders(new Headers(DefaultAPIErrorResponseHeaders));
  res.status(400).send(body);
};

export const isDocumentDownloadAllowed = (req: NextApiRequest): boolean => {
  const allowList =
    process.env.DOCUMENT_DOWNLOAD_ALLOW_IP?.split(",").filter((ip) => ip) || [];
  if (allowList.length === 0) {
    console.log("DOCUMENT_DOWNLOAD_ALLOW_IP not set");
    return true;
  }

  const ip = (req.socket.remoteAddress ?? "")
    .replace(/:\d+$/, "")
    .replace(/^\:\:ffff\:((?:\d+\.){3}\d+)$/, "$1");
  const xForwardedForRaw = req.headers["x-forwarded-for"];
  const xForwardedForStr =
    (Array.isArray(xForwardedForRaw)
      ? xForwardedForRaw.at(-1)
      : xForwardedForRaw) ?? "";
  // 右端の値
  // https://developer.mozilla.org/ja/docs/Web/HTTP/Headers/X-Forwarded-For
  const xfwd = (
    String(xForwardedForStr)
      .split(/\s*,\s*/)
      .filter((ip) => ip)
      .at(-1) ?? ""
  )
    .replace(/:\d+$/, "")
    .replace(/^\:\:ffff\:((?:\d+\.){3}\d+)$/, "$1");

  console.log("IP:", ip, ", x-forwarded-for IP:", xfwd);
  console.log(
    "Raw x-* headers:",
    JSON.stringify(
      Object.fromEntries(
        Object.entries(req.headers).filter(([key]) =>
          key.toLowerCase().startsWith("x-"),
        ),
      ),
    ),
  );

  for (const entry of allowList) {
    if (CIDR.isValidCIDR(entry)) {
      const cidr = new CIDR(entry);
      if (cidr.contains(ip) || cidr.contains(xfwd)) {
        console.log("CIDR allowed:", entry);
        return true;
      }
    } else {
      if (entry === ip || entry === xfwd) {
        console.log("IP allowed:", entry);
        return true;
      }
    }
  }
  return false;
};
