"use client";

import { proxy, useSnapshot } from "valtio";
import { showError } from "@/features/globals/global-message-store";

/** LoadingOverlay (画面全体を覆ったローディング表示) を管理 */
class LoadingOverlayState {
  public isLoading: boolean = false;
  public loadingMessage: string = "";

  public startLoading(message?: string) {
    this.isLoading = true;
    this.loadingMessage = message ?? "";
  }

  public updateLoadingMessage(message: string) {
    this.loadingMessage = message;
  }

  public stopLoading() {
    this.isLoading = false;
    this.loadingMessage = "";
  }

  public showError(message: string) {
    this.stopLoading();
    showError(message);
  }
}

/** LoadingOverlay (画面全体を覆ったローディング表示) を使用 */
export const loadingOverlayStore = proxy(new LoadingOverlayState());

/**
 * LoadingOverlay (画面全体を覆ったローディング表示) の各値を取得
 * - loading-overlay.tsx 以外からは使わない
 */
export const useLoadingOverlay = () => {
  // 仕組み: Proxy API で値の変更を検知した度に再レンダーを実行し、最新の値を反映
  return useSnapshot(loadingOverlayStore, { sync: true });
};
