"use server";

import { EmployeeModel } from "./model/employee-model";
import { findIsDepartmentAdmin } from "./services/company-service";

/**
 * 自身または自身の組織に「管理者」権限が含まれているか
 * @returns admin=true:管理者 admin=false:管理者ではない
 */
export const checkAdmin = async (
  /** 自身の社員情報 */
  user: EmployeeModel,
): Promise<CheckAdminResponse> => {
  try {
    /** 自身が管理者ならすぐに true を返す */
    if (user.administrator) {
      return {
        status: "OK",
        admin: true,
      };
    }

    /** 所属する組織が管理者か取得 */
    const isDepartmentAdminResponse = await findIsDepartmentAdmin(
      user.department_code_8,
    );
    if (isDepartmentAdminResponse.status !== "OK") {
      return {
        status: "ERROR",
        admin: false,
      };
    }
    const isDepartmentAdmin = isDepartmentAdminResponse.response;

    return {
      status: "OK",
      admin: isDepartmentAdmin,
    };
  } catch (error) {
    throw error;
  }
};

interface CheckAdminResponse {
  status: "OK" | "ERROR";
  admin: boolean;
}
