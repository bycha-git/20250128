import * as v from "valibot";
import { isRedirectError } from "@/features/common/util";

/** 引数で実行しているasync関数のエラーをハンドルする */
export const handleError = async <T>(action: Promise<T>): Promise<T> => {
  try {
    const res = await action;
    const canHaveErrorResult = v.safeParse(CanHaveErrorObjectSchema, res);
    if (canHaveErrorResult.success) {
      const response = canHaveErrorResult.output;
      // エラー内容を確認、内容次第で throw する
      // エラーコードが返されればそれ使う？
      // エラーコードの使い方候補
      // - エラーコードが来たらエラーメッセージを取得しにいく
      // - クライアント側でエラーメッセージリストを全部もっておく
      //   - layout.tsx で取得しといて、 store に入れておくとか？
    }
    return res;
  } catch (error) {
    if (isRedirectError(error)) {
      // リダイレクトエラー (リダイレクトされる) の場合、何もしない
      throw error;
    }

    // throw されたらエラー表示したい

    // 続きが実行されてほしくないので、そのまま throw する
    // 外ではエラー表示等をしていないことを要確認
    // ※ エラー表示以外のクリーンアップ (loading状態の解除等) は
    // 　 変わらず外の try-catch や try-finally で行う。
    throw new Error();
  }
};

// メモ:
// - `{ errors: [{ messages: "エラー" }]}` ←この入れ子をもう少しシンプルにしたい気持ちがある。
// - バンドルサイズ (ブラウザに配信されるJSサイズ) 削減のため、
//   zod の代わりに valibot を使っている。
//   safeParse の結果は、 `.result` ではなく `.output` に入る。
//   - そのうち全面的に validot に移行したい。
/** エラーオブジェクトが含まれるかもしれない返り値 */
export const CanHaveErrorObjectSchema = v.partial(
  v.looseObject({
    // status に OK, ERROR, NOT_FOUND でもない謎の値が入っている処理があるので
    // 一旦 string にしておく
    status: v.string(),
    errors: v.tuple([
      v.object({
        message: v.string(),
      }),
    ]),
  }),
);
/** エラーオブジェクトが含まれるかもしれない返り値 */
export type CanHaveErrorObject = v.InferInput<typeof CanHaveErrorObjectSchema>;
