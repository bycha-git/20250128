import { v7 as uuidv7 } from "uuid";
import { ChatListItemProps } from "../chat-menu/chat-list-item";

/** UUIDv7を生成 */
export const uniqueId = () => {
  // const alphabet =
  //   "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
  // const nanoid = customAlphabet(alphabet, 36);
  // return nanoid();
  return uuidv7();
};

type ObjectWithTimestamp = { lastMessageAt: string | Date };

export const sortByTimestamp = (
  a: ObjectWithTimestamp,
  b: ObjectWithTimestamp,
) => {
  return (
    new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime()
  );
};

export const sortByItemTimestamp = (
  a: ChatListItemProps,
  b: ChatListItemProps,
) => {
  return (
    new Date(b.item.lastMessageAt).getTime() -
    new Date(a.item.lastMessageAt).getTime()
  );
};

/** Next.jsにより生成されたリダイレクトエラーであれば true を返す */
// Next.js 内の isRedirectError 関数がバージョンアップで移動したこともあり、最低限の自前実装に切替
export const isRedirectError = (error: unknown): boolean => {
  return (
    !!error &&
    typeof error === "object" &&
    "digest" in error &&
    typeof error.digest === "string" &&
    error?.digest?.startsWith("NEXT_REDIRECT")
  );
};
