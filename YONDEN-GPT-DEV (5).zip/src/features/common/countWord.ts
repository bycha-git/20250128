/**
 * 文字数カウント
 * @param word 対象ワード
 * @returns 全角文字数
 */
export const countWord = (word: string, digit: number) => {
  let length: number = 0;

  for (let i = 0; i < word.length; i++) {
    if (word[i].match(/[ -~]/)) {
      // 半角
      length += 0.5;
    } else {
      // 全角
      length += 1;
    }

    if (length > digit) {
      return word.slice(0, i).concat("…");
    }
  }

  return word;
};
