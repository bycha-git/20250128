"use server";

import { DeleteOperationInput, UpsertOperationInput } from "@azure/cosmos";
import { HistoryJSONObject } from "../model/history/history-common-model";
import { ServerActionResponse } from "../server-action-response";
import { HistoryContainer } from "../services/cosmos";
import { userHashedId } from "@/features/auth-page/helpers";

const MAX_RETRY = 9;

/** 現在のユーザのhistoryコンテナ内レコードを一括削除 */
// TODO: パフォーマンス確認 (Promise.allSettled での同時実行なども試す)
export const bulkDeleteHistoryForCurrentUser = async (
  /** 主キー */
  ids: string[],
  /** パーティションキー */
  currentUserId?: string,
): Promise<ServerActionResponse<boolean>> => {
  try {
    const userId = currentUserId ?? (await userHashedId());

    // 100件ごとに分割 (`bulk()` に渡せる最大数)
    const idChunks = [];
    for (let i = 0; i < ids.length; i += 100) {
      idChunks.push(ids.slice(i, i + 100));
    }

    for (const chunk of idChunks) {
      // まとめて削除
      const operations: DeleteOperationInput[] = chunk.map((id) => ({
        operationType: "Delete",
        partitionKey: userId,
        id,
      }));
      await HistoryContainer().items.bulk(operations, {
        continueOnError: true,
      });
    }

    return {
      status: "OK",
      response: true,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

/** historyコンテナのレコードを一括削除 */
export const bulkDeleteHistory = async (
  /**
   * 削除対象
   * - idとuserIdを指定。
   *   - idとuserIdを含むオブジェクトでも可。
   */
  targets: HistoryJSONObject[],
  retriedCount = 0,
): Promise<ServerActionResponse<boolean>> => {
  try {
    // 100件ごとに分割 (`bulk()` に渡せる最大数)
    const chunks = [];
    for (let i = 0; i < targets.length; i += 100) {
      chunks.push(targets.slice(i, i + 100));
    }

    const retryTargets = [];

    for (const chunk of chunks) {
      // まとめて削除
      const operations: DeleteOperationInput[] = chunk.map((target) => ({
        operationType: "Delete",
        partitionKey: target.userId,
        id: target.id,
      }));
      const responses = await HistoryContainer().items.bulk(operations, {
        continueOnError: true,
      });

      // Too many requests で削除失敗したものをリトライ用に追加
      const chunkRetryTargets = responses
        .map((res, index) => ({ res, index }))
        .filter(({ res }) => res.statusCode === 429)
        .map(({ index }) => chunk[index]);
      retryTargets.push(...chunkRetryTargets);
    }

    // リトライ
    // 通常の作業は SDK によって自動リトライされる (maxRetryAttemptCount) が、
    // `bulk()` の場合はそうでもない気がするため
    if (retryTargets.length > 0) {
      console.log(
        `bulkDeleteHistory: 429 Too many requests が${
          retryTargets.length
        }件発生. リトライ中`,
      );
      await wait(1000);
      const retryResponse = await bulkDeleteHistory(
        retryTargets,
        retriedCount + 1,
      );
      if (retryResponse.status === "ERROR") {
        return retryResponse;
      }
    }

    return {
      status: "OK",
      response: true,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

/** historyコンテナのレコードを一括で作成/編集 */
export const bulkUpsertHistory = async (
  resources: HistoryJSONObject[],
  retriedCount = 0,
): Promise<ServerActionResponse<boolean>> => {
  try {
    // 100件ごとに分割 (`bulk()` に渡せる最大数)
    const chunks = [];
    for (let i = 0; i < resources.length; i += 100) {
      chunks.push(resources.slice(i, i + 100));
    }

    const retryResources = [];

    for (const chunk of chunks) {
      // まとめて挿入
      const operations: UpsertOperationInput[] = chunk.map((resource) => ({
        partitionKey: resource.userId,
        resourceBody: resource,
        operationType: "Upsert",
      }));
      const responses = await HistoryContainer().items.bulk(operations, {
        continueOnError: true,
      });
      // Too many requests で挿入失敗したものをリトライ用に追加
      const chunkRetryResources = responses
        .map((res, index) => ({ res, index }))
        .filter(({ res }) => res.statusCode === 429)
        .map(({ index }) => chunk[index]);
      retryResources.push(...chunkRetryResources);

      const errorResponses = responses.filter(
        (res) => res.statusCode >= 400 && res.statusCode !== 429,
      );
      if (errorResponses.length > 0) {
        throw new Error(`DBエラー: ${errorResponses[0].statusCode}`);
      }
    }

    // リトライ
    // 通常の作業は SDK によって自動リトライされる (maxRetryAttemptCount) が、
    // `bulk()` の場合はそうでもない気がするため
    if (retryResources.length > 0) {
      if (
        retriedCount >= MAX_RETRY &&
        resources.length === retryResources.length
      ) {
        throw new Error("DBエラー: 429");
      }
      console.log("retryResources", retryResources);
      await wait(1000);
      const retryResponse = await bulkUpsertHistory(retryResources);
      if (retryResponse.status === "ERROR") {
        return retryResponse;
      }
    }

    return {
      status: "OK",
      response: true,
    };
  } catch (error) {
    return {
      status: "ERROR",
      errors: [{ message: `${error}` }],
    };
  }
};

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
