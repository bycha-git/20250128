import { redirect } from "next/navigation";

/** YondenGPT 用 */
export const redirectToPage = (path: string) => {
  redirect(`${path.charAt(0) !== "/" ? "/" : ""}${path}`);
};

/** YondenGPT 用 */
export const redirectToChatThread = (chatThreadId: string) => {
  redirect(`/chat/${chatThreadId}`);
};

/** 現在居るパスが指定したリンクに一致するか判定 */
export const checkPathHrefMatch = (
  /** 現在のパス */
  path?: string,
  /** リンク */
  href?: string,
) => {
  if (path === undefined || href === undefined) {
    return false;
  }
  return (
    path.startsWith(href) &&
    (path.length === href.length || /[/?#]/.test(path[href.length]))
  );
};
