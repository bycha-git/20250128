import { z, ZodType } from "zod";

/**
 * 空の文字列を弾く (zod schema の `refine()` 用)
 *
 * - `trim()` により、スペース(全角/半角含む)や改行のみの場合も空文字として判定する
 */
export const refineFromEmpty = (value: string) => {
  if (value.length === 0) {
    return true;
  }
  return value.trim() !== "";
};

/**
 * 配列から、指定した zod schema でパースできたもののみ含む配列を返す。
 *
 * - オブジェクトの場合、 schema に存在しないプロパティの削除も行われる。
 * - 変なデータを通さないために使用。
 */
export const getOnlyParsed = <T extends ZodType>(
  resources: unknown[],
  schema: T,
): z.infer<typeof schema>[] => {
  const safeResources: z.infer<typeof schema>[] = [];
  for (const resource of resources) {
    const parsed = schema.safeParse(resource);
    if (parsed.success) {
      safeResources.push(parsed.data);
    }
  }
  return safeResources;
};
