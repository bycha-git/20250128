"use server";
import { revalidatePath } from "next/cache";

export type Page = "extensions" | "persona" | "prompt" | "chat" | "settings";

export const revalidateCache = async (props: {
  page: Page;
  params?: string | undefined;
  type?: "layout" | "page" | undefined;
}) => {
  const { page, params, type } = props;
  if (params) {
    revalidatePath(`/${page}/${params}`, type);
  } else {
    revalidatePath(`/${page}`, type);
  }
};
