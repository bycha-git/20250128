import * as v from "valibot";

export const ServerAPIErrorMessageIDResponseSchema = v.object({
  status: v.literal("ERROR"),
  errorMessageId: v.string(),
});

export type ServerAPIErrorMessageIDResponse = v.InferInput<
  typeof ServerAPIErrorMessageIDResponseSchema
>;
