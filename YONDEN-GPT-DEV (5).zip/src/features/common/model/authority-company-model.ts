import { z } from "zod";

export const AUTHORITY_COMPANY_TYPE = "DEPARTMENT_PERMISSION";

export type AuthorityCompanyModel = z.infer<typeof AuthorityCompanyModelSchema>;

/**
 * 権限(組織)モデル
 */
export const AuthorityCompanyModelSchema = z.object({
  /** 権限ID */
  id: z.string(),
  /** レコードタイプ */
  type: z.string(),
  /** ユーザーID */
  userId: z.string(),
  /** レコード作成日時 */
  createdAt: z.string(),
  /** 親ID */
  parentId: z.string(),
  /** 所属コード */
  departmentCode: z.string(),
  /** 所属コード名称 */
  departmentName: z.string(),
  /** 権限の種類 */
  permissionId: z.string(),
});
