import { z } from "zod";

/** ドキュメントのレコードタイプ (フォルダ) */
export const FOLDER_DOCUMENT_ATTRIBUTE = "FOLDER_DOCUMENT";
/** ドキュメントのレコードタイプ (ファイル) */
export const FILE_DOCUMENT_ATTRIBUTE = "FILE_DOCUMENT";

/**
 * ドキュメント (フォルダ/ファイル)
 */
export const DocumentModelSchema = z.object({
  /** ドキュメントID */
  id: z.string(),
  /** レコードタイプ */
  type: z.enum([FOLDER_DOCUMENT_ATTRIBUTE, FILE_DOCUMENT_ATTRIBUTE]),
  /** ユーザーID */
  userId: z.string(),
  /** レコード作成日時 */
  createdAt: z.string(),
  /** チャットボットID */
  chatbotId: z.string(),
  /** 親フォルダID (ホームディレクトリの場合は "home") */
  parentFolderId: z.string(),
  /** ドキュメント名 */
  documentName: z.string(),
  /** 最終更新日時 */
  lastUpdateAt: z.string(),
  /** サイズ */
  documentSize: z.number().optional(),
  /** 独自リンクフラグ */
  isOriginalLink: z.boolean().optional(),
  /** 標準リンク */
  standardLink: z.string(),
  /** 独自リンク */
  originalLink: z.string(),
  /** エラーフラグ */
  isError: z.boolean(),
  /** エラーメッセージ */
  errorMessage: z.string(),
  /** ドキュメントパス */
  documentPath: z.string().optional(),
});

/** ドキュメント */
export type DocumentModel = z.infer<typeof DocumentModelSchema>;
