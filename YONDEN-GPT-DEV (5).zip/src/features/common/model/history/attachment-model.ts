import { z } from "zod";

export const ATTACHMENT_IMAGE_ATTRIBUTE = "ATTACHMENT_IMAGE";
export const ATTACHMENT_FILE_ATTRIBUTE = "ATTACHMENT_FILE";
export const ATTACHMENT_ASSISTANT_ATTRIBUTE = "ATTACHMENT_ASSISTANT";

/** 添付ファイルのレコードタイプ */
export const AttachmentTypeSchema = z.union([
  z.literal(ATTACHMENT_IMAGE_ATTRIBUTE),
  z.literal(ATTACHMENT_FILE_ATTRIBUTE),
  z.literal(ATTACHMENT_ASSISTANT_ATTRIBUTE),
]);

/** 添付ファイル */
export const AttachmentModelSchema = z.object({
  /** 添付ファイルID */
  id: z.string(),
  /** レコードタイプ */
  type: AttachmentTypeSchema,
  /** ユーザーID */
  userId: z.string(),
  /** レコード作成日時 (ISO 8601 形式の日時) */
  createdAt: z.string(), // .datetime({ offset: true }),
  /** ファイル名 */
  fileName: z.string(),
  /** メッセージID */
  messageId: z.string(),
  /** 表示順 */
  sortNo: z.number().default(0),
});

/** 添付ファイル */
export type AttachmentModel = z.infer<typeof AttachmentModelSchema>;

/** 添付ファイルのレコードタイプ */
export type AttachmentType = z.infer<typeof AttachmentTypeSchema>;
