import { z } from "zod";
import { JSONValueSchema } from "../common";

/** スレッド 共通プロパティ */
const BaseThreadModelSchema = z.object({
  /** スレッドID */
  id: z.string(),
  /** ユーザーID */
  userId: z.string(),
  /** レコード作成日時 (ISO 8601 形式の日時) */
  createdAt: z.string(), // .datetime({ offset: true }),
  /** 最終更新日 (ISO 8601 形式の日時) */
  lastMessageAt: z.string(), // .datetime({ offset: true }),
  /** スレッド名 */
  name: z.string(),
  /** ブックマーク */
  bookmarked: z.boolean(),
  /** スレッド名編集済みフラグ */
  edited: z.boolean(),
});

export const MODEL_THREAD_ATTRIBUTE = "MODEL_THREAD";

/** スレッド（モデル） */
// 以下の3つ以外に、任意のプロパティを許可
export const ModelThreadModelSchema = BaseThreadModelSchema.extend({
  /** レコードタイプ */
  type: z.literal(MODEL_THREAD_ATTRIBUTE),
  /** モデル */
  modelId: z.string(),
  /** モデル名 */
  modelName: z.string(),
  // 他の任意のプロパティを許可
}).catchall(JSONValueSchema);

export const CHATBOT_THREAD_ATTRIBUTE = "CHATBOT_THREAD";

/** スレッド（チャットボット） */
export const ChatbotThreadModelSchema = BaseThreadModelSchema.extend({
  /** レコードタイプ */
  type: z.literal(CHATBOT_THREAD_ATTRIBUTE),
  /** チャットボット */
  chatbotId: z.string(),
  /** チャットボットの名前 */
  chatbotName: z.string(),
  /** 一般論の制限 */
  inScope: z.boolean().optional(),
  /** 上位検索結果件数 */
  topNDocuments: z.number().optional(),
}).catchall(JSONValueSchema);

/** スレッド */
export const ThreadModelSchema = z.discriminatedUnion("type", [
  ModelThreadModelSchema,
  ChatbotThreadModelSchema,
]);

/** スレッド 共通プロパティ */
export type BaseThreadModel = z.infer<typeof BaseThreadModelSchema>;
/** スレッド（モデル） */
export type ModelThreadModel = z.infer<typeof ModelThreadModelSchema>;
/** スレッド（チャットボット） */
export type ChatbotThreadModel = z.infer<typeof ChatbotThreadModelSchema>;
/** スレッド（モデル/チャットボット） */
export type ThreadModel = z.infer<typeof ThreadModelSchema>;
