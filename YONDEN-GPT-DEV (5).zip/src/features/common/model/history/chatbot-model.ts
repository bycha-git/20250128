import { z } from "zod";

/** チャットボットのレコードタイプ */
export const CHATBOT_ATTRIBUTE = "CHATBOT";

/**
 * チャットボット
 */
export const ChatbotModelSchema = z.object({
  /** チャットボットID */
  id: z.string(),
  /** レコードタイプ */
  type: z.literal(CHATBOT_ATTRIBUTE),
  /** ユーザーID */
  userId: z.string(),
  /** レコード作成日時 */
  createdAt: z.string(),
  /** 最終更新日 */
  lastUpdateAt: z.string(),
  /** 最終更新者 */
  lastUpdateUser: z.string(),
  /** ステータス */
  status: z.string(),
  /** エラーメッセージ */
  errorMessage: z.string(),

  /** 基本情報タブ：名前 */
  chatbotName: z.string(),
  /** 基本情報タブ：説明文 */
  description: z.string(),
  /** 基本情報タブ：指定するモデルのID */
  modelId: z.string(),
  /** 基本情報タブ：指定するモデルのモデル名 */
  modelName: z.string(),

  /** パラメータータブ：チャンクサイズ */
  chunkSizeId: z.string(),
  /** パラメータータブ：トークン数 */
  token: z.string(),
  /** パラメータータブ：オーバーラップ */
  overlap: z.string(),
});

/** チャットボット */
export type ChatbotModel = z.infer<typeof ChatbotModelSchema>;
