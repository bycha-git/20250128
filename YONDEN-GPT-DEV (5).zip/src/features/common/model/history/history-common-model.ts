import { JSONObject } from "@azure/cosmos";
import { z } from "zod";
import { IDSchema } from "../common";

export const HistoryRequiredModel = z.object({
  id: IDSchema,
  type: z.string(),
  userId: z.string(),
});

export type HistoryRequiredModelSchema = z.infer<typeof HistoryRequiredModel>;

export type HistoryJSONObject = JSONObject & HistoryRequiredModelSchema;
