import { z } from "zod";

/** メッセージのレコードタイプ */
export const MESSAGE_ATTRIBUTE = "MESSAGE";

/** メッセージ */
export const MessageModelSchema = z.object({
  /** メッセージID */
  id: z.string(),
  /** レコードタイプ */
  type: z.literal(MESSAGE_ATTRIBUTE),
  /** ユーザーID */
  userId: z.string(),
  /** 送信日 (ISO 8601 形式の日時) */
  createdAt: z.string(), // .datetime({ offset: true }),
  /** スレッドID */
  threadId: z.string(),
  /** メッセージ */
  content: z.string(),
  /** 削除フラグ */
  isDeleted: z.boolean(),
  /** ロール */
  role: z.enum(["user", "assistant", "system"]),
  /** エラーフラグ */
  isError: z.boolean(),
  /** 添付ファイル読み取り結果フラグ */
  isAttachment: z.boolean(),
  /** スレッドで選択中のモデル（チャット履歴検索用） */
  modelId: z.string().optional(),
  /** スレッドで選択中のチャットボット（チャット履歴検索用） */
  chatbotId: z.string().optional(),
});

/** メッセージ */
export type MessageModel = z.infer<typeof MessageModelSchema>;

/** メッセージのロール */
export type MessageRole = MessageModel["role"];
