import { z } from "zod";

export const TEMPLATE_ATTRIBUTE = "TEMPLATE";

/** プロンプトテンプレート */
export const TemplateModelSchema = z.object({
  /** テンプレートID */
  id: z.string(),
  /** レコードタイプ */
  type: z.literal(TEMPLATE_ATTRIBUTE),
  /** ユーザーID */
  userId: z.string(),
  /** レコード作成日時 */
  createdAt: z.string(), // .datetime({ offset: true }),
  /** 最終更新日 */
  lastUpdateAt: z.string(), // .datetime({ offset: true }),
  /** 最終更新者 */
  lastUpdateUser: z.string(),
  /** 選択回数 */
  numberOfChoices: z.number(),
  /** 名前 */
  // TODO: message を消す
  templateName: z.string().min(1 /* , { message: ETEMPLATE0005 } */),
  /** テンプレート */
  template: z.string().min(1 /* { message: ETEMPLATE0005 } */),
});

/** プロンプトテンプレート */
export type TemplateModel = z.infer<typeof TemplateModelSchema>;
