import { z } from "zod";

export type CompanyModel = z.infer<typeof CompanyModelSchema>;

/**
 * 組織モデル
 */
export const CompanyModelSchema = z.object({
  /** id (DBレイアウトには記述なし)*/
  id: z.string(),
  /** 所属コード */
  departmentCode: z.string(),
  /** 所属コード名称 */
  departmentName: z.string(),
  /** 最終更新日(DBレイアウトに記述なし) */
  updatedAt: z.string(),
  /** 管理者フラグ */
  administrator: z.boolean(),
  /** 会社名 */
  companyName: z.boolean(),
});
