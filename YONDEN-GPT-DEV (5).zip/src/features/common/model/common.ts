import { z } from "zod";

/** ID */
export const IDSchema = z.string();

/** IDとタイプを含むオブジェクト */
export const ObjectWithIDAndTypeSchema = z
  .object({
    id: IDSchema,
    type: z.string(),
  })
  .catchall(z.unknown());

const JSONLiteralValueSchema = z.union([
  z.string(),
  z.number(),
  z.boolean(),
  z.null(),
  z.undefined(),
]);
/** JSON で表せる全ての値 */
export const JSONValueSchema = z.union([
  JSONLiteralValueSchema,
  z.array(JSONLiteralValueSchema),
  z.record(JSONLiteralValueSchema),
]);
/** JSON で表せる全ての値 */
export type JSONValue = z.infer<typeof JSONValueSchema>;
