import { z } from "zod";

/** 権限のレコードタイプ */
export const PERMISSION_ATTRIBUTE = "PERMISSION";

/**
 * 権限
 */
export const PermissionModelSchema = z.object({
  /** 権限ID */
  id: z.string(),
  /** レコードタイプ */
  type: z.literal(PERMISSION_ATTRIBUTE),
  /** 表示名 */
  label: z.string(),
  /** 値 */
  value: z.string(),
  /** 表示順 */
  sortNo: z.number(),
});

/** 権限 */
export type PermissionModel = z.infer<typeof PermissionModelSchema>;
