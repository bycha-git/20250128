import { z } from "zod";
import { JSONValueSchema } from "../common";

/** モデルのレコードタイプ */
export const MODEL_ATTRIBUTE = "MODEL";

/**
 * モデル (Azure Functions情報を除外したもの)
 */
export const ModelModelSchema = z.object({
  /** モデルID */
  id: z.string(),
  /** レコードタイプ */
  type: z.literal(MODEL_ATTRIBUTE),
  /** モデル名 */
  name: z.string(),
  /** 表示順 */
  sortNo: z.number(),
  /** 使用可能フラグ */
  enabled: z.boolean(),
  /** 画像ボタン利用可能フラグ */
  imageEnabled: z.boolean(),
  /** チャットボットで指定可能フラグ */
  enabledAtChatbot: z.boolean(),
  /** モデル用初期値フラグ */
  isInitialAtThread: z.boolean(),
  /** チャットボット用初期値フラグ */
  isInitialAtChatbot: z.boolean(),
  /** 対応ファイル形式 */
  supportedFileExt: z.string().optional(),
  /** 画像対応ファイル形式 */
  supportedImageExt: z.string().optional(),
});
/** モデル */
export type ModelModel = z.infer<typeof ModelModelSchema>;

/**
 * モデル (Azure Functions情報つき)
 * - Azure Functions情報を使いたい時以外は使わないこと (情報をクライアントに出さないため)
 */
export const ModelWithFuncInfoModelSchema = ModelModelSchema.extend({
  // TODO: default 解除?
  /** 関数URL */
  functionsUrl: z.string().default(""),
  /** アクセスキー */
  accessKey: z.string().default(""),
});
/** モデル (Azure Functions情報つき) */
export type ModelWithFuncInfoModel = z.infer<
  typeof ModelWithFuncInfoModelSchema
>;

/** モデルパラメータのレコードタイプ */
export const MODEL_PARAMETER_ATTRIBUTE = "MODEL_PARAMETER";

/** モデルパラメータ */
export const ModelParameterModelSchema = z.object({
  /** モデルパラメータID */
  id: z.string(),
  /** レコードタイプ */
  type: z.literal(MODEL_PARAMETER_ATTRIBUTE),
  /** モデル */
  modelId: z.string(),
  /** 要素の種類 */
  elementType: z.enum(["select", "button"]),
  /** パラメータ名 */
  name: z.string(),
  /** 表示名 */
  label: z.string(),
  /** 表示順 */
  sortNo: z.number(),
  /** 説明文 */
  description: z.string(),
});
/** モデルパラメータ */
export type ModelParameterModel = z.infer<typeof ModelParameterModelSchema>;

/** モデルパラメータ選択肢のレコードタイプ */
export const MODEL_PARAMETER_OPTION_ATTRIBUTE = "MODEL_PARAMETER_OPTION";

/** モデルパラメータ選択肢 */
export const ModelParameterOptionModelSchema = z.object({
  /** 選択肢ID */
  id: z.string(),
  /** レコードタイプ */
  type: z.literal(MODEL_PARAMETER_OPTION_ATTRIBUTE),
  /** モデルパラメータID */
  modelParameterId: z.string(),
  /** 表示名 */
  label: z.string(),
  /** 値 */
  value: JSONValueSchema,
  /** 値（スレッド情報参照画面表示用） */
  valueForDisplay: z.string().optional(),
  /** 表示順 */
  sortNo: z.number(),
  /** 初期値フラグ */
  isInitial: z.boolean(),
});
/** モデルパラメータ選択肢 */
export type ModelParameterOptionModel = z.infer<
  typeof ModelParameterOptionModelSchema
>;
