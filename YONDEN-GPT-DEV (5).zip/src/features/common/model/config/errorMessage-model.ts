import { z } from "zod";

export type ErrorMessageModel = z.infer<typeof ErrorMessageModelSchema>;

/**
 * エラーメッセージ
 */
export const ErrorMessageModelSchema = z.object({
  /** エラーメッセージId */
  id: z.string(),
  /** レコードタイプ */
  type: z.string(),
  /** メッセージID（取得用） */
  messageId: z.string(),
  /** エラーメッセージ */
  message: z.string(),
});
