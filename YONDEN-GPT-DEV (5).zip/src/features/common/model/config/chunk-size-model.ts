import { z } from "zod";

/** チャンクサイズのレコードタイプ */
export const CHUNK_SIZE_ATTRIBUTE = "CHUNK_SIZE";

/**
 * チャンクサイズ
 */
export const ChunkSizeModelSchema = z.object({
  /** チャンクサイズID */
  id: z.string(),
  /** レコードタイプ */
  type: z.literal(CHUNK_SIZE_ATTRIBUTE),
  /** モデル名 */
  label: z.string(),
  /** 値 */
  value: z.string(),
  /** 表示順 */
  sortNo: z.number(),
});

/** チャンクサイズ */
export type ChunkSizeModel = z.infer<typeof ChunkSizeModelSchema>;
