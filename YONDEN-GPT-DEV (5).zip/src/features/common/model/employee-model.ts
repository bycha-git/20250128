import { z } from "zod";

export type EmployeeModel = z.infer<typeof EmployeeModelSchema>;

/**
 * 社員モデル
 */
export const EmployeeModelSchema = z.object({
  /** ユーザープリンシパルネーム */
  userPrincipalName: z.string(),
  /** 従業員名 */
  employeeName: z.string(),
  /** 従業員番号 */
  id: z.string(),
  /** 所属コード2桁 */
  department_code_2: z.string(),
  /** 所属コード2桁名称 */
  department_code_2_name: z.string(),
  /** 所属コード4桁 */
  department_code_4: z.string(),
  /** 所属コード4桁名称 */
  department_code_4_name: z.string(),
  /** 所属コード6桁 */
  department_code_6: z.string(),
  /**  所属コード6桁名称 */
  department_code_6_name: z.string(),
  /** 所属コード8桁 */
  department_code_8: z.string(),
  /** 所属コード8桁名称 */
  department_code_8_name: z.string(),
  /** メールアドレス */
  mailAddress: z.string().optional(),
  /** 管理者フラグ */
  administrator: z.boolean(),
  /**最終更新日（DBレイアウトにはない） */
  updatedAt: z.string().optional(),
  /** オブジェクトID */
  objectId: z.string().optional(),
});
