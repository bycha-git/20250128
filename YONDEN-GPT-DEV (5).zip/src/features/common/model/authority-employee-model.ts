import { z } from "zod";

export const AUTHORITY_EMPLOYEE_TYPE = "USER_PERMISSION";

export type AuthorityEmployeeModel = z.infer<
  typeof AuthorityEmployeeModelSchema
>;

/**
 * 権限(ユーザー)モデル
 */
export const AuthorityEmployeeModelSchema = z.object({
  /** 権限ID */
  id: z.string(),
  /** レコードタイプ */
  type: z.string(),
  /** ユーザーID */
  userId: z.string(),
  /** レコード作成日時 */
  createdAt: z.string(),
  /** 親ID */
  parentId: z.string(),
  /** 従業員番号 */
  employeeId: z.string(),
  /** 従業員名 */
  employeeName: z.string(),
  /** 権限の種類 */
  permissionId: z.string(),
});
