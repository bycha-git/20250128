import { z } from "zod";

/** フォームの入力値 */
export const ModelParameterFormSchema = z.object({
  modelId: z.string(),
  /** key: パラメータ名, value: 選択した値 */
  parameters: z.record(z.string(), z.string()),
});

export type ModelParameterFormData = z.infer<typeof ModelParameterFormSchema>;
