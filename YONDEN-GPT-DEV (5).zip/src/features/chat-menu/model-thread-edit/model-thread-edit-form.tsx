"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { ModelParameterFormData, ModelParameterFormSchema } from "./schema";
import { ModelWithParams } from "@/features/chat-view/chat-services/modelOrganizer";
import { Button } from "@/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/ui/form";
import { RadioGroup, RadioGroupItem } from "@/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/ui/select";

interface ModelParameterFormProps {
  models: ModelWithParams[];
  onSubmit?: (data: ModelParameterFormData) => void;
}

// react-hook-form と shadcn/ui の Form 等の組み合わせを試す
export function ModelParameterForm({
  models,
  onSubmit: onSubmitProp,
}: ModelParameterFormProps) {
  const onSubmit = useCallback(
    (data: ModelParameterFormData) => {
      // 仮
      console.log("onSubmit", data);
      onSubmitProp?.(data);
    },
    [onSubmitProp],
  );
  const [selectedModelId, setSelectedModelId] = useState<string>(
    () => models.find((model) => model.isInitialAtThread)?.id ?? "",
  );

  /** 現在選択中のモデル内容 */
  const currentModel = useMemo(() => {
    return models.find((model) => model.id === selectedModelId);
  }, [models, selectedModelId]);

  // フォームの初期値を設定
  const getDefaultValues = useCallback(() => {
    const defaultValues: Record<string, string> = {};
    currentModel?.parameters.forEach((param) => {
      const defaultOption = param.options.find((opt) => opt.isInitial);
      if (defaultOption) {
        defaultValues[param.name] = defaultOption.value;
      }
    });
    return {
      modelId: selectedModelId,
      parameters: defaultValues,
    };
  }, [currentModel, selectedModelId]);

  const form = useForm<ModelParameterFormData>({
    resolver: zodResolver(ModelParameterFormSchema),
    defaultValues: getDefaultValues(),
  });

  // モデル選択時にフォームをリセット
  useEffect(() => {
    form.reset(getDefaultValues());
  }, [form, getDefaultValues, selectedModelId]);

  // TODO:
  // 別モデルを選択してから戻したときに選択肢復元
  // Formコンポーネントをグリッドにしたい
  // (最終的にはPC版のみグリッド、スマホ版は現状と同じ縦並び)
  // RadioGroupをFigmaのデザインに合わせて作り替えたい
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        {/* モデル選択 */}
        <FormField
          control={form.control}
          name="modelId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>モデル</FormLabel>
              <Select
                value={field.value}
                onValueChange={(value) => {
                  field.onChange(value);
                  setSelectedModelId(value);
                }}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="(モデル選択)" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {models.map((model) => (
                    <SelectItem key={model.id} value={model.id}>
                      {model.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* パラメータ選択 */}
        {currentModel?.parameters.map((param) => (
          <FormField
            key={param.id}
            control={form.control}
            name={`parameters.${param.name}`}
            render={({ field }) => (
              <FormItem>
                <FormLabel>{param.label}</FormLabel>
                {param.elementType === "select" && (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="選択してください" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {param.options.map((option) => (
                        <SelectItem key={option.id} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
                {param.elementType === "button" && (
                  <RadioGroup
                    value={field.value}
                    onValueChange={field.onChange}
                    className="flex flex-col space-y-1"
                  >
                    {param.options.map((option) => (
                      <FormControl key={option.id}>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value={option.value} />
                          <span>{option.label}</span>
                        </div>
                      </FormControl>
                    ))}
                  </RadioGroup>
                )}
                {param.description && (
                  <p className="whitespace-pre-wrap text-sm text-gray-03">
                    {param.description}
                  </p>
                )}
                <FormMessage />
              </FormItem>
            )}
          />
        ))}

        {/* TODO: 「会話を開始する」ボタンを使う */}
        <Button type="submit">送信</Button>
      </form>
    </Form>
  );
}
