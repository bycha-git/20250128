import { FC } from "react";
import { ModelWithParams } from "../chat-view/chat-services/modelOrganizer";
import {
  BaseThreadModel,
  ChatbotThreadModel,
  ModelThreadModel,
  ThreadModel,
} from "../common/model/history/thread-model";
import { ChatList } from "./chat-list";
import { ChatListItemProps } from "./chat-list-item";
import { ChatMenuFooter } from "./chat-menu-footer/chat-menu-footer";
import { ChatMenuHeader } from "./chat-menu-header/chat-menu-header";

interface ChatMenuProps {
  listItems?: Array<ThreadModel>;
  models?: Array<ModelWithParams>;
  onCloseMenu?: () => void;
}
export const ChatMenu: FC<ChatMenuProps> = ({
  models = [],
  listItems = [],
  onCloseMenu,
}) => (
  <aside className="row-span-full grid h-full grid-rows-[auto_minmax(0,1fr)_auto] gap-1.5 bg-gray-01">
    <ChatMenuHeader
      models={models}
      disabled={listItems.length < 1}
      onCloseMenu={onCloseMenu}
    />
    <ChatList
      showItemOptions
      listItems={listItems.map(itemToListItem)}
      onCloseMenu={onCloseMenu}
    />
    <ChatMenuFooter />
  </aside>
);

const itemToListItem = (item: Partial<ThreadModel>): ChatListItemProps => {
  const bookmarked = false;
  const createdAt = new Date("2020-01-01T00:00:00Z").toISOString();
  const type = item.type ?? "MODEL_THREAD";
  const userId = "1";
  const href = `/chat/${item.id}`;
  const edited = false;
  const modelId = "";
  const modelName = "";
  const ocr = "ocr_yes";
  const baseItem: BaseThreadModel = {
    id: "",
    name: "",
    lastMessageAt: createdAt,
    bookmarked,
    createdAt,
    userId,
    edited,
  };
  const filledItem =
    type === "MODEL_THREAD"
      ? ({
          ...baseItem,
          modelId,
          modelName,
          ocr,
          ...item,
          type: "MODEL_THREAD",
        } satisfies ModelThreadModel as ModelThreadModel)
      : ({
          ...baseItem,
          chatbotId: "",
          chatbotName: "",
          inScope: false,
          topNDocuments: 0,
          strictness: "neutral",
          strictnessValue: 0,
          ...item,
          type: "CHATBOT_THREAD",
        } satisfies ChatbotThreadModel as ChatbotThreadModel);
  return {
    href,
    item: filledItem,
  };
};
