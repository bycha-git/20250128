"use client";

import {
  createContext,
  FC,
  PropsWithChildren,
  useContext,
  useMemo,
} from "react";

interface ContextProps {
  /** 添付ファイル/ドキュメントとして取込可能なファイル形式のリスト (accept属性に使用) */
  supportedFileExt: string;
  /** 画像として取込可能なファイル形式のリスト (accept属性に使用) */
  supportedImageExt: string;
}

const Context = createContext<ContextProps | null>(null);

interface ProviderProps extends PropsWithChildren, ContextProps {}

/** ホーム画面用の環境引数等を提供 */
export const HomeEnvProvider: FC<ProviderProps> = (props: ProviderProps) => {
  const { supportedFileExt, supportedImageExt } = props;
  const value = useMemo(() => {
    return {
      supportedFileExt,
      supportedImageExt,
    };
  }, [supportedFileExt, supportedImageExt]);
  return <Context.Provider value={value}>{props.children}</Context.Provider>;
};

/** ホーム画面用の環境引数等を取得 */
export const useHomeEnvContext = () => {
  const context = useContext(Context);
  if (!context) {
    throw new Error("Home Context is null");
  }

  return context;
};
