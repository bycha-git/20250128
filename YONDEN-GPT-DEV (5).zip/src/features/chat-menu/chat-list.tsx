"use client";
import { forwardRef } from "react";
import { ThreadModel } from "../common/model/history/thread-model";
import { sortByItemTimestamp } from "../common/util";
import { cn } from "../ui/lib";
import { ScrollArea } from "../ui/scroll-area";
import { ChatListGroup } from "./chat-list-group";
import { ChatListItem, ChatListItemProps } from "./chat-list-item";
import {
  CHAT_LIST_GROUP_BOOKMARKED,
  CHAT_LIST_GROUP_OTHER,
  CHAT_LIST_GROUP_RECENT,
  CHAT_LIST_GROUPS,
  ChatListItemsGroup,
  ChatListItemsGroupName,
} from "./chat-menu-services/models";

interface Props {
  className?: string;
  /** リスト内容 */
  listItems?: Array<ChatListItemProps>;
  /** リストの項目がクリックされた時に実行される関数 */
  onListItemClick?: (
    item: ThreadModel,
    event: React.MouseEvent<HTMLElement, MouseEvent>,
  ) => void;
  /** モバイル版のメニュー画面を閉じる */
  onCloseMenu?: () => void;
  /**
   * ブックマーク/タイトル編集/削除のアイコンを表示するか
   * @default false
   */
  showItemOptions?: boolean;
}

export const ChatList = forwardRef<React.ElementRef<typeof ScrollArea>, Props>(
  (
    {
      className,
      listItems = [],
      onListItemClick,
      onCloseMenu,
      showItemOptions = false,
    },
    ref,
  ) => {
    const groupList = groupChatThreadByType(listItems);
    return (
      <ScrollArea
        ref={ref}
        className={cn("flex flex-col gap-[0.8125rem] px-3 py-1.5", className)}
      >
        {groupList.map((group) => (
          <ChatListGroup key={group.groupName} title={group.groupName}>
            {group.list.map((prop) => (
              <ChatListItem
                key={prop.item.id}
                showItemOptions={showItemOptions}
                onClick={onListItemClick}
                onCloseMenu={onCloseMenu}
                {...prop}
              />
            ))}
          </ChatListGroup>
        ))}
      </ScrollArea>
    );
  },
);
ChatList.displayName = "ChatList";

const groupChatThreadByType = (menuItems: Array<ChatListItemProps>) => {
  /** グループ名を付けたリスト */
  const groupedMenuItems: Array<ChatListItemsGroup> = [];

  // 現在時刻
  const today = new Date();
  // 7日前の時刻
  const sevenDaysAgo = new Date(today);
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

  // グループ名を付ける
  menuItems.sort(sortByItemTimestamp).forEach((el) => {
    const item = el.item;
    if (item.bookmarked) {
      groupedMenuItems.push({
        ...el,
        groupName: CHAT_LIST_GROUP_BOOKMARKED,
      });
    } else if (new Date(item.lastMessageAt) > sevenDaysAgo) {
      groupedMenuItems.push({
        ...el,
        groupName: CHAT_LIST_GROUP_RECENT,
      });
    } else {
      groupedMenuItems.push({
        ...el,
        groupName: CHAT_LIST_GROUP_OTHER,
      });
    }
  });

  // Mapにまとめる
  const menuItemsGrouped = groupedMenuItems.reduce(
    (acc, el) => {
      const key = el.groupName;
      const list = acc.get(key) ?? [];
      list.push(el);
      acc.set(key, list);
      return acc;
    },
    new Map<ChatListItemsGroupName, Array<ChatListItemsGroup>>([
      [CHAT_LIST_GROUP_BOOKMARKED, []],
      [CHAT_LIST_GROUP_RECENT, []],
      [CHAT_LIST_GROUP_OTHER, []],
    ]),
  );

  const groupNames = CHAT_LIST_GROUPS;

  // 配列にまとめる
  const groupList: Array<{
    groupName: string;
    list: Array<ChatListItemProps>;
  }> = [];
  for (const groupName of groupNames) {
    const list = menuItemsGrouped.get(groupName);
    if (list) {
      groupList.push({
        groupName: groupName,
        list: list.sort(sortByItemTimestamp),
      });
    }
  }

  return groupList;
};
