import { FC } from "react";
import { ChatMenuProfileButton } from "./chat-menu-profile-button";
import { UserModel } from "@/types/next-auth";

interface ChatMenuFooterProps {
  user?: UserModel | null;
}

export const ChatMenuFooter: FC<ChatMenuFooterProps> = ({ user }) => (
  <div className={`m-1 p-1`}>
    <ChatMenuProfileButton />
  </div>
);
