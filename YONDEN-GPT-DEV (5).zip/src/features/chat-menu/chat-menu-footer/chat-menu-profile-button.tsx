import { signOut, useSession } from "next-auth/react";
import { FC, useState } from "react";
import { Button } from "@/features/ui/button";
import { MobileMenuIcon } from "@/features/ui/mobile-menu-icon";
import { ForMobile, useResponsive } from "@/features/ui/responsive";
import { Window } from "@/features/ui/window";

export const ChatMenuProfileButton: FC = () => {
  const { data: session } = useSession();
  const [isOpen, setIsOpen] = useState(false);
  return (
    <ForMobile>
      <Button className="w-full bg-gray-01 p-0" onClick={() => setIsOpen(true)}>
        <div className={`flex w-full items-center gap-2 px-3 pt-3`}>
          <MobileMenuIcon variant="profile" />
          <div className="flex-grow text-left text-sm text-black">
            {session?.user.name || "プロフィール"}
          </div>
          <span className="i-lucide-ellipsis h-5 w-5 text-black" />
        </div>
      </Button>
      <ChatMenuProfileWindow open={isOpen} onOpenChange={setIsOpen} />
    </ForMobile>
  );
};

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const ChatMenuProfileWindow: FC<Props> = ({ open, onOpenChange }: Props) => {
  const { isMobile } = useResponsive();
  const { data: session } = useSession();

  return (
    <Window
      title={session?.user.name || "ユーザー名"}
      open={open}
      onOpenChange={onOpenChange}
      className="h-full w-full rounded-none"
      mobileFlg={isMobile}
    >
      <div className="flex flex-col gap-2 p-2">
        <div className="text-[12px]/[14px]">メールアドレス</div>
        <div className="mb-2 text-[14px]/[16px]">{session?.user.email}</div>
        <div className="text-[12px]/[14px]">組織名</div>
        <div className="mb-5 text-[14px]/[16px]">
          {session?.user.departmentName}
        </div>
        <Button
          icon={"i-material-symbols-logout-rounded size-6"}
          text="ログアウト"
          className="w-fit px-2"
          onClick={() => signOut({ callbackUrl: "/" })}
          variant={"link"}
        ></Button>
      </div>
    </Window>
  );
};
