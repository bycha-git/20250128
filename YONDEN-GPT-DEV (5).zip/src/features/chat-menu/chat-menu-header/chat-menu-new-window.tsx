"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import {
  createChatAndRedirect,
  ModelThreadParams,
} from "@/features/chat-view/chat-services/chat-thread-service";
import {
  ModelParameter,
  ModelParameterOption,
  ModelWithParams,
} from "@/features/chat-view/chat-services/modelOrganizer";
import { JSONValue } from "@/features/common/model/common";
import { ModelThreadModel } from "@/features/common/model/history/thread-model";
import { isRedirectError } from "@/features/common/util";
import { showError } from "@/features/globals/global-message-store";
import { useResponsive } from "@/features/ui/responsive";
import { ScrollArea } from "@/features/ui/scroll-area";
import { Button } from "@/ui/button";
import ComboBox from "@/ui/combbox";
import { Separator } from "@/ui/separator";
import { Window } from "@/ui/window";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  models: Array<ModelWithParams>;
  onCloseMenu?: () => void;
}

type ChangeThreadParams = (params: ChangeThreadParamsMap) => void;
type ChangeThreadParamsMap = Map<string, JSONValue>;

/** ホーム 会話開始画面(モデル) */
export const ChatMenuNewWindow = ({
  open,
  onOpenChange,
  models,
  onCloseMenu,
}: Props) => {
  const errMessage = useErrorMessage();
  const { isMobile } = useResponsive();
  const [loading, setLoading] = useState(false);
  const [prevOpen, setPrevOpen] = useState(open);
  if (prevOpen !== open) {
    if (open) setLoading(false);
    setPrevOpen(open);
  }
  const initialModel = useMemo(() => {
    return (
      models.find((model) => model.isInitialAtThread && model.enabled) ??
      models.find((model) => model.enabled)
    );
  }, [models]);
  // 選択されたモデル
  const [selectedModel, setSelectedModel] = useState<
    ModelWithParams | undefined
  >(initialModel);
  // 各モデルごとにパラメータを保存
  const [threadParams, setThreadParams] = useState<{
    [id: string]: ModelThreadParams;
  }>();
  const initialThreadParams = useMemo(() => {
    const initThreadParams: { [id: string]: ModelThreadParams } = {};
    models
      .filter((model) => model.enabled)
      .forEach((model) => {
        const threadParam: ModelThreadParams = {
          modelId: model.id,
          modelName: model.name,
        };
        model.parameters.forEach((param) => {
          // 初期値を設定
          const initialOption =
            param.options.find((option) => option.isInitial) ??
            param.options.at(0);
          if (initialOption?.valueForDisplay) {
            threadParam[param.name] = initialOption.valueForDisplay;
            // TODO: Number変換を削除
            threadParam[`${param.name}Value`] = Number(initialOption.value);
          } else {
            threadParam[param.name] = initialOption?.value;
          }
        });
        initThreadParams[model.id] = threadParam;
      });
    return initThreadParams;
  }, [models]);
  // 選択されたモデルに対応したパラメータを設定
  const threadParameter = useMemo(
    () =>
      threadParams
        ? threadParams[selectedModel?.id || ""] || {
            modelId: "",
            modelName: "",
          }
        : {
            modelId: "",
            modelName: "",
          },
    [selectedModel, threadParams],
  );

  // パラメータ選択時の処理
  const changeThreadParams: ChangeThreadParams = (params) => {
    const isChanged = [...params.entries()].some(
      ([key, val]) => threadParameter[key] !== val,
    );
    if (isChanged) {
      const selectedThreadParams = { ...threadParameter };
      for (const [key, val] of params.entries()) {
        selectedThreadParams[key] = val;
      }
      setThreadParams({
        ...threadParams,
        [selectedThreadParams.modelId]: selectedThreadParams,
      });
    }
  };
  // 会話開始ボタン押下時の処理
  const handleStartChat = useCallback(async () => {
    setLoading(true);
    const createModelThreadParams: ModelThreadParams = {
      ...threadParameter,
    };

    try {
      const response = await createChatAndRedirect(createModelThreadParams);
      // throw されずにここに戻ってきた
      // →エラー。画面を閉じない
      if (response) {
        showError(errMessage[response.errors[0]?.message]);
      }
    } catch (e) {
      // NEXT_REDIRECT が throw された (スレッド画面にリダイレクトされた)
      // →正常。画面を閉じる
      if (isRedirectError(e)) {
        onCloseMenu?.();
        onOpenChange(false);
      } else {
        showError(errMessage["ECOMMON0001"]);
      }
    }
    setLoading(false);
  }, [errMessage, onCloseMenu, onOpenChange, threadParameter]);

  // モーダルを閉じるときまたはモーダルが閉じているときに画面が更新された場合に
  // 選択モデルと各モデルパラメータを初期化
  useEffect(() => {
    if (!open) {
      setSelectedModel(initialModel);
      setThreadParams(initialThreadParams);
    }
  }, [initialModel, initialThreadParams, models, open]);

  return (
    <Window
      open={open}
      onOpenChange={onOpenChange}
      title={"会話を始めましょう"}
      showClose={true}
      primaryButtonText={!isMobile && "会話を開始する"}
      onClickPrimary={handleStartChat}
      className={isMobile ? "h-full w-full rounded-none" : "w-fit"}
      mobileFlg={isMobile}
    >
      <div
        className={`grid h-[90%] min-h-0 items-center gap-2 overflow-y-auto ${isMobile ? "grid-cols-1 grid-rows-[auto_auto_minmax(auto,1fr)_auto]" : "grid-cols-[150px_1fr]"}`}
      >
        <p>モデル</p>
        <ModelSelector
          models={models.filter((model) => model.enabled)}
          onSelect={(id) => {
            const selectItem = models.find((model) => model.id == id);
            setSelectedModel(selectItem);
          }}
          selectedItemName={selectedModel?.name || ""}
        />
        <ModelParameterArea
          model={selectedModel}
          threadParams={threadParameter}
          changeThreadParams={changeThreadParams}
        />

        {isMobile && (
          <Button
            text="会話を開始する"
            className={`mx-auto`}
            onClick={handleStartChat}
          />
        )}
      </div>
    </Window>
  );
};

export const ModelSelector = (props: {
  models: Array<ModelWithParams>;
  onSelect?: (value: string) => void;
  selectedItemName?: string;
  disabled?: boolean;
  placeholder?: string;
}) => {
  const {
    models,
    onSelect,
    selectedItemName,
    disabled = false,
    placeholder,
  } = props;
  return (
    <div className="flex items-center gap-3">
      <ComboBox
        items={models}
        className="w-full text-gray-01"
        onSelectId={(id) => {
          if (onSelect) onSelect(id);
        }}
        placeholder={placeholder}
        idField={"id"}
        textField={"name"}
        selectedItem={selectedItemName}
        disabled={disabled}
      ></ComboBox>
    </div>
  );
};

export const ModelParameterArea = (props: {
  model?: ModelWithParams;
  threadParams: ModelThreadParams | ModelThreadModel;
  changeThreadParams?: ChangeThreadParams;
  disabled?: boolean;
}) => {
  const { model, threadParams, changeThreadParams, disabled = false } = props;
  return (
    <ScrollArea className="col-span-full h-full">
      <div className="items-center gap-2 md:grid md:grid-cols-[150px_1fr]">
        {model?.parameters.map((param: ModelParameter) => (
          <ModelParameterContent
            key={param.id}
            param={param}
            threadParams={threadParams}
            changeThreadParams={changeThreadParams}
            disabled={disabled}
          />
        ))}
      </div>
    </ScrollArea>
  );
};
const ModelParameterContent = ({
  param,
  threadParams,
  changeThreadParams,
  disabled,
}: {
  param: ModelParameter;
  threadParams: ModelThreadParams | ModelThreadModel;
  changeThreadParams?: ChangeThreadParams;
  disabled?: boolean;
}) => {
  const { isDesktop } = useResponsive();
  return (
    <>
      {isDesktop && <Separator className="col-span-full" />}
      <p>{param.label}</p>
      <ParameterSelecter
        type={param.elementType}
        paramName={param.name}
        parameterOptions={param.options}
        threadParams={threadParams}
        changeThreadParams={changeThreadParams}
        disabled={disabled}
      />
      <div />
      <div className="whitespace-pre-wrap text-sm">{param.description}</div>
    </>
  );
};

const ParameterSelecter = (props: {
  type: "button" | "select";
  paramName: string;
  parameterOptions: ModelParameterOption[];
  threadParams: ModelThreadParams | ModelThreadModel;
  changeThreadParams?: ChangeThreadParams;
  disabled?: boolean;
}) => {
  const {
    type,
    paramName,
    parameterOptions,
    threadParams,
    changeThreadParams,
    disabled = false,
  } = props;
  switch (type) {
    case "button":
      return (
        // TODO: デザイン修正
        <div
          className={`flex size-fit flex-wrap items-center gap-4 rounded-md ${disabled ? "bg-white-01" : "bg-gray-01"} p-2`}
        >
          {parameterOptions.map((option, i) => {
            const selected =
              (option.valueForDisplay || option.value) ===
              threadParams[paramName];
            return (
              <span key={i} className="w-fit">
                <Button
                  className={`h-fit !flex-[0_0_auto] p-2 ${
                    selected
                      ? disabled
                        ? "bg-gray-hover"
                        : "bg-white-01"
                      : disabled
                        ? "bg-white-01"
                        : "bg-gray-01"
                  } !rounded-md text-sm/4 text-black md:text-base`}
                  color="default"
                  text={option.label}
                  onClick={() => {
                    const params: ChangeThreadParamsMap = new Map();
                    if (option.valueForDisplay) {
                      params.set(paramName, option.valueForDisplay);
                      // TODO: Number変換を削除
                      params.set(`${paramName}Value`, Number(option.value));
                    } else {
                      params.set(paramName, option.value);
                    }
                    changeThreadParams?.(params);
                  }}
                  disabled={disabled}
                ></Button>
              </span>
            );
          })}
        </div>
      );
    case "select":
      return (
        <ComboBox
          items={parameterOptions}
          selectedItem={
            parameterOptions.find(
              (option) =>
                (option.valueForDisplay || option.value) ===
                threadParams[paramName],
            )?.label
          }
          idField={"id"}
          textField={"label"}
          onSelectId={(id) => {
            const option = parameterOptions.find((option) => option.id === id)!;
            const params: ChangeThreadParamsMap = new Map();
            if (option.valueForDisplay) {
              params.set(paramName, option.valueForDisplay);
              // TODO: Number変換を削除
              params.set(`${paramName}Value`, Number(option.value));
            } else {
              params.set(paramName, option.value);
            }
            changeThreadParams?.(params);
          }}
          disabled={disabled}
        ></ComboBox>
      );
  }
};
