"use client";

import { useCallback } from "react";
import { deleteAllThreads } from "../chat-menu-services/chat-menu-service";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { showError } from "@/features/globals/global-message-store";
import { useConfirm } from "@/ui/confirm";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/ui/dropdown-menu";
import { cn } from "@/ui/lib";

interface Props {
  className?: string;
  disabled: boolean;
}
export const ChatMenuOptions = ({ className, disabled }: Props) => {
  const { confirmWait } = useConfirm();
  const errMessage = useErrorMessage();

  const handleDeleteAllThreads = useCallback(async () => {
    // 確認画面表示
    const confirmWindow = await confirmWait({
      title: "スレッドを削除しますか？",
      text: (
        <>
          <strong>全てのスレッド</strong>
          {" を削除します。"}
        </>
      ),
      okButtonText: "削除する",
      cancelButtonText: "キャンセルする",
    });

    // 確認結果
    if (confirmWindow.ok) {
      // 処理実行
      try {
        const response = await deleteAllThreads();
        // throw されずにここに戻ってきた
        // →エラーだが、これは通常起きないはず。また確認画面はもう一度ボタンを押せない。
        // 画面を閉じたうえで、一応エラー表示
        if (response) {
          showError(errMessage["ECOMMON0001"]);
        }
      } catch {
        // NEXT_REDIRECT が throw された (スレッド画面にリダイレクトされた)
        // →正常。画面を閉じる
      }
    }
    // 確認画面を閉じる
    confirmWindow.close();
  }, [confirmWait, errMessage]);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          aria-label="オプションを開く"
          title="オプション"
          className={cn("px-1 py-2.5 hover:bg-gray-hover", className)}
        >
          <span className="i-lucide-ellipsis h-4 w-4" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent side="bottom" align="start">
        <DropdownMenuItem onSelect={handleDeleteAllThreads} disabled={disabled}>
          <div className="flex gap-2">
            <span className="i-material-symbols-delete-outline-rounded size-6" />
            <span className="text-sm/6">全てのスレッドを削除</span>
          </div>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
