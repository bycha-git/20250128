"use client";

import Link from "next/link";
import { FC } from "react";
import { MobileMenuIcon } from "../../ui/mobile-menu-icon";

export const ChatMenuChatbotButton: FC = () => {
  return (
    <div className="md:hidden">
      <Link
        className="flex w-full items-center gap-2 p-2.5 hover:bg-gray-hover md:gap-0.5"
        href={"/chatbot"}
      >
        <MobileMenuIcon variant="newChatbotChat" className="md:hidden" />
        <span className="text-sm text-black-01 md:text-xs md:font-medium">
          チャットボットと会話する
        </span>
      </Link>
    </div>
  );
};
