"use client";

import { FC, useState } from "react";
import { ChatMenuNewWindow } from "./chat-menu-new-window";
import { ModelWithParams } from "@/features/chat-view/chat-services/modelOrganizer";
import { MobileMenuIcon } from "@/ui/mobile-menu-icon";
import { ForDesktop, ForMobile } from "@/ui/responsive";

interface Props {
  models: Array<ModelWithParams>;
  onCloseMenu?: () => void;
}

export const ChatMenuNewButton: FC<Props> = ({ models, onCloseMenu }) => {
  // TODO: URL でモーダルルーティングしたい
  // ChatGPT の動作を参考にしたい
  // 参考?: https://dev.to/unorthodev/how-to-make-routable-modals-in-react-with-react-router-3hgp

  const [windowOpen, setWindowOpen] = useState(false);
  return (
    <div>
      <ForDesktop>
        <button
          className="flex items-center gap-0.5 rounded-lg border border-black-01 p-2.5 hover:bg-gray-hover"
          onClick={() => setWindowOpen(true)}
        >
          <span className="i-lucide-plus h-4 w-4" />
          <span className="text-xs font-medium text-black-01">
            モデルと会話する
          </span>
        </button>
      </ForDesktop>
      <ForMobile>
        <button
          className="flex w-full items-center gap-2 p-2.5"
          onClick={() => setWindowOpen(true)}
        >
          <MobileMenuIcon variant="newModelChat" />
          <span className="text-sm text-black-01">モデルと会話する</span>
        </button>
      </ForMobile>
      <ChatMenuNewWindow
        open={windowOpen}
        onOpenChange={setWindowOpen}
        models={models}
        onCloseMenu={onCloseMenu}
      />
    </div>
  );
};
