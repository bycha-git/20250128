import { FC } from "react";
import { ChatMenuChatbotButton } from "./chat-menu-chatbot-button";
import { ChatMenuNewButton } from "./chat-menu-new-button";
import { ChatMenuOptions } from "./chat-menu-options";
import { ModelWithParams } from "@/features/chat-view/chat-services/modelOrganizer";

interface ChatMenuHeaderProps {
  models: Array<ModelWithParams>;
  disabled: boolean;
  onCloseMenu?: () => void;
}

export const ChatMenuHeader: FC<ChatMenuHeaderProps> = ({
  models,
  disabled,
  onCloseMenu,
}) => (
  <div
    className={`flex flex-col md:flex-row md:items-center md:justify-end md:gap-2.5 md:border-b-0 md:px-3 md:pt-3`}
  >
    <ChatMenuNewButton models={models} onCloseMenu={onCloseMenu} />
    <ChatMenuChatbotButton />
    <ChatMenuOptions disabled={disabled} className="hidden md:block" />
  </div>
);
