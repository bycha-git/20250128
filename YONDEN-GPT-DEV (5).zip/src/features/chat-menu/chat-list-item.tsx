"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useState } from "react";
import { ThreadModel } from "../common/model/history/thread-model";
import { checkPathHrefMatch } from "../common/redirect-helpers";
import { showError } from "../globals/global-message-store";
import { useConfirm } from "../ui/confirm";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";
import { Input } from "../ui/input";
import { cn } from "../ui/lib";
import { useResponsive } from "../ui/responsive";
import {
  chatItemBookmarkIconVariants,
  ChatListItemOptions,
} from "./chat-list-item-options";
import {
  bookmarkThread,
  deleteChatThreadByID,
  updateChatThreadTitle,
} from "./chat-menu-services/chat-menu-service";
import { useErrorMessage } from "@/app/(authenticated)/errorMessageContext";
import { isRedirectError } from "@/features/common/util";

export interface ChatListItemProps {
  item: ThreadModel;
  href?: string;
  active?: boolean;
  handleBookmark?: () => void;
  onClickEditButton?: () => void;
  confirmDeleteThread?: () => void;
}

type Props = ChatListItemProps & {
  showItemOptions: boolean;
  onClick?: (
    item: ThreadModel,
    event: React.MouseEvent<HTMLElement, MouseEvent>,
  ) => void;
  onCloseMenu?: () => void;
};

export const ChatListItem = ({
  item,
  href,
  active: activeProp = false,
  showItemOptions,
  onClick,
  onCloseMenu,
}: Props) => {
  const { isDesktop, isMobile } = useResponsive();
  const path = usePathname() ?? "";
  const pathHrefMatch = href && checkPathHrefMatch(path, href);
  const active = !!(activeProp || pathHrefMatch);
  const bookmarked = item.bookmarked;
  const [editFlg, setEditFlg] = useState(false);
  const [editLoading, setEditLoading] = useState(false);
  const [newName, setNewName] = useState("");
  const inputRef = (element: HTMLInputElement | null) => {
    element?.focus();
  };
  const errMessage = useErrorMessage();
  const handleBookmark = useCallback(async () => {
    const threadId = item.id;
    const newBookmarked = !item.bookmarked;
    try {
      const response = await bookmarkThread({
        threadId,
        bookmarked: newBookmarked,
      });
      if (response.status !== "OK") {
        showError(errMessage["ECOMMON0001"]);
      }
    } catch (error) {
      showError(errMessage["ECOMMON0001"]);
    }

    return;
  }, [errMessage, item.bookmarked, item.id]);
  const handleChangeName = async (thread: ThreadModel, newName: string) => {
    if (newName && thread.name !== newName) {
      setEditLoading(true);
      try {
        const updateResponse = await updateChatThreadTitle({
          threadId: thread.id,
          name: newName,
        });
        if (updateResponse.status !== "OK") {
          showError(errMessage["ECOMMON0001"]);
        }
      } catch {
        showError(errMessage["ECOMMON0001"]);
      } finally {
        setEditLoading(false);
      }
    }
    setEditFlg(false);
  };
  const onClickEditButton = (name: string) => {
    setEditFlg(true);
    setNewName(name);
  };
  const { confirmWait } = useConfirm();
  // スレッド削除確認画面
  const handleDeleteThread = async () => {
    const threadId = item.id;
    const redirectTo = path.includes(threadId) ? "chat" : undefined;
    const response = await deleteChatThreadByID(threadId, redirectTo);
    if (response) showError(errMessage["ECOMMON0001"]);
  };
  const confirmDeleteThread = async () => {
    const confirmWindow = await confirmWait({
      text: (
        <>
          <strong>{item.name}</strong>を削除します
        </>
      ),
      title: "スレッドを削除しますか？",
      okButtonText: "削除する",
      cancelButtonText: "キャンセルする",
    });
    if (confirmWindow.ok) {
      try {
        await handleDeleteThread();
        // 現在表示中でないスレッドを削除した場合は何も起きない。正常
      } catch (e) {
        // NEXT_REDIRECT が throw された (ホームにリダイレクトされた)
        // →正常
        if (!isRedirectError(e)) {
          showError(errMessage["ECOMMON0001"]);
        }
      }
    }
    confirmWindow.close();
  };
  return (
    <div
      data-active={active}
      className={cn(
        "group flex select-none items-center rounded-md",
        // TODO: hover時とactive時で色が違うはず
        "hover:bg-gray-hover data-[active=true]:bg-gray-hover",
      )}
      onClick={(e) => onClick?.(item, e)}
    >
      {href === undefined && (
        <button
          type="button"
          title={item.name}
          className="flex-1 overflow-hidden text-ellipsis whitespace-nowrap p-3 text-left text-sm text-black-01"
        >
          {item.name}
        </button>
      )}
      {href !== undefined &&
        (editFlg ? (
          // TODO: editLoading 時の表示を分かりやすくする
          // ローディング表示 or 既に確定したのと同じ見た目 (Input でない) にする
          <form
            className="contents"
            onSubmit={(e) => {
              e.preventDefault();
              handleChangeName(item, newName);
            }}
          >
            <Input
              value={newName}
              onInputText={setNewName}
              onFocus={(e) => {
                e.target.setSelectionRange(0, -1);
              }}
              readOnly={editLoading}
              onBlur={() => handleChangeName(item, newName)}
              className="w-full"
              ref={inputRef}
              maxLength={50}
              enterKeyHint="done"
            />
          </form>
        ) : (
          <Link
            href={href || "#"}
            title={item.name}
            className="flex-1 overflow-hidden text-ellipsis whitespace-nowrap p-3 text-sm text-black-01"
            onClick={onCloseMenu}
          >
            {item.name && <span>{item.name}</span>}
            {!item.name && <span>&nbsp;</span>}
          </Link>
        ))}
      {showItemOptions && !editFlg && isDesktop && (
        <ChatListItemOptions
          item={item}
          href={href}
          active={active}
          handleBookmark={handleBookmark}
          onClickEditButton={() => onClickEditButton(item.name)}
          confirmDeleteThread={confirmDeleteThread}
        />
      )}
      {showItemOptions && !editFlg && isMobile && (
        <DropdownMenu>
          <DropdownMenuTrigger>
            <span className="justify-right i-mdi-dots-horizontal flex h-6 w-6 p-0 text-gray-500 hover:text-gray-700" />
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={handleBookmark}>
              <div className="flex gap-2">
                <div className="flex justify-center">
                  <span
                    className={cn(
                      chatItemBookmarkIconVariants({ bookmarked }),
                      "size-5",
                    )}
                  />
                </div>
                <div className="text-xs/5">
                  {bookmarked ? "ブックマークを解除" : "ブックマーク"}
                </div>
              </div>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="mx-0" />
            <DropdownMenuItem onClick={() => onClickEditButton(item.name)}>
              <div className="flex gap-2">
                <div className="flex justify-center">
                  <span className="i-tdesign-edit-2 size-5" />
                </div>
                <div className="text-xs/5">スレッド名を変更</div>
              </div>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="mx-0" />
            <DropdownMenuItem onClick={confirmDeleteThread}>
              <div className="flex gap-2">
                <div className="flex justify-center">
                  <span className="i-material-symbols-delete-outline-rounded size-5" />
                </div>
                <div className="text-xs/5">削除</div>
              </div>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      )}
    </div>
  );
};
