"use client";

import React, { forwardRef } from "react";
import { cn } from "@/ui/lib";

export const ChatMenuTray = forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => {
  return (
    <div
      ref={ref}
      className={cn(
        "flex w-[21.5rem] flex-col overflow-hidden border-r transition-all duration-700",
        className,
      )}
      {...props}
    >
      {props.children}
    </div>
  );
});
ChatMenuTray.displayName = "ChatMenuTray";
