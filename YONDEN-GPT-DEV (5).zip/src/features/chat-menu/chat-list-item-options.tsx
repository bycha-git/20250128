"use client";
import { cva } from "class-variance-authority";
import { cn } from "../ui/lib";
import { ChatListItemProps } from "./chat-list-item";

type Props = ChatListItemProps;

export const ChatListItemOptions = ({
  item,
  handleBookmark,
  onClickEditButton,
  confirmDeleteThread,
}: Props) => {
  const bookmarked = item.bookmarked;

  return (
    <div className="ml-auto hidden items-center gap-1.5 pe-3 ps-0 group-hover:flex">
      <button
        title={bookmarked ? "ブックマークを解除" : "ブックマーク"}
        onClick={handleBookmark}
        className="y-full"
      >
        <span className={cn(chatItemBookmarkIconVariants({ bookmarked }))} />
      </button>
      <button
        title={"スレッド名を編集"}
        onClick={onClickEditButton}
        className="y-full"
      >
        <span className="i-tdesign-edit-2 h-4 w-4 text-black-01" />
      </button>
      <button
        title={"削除する"}
        onClick={confirmDeleteThread}
        className="y-full"
      >
        <span className="i-material-symbols-delete-outline-rounded h-4 w-4 text-black-01" />
      </button>
    </div>
  );
};

export const chatItemBookmarkIconVariants = cva("h-4 w-4 text-black-01", {
  variants: {
    bookmarked: {
      true: "i-material-symbols-bookmark-outline-rounded",
      false: "i-material-symbols-bookmark-star-outline-rounded",
    },
  },
  defaultVariants: {
    bookmarked: false,
  },
});
