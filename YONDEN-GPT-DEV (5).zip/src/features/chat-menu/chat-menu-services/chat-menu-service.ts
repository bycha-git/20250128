"use server";

import {
  deleteAllThreadsForCurrentUser,
  deleteThreadForCurrentUser,
  findThreadForCurrentUser,
  updateThreadTitle,
  upsertThread,
} from "@/features/chat-view/chat-services/chat-thread-service";
import { revalidateCache } from "@/features/common/navigation-helpers";
import { redirectToPage } from "@/features/common/redirect-helpers";
import { ServerActionResponse } from "@/features/common/server-action-response";

// チャットメニューで使う機能を提供

export const deleteChatThreadByID = async (
  chatThreadID: string,
  redirectTo?: string,
) => {
  const response = await deleteThreadForCurrentUser(chatThreadID);
  if (response.status !== "OK") {
    return response;
  }
  revalidateCache({
    page: "chat",
    type: "layout",
  });
  if (redirectTo !== undefined) {
    redirectToPage(redirectTo);
  }
};

export const deleteAllThreads = async () => {
  const response = await deleteAllThreadsForCurrentUser();
  if (response.status !== "OK") {
    return response;
  }
  redirectToPage("chat");
};

export const updateChatThreadTitle = async (props: {
  threadId: string;
  name: string;
}): Promise<ServerActionResponse<boolean>> => {
  const updateResponse = await updateThreadTitle(props.threadId, props.name);
  if (updateResponse.status !== "OK") {
    return updateResponse;
  }

  revalidateCache({
    page: "chat",
    type: "layout",
  });
  return {
    status: "OK",
    response: true,
  };
};

export const bookmarkThread = async (props: {
  threadId: string;
  bookmarked: boolean;
}) => {
  const threadResponse = await findThreadForCurrentUser(props.threadId);
  if (threadResponse.status !== "OK") {
    return threadResponse;
  }
  const thread = threadResponse.response;

  await upsertThread(
    {
      ...thread,
      bookmarked: props.bookmarked,
    },
    false,
  );

  revalidateCache({
    page: "chat",
    type: "layout",
  });
  return {
    status: "OK",
    response: true,
  };
};
