import { ChatListItemProps } from "../chat-list-item";

export const CHAT_LIST_GROUP_BOOKMARKED = "ブックマーク";
export const CHAT_LIST_GROUP_RECENT = "1週間以内";
export const CHAT_LIST_GROUP_OTHER = "それ以前";

export const CHAT_LIST_GROUPS = [
  CHAT_LIST_GROUP_BOOKMARKED,
  CHAT_LIST_GROUP_RECENT,
  CHAT_LIST_GROUP_OTHER,
] as const;

export type ChatListItemsGroupName = (typeof CHAT_LIST_GROUPS)[number];

export type ChatListItemsGroup = {
  groupName: ChatListItemsGroupName;
} & ChatListItemProps;
