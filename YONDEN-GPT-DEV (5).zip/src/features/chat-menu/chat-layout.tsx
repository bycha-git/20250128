"use client";

import { VisuallyHidden } from "@radix-ui/react-visually-hidden";
import { PropsWithChildren, useState } from "react";
import { ModelWithParams } from "../chat-view/chat-services/modelOrganizer";
import { ChatViewContainer } from "../chat-view/chat-view-container";
import { ThreadModel } from "../common/model/history/thread-model";
import { Button } from "../ui/button";
import { cn } from "../ui/lib";
import { ForDesktop, ForMobile } from "../ui/responsive";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "../ui/sheet";
import { ChatMenu } from "./chat-menu";

interface Props extends PropsWithChildren {
  listItems?: Array<ThreadModel>;
  models?: Array<ModelWithParams>;
}

export const ChatLayout = ({ children, listItems, models }: Props) => {
  const [sheetOpen, setSheetOpen] = useState(false);
  const onCloseMenu = () => setSheetOpen(false);
  return (
    <Container>
      <ChatViewContainerMobile>
        <FragmentOrSheet sheetOpen={sheetOpen} setSheetOpen={setSheetOpen}>
          <SideMenuOrSheetContent>
            <ChatMenu
              listItems={listItems}
              models={models}
              onCloseMenu={onCloseMenu}
            />
          </SideMenuOrSheetContent>
          <NothingOrSheetTrigger />
        </FragmentOrSheet>
        <ChatViewContainerDesktop>{children}</ChatViewContainerDesktop>
      </ChatViewContainerMobile>
    </Container>
  );
};

/** コンテナーになる要素 */
const Container = ({ children }: PropsWithChildren) => {
  return (
    <div
      className={cn(
        "w-full md:grid md:grid-cols-[max-content_1fr] md:items-stretch",
      )}
    >
      {children}
    </div>
  );
};

/** モバイルの場合シートになる要素 */
const FragmentOrSheet = ({
  children,
  sheetOpen,
  setSheetOpen,
}: PropsWithChildren & {
  sheetOpen: boolean;
  setSheetOpen: (sheetOpen: boolean) => void;
}) => {
  return (
    <>
      <ForDesktop>{children}</ForDesktop>
      <ForMobile>
        <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
          {children}
        </Sheet>
      </ForMobile>
    </>
  );
};

/** デスクトップの場合サイドメニュー、モバイルの場合シート実体になる要素 */
const SideMenuOrSheetContent = ({ children }: PropsWithChildren) => {
  return (
    <>
      <ForDesktop>
        <div className="flex-0 flex w-96 max-w-[30vw] flex-col overflow-hidden border-r">
          {children}
        </div>
      </ForDesktop>
      <ForMobile>
        <SheetContent
          side="left"
          padding={false}
          showClose={false}
          className="flex w-96 max-w-[80vw] flex-col"
        >
          <VisuallyHidden>
            <SheetTitle>チャットメニュー</SheetTitle>
          </VisuallyHidden>
          {children}
        </SheetContent>
      </ForMobile>
    </>
  );
};

/** モバイルの場合メニューを開くボタン */
const NothingOrSheetTrigger = () => {
  return (
    <>
      <ForMobile>
        <SheetTrigger asChild>
          <Button
            variant="ghost"
            size="auto"
            aria-label="チャットメニューを開く"
            className="aspect-square h-full w-[3rem] rounded-none border-b border-gray-03 px-[.5rem]"
          >
            <span className="i-material-symbols-menu-rounded size-[2rem] bg-black-01" />
          </Button>
        </SheetTrigger>
      </ForMobile>
    </>
  );
};

const ChatViewContainerMobile = ({ children }: PropsWithChildren) => {
  return (
    <>
      <ForDesktop>{children}</ForDesktop>
      <ForMobile>
        <ChatViewContainer>{children}</ChatViewContainer>
      </ForMobile>
    </>
  );
};

const ChatViewContainerDesktop = ({ children }: PropsWithChildren) => {
  return (
    <>
      <ForDesktop>
        <ChatViewContainer>{children}</ChatViewContainer>
      </ForDesktop>
      <ForMobile>{children}</ForMobile>
    </>
  );
};
