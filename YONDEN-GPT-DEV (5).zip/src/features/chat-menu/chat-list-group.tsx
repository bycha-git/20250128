import { Separator } from "../ui/separator";

export const ChatListGroup = ({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) => (
  <section>
    <Separator className="mb-2 md:hidden" />
    <h3 className="mb-3 text-xs font-medium text-black-01">{title}</h3>
    <div className="mb-5 flex flex-col gap-3">{children}</div>
  </section>
);
