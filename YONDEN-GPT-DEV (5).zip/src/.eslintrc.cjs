module.exports = {
  extends: [
    "next/core-web-vitals",
    "next/typescript",
    "plugin:@typescript-eslint/recommended-type-checked",
    "plugin:import/recommended",
    "plugin:import/typescript",
    "prettier",
  ],
  rules: {
    // 自動修正されるようエディタ連携を設定しているため、エラーとして見せる必要がない
    "prefer-const": "warn",

    // 命名規則
    "@typescript-eslint/naming-convention": [
      "error",
      {
        selector: "default",
        format: ["camelCase", "PascalCase", "UPPER_CASE"],
        leadingUnderscore: "allow",
      },
      {
        selector: "property",
        format: null,
      },
      {
        selector: ["typeLike", "interface"],
        format: ["PascalCase"],
      },
    ],

    // @typescript-eslint/recommended-type-checked の緩和
    // servicesのエラー処理で使っているため
    "@typescript-eslint/restrict-template-expressions": "off",
    // 自動修正できず、手動修正には知識が必要なほか、影響がほぼ無いため
    "@typescript-eslint/no-floating-promises": "off",
    "@typescript-eslint/no-misused-promises": "off",
    // 意図している場合もあるため。また呼び出し側も修正が必要な場合があるため
    "@typescript-eslint/require-await": "off",
    // any をすぐに除去するのが難しいが、最終的には除去したいため
    "@typescript-eslint/no-unsafe-argument": "warn",
    "@typescript-eslint/no-unsafe-assignment": "warn",
    "@typescript-eslint/no-unsafe-call": "warn",
    "@typescript-eslint/no-unsafe-declaration-merging": "warn",
    "@typescript-eslint/no-unsafe-enum-comparison": "warn",
    "@typescript-eslint/no-unsafe-function-type": "warn",
    "@typescript-eslint/no-unsafe-member-access": "warn",
    "@typescript-eslint/no-unsafe-return": "warn",
    "@typescript-eslint/no-unsafe-unary-minus": "warn",

    // 未使用インポートの除去
    "unused-imports/no-unused-imports": "warn",
    "unused-imports/no-unused-vars": [
      "warn",
      {
        vars: "all",
        varsIgnorePattern: "^_",
        args: "after-used",
        argsIgnorePattern: "^_",
      },
    ],
    "@typescript-eslint/no-unused-vars": "off",

    // インポート順序の強制
    "import/order": [
      "warn",
      {
        "newlines-between": "never",
        named: true,
        alphabetize: {
          order: "asc",
          caseInsensitive: true,
        },
        distinctGroup: false,
      },
    ],
  },
  plugins: ["unused-imports"],
  settings: {
    "import/resolver": {
      typescript: true,
      node: true,
    },
  },
  ignorePatterns: ["**/figma/*"],
  reportUnusedDisableDirectives: true,
  parser: "@typescript-eslint/parser",
  parserOptions: {
    projectService: {
      allowDefaultProject: ["*.cjs", ".eslintrc.cjs"],
    },
    tsconfigRootDir: __dirname,
  },
};
