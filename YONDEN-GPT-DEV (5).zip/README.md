# YondenGPT-App

## ベースプログラム

<https://github.com/microsoft/azurechat>

## 必要な環境変数

Next.js アプリの動作に必要な環境変数は [src/.env.example](src/.env.example) に記載しています。

Azure App Service にデプロイする際、追加で以下の環境変数が必要な場合があります。 (デプロイ方法によります)

- `SCM_DO_BUILD_DURING_DEPLOYMENT` = `true`
- `CUSTOM_BUILD_COMMAND` = `bash build.sh`

## 開発

基本的に、 Azure Chat と同じように実行します。

### 開発モードで実行

- [src/.env.example](src/.env.example) ファイルを元に、 `src/.env.local` ファイルを作成
- src フォルダー上で `npm i` を実行
  - Dev Container (開発コンテナー) 内で作業している場合、どこでも `npm i` が実行できるようになっているはずです
- 以下のどちらかでサーバーを起動
  - VSCode の「実行とデバッグ」から、「Next.js: debug server-side」を実行
  - ターミナルで `npm run dev` を実行
- 以下のどちらかでアプリを開く
  - VSCode の「実行とデバッグ」から、「Next.js: debug client-side」を実行
  - ブラウザーで `http://localhost:3009` を開く

注意
- VSCode でブレークポイント等のデバッグ機能を利用したい場合、サーバーとクライアントのどちらも「実行とデバッグ」から起動する必要があります。

### ビルドして実行

- ポート番号が 3000 に固定される (?) ので、事前に `src/.env.local` 内の `NEXTAUTH_URL` を `http://localhost:3009` から `http://localhost:3000` に変更する必要があります

以下のコマンドを実行

```sh
npm run build
npm run start
```

## 使用技術

### 言語 / フレームワーク

- TypeScript
- Next.js (App Router)
  - フロント/サーバー共に JavaScript/TypeScript と React で実装するフレームワーク
- NextAuth.js (現 Auth.js)
  - Entra ID などの認証を組み込む
  - JWT で管理を行うため、セッション情報を管理するデータベースなどが不要
- Valtio
  - 状態管理 (主にチャット画面で使用)
  - ページ間で共通の値を定義できる
  - Proxy API により、プロパティに代入するだけで再レンダリングを適切に行う

### UI フレームワーク

- Tailwind CSS
  - 短いクラス名で CSS を表現できる
  - 公式の VSCode 拡張機能で、クラス名の入力支援を適用している (マウスオンで実際に適用される CSS を表示、 Ctrl+Space でクラス名の入力補完)
- @egoist/tailwindcss-icons
  - Iconify のアイコンを Tailwind CSS で使う
- Radix UI
  - UI ライブラリ
  - 主に shadcn/ui により生成された UI コンポーネントを通して使っている
- shadcn/ui
  - Radix UI などのライブラリを用いて作られた UI コンポーネント集
  - コマンドを使って features/ui フォルダーにコンポーネントファイルを追加した後、今回のアプリ用に書き換えて利用する

### その他ライブラリ

- axios
  - XMLHttpRequest のラッパー
  - 現状の Fetch API ではアップロードの進捗取得が不可能だが XMLHttpRequest では可能なため、アップロードの進捗が必要な場面で使用
- undici
  - Node.js 開発チーム公式の Fetch API 実装。
  - Node.js にバンドルされているが、以下の理由によりライブラリとして使用
    - Node.js のバージョンアップ等で挙動が変わってほしくない
    - 標準の fetch だと、 VSCode 上の fetch 関数の型が Web のものと混ざる

### 開発用ツール

- Dev Containers
  - 開発用のコンテナ環境を自動で整備して、その中で開発作業を行える
  - [.devcontainer/devcontainer.json](.devcontainer/devcontainer.json) にて、以下のような設定をしている
    - どの Node.js バージョンがインストールされたコンテナを使うか
    - どの拡張機能等を入れるか
  - 開発 PC には WSL, docker, VSCode が入っていればよい (インストールされている Node.js のバージョンを合わせたりする必要がない)
- ESLint
  - リンター
  - 一般的に推奨されるコーディングルールや独自で設定したルールに基づき、警告表示や自動修正を行う
  - ESLint のプラグインにより、不要なインポートの自動消去なども行っている
  - 公式の VSCode 拡張機能で、警告表示と保存時の自動修正を適用している
- Prettier
  - フォーマッター
  - 全員のコードが自動で同じようにフォーマットされ、人によるインデントなどの差を無くす
  - インデントなどを気にしなくて良いため、コーディング中に考えることを減らせる
  - 公式の VSCode 拡張機能で、保存時の自動でフォーマットを適用している
